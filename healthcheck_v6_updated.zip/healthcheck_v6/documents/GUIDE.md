# Health Check v6 — Complete Application Guide

**Version:** 6.0  
**Database:** hc_v6 (MySQL)  
**Framework:** Django 4.x + APScheduler  
**Stack:** Python · Django · MySQL · pymysql · APScheduler · Bootstrap 5

---

## Table of Contents

1. [What This Application Does](#1-what-this-application-does)
2. [Project Structure](#2-project-structure)
3. [Setup & Installation](#3-setup--installation)
4. [Database Setup](#4-database-setup)
5. [Configuration Reference](#5-configuration-reference)
6. [Core Concepts & Data Flow](#6-core-concepts--data-flow)
7. [Pages & Features](#7-pages--features)
8. [Scheduler — How It Works](#8-scheduler--how-it-works)
9. [Escalation System](#9-escalation-system)
10. [Rerun Queue](#10-rerun-queue)
11. [Reports & Logs](#11-reports--logs)
12. [Admin Panel](#12-admin-panel)
13. [Email Notifications](#13-email-notifications)
14. [Security & Roles](#14-security--roles)
15. [Troubleshooting](#15-troubleshooting)
16. [Database Table Reference](#16-database-table-reference)

---

## 1. What This Application Does

Health Check v6 is an automated server and Oracle database monitoring platform. It:

- **Runs scheduled health checks** against production, validation, and development environments on a configurable cron schedule.
- **Checks servers** (disk space, CPU, memory, connectivity) and **Oracle databases** (tablespace, sessions, archive logs, jobs, locks).
- **Tracks issues** — if a check fails repeatedly, it escalates and sends email alerts.
- **Auto-retries failed runs** via a rerun queue.
- **Generates Excel reports** for each completed run.
- Provides a **web dashboard** showing run status, issues, and scheduler state in real time.

---

## 2. Project Structure

```
healthcheck_v6/
├── django_hc/                  # Django project settings
│   ├── settings.py             # All configuration (reads from .env)
│   ├── urls.py                 # URL routing
│   ├── wsgi.py / asgi.py
│   └── __init__.py
├── healthcheck/                # Main application
│   ├── models.py               # Django ORM models (managed=False, raw MySQL)
│   ├── views.py                # All HTTP views — dashboard, reports, escalation, rerun
│   ├── admin.py                # Django admin customisations
│   ├── urls.py                 # App URL patterns
│   ├── scheduler_service.py    # APScheduler integration + run orchestration
│   ├── engine_bridge.py        # Bridge between Django and engine
│   ├── middleware.py           # DB health check middleware
│   ├── forms.py
│   ├── ist_utils.py            # IST timezone helpers
│   ├── db_router.py            # Routes ORM queries to healthcheck_db
│   ├── templatetags/
│   │   └── ist_filters.py      # Custom template filters (ist, get_item)
│   ├── management/commands/
│   │   └── encrypt_password.py # CLI tool to encrypt passwords
│   ├── engine/                 # Core check engine (no Django dependency)
│   │   ├── core/
│   │   │   ├── db_manager.py   # MySQL connection wrapper (pymysql)
│   │   │   ├── config.py       # DB_CONFIG dataclass
│   │   │   ├── executor.py     # Orchestrates a single run
│   │   │   ├── issue_tracker.py# Updates IssueTracker table
│   │   │   └── logger.py       # Per-run log writer
│   │   ├── checks/
│   │   │   ├── server_manager.py   # SSH server checks
│   │   │   └── oracle_manager.py   # JDBC Oracle checks
│   │   ├── notifications/
│   │   │   └── email_service.py    # SMTP email sender
│   │   ├── reports/
│   │   │   └── excel_generator.py  # Excel report builder
│   │   └── scheduling/
│   │       ├── scheduler.py        # APScheduler wrapper
│   │       └── run_launcher.py     # Rerun queue logic
│   └── templates/healthcheck/  # All HTML templates
├── documents/
│   ├── hc_v6_database.sql      # Full MySQL schema + seed data
│   └── GUIDE.md                # This file
├── manage.py
├── requirements.txt
└── .env.example                # Environment variable template
```

---

## 3. Setup & Installation

### Prerequisites

- Python 3.10+
- MySQL 8.0+ (or compatible MariaDB)
- pip

### Steps

```bash
# 1. Clone / extract the project
cd healthcheck_v6

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — fill in DB credentials, secret key, email settings

# 5. Set up the database (see Section 4)

# 6. Apply Django migrations (SQLite default DB only)
python manage.py migrate

# 7. Create a Django superuser
python manage.py createsuperuser

# 8. Run the development server
python manage.py runserver
```

Open http://127.0.0.1:8000/healthcheck/ in your browser.

---

## 4. Database Setup

The application uses **two databases**:

| Database | Engine | Purpose |
|---|---|---|
| `default` (SQLite) | django.db.backends.sqlite3 | Django auth, sessions, admin |
| `healthcheck_db` (MySQL) | django.db.backends.mysql | All health check data |

### Create the MySQL database

```bash
# Log into MySQL as root
mysql -u root -p

# Create database and user
CREATE DATABASE hc_v6 CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'hc_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON hc_v6.* TO 'hc_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import the full schema (tables + seed data)
mysql -u hc_user -p hc_v6 < documents/hc_v6_database.sql
```

### What the SQL file creates

- All 23+ tables with proper InnoDB FK constraints
- Default system_config values (rerun settings, email limits)
- Test catalog (36 standard health check tests)
- Oracle query definitions
- Email templates (HTML)
- A sample customer, escalation config, and schedule for testing

---

## 5. Configuration Reference

### .env variables

| Variable | Description | Default |
|---|---|---|
| `DJANGO_SECRET_KEY` | Django secret key — **must be changed in production** | — |
| `DJANGO_DEBUG` | Enable debug mode | `True` |
| `DJANGO_ALLOWED_HOSTS` | Comma-separated allowed hostnames | `127.0.0.1,localhost` |
| `HC_DB_NAME` | MySQL database name | `hc_v6` |
| `HC_DB_USER` | MySQL username | `hc_user` |
| `HC_DB_PASSWORD` | MySQL password | — |
| `HC_DB_HOST` | MySQL host | `localhost` |
| `HC_DB_PORT` | MySQL port | `3306` |
| `EMAIL_HOST` | SMTP server | `smtp.gmail.com` |
| `EMAIL_PORT` | SMTP port | `587` |
| `EMAIL_HOST_USER` | SMTP login email | — |
| `EMAIL_HOST_PASSWORD` | SMTP password / app password | — |

### system_config table (in MySQL)

These are edited via Django admin → System Config:

| config_key | Description | Default |
|---|---|---|
| `rerun_max_attempts` | Max automatic rerun retries per failed run | `3` |
| `rerun_interval_hours` | Hours between automatic rerun attempts | `2` |
| `escalation_threshold` | Consecutive failures before first escalation email | `3` |
| `escalation_interval_hours` | Min hours between repeat escalation emails | `4` |
| `max_emails_per_day` | Max escalation emails sent per day per customer/env | `5` |

---

## 6. Core Concepts & Data Flow

### Run Lifecycle

```
Trigger (scheduled / manual / rerun)
    │
    ▼
execution_runs row created (status=PENDING)
    │
    ▼
Engine executor runs all checks
  ├─ server checks (SSH)
  └─ Oracle checks (JDBC)
    │
    ▼
Results saved to run_results
    │
    ├─ Any failures? → issue_tracker updated (OPEN / ESCALATED)
    │                 → Escalation email sent if threshold reached
    │
    ├─ All pass?     → issue_tracker reset (consecutive_failures = 0)
    │
    ▼
execution_runs updated (status=COMPLETED / FAILED / PARTIAL)
    │
    ├─ COMPLETED → Excel report generated → run_reports saved
    │
    └─ FAILED / PARTIAL → rerun_queue entry created for auto-retry
```

### Two-database design

The Django ORM is used for **reading** via `db_router.py` (all model queries go to `healthcheck_db`). The engine uses **raw pymysql** (via `DBManager`) for all writes to guarantee short, explicit transactions and avoid Django's ORM transaction holding row locks.

---

## 7. Pages & Features

### Dashboard (`/healthcheck/`)

**What it shows:**
- Summary cards: Open Issues, Escalated, Pending Reruns, Scheduler ON/OFF
- Execution Runs table — filterable by Customer, Status, Environment, with pagination
- Open/Escalated Issues sidebar
- Upcoming Scheduler jobs
- Active runs banner (real-time, updates every 8 seconds via API)

**How to use:**
- Use the filter row above the runs table to narrow by customer, status, or environment
- Click **View** on any run to open its detailed report
- Auto-refreshes every 30 seconds

### Reports (`/healthcheck/reports/`)

**What it shows:**
- All completed/failed/partial execution runs in a sortable, filterable table
- Columns: #, Customer, Env, Type, Status (with icon badges), Started, Completed, Duration, Actions

**How to use:**
- Filter by Customer, Environment, Status
- **View** — opens the detailed run report (pass/fail per test)
- **Excel icon** — downloads the Excel report for that run
- **Log icon** — opens the raw engine log for that run

### Escalation (`/healthcheck/escalation/`)

**What it shows:**
- Escalation config cards (one per customer/env) — pause/resume controls
- Issues table: all OPEN, ESCALATED, and RESOLVED issues
- For each issue: consecutive failures, total failures, status badge, last error, email sent details
- **Report** column — links directly to the specific execution run that triggered this escalation

**How to use:**
- Click **Open/Escalated/Resolved** summary badges to quick-filter
- Use the Filter bar to narrow by Customer, Status, Environment
- **Pause** a customer/env to stop escalation emails (e.g. during maintenance)
- **Resume** to restart escalation emails
- Click the **Report #N** button to open the exact execution run that caused the issue

**Why the Report link matters:**
Each OPEN/ESCALATED row links to `last_failed_run_id` — the specific run where the failure happened. For RESOLVED rows, it shows the run where the check finally passed. This lets you see exactly what test failed and what the error was.

### Rerun Queue (`/healthcheck/rerun/`)

**What it shows:**
- **Pending & In-Progress** table — runs waiting to be retried
- **Rerun History** table — completed/exhausted/failed retry attempts, with filter and pagination

**Pending table:**
- Shows Queue ID, Customer, Env, Original Run #, Retry count, Status, timestamps, failure reason
- **Logs button is hidden** for pending/in-progress items — the run hasn't completed yet, so there are no meaningful logs
- Staff users see a **Play** button to trigger the retry immediately

**History table:**
- Filter by Customer and Status
- The **Logs** button links to the **rerun attempt's own execution_run logs**, not the original failed run
- For example: if Queue #5 is attempt 2/3, the Logs button shows the logs of the execution_run created for attempt 2 — so you can see exactly what happened in that retry
- If no rerun run is found (e.g. very old data), it falls back to original run logs

### Scheduler (`/healthcheck/scheduler/`)

Shows the APScheduler state: running jobs, next run times, active runs in progress. Admin can trigger a schedule to run immediately.

### Manual Run (`/healthcheck/manual/`)

Staff only. Select customer + environment and trigger an immediate health check run outside the normal schedule.

### Alert History (`/healthcheck/alert-history/`)

Full log of every escalation and resolved email sent, with to/cc recipients and send status.

---

## 8. Scheduler — How It Works

### Technology
Uses **APScheduler** with a chain-trigger pattern. Each run schedules the next one immediately after completing, preserving the exact minute offset from `start_at` forever (no clock drift).

### Chain pattern
```
start_at DateTrigger → _chain_run(1)
    → executes run
    → schedules DateTrigger(now + interval) → _chain_run(2)
    → executes run
    → schedules DateTrigger(now + interval) → _chain_run(3)
    → ...
```

### Why this design
Standard cron triggers (e.g. `*/10 * * * *`) fire at wall-clock boundaries (:00, :10, :20). If start_at is 4:08, a cron trigger would fire at 4:10, losing the exact offset. The chain trigger fires at 4:08, 4:18, 4:28, always preserving the customer's preferred time.

### Changing a schedule
When you edit `start_at` or `cron_expression` in Django Admin:
1. `save_model` detects the change
2. It defers the reschedule using `transaction.on_commit()` — this runs **after** Django's transaction commits and releases its row lock on `schedules`
3. `reschedule_after_start_at_update()` fires, resets `last_run_at`/`next_run_at`, and re-registers the APScheduler trigger

This design prevents MySQL error 1205 (Lock wait timeout).

### All times
All stored times are **UTC**. All displayed times are **IST (Asia/Kolkata, UTC+5:30)**. Cron expressions are entered in IST.

---

## 9. Escalation System

### How it works
1. A run completes. For each check that **failed**, `issue_tracker` is updated: `consecutive_failures` incremented.
2. If `consecutive_failures >= threshold` (from `escalation_config.threshold`), an escalation email is sent to configured recipients.
3. Emails are rate-limited by `interval_hours` — no repeat within N hours.
4. If a subsequent run has a **pass** for that check, `consecutive_failures` resets to 0 and the issue status becomes RESOLVED. If `send_resolved_mail = True`, a resolved email is sent.

### Pausing
An escalation config can be paused for N hours. No emails are sent while paused. Use this during planned maintenance.

### Issue statuses
- **OPEN** — threshold reached, emails sent, still failing
- **ESCALATED** — same as OPEN (distinction kept for display)
- **RESOLVED** — most recent check passed, consecutive_failures = 0

---

## 10. Rerun Queue

### Automatic reruns
When a run completes with status FAILED or PARTIAL, `run_launcher._queue_rerun()` creates a `rerun_queue` entry.

The background scheduler picks this up and fires a new RERUN-type `execution_run` after `rerun_interval_hours`.

This repeats up to `rerun_max_attempts` times. After all attempts:
- If any attempt COMPLETED → queue entry status = COMPLETED
- If all fail → queue entry status = EXHAUSTED

### Manual reruns (staff only)
On the Rerun page, staff can click the **Play** button next to a pending item to trigger it immediately, skipping the interval wait.

### Log navigation
Each retry creates its own `execution_run` row (with `run_type=RERUN` and `rerun_of_run_id` pointing to the original). The **Logs** button in the history table links to that specific rerun's logs — not the original. This makes it easy to diagnose why attempt 2 failed differently from attempt 1.

---

## 11. Reports & Logs

### Report detail
Each execution run has a detail page showing:
- Summary (customer, env, run type, status, timing)
- Per-test results in a table: test name, category, server role, result (PASS/FAIL/ERROR), actual value, expected value, notes

### Excel download
Generates an Excel file with the same per-test data, formatted with colour coding. Available from the Reports list or Report detail page.

### Logs
Raw engine logs for each run. Stored in `run_logs` table. Visible on the Logs page. Colour-highlighted: WARNING (yellow), ERROR/CRITICAL (red).

---

## 12. Admin Panel

Access via `/admin/` with a superuser account.

### Key admin models

| Model | Path | Purpose |
|---|---|---|
| Customers | Admin → Customers | Add/edit customers |
| Environments | Admin → Environments | Server credentials per customer/env |
| Schedules | Admin → Schedules | Configure cron schedules |
| Escalation Configs | Admin → Escalation Configs | Set thresholds and intervals |
| Mail Configs | Admin → Mail Configs | SMTP settings per customer/env |
| Mail Recipients | Admin → Mail Recipients | Who receives escalation emails |
| System Config | Admin → System Configs | Global settings (rerun attempts, intervals) |
| Test Catalog | Admin → Test Catalogs | Enable/disable tests globally |
| Test Overrides | Admin → Test Overrides | Disable specific tests for specific customers |

### Encrypting passwords
Server and Oracle database passwords are AES-encrypted at rest. To encrypt a password for entry:

```bash
python manage.py encrypt_password "your_plain_password"
# Copy the output and paste into the password field in admin
```

Or simply type the plain password into the admin form — it will be encrypted on save.

---

## 13. Email Notifications

### Types of emails
- **Escalation** — sent when consecutive failures reach threshold
- **Resolved** — sent when a previously escalated check passes (if enabled)

### Configuration
1. Add a **Mail Config** for the customer/env (SMTP host, port, credentials)
2. Add **Mail Recipients** (To and CC addresses)
3. Set **Escalation Config** threshold and interval_hours
4. Optionally enable `send_resolved_mail`

### Email rate limiting
`max_emails_per_day` (system_config) prevents email floods. Escalation emails are also rate-limited by `interval_hours` per customer/env pair.

### Templates
Email body uses HTML templates stored in the `mail_templates` table. Edit via Django admin → Mail Templates.

---

## 14. Security & Roles

### Authentication
All pages require login (`@login_required`). Use `/healthcheck/login/` or Django admin.

### Roles
- **Regular user** — can view dashboard, reports, escalations, rerun history. Cannot trigger runs, pause escalations, or access admin.
- **Staff user** (`is_staff=True`) — can trigger manual runs, trigger reruns immediately, pause/resume escalations, access all pages.
- **Superuser** — full admin access.

### Password storage
Server passwords and Oracle DB passwords are AES-encrypted in the database. The encryption key is derived from `DJANGO_SECRET_KEY`.

---

## 15. Troubleshooting

### MySQL Error 1205 — Lock wait timeout
**Cause:** Two connections tried to UPDATE the same `schedules` row simultaneously — one from Django admin saving a schedule change, and one from the scheduler updating `last_run_at`.

**Fix applied in v6:** 
- `save_model` defers the reschedule using `transaction.on_commit()` so it runs after Django releases its row lock.
- `run_now_sync` splits READ/INSERT/UPDATE into separate short connections.
- `settings.py` sets `innodb_lock_wait_timeout=15` and `CONN_MAX_AGE=0` on the MySQL connection.

### Scheduler not starting
Check the Django startup logs. The scheduler starts via `apps.py` `ready()` hook. Common causes:
- `.env` missing or `HC_DB_*` variables incorrect
- MySQL not running or hc_v6 database not created

### Runs stuck in PENDING
The scheduler may not be running. Check `/healthcheck/scheduler/` to see if it shows ON.

### Emails not sending
- Check `mail_configs` table has correct SMTP settings for the customer/env
- Check `alert_history` table to see if send_status is FAILED and what the error is
- For Gmail, use an App Password, not your account password

### "Expected a number but got None" pagination error
This is the pagination bug that was fixed in v6. It happened when filter parameters were not preserved in pagination links, causing `page=None` to be passed to Django's Paginator. The fix: all pagination links now include all active filter parameters as query string values with `|default:''`.

---

## 16. Database Table Reference

| Table | Purpose |
|---|---|
| `customers` | Customer master — name, contact |
| `environments` | SSH server credentials per customer/env |
| `servers` | Oracle server connection details |
| `oracle_databases` | Oracle DB credentials |
| `test_catalog` | Master list of all health check tests |
| `test_overrides` | Disable specific tests per customer |
| `mail_configs` | SMTP settings per customer/env |
| `mail_recipients` | Email To/CC lists per customer/env |
| `mail_templates` | HTML email body templates |
| `system_config` | Global app settings (key/value) |
| `escalation_config` | Threshold, interval, pause settings per customer/env |
| `schedules` | Cron schedules: when to run, for whom |
| `scheduler_tracker` | One row per scheduled fire — tracks timing |
| `execution_runs` | One row per run (scheduled, manual, rerun) |
| `run_results` | One row per test per run — pass/fail/value |
| `run_logs` | Raw engine log lines per run |
| `issue_tracker` | Current issue state per customer/env/test |
| `alert_history` | Log of every email sent (to, cc, status) |
| `rerun_queue` | Auto-retry queue for failed/partial runs |
| `oracle_queries` | JDBC SQL queries used in Oracle checks |
| `run_step_log` | Timing breakdown of each run phase |

---

*Health Check v6 — Internal Monitoring Platform*  
*All times are stored in UTC and displayed in IST (Asia/Kolkata)*
