"""
email_manager.py

Sends SUCCESS / FAILURE automation emails at the end of master_main.py.

Behaviour (per follow up prompt Phase 1 / Phase 9):
    - Email settings come from the email_config DB table
      (config_name = config.DEFAULT_EMAIL_CONFIG_NAME), NOT hardcoded here.
    - If DB is disabled/unreachable, falls back to config.py
      FALLBACK_EMAIL_CONFIG (optional) so the project still works without
      MySQL.
    - Every send attempt (success or failure) is recorded in email_status
      via db_helpers.insert_email_status().
    - Never raises into master_main.py - a failed email must not fail the
      automation run.
"""

import os
import smtplib
import traceback
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

import config
import db_helpers
from logger import get_logger

logger = get_logger(__name__)


def _split_emails(value) -> list:
    if not value:
        return []
    if isinstance(value, (list, tuple)):
        return [str(item).strip() for item in value if str(item).strip()]
    return [item.strip() for item in str(value).split(",") if item.strip()]


def _resolve_email_config():
    """
    Returns a dict with smtp_host, smtp_port, smtp_username, smtp_password,
    from_email, to_emails, cc_emails, bcc_emails, use_ssl, use_tls,
    email_config_id (None if not from DB).

    Priority:
        1. email_config table row (config_name = DEFAULT_EMAIL_CONFIG_NAME)
        2. config.FALLBACK_EMAIL_CONFIG dict, if defined in config.py
        3. None -> caller should skip sending
    """

    config_name = getattr(config, "DEFAULT_EMAIL_CONFIG_NAME", "DEFAULT_SMTP")

    db_row = db_helpers.get_active_email_config(config_name)

    if db_row:
        db_row["email_config_id"] = db_row.get("email_config_id")
        return db_row

    fallback = getattr(config, "FALLBACK_EMAIL_CONFIG", None)

    if fallback:
        fallback = dict(fallback)
        fallback["email_config_id"] = None
        return fallback

    return None


def _build_message(email_cfg, subject, body_text, attachment_paths):

    message = MIMEMultipart()
    message["Subject"] = subject
    message["From"] = email_cfg.get("from_email", "")
    message["To"] = ", ".join(_split_emails(email_cfg.get("to_emails")))

    cc_list = _split_emails(email_cfg.get("cc_emails"))
    if cc_list:
        message["Cc"] = ", ".join(cc_list)

    message.attach(MIMEText(body_text, "plain"))

    attached = []
    missing_reason = ""

    for path in attachment_paths or []:
        try:
            if path and os.path.exists(path):
                with open(path, "rb") as file_handle:
                    part = MIMEApplication(file_handle.read(), Name=os.path.basename(path))
                part["Content-Disposition"] = f'attachment; filename="{os.path.basename(path)}"'
                message.attach(part)
                attached.append(path)
            elif path:
                missing_reason += f"File not found: {path}. "
        except Exception as error:
            missing_reason += f"Could not attach {path}: {error}. "

    return message, attached, missing_reason


def _send_smtp(email_cfg, message, to_list, cc_list, bcc_list):

    host = email_cfg.get("smtp_host")
    port = int(email_cfg.get("smtp_port", 587))
    username = email_cfg.get("smtp_username")
    password = email_cfg.get("smtp_password")
    use_ssl = bool(email_cfg.get("use_ssl"))
    use_tls = bool(email_cfg.get("use_tls", True))

    all_recipients = to_list + cc_list + bcc_list

    if use_ssl:
        server = smtplib.SMTP_SSL(host, port, timeout=30)
    else:
        server = smtplib.SMTP(host, port, timeout=30)

    try:
        if use_tls and not use_ssl:
            server.starttls()

        if username:
            server.login(username, password or "")

        server.sendmail(email_cfg.get("from_email", ""), all_recipients, message.as_string())

    finally:
        try:
            server.quit()
        except Exception:
            pass


def send_automation_email(mail_type, subject, body_text, attachment_paths=None):
    """
    mail_type: "SUCCESS_EMAIL" or "FAILURE_EMAIL"
    Returns True if sent, False otherwise. Never raises.
    """

    if not getattr(config, "ENABLE_EMAIL_NOTIFICATION", False):
        logger.info("Email notification disabled via config.ENABLE_EMAIL_NOTIFICATION")
        return False

    if mail_type == "SUCCESS_EMAIL" and not getattr(config, "EMAIL_SEND_SUCCESS", True):
        logger.info("SUCCESS email skipped via config.EMAIL_SEND_SUCCESS=False")
        return False

    if mail_type == "FAILURE_EMAIL" and not getattr(config, "EMAIL_SEND_FAILURE", True):
        logger.info("FAILURE email skipped via config.EMAIL_SEND_FAILURE=False")
        return False

    email_cfg = _resolve_email_config()

    if not email_cfg:
        logger.warning("No active email configuration found (DB or fallback). Email not sent.")
        db_helpers.insert_email_status(
            email_config_id=None,
            mail_type=mail_type,
            mail_subject=subject,
            from_email="",
            to_emails="",
            cc_emails="",
            bcc_emails="",
            attachment_included=False,
            attachment_paths="",
            attachment_missing_reason="No active email_config found",
            send_status="FAILED",
            error_message="No active email_config found",
        )
        return False

    attach_output = getattr(config, "EMAIL_ATTACH_OUTPUT_REPORTS", True)

    paths_to_attach = attachment_paths if attach_output else []

    try:
        message, attached, missing_reason = _build_message(
            email_cfg, subject, body_text, paths_to_attach
        )

        to_list = _split_emails(email_cfg.get("to_emails"))
        cc_list = _split_emails(email_cfg.get("cc_emails"))
        bcc_list = _split_emails(email_cfg.get("bcc_emails"))

        _send_smtp(email_cfg, message, to_list, cc_list, bcc_list)

        logger.info("Automation email sent | type=%s | to=%s", mail_type, to_list)

        db_helpers.insert_email_status(
            email_config_id=email_cfg.get("email_config_id"),
            mail_type=mail_type,
            mail_subject=subject,
            from_email=email_cfg.get("from_email", ""),
            to_emails=", ".join(to_list),
            cc_emails=", ".join(cc_list),
            bcc_emails=", ".join(bcc_list),
            attachment_included=bool(attached),
            attachment_paths=", ".join(attached),
            attachment_missing_reason=missing_reason,
            send_status="SUCCESS",
        )

        return True

    except Exception as error:
        logger.error("Failed to send automation email: %s", error)
        logger.debug(traceback.format_exc())

        db_helpers.insert_email_status(
            email_config_id=email_cfg.get("email_config_id"),
            mail_type=mail_type,
            mail_subject=subject,
            from_email=email_cfg.get("from_email", ""),
            to_emails=email_cfg.get("to_emails", ""),
            cc_emails=email_cfg.get("cc_emails", ""),
            bcc_emails=email_cfg.get("bcc_emails", ""),
            attachment_included=False,
            attachment_paths="",
            attachment_missing_reason="Send failed before/while attaching",
            send_status="FAILED",
            error_message=str(error),
            error_trace=traceback.format_exc(),
        )

        return False
