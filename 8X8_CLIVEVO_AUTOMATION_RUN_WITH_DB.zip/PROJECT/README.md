# MASTER Single Execution: 8x8 + CLINEVO

## Final folder structure

Put all existing process files in this same folder:

```text
master_single_execution_project/
├── master_main.py
├── config.py
├── intilial_process_1.py
├── excel_extration_callids.py
├── call_info_ui.py
├── validation_report.py
├── intilial_process_2.py
├── extract_clinivo_excel_check.py
├── requirements.txt
└── README.md
```

## Run everything in one shot

```bash
python master_main.py
```

## Execution order

```text
1. 8x8 flow
   1.1 Download 8x8 Analytics Excel
   1.2 Extract Call IDs
   1.3 Capture UI audio size/duration
   1.4 Generate Recording_Validation_Report.xlsx

2. CLINEVO flow
   2.1 Download CLINEVO Advagen/Validus Excel
   2.2 Generate Clinevo_Case_File_Check_Report.xlsx
```

## Output folders

```text
data/
├── 8x8/
│   ├── excel/
│   ├── json/
│   ├── reports/
│   └── screenshots/
│
└── clinevo/
    ├── excel/
    ├── reports/
    └── screenshots/

logs/
└── master_single_execution.log
```

## Reports generated

```text
data/8x8/reports/Recording_Validation_Report.xlsx

data/clinevo/reports/Clinevo_Case_Check_Report/Clinevo_Case_File_Check_Report.xlsx
```

## Configuration

Edit only `config.py` for:

- 8x8 username/password
- CLINEVO username/password
- 8x8 date range/timezone
- CLINEVO report from/to dates
- Excel folders
- JSON folders
- report folders
- local recording/document folders

## Clear old files behavior

By default, `master_main.py` clears old Excel files and old JSON files before running:

```python
CLEAR_OLD_EXCEL_BEFORE_RUN = True
CLEAR_OLD_JSON_BEFORE_RUN = True
```

This avoids old downloads mixing with fresh downloads.

## Run only one flow if needed

In `config.py`:

```python
RUN_8X8 = True
RUN_CLINEVO = False
```

or:

```python
RUN_8X8 = False
RUN_CLINEVO = True
```

---

# MySQL Database + Email Notification Integration (NEW)

This project now optionally stores all automation results in a MySQL
database (`caller_automation`) and sends SUCCESS/FAILURE emails at the
end of every run. **All automation/UI/Excel logic is 100% unchanged.**
The database layer is purely additive: if MySQL is unreachable or
`ENABLE_DB_LOGGING = False`, the automation runs exactly like it did
before this change, using JSON files (`call_ids.json`, `ui_capture.json`)
as the only data source.

## New files added

```text
master_single_execution_project/
├── schema.sql              <- run this once in MySQL to create all 16 tables
├── database_manager.py     <- pymysql connection manager (DictCursor, retry, context manager)
├── db_helpers.py           <- one safe function per table, used by every process file
├── runtime_context.py      <- shares execution_id across all modules for one run
├── email_manager.py        <- sends SUCCESS/FAILURE emails, config from DB
├── logger.py                <- shared logger used by the new modules
└── requirements.txt         <- now also includes pymysql
```

## What changed in each existing file (additive only)

| File | What was added |
|---|---|
| `config.py` | `DB_CONFIG`, `ENABLE_DB_LOGGING`, email settings, `OUTPUT_ZIP_DIR` |
| `master_main.py` | Creates one `automation_process_status` row per run, tracks step-by-step status, builds an output ZIP, sends SUCCESS/FAILURE email |
| `excel_extration_callids.py` | Every extracted 8x8 Excel row is stored in `audit_by_call_id`; the filtered list needing UI lookup is stored in `ui_needed_call_items` |
| `call_info_ui.py` | Reads Call IDs to search from `ui_needed_call_items` (falls back to `call_ids.json`); stores every UI lookup result in `ui_capture_record` + `screenshot_log` |
| `validation_report.py` | Reads UI results from `ui_capture_record` (falls back to `ui_capture.json`); stores every report row in `recording_validation_result`; adds a new **"Missing Call ID s Audio Info"** sheet with embedded screenshots (existing sheets are untouched) |
| `intilial_process_1.py` | Stores every 8x8 Excel download attempt in `eightxeight_downloaded_excel_status` |
| `intilial_process_2.py` | Stores every CLINEVO Excel download attempt in `clinevo_downloaded_excel_status`; stores every SQL date-range edit in `sql_update_audit` |
| `extract_clinivo_excel_check.py` | Stores every extracted CLINEVO case in `clinevo_case_record`; stores every audio-vs-case-id check result in `clinevo_case_audio_result` |

Every single DB call above is wrapped in `try/except` inside `db_helpers.py`.
**If MySQL is down, the automation logs a warning and keeps running exactly
as it did before this integration.**

## Setup steps (do these in order)

### 1. Install the new Python dependency

```bash
pip install -r requirements.txt
```

(This adds `pymysql` on top of your existing packages.)

### 2. Create the MySQL database and tables

```bash
mysql -u root -p < schema.sql
```

This creates the `caller_automation` database and all 16 tables:
`app_config`, `automation_process_status`, `execution_step_log`,
`eightxeight_downloaded_excel_status`, `clinevo_downloaded_excel_status`,
`audit_by_call_id`, `ui_needed_call_items`, `ui_capture_record`,
`recording_validation_result`, `clinevo_case_record`,
`clinevo_case_audio_result`, `screenshot_log`, `error_log`,
`sql_update_audit`, `email_config`, `email_status`.

### 3. Point `config.py` at your MySQL server

Edit these values in `config.py`:

```python
ENABLE_DB_LOGGING = True   # set False to disable DB entirely

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "your_mysql_password",
    "database": "caller_automation",
}
```

### 4. Add an email configuration row (for SUCCESS/FAILURE emails)

Run this in MySQL (edit the values first):

```sql
INSERT INTO email_config (
    config_name, smtp_host, smtp_port, smtp_username, smtp_password,
    from_email, to_emails, cc_emails, bcc_emails,
    use_ssl, use_tls, is_active, remarks
)
VALUES (
    'DEFAULT_SMTP', 'smtp.office365.com', 587,
    'your_email@company.com', 'your_password_or_app_password',
    'your_email@company.com', 'person1@company.com,person2@company.com',
    '', '', FALSE, TRUE, TRUE, 'Default automation email'
);
```

`config.DEFAULT_EMAIL_CONFIG_NAME` (default `"DEFAULT_SMTP"`) must match
`config_name` above. If you don't want emails at all, set
`ENABLE_EMAIL_NOTIFICATION = False` in `config.py`.

### 5. Run the automation exactly as before

```bash
python master_main.py
```

Nothing about how you run it has changed. On completion you will find:

- The same reports as before at `config.FINAL_REPORT_FILE` and
  `config.CLINEVO_REPORT_FILE` (unchanged paths/layout).
- A new ZIP at `data/automation_output_zips/Automation_Output_RUN_<id>_<from>_<to>.zip`
  containing source Excel files, per-run named report copies, and
  screenshots.
- A SUCCESS or FAILURE email (if enabled).
- Every step recorded in MySQL under `execution_id` for that run
  (visible in `automation_process_status`, `execution_step_log`,
  `error_log`, etc.).

### 6. Verify

```sql
USE caller_automation;
SELECT * FROM automation_process_status ORDER BY execution_id DESC LIMIT 1;
SELECT * FROM execution_step_log WHERE execution_id = <id>;
SELECT * FROM error_log WHERE execution_id = <id>;
```

## Rollback / disable DB at any time

Set in `config.py`:

```python
ENABLE_DB_LOGGING = False
ENABLE_EMAIL_NOTIFICATION = False
```

The automation immediately goes back to using only
`call_ids.json` / `ui_capture.json` and the original static report
paths, with zero MySQL dependency - no code changes required.

