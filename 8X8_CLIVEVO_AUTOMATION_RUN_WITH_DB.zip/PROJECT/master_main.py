"""
MASTER single execution for both:
1. 8x8 automation and recording validation report
2. CLINEVO automation and case file check report

Run:
    python master_main.py

Keep all existing process files in this same folder:
    intilial_process_1.py
    excel_extration_callids.py
    call_info_ui.py
    validation_report.py
    intilial_process_2.py
    extract_clinivo_excel_check.py
"""

import asyncio
import importlib
import logging
import shutil
import sys
import traceback
import zipfile
from datetime import datetime
from pathlib import Path

import config

# --------------------------------------------------------------------
# NEW: MySQL backend integration (additive only).
# If any of these imports fail (e.g. pymysql not installed) the master
# execution still runs exactly like before - db_helpers functions are all
# individually guarded and simply return None/False when unavailable.
# --------------------------------------------------------------------
try:
    import runtime_context
    import db_helpers
    import email_manager
except Exception as _import_error:  # pragma: no cover
    runtime_context = None
    db_helpers = None
    email_manager = None
    print(
        "[master_main.py] WARNING: DB/email modules not available, "
        f"continuing without DB logging: {_import_error}"
    )

class _NoOpModule:
    """Used only if db_helpers/runtime_context/email_manager failed to import."""

    def __getattr__(self, name):
        def _noop(*args, **kwargs):
            return None
        return _noop


if db_helpers is None:
    db_helpers = _NoOpModule()

if runtime_context is None:
    runtime_context = _NoOpModule()

if email_manager is None:
    email_manager = _NoOpModule()

LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"


def setup_logging() -> None:

    config.create_required_folders()

    logging.basicConfig(
        level=logging.INFO,
        format=LOG_FORMAT,
        handlers=[
            logging.FileHandler(
                config.MASTER_LOG_FILE,
                encoding="utf-8"
            ),
            logging.StreamHandler(
                sys.stdout
            ),
        ],
        force=True,
    )


def as_str(path_value):

    return str(
        path_value
    )


def import_first_available(module_names):

    last_error = None

    for module_name in module_names:

        try:

            return importlib.import_module(
                module_name
            )

        except ModuleNotFoundError as error:

            last_error = error

    raise ModuleNotFoundError(
        "None of these modules were found: " + ", ".join(module_names)
    ) from last_error


def clear_folder_files(logger, folder, extensions):

    folder = Path(
        folder
    )

    folder.mkdir(
        parents=True,
        exist_ok=True
    )

    for file_path in folder.glob("*"):

        if file_path.is_file() and file_path.suffix.lower() in extensions:

            try:

                file_path.unlink()

                logger.info(
                    "Deleted old file: %s",
                    file_path
                )

            except Exception as error:

                logger.warning(
                    "Failed to delete old file %s: %s",
                    file_path,
                    error
                )


def clear_old_inputs(logger):

    if config.CLEAR_OLD_EXCEL_BEFORE_RUN:

        excel_folders = [
            config.ADVAGEN_EXCEL_FOLDER,
            config.VALIDUS_EXCEL_FOLDER,
            config.ADVAGEN_CLINEVO_EXCEL_FOLDER,
            config.VALIDUS_CLINEVO_EXCEL_FOLDER,
        ]

        for folder in excel_folders:

            clear_folder_files(
                logger,
                folder,
                {
                    ".xlsx",
                    ".xls",
                }
            )

    if config.CLEAR_OLD_JSON_BEFORE_RUN:

        for json_file in [
            config.CALL_IDS_JSON,
            config.UI_CAPTURE_JSON,
        ]:

            try:

                if Path(
                    json_file
                ).exists():

                    Path(
                        json_file
                    ).unlink()

                    logger.info(
                        "Deleted old JSON file: %s",
                        json_file
                    )

            except Exception as error:

                logger.warning(
                    "Failed to delete old JSON file %s: %s",
                    json_file,
                    error
                )


def patch_8x8_module_config(module):

    values = {
        "USERNAME": config.USERNAME,
        "PASSWORD": config.PASSWORD,

        "DATE_RANGE": config.DATE_RANGE,
        "INPUT_FROM_DATERANGE": config.INPUT_FROM_DATERANGE,
        "INPUT_TO_DATERANGE": config.INPUT_TO_DATERANGE,

        "TIME_ZONE": config.TIME_ZONE,
        "SITE_FILTER_1": config.SITE_FILTER_1,
        "SITE_FILTER_2": config.SITE_FILTER_2,

        "SITE_FILTER_1_DOWNLOAD_FOLDER": as_str(
            config.ADVAGEN_EXCEL_FOLDER
        ),
        "SITE_FILTER_2_DOWNLOAD_FOLDER": as_str(
            config.VALIDUS_EXCEL_FOLDER
        ),

        "ADVAGEN_EXCEL_FOLDER": as_str(
            config.ADVAGEN_EXCEL_FOLDER
        ),
        "VALIDUS_EXCEL_FOLDER": as_str(
            config.VALIDUS_EXCEL_FOLDER
        ),

        "ANALYTICS_URL": config.ANALYTICS_URL,
        "APP_URL": config.APP_URL,
        "RECORDINGS_URL": config.RECORDINGS_URL,

        "CHROME_DEBUG_URL": config.CHROME_DEBUG_URL,
        "CHROME_EXE_PATH": config.CHROME_EXE_PATH,
        "CHROME_USER_DATA_DIR": config.CHROME_USER_DATA_DIR,

        "CALL_IDS_JSON": as_str(
            config.CALL_IDS_JSON
        ),
        "UI_CAPTURE_JSON": as_str(
            config.UI_CAPTURE_JSON
        ),

        "SCREENSHOT_FOLDER": as_str(
            config.PROCESS2_SCREENSHOT_FOLDER
        ),
        "REPORT_FOLDER": as_str(
            config.EIGHTX8_REPORT_DIR
        ),
        "REPORT_FILE": as_str(
            config.FINAL_REPORT_FILE
        ),

        "ADVAGEN_RECORDING_PATH": as_str(
            config.ADVAGEN_RECORDING_PATH
        ),
        "VALIDUS_RECORDING_PATH": as_str(
            config.VALIDUS_RECORDING_PATH
        ),

        "SITE_PATHS": {
            key: as_str(value)
            for key, value in config.SITE_PATHS.items()
        },

        "SITE_ORDER": config.SITE_ORDER,
        "AUDIO_EXTENSIONS": config.AUDIO_EXTENSIONS,
        "SIZE_TOLERANCE": config.SIZE_TOLERANCE,
    }

    for key, value in values.items():

        setattr(
            module,
            key,
            value
        )

    return module


def patch_clinevo_module_config(module):

    values = {
        "LOGIN_URL": config.LOGIN_URL,

        "CLINEVO_USERNAME": config.CLINEVO_USERNAME,
        "CLINEVO_PASSWORD": config.CLINEVO_PASSWORD,

        "CLINEVO_ENTERPRISE_1": config.CLINEVO_ENTERPRISE_1,
        "CLINEVO_ENTERPRISE_2": config.CLINEVO_ENTERPRISE_2,

        "REPORT_FROM_DATE": config.REPORT_FROM_DATE,
        "REPORT_TO_DATE": config.REPORT_TO_DATE,

        "CHROME_DEBUG_URL": config.CHROME_DEBUG_URL,

        "SCREENSHOT_FOLDER": as_str(
            config.CLINEVO_SCREENSHOT_DIR
        ),

        "CLINEVO_ENTERPRISE_1_EXCEL": as_str(
            config.ADVAGEN_CLINEVO_EXCEL_FOLDER
        ),
        "CLINEVO_ENTERPRISE_2_EXCEL": as_str(
            config.VALIDUS_CLINEVO_EXCEL_FOLDER
        ),

        "ADVAGEN_CLINIVO_EXCEL_FOLDER": as_str(
            config.ADVAGEN_CLINEVO_EXCEL_FOLDER
        ),
        "VALIDUS_CLINIVO_EXCEL_FOLDER": as_str(
            config.VALIDUS_CLINEVO_EXCEL_FOLDER
        ),

        "ADVAGEN_CLINEVO_EXCEL_FOLDER": as_str(
            config.ADVAGEN_CLINEVO_EXCEL_FOLDER
        ),
        "VALIDUS_CLINEVO_EXCEL_FOLDER": as_str(
            config.VALIDUS_CLINEVO_EXCEL_FOLDER
        ),

        "ADVAGEN_LOCAL_DOCUMENT_FOLDER": as_str(
            config.ADVAGEN_LOCAL_DOCUMENT_FOLDER
        ),
        "VALIDUS_LOCAL_DOCUMENT_FOLDER": as_str(
            config.VALIDUS_LOCAL_DOCUMENT_FOLDER
        ),

        "SITE_CONFIG": config.CLINEVO_SITE_CONFIG,

        "REPORT_FOLDER": as_str(
            config.CLINEVO_REPORT_FOLDER
        ),
        "REPORT_FILE": as_str(
            config.CLINEVO_REPORT_FILE
        ),

        "SUPPORTED_LOCAL_FILE_EXTENSIONS": config.SUPPORTED_LOCAL_FILE_EXTENSIONS,
    }

    for key, value in values.items():

        setattr(
            module,
            key,
            value
        )

    return module


def update_clinevo_report_date_from_8x8_result(logger, process1_result):

    if isinstance(
        process1_result,
        dict
    ):

        selected_from_date = process1_result.get(
            "selected_from_date"
        )

        selected_to_date = process1_result.get(
            "selected_to_date"
        )

        if selected_from_date and selected_to_date:

            config.REPORT_FROM_DATE = selected_from_date
            config.REPORT_TO_DATE = selected_to_date

            logger.info(
                "CLINEVO report date updated from 8x8 selected date | From : %s | To : %s",
                config.REPORT_FROM_DATE,
                config.REPORT_TO_DATE
            )

        else:

            logger.warning(
                "8x8 selected date was not returned. CLINEVO will use default config dates | From : %s | To : %s",
                config.REPORT_FROM_DATE,
                config.REPORT_TO_DATE
            )

    else:

        logger.warning(
            "8x8 process did not return dictionary result. CLINEVO will use default config dates | From : %s | To : %s",
            config.REPORT_FROM_DATE,
            config.REPORT_TO_DATE
        )


async def _run_8x8_flow_inner(logger):

    logger.info("=" * 100)
    logger.info("8x8 FLOW STARTED")
    logger.info("=" * 100)

    mod_download = patch_8x8_module_config(
        import_first_available(
            [
                "intilial_process_1",
                "initial_process_1",
            ]
        )
    )

    if not hasattr(
        mod_download,
        "main"
    ):

        raise RuntimeError(
            "intilial_process_1.py must contain async main()"
        )

    process1_result = await mod_download.main()

    logger.info(
        "8x8 Process 1 Result : %s",
        process1_result
    )

    update_clinevo_report_date_from_8x8_result(
        logger,
        process1_result
    )

    mod_extract = patch_8x8_module_config(
        import_first_available(
            [
                "excel_extration_callids",
                "excel_extraction_callids",
            ]
        )
    )

    if not hasattr(
        mod_extract,
        "process1"
    ):

        raise RuntimeError(
            "excel_extration_callids.py must contain process1()"
        )

    mod_extract.process1()

    mod_ui = patch_8x8_module_config(
        import_first_available(
            [
                "call_info_ui",
            ]
        )
    )

    if not hasattr(
        mod_ui,
        "process2"
    ):

        raise RuntimeError(
            "call_info_ui.py must contain async process2()"
        )

    await mod_ui.process2()

    mod_report = patch_8x8_module_config(
        import_first_available(
            [
                "validation_report",
            ]
        )
    )

    if not hasattr(
        mod_report,
        "process3"
    ):

        raise RuntimeError(
            "validation_report.py must contain process3()"
        )

    mod_report.process3()

    logger.info(
        "8x8 FLOW COMPLETED | Report: %s",
        config.FINAL_REPORT_FILE
    )


async def _run_clinevo_flow_inner(logger):

    logger.info("=" * 100)
    logger.info("CLINEVO FLOW STARTED")
    logger.info("=" * 100)

    logger.info(
        "CLINEVO SQL Report Date Range | From : %s | To : %s",
        config.REPORT_FROM_DATE,
        config.REPORT_TO_DATE
    )

    mod_download = patch_clinevo_module_config(
        import_first_available(
            [
                "intilial_process_2",
                "initial_process_2",
            ]
        )
    )

    if not hasattr(
        mod_download,
        "main"
    ):

        raise RuntimeError(
            "intilial_process_2.py must contain async main()"
        )

    await mod_download.main()

    mod_report = patch_clinevo_module_config(
        import_first_available(
            [
                "extract_clinevo_excel_check",
                "extract_clinivo_excel_check",
            ]
        )
    )

    if not hasattr(
        mod_report,
        "process_clinivo_case_check"
    ):

        raise RuntimeError(
            "CLINEVO report file must contain process_clinivo_case_check()"
        )

    mod_report.process_clinivo_case_check()

    logger.info(
        "CLINEVO FLOW COMPLETED | Report: %s",
        config.CLINEVO_REPORT_FILE
    )


async def run_8x8_flow(logger):
    """
    Wraps _run_8x8_flow_inner() with execution_step_log / error_log /
    automation_process_status.eightx8_status tracking. The original
    working flow logic in _run_8x8_flow_inner() is completely unchanged.
    """

    db_helpers.update_execution_fields(eightx8_status="STARTED")
    db_helpers.log_step(
        "master_main", "run_8x8_flow", "8x8 flow started",
        status="STARTED", source_system="8x8",
    )

    try:
        await _run_8x8_flow_inner(logger)

        db_helpers.update_execution_fields(eightx8_status="COMPLETED")
        db_helpers.log_step(
            "master_main", "run_8x8_flow", "8x8 flow completed",
            status="COMPLETED", source_system="8x8",
        )

    except Exception as error:
        db_helpers.update_execution_fields(eightx8_status="FAILED")
        db_helpers.log_step(
            "master_main", "run_8x8_flow", "8x8 flow failed",
            status="FAILED", source_system="8x8", message=str(error),
        )
        db_helpers.insert_error_log(
            source_system="8x8",
            module_name="master_main",
            function_name="run_8x8_flow",
            step_name="8x8 flow",
            error_message=str(error),
            error_trace=traceback.format_exc(),
        )
        raise


async def run_clinevo_flow(logger):
    """
    Wraps _run_clinevo_flow_inner() with execution_step_log / error_log /
    automation_process_status.clinevo_status tracking. The original
    working flow logic in _run_clinevo_flow_inner() is completely
    unchanged.
    """

    db_helpers.update_execution_fields(clinevo_status="STARTED")
    db_helpers.log_step(
        "master_main", "run_clinevo_flow", "CLINEVO flow started",
        status="STARTED", source_system="CLINEVO",
    )

    try:
        await _run_clinevo_flow_inner(logger)

        db_helpers.update_execution_fields(clinevo_status="COMPLETED")
        db_helpers.log_step(
            "master_main", "run_clinevo_flow", "CLINEVO flow completed",
            status="COMPLETED", source_system="CLINEVO",
        )

    except Exception as error:
        db_helpers.update_execution_fields(clinevo_status="FAILED")
        db_helpers.log_step(
            "master_main", "run_clinevo_flow", "CLINEVO flow failed",
            status="FAILED", source_system="CLINEVO", message=str(error),
        )
        db_helpers.insert_error_log(
            source_system="CLINEVO",
            module_name="master_main",
            function_name="run_clinevo_flow",
            step_name="CLINEVO flow",
            error_message=str(error),
            error_trace=traceback.format_exc(),
        )
        raise


# ==========================================================
# OUTPUT ZIP PACKAGING
# (Does not modify or rename the original report files that
#  validation_report.py / extract_clinivo_excel_check.py already write.
#  It only creates additional, per-run named COPIES for the zip, so
#  existing report paths/behaviour stay exactly as before.)
# ==========================================================

def _safe_date_for_filename(date_text):
    return str(date_text or "UNKNOWN").replace("/", "-").strip()


def _collect_existing_files(paths):
    collected = []
    for path in paths:
        try:
            path = Path(path)
            if path.exists() and path.is_file():
                collected.append(path)
        except Exception:
            continue
    return collected


def _collect_folder_files(folder, extensions=None):
    collected = []
    try:
        folder = Path(folder)
        if not folder.exists():
            return collected
        for file_path in folder.rglob("*"):
            if file_path.is_file():
                if extensions and file_path.suffix.lower() not in extensions:
                    continue
                collected.append(file_path)
    except Exception:
        pass
    return collected


def create_output_zip(logger, execution_id):
    """
    Builds:
        Automation_Output_RUN_<execution_id>_<from>_<to>.zip
    containing:
        - 8x8 downloaded source Excel files
        - CLINEVO downloaded source Excel files
        - 8x8 output validation report (per-run named copy)
        - CLINEVO output report (per-run named copy)
        - important screenshots, if any exist

    Historical ZIP files and reports are NEVER deleted.
    Returns the zip Path, or None if it could not be created.
    """

    try:
        from_date, to_date = runtime_context.get_report_dates()
        from_date = from_date or config.REPORT_FROM_DATE
        to_date = to_date or config.REPORT_TO_DATE

        run_tag = f"RUN_{execution_id}" if execution_id else "RUN_LOCAL"
        date_tag = f"{_safe_date_for_filename(from_date)}_to_{_safe_date_for_filename(to_date)}"

        config.OUTPUT_ZIP_DIR.mkdir(parents=True, exist_ok=True)

        zip_path = config.OUTPUT_ZIP_DIR / f"Automation_Output_{run_tag}_{date_tag}.zip"

        renamed_report_dir = config.OUTPUT_ZIP_DIR / f"_renamed_reports_{run_tag}"
        renamed_report_dir.mkdir(parents=True, exist_ok=True)

        renamed_files = []

        if config.FINAL_REPORT_FILE.exists():
            renamed_8x8_report = (
                renamed_report_dir
                / f"Recording_Validation_Report_{run_tag}_{date_tag}.xlsx"
            )
            shutil.copy2(config.FINAL_REPORT_FILE, renamed_8x8_report)
            renamed_files.append(renamed_8x8_report)

        if config.CLINEVO_REPORT_FILE.exists():
            renamed_clinevo_report = (
                renamed_report_dir
                / f"Clinevo_Case_File_Check_Report_{run_tag}_{date_tag}.xlsx"
            )
            shutil.copy2(config.CLINEVO_REPORT_FILE, renamed_clinevo_report)
            renamed_files.append(renamed_clinevo_report)

        source_excel_files = _collect_folder_files(
            config.ADVAGEN_EXCEL_FOLDER, {".xlsx", ".xls"}
        ) + _collect_folder_files(
            config.VALIDUS_EXCEL_FOLDER, {".xlsx", ".xls"}
        ) + _collect_folder_files(
            config.ADVAGEN_CLINEVO_EXCEL_FOLDER, {".xlsx", ".xls"}
        ) + _collect_folder_files(
            config.VALIDUS_CLINEVO_EXCEL_FOLDER, {".xlsx", ".xls"}
        )

        screenshot_files = _collect_folder_files(
            config.PROCESS2_SCREENSHOT_FOLDER, {".png", ".jpg", ".jpeg"}
        ) + _collect_folder_files(
            config.CLINEVO_SCREENSHOT_DIR, {".png", ".jpg", ".jpeg"}
        )

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zip_file:

            for file_path in renamed_files:
                zip_file.write(file_path, arcname=f"reports/{file_path.name}")

            for file_path in source_excel_files:
                zip_file.write(
                    file_path,
                    arcname=f"source_excel/{file_path.parent.name}/{file_path.name}",
                )

            for file_path in screenshot_files:
                zip_file.write(
                    file_path,
                    arcname=f"screenshots/{file_path.parent.name}/{file_path.name}",
                )

        shutil.rmtree(renamed_report_dir, ignore_errors=True)

        logger.info("Output ZIP created: %s", zip_path)

        return zip_path

    except Exception as error:
        logger.warning("Failed to create output ZIP: %s", error)
        return None


async def main():

    setup_logging()

    logger = logging.getLogger(
        "master_single_execution"
    )

    config.create_required_folders()

    config.validate_common_date_range()

    logger.info("=" * 100)
    logger.info("MASTER SINGLE EXECUTION STARTED")
    logger.info("=" * 100)

    logger.info(
        "CONFIG DATE SETTINGS | DATE_RANGE : %s | CUSTOM_FROM_DATE : %s | CUSTOM_TO_DATE : %s",
        config.DATE_RANGE,
        config.CUSTOM_FROM_DATE,
        config.CUSTOM_TO_DATE
    )

    logger.info(
        "INITIAL CLINEVO REPORT DATE | From : %s | To : %s",
        config.REPORT_FROM_DATE,
        config.REPORT_TO_DATE
    )

    # ------------------------------------------------------------
    # NEW: Start DB execution tracking (safe no-op if DB disabled).
    # ------------------------------------------------------------
    runtime_context.reset()

    date_range_mode = "PRESET" if config.DATE_RANGE else "CUSTOM"
    date_range_value = config.DATE_RANGE or ""

    db_helpers.sync_app_config_to_db()

    provisional_run_name = "RUN_" + datetime.now().strftime("%Y%m%d_%H%M%S")

    execution_id = db_helpers.start_execution(
        run_name=provisional_run_name,
        run_mode="SINGLE_EXECUTION",
        date_range_mode=date_range_mode,
        date_range_value=date_range_value,
        custom_from_date=config.CUSTOM_FROM_DATE,
        custom_to_date=config.CUSTOM_TO_DATE,
        final_report_from_date=config.REPORT_FROM_DATE,
        final_report_to_date=config.REPORT_TO_DATE,
        run_8x8=config.RUN_8X8,
        run_clinevo=config.RUN_CLINEVO,
        remarks="Started by master_main.py",
    )

    if execution_id:
        db_helpers.update_execution_fields(run_name=f"RUN_{execution_id}")
        runtime_context.set_run_name(f"RUN_{execution_id}")
        logger.info("DB EXECUTION TRACKING ENABLED | execution_id=%s", execution_id)
    else:
        logger.info(
            "DB EXECUTION TRACKING DISABLED OR UNAVAILABLE | "
            "Automation will continue using JSON files only."
        )

    db_helpers.log_step(
        "master_main", "main", "Master execution started", status="STARTED"
    )

    overall_status = "COMPLETED"
    failure_reason = None

    clear_old_inputs(
        logger
    )

    if config.RUN_8X8:

        try:
            await run_8x8_flow(
                logger
            )

        except Exception as error:
            overall_status = "PARTIALLY_COMPLETED"
            failure_reason = f"8x8 flow failed: {error}"
            logger.error(failure_reason)

    else:

        logger.info(
            "8x8 flow skipped because RUN_8X8=False"
        )
        db_helpers.update_execution_fields(eightx8_status="SKIPPED")

    if config.RUN_CLINEVO:

        try:
            await run_clinevo_flow(
                logger
            )

        except Exception as error:
            overall_status = (
                "FAILED" if overall_status != "COMPLETED" else "PARTIALLY_COMPLETED"
            )
            failure_reason = (failure_reason + " | " if failure_reason else "") + (
                f"CLINEVO flow failed: {error}"
            )
            logger.error(f"CLINEVO flow failed: {error}")

    else:

        logger.info(
            "CLINEVO flow skipped because RUN_CLINEVO=False"
        )
        db_helpers.update_execution_fields(clinevo_status="SKIPPED")

    logger.info("=" * 100)
    logger.info("MASTER SINGLE EXECUTION COMPLETED")

    logger.info(
        "8x8 report: %s",
        config.FINAL_REPORT_FILE
    )

    logger.info(
        "CLINEVO report: %s",
        config.CLINEVO_REPORT_FILE
    )

    logger.info(
        "Final CLINEVO SQL Report Date | From : %s | To : %s",
        config.REPORT_FROM_DATE,
        config.REPORT_TO_DATE
    )

    logger.info("=" * 100)

    # ------------------------------------------------------------
    # NEW: finish DB execution tracking, build output ZIP, send email.
    # ------------------------------------------------------------
    runtime_context.update_report_dates(config.REPORT_FROM_DATE, config.REPORT_TO_DATE)

    db_helpers.finish_execution(overall_status, remarks=failure_reason or "Run completed")
    db_helpers.log_step(
        "master_main", "main", "Master execution finished",
        status=overall_status, message=failure_reason or "",
    )

    zip_path = create_output_zip(logger, execution_id)

    attachment_paths = [str(config.FINAL_REPORT_FILE), str(config.CLINEVO_REPORT_FILE)]
    if zip_path:
        attachment_paths.append(str(zip_path))

    run_tag = f"RUN_{execution_id}" if execution_id else provisional_run_name

    if overall_status == "COMPLETED":
        email_manager.send_automation_email(
            mail_type="SUCCESS_EMAIL",
            subject=f"[8x8 + CLINEVO Automation] SUCCESS | {run_tag}",
            body_text=(
                f"Automation run {run_tag} completed successfully.\n\n"
                f"Date range: {config.REPORT_FROM_DATE} to {config.REPORT_TO_DATE}\n"
                f"8x8 report: {config.FINAL_REPORT_FILE}\n"
                f"CLINEVO report: {config.CLINEVO_REPORT_FILE}\n"
                f"Output ZIP: {zip_path}\n"
            ),
            attachment_paths=attachment_paths,
        )
    else:
        email_manager.send_automation_email(
            mail_type="FAILURE_EMAIL",
            subject=f"[8x8 + CLINEVO Automation] {overall_status} | {run_tag}",
            body_text=(
                f"Automation run {run_tag} finished with status: {overall_status}\n\n"
                f"Reason: {failure_reason}\n\n"
                f"Date range: {config.REPORT_FROM_DATE} to {config.REPORT_TO_DATE}\n"
                f"8x8 report (if available): {config.FINAL_REPORT_FILE}\n"
                f"CLINEVO report (if available): {config.CLINEVO_REPORT_FILE}\n"
                f"Output ZIP (if available): {zip_path}\n"
                f"See execution_step_log / error_log for execution_id={execution_id} "
                f"for full details.\n"
            ),
            attachment_paths=attachment_paths,
        )

    if overall_status == "FAILED":
        raise RuntimeError(failure_reason or "Automation failed")


if __name__ == "__main__":

    asyncio.run(
        main()
    )