import importlib
from pathlib import Path
import config


REQUIRED_FILES = [
    "config.py",
    "master_main.py",
    "intilial_process_1.py",
    "intilial_process_2.py",
    "excel_extration_callids.py",
    "validation_report.py",
    "extract_clinivo_excel_check.py",
]


REQUIRED_CONFIG_VALUES = [
    "DATA_DIR",
    "LOG_DIR",
    "MASTER_LOG_FILE",

    "ADVAGEN_EXCEL_FOLDER",
    "VALIDUS_EXCEL_FOLDER",
    "CALL_IDS_JSON",
    "UI_CAPTURE_JSON",
    "FINAL_REPORT_FILE",

    "USERNAME",
    "PASSWORD",
    "DATE_RANGE",
    "CUSTOM_FROM_DATE",
    "CUSTOM_TO_DATE",
    "INPUT_FROM_DATERANGE",
    "INPUT_TO_DATERANGE",
    "REPORT_FROM_DATE",
    "REPORT_TO_DATE",

    "TIME_ZONE",
    "SITE_FILTER_1",
    "SITE_FILTER_2",
    "SITE_ORDER",

    "ADVAGEN_RECORDING_PATH",
    "VALIDUS_RECORDING_PATH",
    "SITE_PATHS",
    "AUDIO_EXTENSIONS",
    "SIZE_TOLERANCE",

    "LOGIN_URL",
    "CLINEVO_USERNAME",
    "CLINEVO_PASSWORD",
    "CLINEVO_ENTERPRISE_1",
    "CLINEVO_ENTERPRISE_2",

    "ADVAGEN_CLINEVO_EXCEL_FOLDER",
    "VALIDUS_CLINEVO_EXCEL_FOLDER",
    "CLINEVO_REPORT_FOLDER",
    "CLINEVO_REPORT_FILE",

    "CLINEVO_SCREENSHOT_DIR",
    "SUPPORTED_LOCAL_FILE_EXTENSIONS",

    "CHROME_DEBUG_URL",
    "CHROME_EXE_PATH",
    "CHROME_USER_DATA_DIR",
]


MODULE_FUNCTION_CHECKS = {
    "intilial_process_1": [
        "main",
        "analytics_flow",
        "select_date_range",
        "capture_selected_date_range",
    ],
    "excel_extration_callids": [
        "process1",
    ],
    "validation_report": [
        "process3",
    ],
    "intilial_process_2": [
        "main",
        "update_sql_date_range",
        "validate_dd_mon_yyyy",
    ],
    "extract_clinivo_excel_check": [
        "process_clinivo_case_check",
    ],
    "master_main": [
        "main",
        "run_8x8_flow",
        "run_clinevo_flow",
        "patch_8x8_module_config",
        "patch_clinevo_module_config",
    ],
}


def check_files_exist():
    print("=" * 100)
    print("CHECK 1: Required files")
    print("=" * 100)

    missing_files = []

    for file_name in REQUIRED_FILES:
        file_path = Path(file_name)

        if file_path.exists():
            print(f"OK   : {file_name}")
        else:
            print(f"MISS : {file_name}")
            missing_files.append(file_name)

    if missing_files:
        raise FileNotFoundError(
            f"Missing required files: {missing_files}"
        )


def check_config_values():
    print("=" * 100)
    print("CHECK 2: Required config values")
    print("=" * 100)

    missing_values = []

    for name in REQUIRED_CONFIG_VALUES:
        if hasattr(config, name):
            value = getattr(config, name)
            print(f"OK   : config.{name} = {value}")
        else:
            print(f"MISS : config.{name}")
            missing_values.append(name)

    if missing_values:
        raise AttributeError(
            f"Missing config values: {missing_values}"
        )


def check_date_format():
    print("=" * 100)
    print("CHECK 3: Date validation")
    print("=" * 100)

    config.validate_common_date_range()

    from_date = config.normalize_date_to_dd_mon_yyyy(
        config.CUSTOM_FROM_DATE
    )

    to_date = config.normalize_date_to_dd_mon_yyyy(
        config.CUSTOM_TO_DATE
    )

    print(f"OK : CUSTOM_FROM_DATE normalized = {from_date}")
    print(f"OK : CUSTOM_TO_DATE normalized   = {to_date}")
    print(f"OK : INPUT_FROM_DATERANGE        = {config.INPUT_FROM_DATERANGE}")
    print(f"OK : INPUT_TO_DATERANGE          = {config.INPUT_TO_DATERANGE}")
    print(f"OK : REPORT_FROM_DATE            = {config.REPORT_FROM_DATE}")
    print(f"OK : REPORT_TO_DATE              = {config.REPORT_TO_DATE}")

    if config.DATE_RANGE.strip():
        print(f"MODE : Preset date range mode enabled = {config.DATE_RANGE}")
        print("NOTE : 8x8 captured UI dates will override CLINEVO report dates in master_main.py")
    else:
        print("MODE : Custom date range mode enabled")


def check_required_folders():
    print("=" * 100)
    print("CHECK 4: Folder creation")
    print("=" * 100)

    config.create_required_folders()

    folders = [
        config.DATA_DIR,
        config.LOG_DIR,
        config.ADVAGEN_EXCEL_FOLDER,
        config.VALIDUS_EXCEL_FOLDER,
        config.PROCESS1_SCREENSHOT_FOLDER,
        config.PROCESS2_SCREENSHOT_FOLDER,
        config.EIGHTX8_JSON_DIR,
        config.EIGHTX8_REPORT_DIR,
        config.ADVAGEN_CLINEVO_EXCEL_FOLDER,
        config.VALIDUS_CLINEVO_EXCEL_FOLDER,
        config.CLINEVO_REPORT_FOLDER,
        config.CLINEVO_SCREENSHOT_DIR,
    ]

    for folder in folders:
        folder = Path(folder)

        if folder.exists():
            print(f"OK : {folder}")
        else:
            raise FileNotFoundError(
                f"Folder was not created: {folder}"
            )


def check_module_imports_and_functions():
    print("=" * 100)
    print("CHECK 5: Module imports and required functions")
    print("=" * 100)

    for module_name, required_functions in MODULE_FUNCTION_CHECKS.items():
        print("-" * 100)
        print(f"Importing module: {module_name}")

        module = importlib.import_module(module_name)

        print(f"OK : Imported {module_name}")

        for function_name in required_functions:
            if hasattr(module, function_name):
                print(f"OK : {module_name}.{function_name} exists")
            else:
                raise AttributeError(
                    f"Missing function: {module_name}.{function_name}"
                )


def check_duplicate_report_dates_in_config_file():
    print("=" * 100)
    print("CHECK 6: Duplicate hardcoded CLINEVO report dates in config.py")
    print("=" * 100)

    config_text = Path("config.py").read_text(
        encoding="utf-8"
    )

    bad_lines = [
        'REPORT_FROM_DATE = "15-JUL-2026"',
        "REPORT_FROM_DATE = '15-JUL-2026'",
        'REPORT_TO_DATE = "15-JUL-2026"',
        "REPORT_TO_DATE = '15-JUL-2026'",
    ]

    found_bad_lines = [
        line for line in bad_lines
        if line in config_text
    ]

    if found_bad_lines:
        raise ValueError(
            "Duplicate hardcoded report dates found in config.py. "
            f"Remove these lines: {found_bad_lines}"
        )

    print("OK : No duplicate hardcoded REPORT_FROM_DATE / REPORT_TO_DATE found")


def check_escaped_symbols():
    print("=" * 100)
    print("CHECK 7: Escaped HTML symbols")
    print("=" * 100)

    patterns = [
        "&gt;",
        "&lt;",
        "=&gt;",
        "&amp;",
        "\\g&lt;",
        "\\g&gt;",
    ]

    files_with_issues = []

    for file_path in Path(".").glob("*.py"):

        # Skip this preflight checker file because it contains
        # the escaped-symbol patterns intentionally.
        if file_path.name == "preflight_check.py":
            continue

        text = file_path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        for pattern in patterns:
            if pattern in text:
                files_with_issues.append(
                    f"{file_path.name} contains {pattern}"
                )

    if files_with_issues:
        raise ValueError(
            "Escaped symbols found. Fix these before running:\n"
            + "\n".join(files_with_issues)
        )

    print("OK : No escaped HTML symbols found in automation files")


def main():
    check_files_exist()
    check_config_values()
    check_date_format()
    check_required_folders()
    check_duplicate_report_dates_in_config_file()
    check_escaped_symbols()
    check_module_imports_and_functions()

    print("=" * 100)
    print("PREFLIGHT CHECK PASSED")
    print("Your config and module connections look ready for execution.")
    print("=" * 100)


if __name__ == "__main__":
    main()