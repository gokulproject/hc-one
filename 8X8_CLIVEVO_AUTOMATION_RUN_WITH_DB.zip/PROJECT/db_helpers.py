"""
db_helpers.py

High level, safe database helper functions used by master_main.py and every
process file (intilial_process_1.py, excel_extration_callids.py,
call_info_ui.py, validation_report.py, intilial_process_2.py,
extract_clinivo_excel_check.py).

Design rules followed here (per follow up prompt):
    1. No hardcoded config values - everything comes from config.py.
    2. Uses database_manager.DatabaseManager (pymysql, DictCursor).
    3. Every public function is wrapped in try/except. If MySQL is
       unreachable, or ENABLE_DB_LOGGING is False, or any DB error happens,
       these functions log a warning and return a safe default
       (None, [], or False). They NEVER raise into the calling automation
       code. This guarantees the existing Playwright/Excel logic keeps
       working exactly as before even if MySQL is completely unavailable.
    4. execution_id is read automatically from runtime_context so callers
       do not need to change their function signatures just to pass it
       around.

This file contains NO Playwright / Selenium / UI selector logic and NO
Excel parsing / regex / date-format logic. It only stores and retrieves
data that the existing process files already compute.
"""

import json
import traceback
from datetime import datetime

import config
import runtime_context
from database_manager import DatabaseManager
from logger import get_logger

logger = get_logger(__name__)


# ==========================================================
# COMMON HELPERS
# ==========================================================

def is_db_enabled() -> bool:
    try:
        return bool(getattr(config, "ENABLE_DB_LOGGING", False))
    except Exception:
        return False


def _now():
    return datetime.now()


def _safe_json_dumps(value) -> str:
    try:
        return json.dumps(value, default=str, ensure_ascii=False)
    except Exception:
        try:
            return json.dumps(str(value))
        except Exception:
            return "{}"


def _log_failure(context_name: str, error: Exception):
    logger.warning(
        "DB HELPER FAILED (automation continues) | %s | %s",
        context_name,
        error,
    )
    logger.debug(traceback.format_exc())


# ==========================================================
# APP CONFIG SYNC
# ==========================================================

# Keys from config.py that are safe/relevant to mirror into app_config.
# Passwords and secrets are intentionally excluded from config_key list
# unless is_sensitive is also stored True and value is masked.
_APP_CONFIG_KEYS = [
    "DATE_RANGE",
    "CUSTOM_FROM_DATE",
    "CUSTOM_TO_DATE",
    "INPUT_FROM_DATERANGE",
    "INPUT_TO_DATERANGE",
    "REPORT_FROM_DATE",
    "REPORT_TO_DATE",
    "TIME_ZONE",
    "SITE_FILTER_1",
    "SITE_FILTER_2",
    "RUN_8X8",
    "RUN_CLINEVO",
    "CLEAR_OLD_EXCEL_BEFORE_RUN",
    "CLEAR_OLD_JSON_BEFORE_RUN",
    "ANALYTICS_URL",
    "APP_URL",
    "RECORDINGS_URL",
    "LOGIN_URL",
    "CLINEVO_ENTERPRISE_1",
    "CLINEVO_ENTERPRISE_2",
    "SIZE_TOLERANCE",
    "DATA_DIR",
    "LOG_DIR",
    "EIGHTX8_EXCEL_DIR",
    "EIGHTX8_JSON_DIR",
    "EIGHTX8_REPORT_DIR",
    "EIGHTX8_SCREENSHOT_DIR",
    "ADVAGEN_EXCEL_FOLDER",
    "VALIDUS_EXCEL_FOLDER",
    "CALL_IDS_JSON",
    "UI_CAPTURE_JSON",
    "FINAL_REPORT_FILE",
    "CLINEVO_DIR",
    "CLINEVO_EXCEL_DIR",
    "CLINEVO_REPORT_DIR",
    "CLINEVO_SCREENSHOT_DIR",
    "ADVAGEN_CLINEVO_EXCEL_FOLDER",
    "VALIDUS_CLINEVO_EXCEL_FOLDER",
    "CLINEVO_REPORT_FOLDER",
    "CLINEVO_REPORT_FILE",
    "ENABLE_DB_LOGGING",
    "ENABLE_EMAIL_NOTIFICATION",
    "DEFAULT_EMAIL_CONFIG_NAME",
    "EMAIL_SEND_SUCCESS",
    "EMAIL_SEND_FAILURE",
    "EMAIL_ATTACH_OUTPUT_REPORTS",
    "OUTPUT_ZIP_DIR",
]

_APP_CONFIG_GROUPS = {
    "DATE_RANGE": "date",
    "CUSTOM_FROM_DATE": "date",
    "CUSTOM_TO_DATE": "date",
    "INPUT_FROM_DATERANGE": "date",
    "INPUT_TO_DATERANGE": "date",
    "REPORT_FROM_DATE": "date",
    "REPORT_TO_DATE": "date",
    "TIME_ZONE": "date",
    "SITE_FILTER_1": "site",
    "SITE_FILTER_2": "site",
    "RUN_8X8": "run_option",
    "RUN_CLINEVO": "run_option",
    "CLEAR_OLD_EXCEL_BEFORE_RUN": "run_option",
    "CLEAR_OLD_JSON_BEFORE_RUN": "run_option",
    "ENABLE_DB_LOGGING": "db",
    "ENABLE_EMAIL_NOTIFICATION": "email",
    "DEFAULT_EMAIL_CONFIG_NAME": "email",
    "EMAIL_SEND_SUCCESS": "email",
    "EMAIL_SEND_FAILURE": "email",
    "EMAIL_ATTACH_OUTPUT_REPORTS": "email",
}


def sync_app_config_to_db() -> bool:
    """
    Mirrors relevant config.py values into app_config.
    Uses "insert if new else update" (upsert by config_key).
    Safe no-op if DB is disabled or unreachable.
    """

    if not is_db_enabled():
        return False

    try:
        with DatabaseManager() as db:
            for key in _APP_CONFIG_KEYS:
                if not hasattr(config, key):
                    continue

                value = getattr(config, key)
                group = _APP_CONFIG_GROUPS.get(key, "general")

                existing = db.fetch_one(
                    "SELECT config_id FROM app_config WHERE config_key = %s",
                    (key,),
                )

                if existing:
                    db.execute(
                        """
                        UPDATE app_config
                        SET config_value = %s, config_group = %s, is_active = TRUE
                        WHERE config_key = %s
                        """,
                        (str(value), group, key),
                    )
                else:
                    db.execute(
                        """
                        INSERT INTO app_config
                            (config_key, config_value, config_group, is_sensitive, is_active)
                        VALUES (%s, %s, %s, FALSE, TRUE)
                        """,
                        (key, str(value), group),
                    )

        return True

    except Exception as error:
        _log_failure("sync_app_config_to_db", error)
        return False


# ==========================================================
# AUTOMATION PROCESS STATUS (1 ROW PER master_main.py RUN)
# ==========================================================

def start_execution(run_name, run_mode, date_range_mode, date_range_value,
                     custom_from_date, custom_to_date,
                     final_report_from_date, final_report_to_date,
                     run_8x8, run_clinevo, remarks=""):
    """
    Inserts one row into automation_process_status and stores the
    returned execution_id into runtime_context for the rest of this run.

    Returns execution_id (int) or None if DB is disabled/unreachable.
    """

    if not is_db_enabled():
        return None

    try:
        with DatabaseManager() as db:
            execution_id = db.insert_and_get_id(
                """
                INSERT INTO automation_process_status
                    (run_name, run_mode, started_at, status,
                     eightx8_status, clinevo_status,
                     date_range_mode, date_range_value,
                     custom_from_date, custom_to_date,
                     final_report_from_date, final_report_to_date,
                     run_8x8, run_clinevo, remarks)
                VALUES
                    (%s, %s, %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s, %s)
                """,
                (
                    run_name, run_mode, _now(), "STARTED",
                    "PENDING", "PENDING",
                    date_range_mode, date_range_value,
                    custom_from_date, custom_to_date,
                    final_report_from_date, final_report_to_date,
                    bool(run_8x8), bool(run_clinevo), remarks,
                ),
            )

        runtime_context.set_execution_id(execution_id)
        runtime_context.set_run_name(run_name)
        runtime_context.update_report_dates(final_report_from_date, final_report_to_date)

        logger.info("DB execution row created | execution_id=%s", execution_id)

        return execution_id

    except Exception as error:
        _log_failure("start_execution", error)
        return None


def update_execution_fields(**fields) -> bool:
    """
    Updates arbitrary columns on automation_process_status for the current
    execution_id. Example:
        update_execution_fields(eightx8_status="COMPLETED")
        update_execution_fields(status="FAILED", ended_at=datetime.now())
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id or not fields:
        return False

    try:
        set_clause = ", ".join(f"{key} = %s" for key in fields.keys())
        params = list(fields.values()) + [execution_id]

        with DatabaseManager() as db:
            db.execute(
                f"UPDATE automation_process_status SET {set_clause} "
                f"WHERE execution_id = %s",
                tuple(params),
            )

        return True

    except Exception as error:
        _log_failure("update_execution_fields", error)
        return False


def finish_execution(status, remarks=None) -> bool:

    fields = {"status": status, "ended_at": _now()}

    if remarks is not None:
        fields["remarks"] = remarks

    return update_execution_fields(**fields)


def update_email_status_on_execution(email_status, sent_at=None) -> bool:

    return update_execution_fields(
        email_status=email_status,
        email_sent_at=sent_at or _now(),
    )


# ==========================================================
# EXECUTION STEP LOG
# ==========================================================

def log_step(module_name, function_name, step_name, status,
              source_system="", site_name="", enterprise_name="",
              message=""):
    """
    Inserts one row into execution_step_log.
    Returns step_id or None.
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return None

    try:
        with DatabaseManager() as db:
            step_id = db.insert_and_get_id(
                """
                INSERT INTO execution_step_log
                    (execution_id, module_name, function_name, step_name,
                     source_system, site_name, enterprise_name,
                     started_at, ended_at, status, message)
                VALUES
                    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    execution_id, module_name, function_name, step_name,
                    source_system, site_name, enterprise_name,
                    _now(), _now(), status, message,
                ),
            )

        return step_id

    except Exception as error:
        _log_failure("log_step", error)
        return None


# ==========================================================
# 8x8 DOWNLOADED EXCEL STATUS
# ==========================================================

def insert_8x8_download_status(site_name, file_path, download_folder,
                                 date_range_mode, date_range_value,
                                 report_from_date, report_to_date,
                                 custom_from_date, custom_to_date,
                                 status, remarks=""):

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return None

    try:
        import os

        file_exists = bool(file_path) and os.path.exists(str(file_path))
        file_size = os.path.getsize(str(file_path)) if file_exists else 0
        file_name = os.path.basename(str(file_path)) if file_path else ""

        with DatabaseManager() as db:
            download_id = db.insert_and_get_id(
                """
                INSERT INTO eightxeight_downloaded_excel_status
                    (execution_id, site_name, report_type,
                     date_range_mode, date_range_value,
                     report_from_date, report_to_date,
                     custom_from_date, custom_to_date,
                     file_name, file_path, download_folder,
                     downloaded_at, file_exists, file_size_bytes,
                     status, remarks)
                VALUES
                    (%s, %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s, %s,
                     %s, %s, %s,
                     %s, %s)
                """,
                (
                    execution_id, site_name, "Call Detail Records",
                    date_range_mode, date_range_value,
                    report_from_date, report_to_date,
                    custom_from_date, custom_to_date,
                    file_name, str(file_path) if file_path else "", str(download_folder),
                    _now(), file_exists, file_size,
                    status, remarks,
                ),
            )

        return download_id

    except Exception as error:
        _log_failure("insert_8x8_download_status", error)
        return None


# ==========================================================
# CLINEVO DOWNLOADED EXCEL STATUS
# ==========================================================

def insert_clinevo_download_status(enterprise_name, site_name, file_path,
                                     download_folder, date_range_mode,
                                     date_range_value, report_from_date,
                                     report_to_date, custom_from_date,
                                     custom_to_date, status, remarks=""):

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return None

    try:
        import os

        file_exists = bool(file_path) and os.path.exists(str(file_path))
        file_size = os.path.getsize(str(file_path)) if file_exists else 0
        file_name = os.path.basename(str(file_path)) if file_path else ""

        with DatabaseManager() as db:
            download_id = db.insert_and_get_id(
                """
                INSERT INTO clinevo_downloaded_excel_status
                    (execution_id, enterprise_name, site_name, report_type,
                     date_range_mode, date_range_value,
                     report_from_date, report_to_date,
                     custom_from_date, custom_to_date,
                     file_name, file_path, download_folder,
                     downloaded_at, file_exists, file_size_bytes,
                     status, remarks)
                VALUES
                    (%s, %s, %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s, %s,
                     %s, %s, %s,
                     %s, %s)
                """,
                (
                    execution_id, enterprise_name, site_name, "Line Listing MICC",
                    date_range_mode, date_range_value,
                    report_from_date, report_to_date,
                    custom_from_date, custom_to_date,
                    file_name, str(file_path) if file_path else "", str(download_folder),
                    _now(), file_exists, file_size,
                    status, remarks,
                ),
            )

        return download_id

    except Exception as error:
        _log_failure("insert_clinevo_download_status", error)
        return None


# ==========================================================
# AUDIT BY CALL ID  +  UI NEEDED CALL ITEMS
# (Phase 3 - replaces call_ids.json as the primary source)
# ==========================================================

def insert_audit_and_ui_needed_rows(site_name, audit_call_items, ui_needed_call_items):
    """
    Inserts every extracted 8x8 Excel row into audit_by_call_id (no filtering)
    and inserts the already-filtered ui_needed_call_items rows
    (built by excel_extration_callids.py exactly as before) into
    ui_needed_call_items, linked to the matching audit_by_call_id row when
    possible.

    audit_call_items: list of dicts produced by
        excel_extration_callids.extract_site_excel_data()["audit_call_items"]
        each item has keys: call_id, source_excel_site, excel_date_time,
        excel_date, answered, excel_row_sequence, source_excel_file,
        excel_row_data (the full original Excel row as dict)

    ui_needed_call_items: list of dicts (subset of the same structure)
        each item has keys: call_id, source_excel_site, excel_date_time,
        excel_date, answered, excel_row_sequence

    Returns True on success (or DB disabled), False on failure.
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return False

    try:
        # audit_id per call_id, keeps the LAST inserted audit row id for that
        # call_id in this site batch - good enough for FK linkage purposes.
        audit_id_by_call_id = {}

        with DatabaseManager() as db:

            for item in audit_call_items:
                row_data = item.get("excel_row_data", {}) or {}

                caller = row_data.get("Caller") or row_data.get("caller") or ""
                callee = row_data.get("Callee") or row_data.get("callee") or ""
                queue_name = (
                    row_data.get("Queue")
                    or row_data.get("Queue Name")
                    or row_data.get("queue")
                    or ""
                )
                agent_name = (
                    row_data.get("Agent")
                    or row_data.get("Agent Name")
                    or row_data.get("agent")
                    or ""
                )
                direction = row_data.get("Direction") or row_data.get("direction") or ""

                audit_id = db.insert_and_get_id(
                    """
                    INSERT INTO audit_by_call_id
                        (execution_id, source_site, call_id, direction,
                         excel_date_time, excel_date, answered,
                         caller, callee, queue_name, agent_name,
                         source_excel_file, raw_row_json)
                    VALUES
                        (%s, %s, %s, %s,
                         %s, %s, %s,
                         %s, %s, %s, %s,
                         %s, %s)
                    """,
                    (
                        execution_id, item.get("source_excel_site", site_name),
                        item.get("call_id", ""), direction,
                        item.get("excel_date_time", ""), item.get("excel_date", ""),
                        item.get("answered", ""),
                        caller, callee, queue_name, agent_name,
                        item.get("source_excel_file", ""),
                        _safe_json_dumps(row_data),
                    ),
                )

                if item.get("call_id"):
                    audit_id_by_call_id[item["call_id"]] = audit_id

            for item in ui_needed_call_items:
                call_id = item.get("call_id", "")

                db.execute(
                    """
                    INSERT INTO ui_needed_call_items
                        (execution_id, audit_id, source_site, call_id,
                         direction, excel_date_time, excel_date, answered,
                         source_excel_file, status, remarks)
                    VALUES
                        (%s, %s, %s, %s,
                         %s, %s, %s, %s,
                         %s, %s, %s)
                    """,
                    (
                        execution_id, audit_id_by_call_id.get(call_id),
                        item.get("source_excel_site", site_name), call_id,
                        item.get("direction", ""), item.get("excel_date_time", ""),
                        item.get("excel_date", ""), item.get("answered", ""),
                        item.get("source_excel_file", ""), "PENDING_UI_SEARCH", "",
                    ),
                )

        logger.info(
            "DB audit rows inserted | site=%s | audit_rows=%s | ui_needed_rows=%s",
            site_name, len(audit_call_items), len(ui_needed_call_items),
        )

        return True

    except Exception as error:
        _log_failure("insert_audit_and_ui_needed_rows", error)
        return False


def fetch_ui_needed_call_items():
    """
    Fetches ui_needed_call_items rows for the current execution_id, shaped
    exactly like the records call_info_ui.load_call_id_records() already
    expects (same dict keys), so call_info_ui.py's existing Playwright
    search logic does not need to change at all.

    Returns [] if DB disabled, unreachable, or no rows found (caller then
    falls back to call_ids.json).
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return []

    try:
        with DatabaseManager() as db:
            rows = db.fetch_all(
                """
                SELECT ui_item_id, source_site, call_id, direction,
                       excel_date_time, excel_date, answered,
                       source_excel_file
                FROM ui_needed_call_items
                WHERE execution_id = %s
                ORDER BY ui_item_id ASC
                """,
                (execution_id,),
            )

        records = []

        for index, row in enumerate(rows, start=1):
            records.append(
                {
                    "call_id": row.get("call_id", ""),
                    "source_excel_site": row.get("source_site", ""),
                    "excel_date_time": row.get("excel_date_time", ""),
                    "excel_date": row.get("excel_date", ""),
                    "answered": row.get("answered", ""),
                    "excel_row_sequence": index,
                    "ui_item_id": row.get("ui_item_id"),
                }
            )

        logger.info("Fetched %s ui_needed_call_items rows from DB", len(records))

        return records

    except Exception as error:
        _log_failure("fetch_ui_needed_call_items", error)
        return []


def update_ui_needed_item_status(ui_item_id, status, remarks=""):

    if not is_db_enabled() or not ui_item_id:
        return False

    try:
        with DatabaseManager() as db:
            db.execute(
                "UPDATE ui_needed_call_items SET status = %s, remarks = %s "
                "WHERE ui_item_id = %s",
                (status, remarks, ui_item_id),
            )
        return True
    except Exception as error:
        _log_failure("update_ui_needed_item_status", error)
        return False


# ==========================================================
# UI CAPTURE RECORD  (Phase 4)
# ==========================================================

def insert_ui_capture_records(ui_records):
    """
    Inserts one row per UI-searched Call ID into ui_capture_record.
    ui_records: the same list of dicts already built by
        call_info_ui.build_ui_record() (call_id, source_excel_site,
        excel_date_time, excel_date, answered, ui_site, ui_size,
        ui_duration, status, remarks, screenshot_path).

    Also writes a screenshot_log row whenever screenshot_path is present.

    Returns True on success (or DB disabled), False on failure.
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return False

    try:
        with DatabaseManager() as db:
            for item in ui_records:
                call_id = item.get("call_id", "")
                screenshot_path = item.get("screenshot_path", "") or ""

                db.execute(
                    """
                    INSERT INTO ui_capture_record
                        (execution_id, ui_item_id, call_id, source_excel_site,
                         direction, excel_date_time, excel_date, answered,
                         ui_site, ui_audio_duration, ui_audio_size,
                         ui_status, remarks, screenshot_path, raw_json)
                    VALUES
                        (%s, %s, %s, %s,
                         %s, %s, %s, %s,
                         %s, %s, %s,
                         %s, %s, %s, %s)
                    """,
                    (
                        execution_id, item.get("ui_item_id"), call_id,
                        item.get("source_excel_site", ""),
                        item.get("direction", ""), item.get("excel_date_time", ""),
                        item.get("excel_date", ""), item.get("answered", ""),
                        item.get("ui_site", ""), item.get("ui_duration", ""),
                        item.get("ui_size", ""),
                        item.get("status", ""), item.get("remarks", ""),
                        screenshot_path, _safe_json_dumps(item),
                    ),
                )

                if screenshot_path:
                    db.execute(
                        """
                        INSERT INTO screenshot_log
                            (execution_id, source_system, module_name,
                             function_name, step_name, site_name,
                             enterprise_name, call_id_or_case_id,
                             screenshot_path)
                        VALUES
                            (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            execution_id, "8x8", "call_info_ui",
                            "capture_process2_screenshot",
                            "UI audio info not found / evidence screenshot",
                            item.get("source_excel_site", ""), "",
                            call_id, screenshot_path,
                        ),
                    )

        logger.info("DB ui_capture_record rows inserted | count=%s", len(ui_records))

        return True

    except Exception as error:
        _log_failure("insert_ui_capture_records", error)
        return False


def fetch_ui_capture_records():
    """
    Fetches ui_capture_record rows for the current execution_id, shaped
    exactly like the ui_capture.json records that validation_report.py
    already expects. Returns [] if unavailable (caller falls back to JSON).
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return []

    try:
        with DatabaseManager() as db:
            rows = db.fetch_all(
                """
                SELECT call_id, source_excel_site, direction, excel_date_time,
                       excel_date, answered, ui_site, ui_audio_duration,
                       ui_audio_size, ui_status, remarks, screenshot_path
                FROM ui_capture_record
                WHERE execution_id = %s
                ORDER BY ui_capture_id ASC
                """,
                (execution_id,),
            )

        records = []

        for row in rows:
            records.append(
                {
                    "call_id": row.get("call_id", ""),
                    "source_excel_site": row.get("source_excel_site", ""),
                    "excel_date_time": row.get("excel_date_time", ""),
                    "excel_date": row.get("excel_date", ""),
                    "answered": row.get("answered", ""),
                    "ui_site": row.get("ui_site", ""),
                    "ui_size": row.get("ui_audio_size", ""),
                    "ui_duration": row.get("ui_audio_duration", ""),
                    "status": row.get("ui_status", ""),
                    "remarks": row.get("remarks", ""),
                    "screenshot_path": row.get("screenshot_path", ""),
                }
            )

        logger.info("Fetched %s ui_capture_record rows from DB", len(records))

        return records

    except Exception as error:
        _log_failure("fetch_ui_capture_records", error)
        return []


# ==========================================================
# RECORDING VALIDATION RESULT  (Phase 4)
# ==========================================================

def insert_recording_validation_results(report_rows):
    """
    report_rows: list of dicts shaped like validation_report.build_report_row()
    output, PLUS optional extra keys "direction" and "simplified_status"
    that validation_report.py adds only for DB storage (business Excel
    layout stays unchanged).
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return False

    try:
        with DatabaseManager() as db:
            for row in report_rows:
                db.execute(
                    """
                    INSERT INTO recording_validation_result
                        (execution_id, call_id, direction, source_excel_site,
                         excel_date_time, answered, ui_site,
                         ui_audio_duration, local_audio_duration,
                         ui_audio_size, local_audio_size,
                         folder_available, file_available,
                         status, simplified_status,
                         audio_file_name, audio_file_path, remarks)
                    VALUES
                        (%s, %s, %s, %s,
                         %s, %s, %s,
                         %s, %s,
                         %s, %s,
                         %s, %s,
                         %s, %s,
                         %s, %s, %s)
                    """,
                    (
                        execution_id,
                        row.get("Call ID", ""),
                        row.get("direction", ""),
                        row.get("Source Excel Site", ""),
                        row.get("Excel Date Time", ""),
                        row.get("Answered", ""),
                        row.get("UI Site", ""),
                        row.get("UI Audio Duration", ""),
                        row.get("Local Audio Duration", ""),
                        row.get("UI Audio Size", ""),
                        row.get("Local Audio Size", ""),
                        row.get("Folder Available", ""),
                        row.get("File Available", ""),
                        row.get("Status", ""),
                        row.get("simplified_status", row.get("Status", "")),
                        row.get("Audio File Name", ""),
                        row.get("audio_file_path", ""),
                        row.get("Remarks", ""),
                    ),
                )

        logger.info("DB recording_validation_result rows inserted | count=%s", len(report_rows))

        return True

    except Exception as error:
        _log_failure("insert_recording_validation_results", error)
        return False


# ==========================================================
# CLINEVO CASE RECORD  (Phase 5)
# ==========================================================

def insert_clinevo_case_records(enterprise_name, site_name, cases):
    """
    cases: list of dicts produced by
        extract_clinivo_excel_check.extract_cases_from_excel()
        each item has: site_name, case_id, received_date_raw, received_date,
        date_key, and optionally raw_row_data (full original Excel row)
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return False

    try:
        with DatabaseManager() as db:
            for case_item in cases:
                db.execute(
                    """
                    INSERT INTO clinevo_case_record
                        (execution_id, enterprise_name, site_name,
                         case_number, case_version, received_date, date_key,
                         source_excel_file, raw_row_json)
                    VALUES
                        (%s, %s, %s,
                         %s, %s, %s, %s,
                         %s, %s)
                    """,
                    (
                        execution_id, enterprise_name, site_name,
                        case_item.get("case_id", ""),
                        case_item.get("case_version", ""),
                        case_item.get("received_date", ""),
                        case_item.get("date_key", ""),
                        case_item.get("source_excel_file", ""),
                        _safe_json_dumps(case_item.get("raw_row_data", case_item)),
                    ),
                )

        logger.info(
            "DB clinevo_case_record rows inserted | site=%s | count=%s",
            site_name, len(cases),
        )

        return True

    except Exception as error:
        _log_failure("insert_clinevo_case_records", error)
        return False


# ==========================================================
# CLINEVO CASE AUDIO RESULT  (Phase 5)
# ==========================================================

def insert_clinevo_case_audio_results(enterprise_name, site_name, report_rows):
    """
    report_rows: list of dicts produced by
        extract_clinivo_excel_check.check_audio_case_id_present_in_excel()
        Keys: "Received Date", "Audio File Name", "Audio Folder Path",
        "Extracted Case ID", "Excel Case ID Count", "Status", "Remarks"
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return False

    _simplified_map = {
        "Present in Clinivo Excel": "OK",
        "Present in Clinivo Excel - Duplicate Found": "DUPLICATE",
        "Missing in Clinivo Excel": "MISSING",
        "Case ID Not Found in Audio File Name": "CASE_ID_NOT_FOUND",
        "No Audio Files": "NO_AUDIO_FILES",
        "Date Folder Missing": "FOLDER_MISSING",
    }

    try:
        with DatabaseManager() as db:
            for row in report_rows:
                status = row.get("Status", "")

                db.execute(
                    """
                    INSERT INTO clinevo_case_audio_result
                        (execution_id, enterprise_name, site_name,
                         received_date, audio_file_name, audio_folder_path,
                         extracted_case_id, excel_case_id_count,
                         status, simplified_status, remarks)
                    VALUES
                        (%s, %s, %s,
                         %s, %s, %s,
                         %s, %s,
                         %s, %s, %s)
                    """,
                    (
                        execution_id, enterprise_name, site_name,
                        row.get("Received Date", ""),
                        row.get("Audio File Name", ""),
                        row.get("Audio Folder Path", ""),
                        row.get("Extracted Case ID", ""),
                        row.get("Excel Case ID Count", 0),
                        status, _simplified_map.get(status, status),
                        row.get("Remarks", ""),
                    ),
                )

        logger.info(
            "DB clinevo_case_audio_result rows inserted | site=%s | count=%s",
            site_name, len(report_rows),
        )

        return True

    except Exception as error:
        _log_failure("insert_clinevo_case_audio_results", error)
        return False


# ==========================================================
# SCREENSHOT LOG  (generic, used for execution-error screenshots)
# ==========================================================

def insert_screenshot_log(source_system, module_name, function_name, step_name,
                            screenshot_path, site_name="", enterprise_name="",
                            call_id_or_case_id=""):

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id or not screenshot_path:
        return None

    try:
        with DatabaseManager() as db:
            screenshot_id = db.insert_and_get_id(
                """
                INSERT INTO screenshot_log
                    (execution_id, source_system, module_name, function_name,
                     step_name, site_name, enterprise_name,
                     call_id_or_case_id, screenshot_path)
                VALUES
                    (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    execution_id, source_system, module_name, function_name,
                    step_name, site_name, enterprise_name,
                    call_id_or_case_id, str(screenshot_path),
                ),
            )

        return screenshot_id

    except Exception as error:
        _log_failure("insert_screenshot_log", error)
        return None


# ==========================================================
# ERROR LOG
# ==========================================================

def insert_error_log(source_system, module_name, function_name, step_name,
                       error_message, error_trace="", site_name="",
                       enterprise_name="", call_id_or_case_id="",
                       screenshot_path=""):
    """
    Inserts an error_log row. Also flips automation_process_status to
    PARTIALLY_COMPLETED if it is not already FAILED, so a single business
    error does not silently disappear.

    This function is deliberately very defensive - if MySQL is completely
    down, it falls back to a plain file log line so the error is never lost.
    """

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled():
        logger.error(
            "AUTOMATION ERROR (DB disabled) | %s | %s | %s | %s",
            source_system, module_name, step_name, error_message,
        )
        return None

    try:
        with DatabaseManager() as db:
            error_id = db.insert_and_get_id(
                """
                INSERT INTO error_log
                    (execution_id, source_system, module_name, function_name,
                     step_name, site_name, enterprise_name,
                     call_id_or_case_id, error_message, error_trace,
                     screenshot_path)
                VALUES
                    (%s, %s, %s, %s,
                     %s, %s, %s,
                     %s, %s, %s,
                     %s)
                """,
                (
                    execution_id, source_system, module_name, function_name,
                    step_name, site_name, enterprise_name,
                    call_id_or_case_id, error_message, error_trace,
                    screenshot_path,
                ),
            )

        return error_id

    except Exception as error:
        logger.error(
            "DB error_log insert FAILED - logging to file only | %s | %s",
            error_message, error,
        )
        return None


# ==========================================================
# SQL UPDATE AUDIT  (Phase 6)
# ==========================================================

def insert_sql_update_audit(enterprise_name, date_range_mode, date_range_value,
                              custom_from_date, custom_to_date,
                              final_report_from_date, final_report_to_date,
                              from_datetime, to_datetime,
                              old_sql_condition, new_sql_condition,
                              full_sql_before, full_sql_after,
                              update_status, remarks=""):

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled() or not execution_id:
        return None

    try:
        with DatabaseManager() as db:
            sql_update_id = db.insert_and_get_id(
                """
                INSERT INTO sql_update_audit
                    (execution_id, enterprise_name, report_name,
                     date_range_mode, date_range_value,
                     custom_from_date, custom_to_date,
                     final_report_from_date, final_report_to_date,
                     from_datetime, to_datetime, sql_section_updated,
                     old_sql_condition, new_sql_condition,
                     full_sql_before, full_sql_after,
                     update_status, remarks)
                VALUES
                    (%s, %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s, %s,
                     %s, %s,
                     %s, %s,
                     %s, %s)
                """,
                (
                    execution_id, enterprise_name, "Line Listing MICC",
                    date_range_mode, date_range_value,
                    custom_from_date, custom_to_date,
                    final_report_from_date, final_report_to_date,
                    from_datetime, to_datetime, "CASE_RECEIVED_DATE",
                    old_sql_condition, new_sql_condition,
                    full_sql_before, full_sql_after,
                    update_status, remarks,
                ),
            )

        logger.info(
            "DB sql_update_audit row inserted | enterprise=%s | status=%s",
            enterprise_name, update_status,
        )

        return sql_update_id

    except Exception as error:
        _log_failure("insert_sql_update_audit", error)
        return None


# ==========================================================
# EMAIL CONFIG  +  EMAIL STATUS  (Phase 9)
# ==========================================================

def get_active_email_config(config_name):

    if not is_db_enabled():
        return None

    try:
        with DatabaseManager() as db:
            row = db.fetch_one(
                """
                SELECT * FROM email_config
                WHERE config_name = %s AND is_active = TRUE
                ORDER BY email_config_id DESC
                LIMIT 1
                """,
                (config_name,),
            )

        return row

    except Exception as error:
        _log_failure("get_active_email_config", error)
        return None


def insert_email_status(email_config_id, mail_type, mail_subject, from_email,
                          to_emails, cc_emails, bcc_emails,
                          attachment_included, attachment_paths,
                          attachment_missing_reason, send_status,
                          error_message="", error_trace="", remarks=""):

    execution_id = runtime_context.get_execution_id()

    if not is_db_enabled():
        return None

    try:
        with DatabaseManager() as db:
            email_status_id = db.insert_and_get_id(
                """
                INSERT INTO email_status
                    (execution_id, email_config_id, mail_type, mail_subject,
                     from_email, to_emails, cc_emails, bcc_emails,
                     attachment_included, attachment_paths,
                     attachment_missing_reason, send_status, sent_at,
                     error_message, error_trace, remarks)
                VALUES
                    (%s, %s, %s, %s,
                     %s, %s, %s, %s,
                     %s, %s,
                     %s, %s, %s,
                     %s, %s, %s)
                """,
                (
                    execution_id, email_config_id, mail_type, mail_subject,
                    from_email, to_emails, cc_emails, bcc_emails,
                    bool(attachment_included), attachment_paths,
                    attachment_missing_reason, send_status, _now(),
                    error_message, error_trace, remarks,
                ),
            )

        if execution_id:
            update_email_status_on_execution(send_status)

        return email_status_id

    except Exception as error:
        _log_failure("insert_email_status", error)
        return None
