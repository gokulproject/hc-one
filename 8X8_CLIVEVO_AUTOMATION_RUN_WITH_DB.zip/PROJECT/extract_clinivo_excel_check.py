import os
import re
import glob
import logging
from datetime import datetime
from collections import Counter

import config
import pandas as pd

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

try:
    import db_helpers
except Exception:
    db_helpers = None


# ==========================================================
# CONFIGURATION
# ==========================================================

# ==========================================================
# CONFIGURATION
# Source of truth is config.py.
# Do not edit values in this file.
# ==========================================================

ADVAGEN_CLINIVO_EXCEL_FOLDER = str(
    config.ADVAGEN_CLINEVO_EXCEL_FOLDER
)

VALIDUS_CLINIVO_EXCEL_FOLDER = str(
    config.VALIDUS_CLINEVO_EXCEL_FOLDER
)

ADVAGEN_LOCAL_AUDIO_FOLDER = str(
    config.ADVAGEN_LOCAL_DOCUMENT_FOLDER
)

VALIDUS_LOCAL_AUDIO_FOLDER = str(
    config.VALIDUS_LOCAL_DOCUMENT_FOLDER
)

SITE_CONFIG = {
    "Advagen MICC": {
        "excel_folder": ADVAGEN_CLINIVO_EXCEL_FOLDER,
        "audio_folder": ADVAGEN_LOCAL_AUDIO_FOLDER,
        "sheet_name": "Advagen",
    },
    "Validus MICC": {
        "excel_folder": VALIDUS_CLINIVO_EXCEL_FOLDER,
        "audio_folder": VALIDUS_LOCAL_AUDIO_FOLDER,
        "sheet_name": "Validus",
    },
}

REPORT_FOLDER = str(
    config.CLINEVO_REPORT_FOLDER
)

REPORT_FILE = str(
    config.CLINEVO_REPORT_FILE
)

SUPPORTED_AUDIO_EXTENSIONS = tuple(
    ext for ext in config.SUPPORTED_LOCAL_FILE_EXTENSIONS
    if ext.lower() in (
        ".wav",
        ".mp3",
        ".m4a",
        ".wma",
        ".aac",
        ".ogg",
        ".flac",
    )
)

config.create_required_folders()


# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)


# ==========================================================
# COMMON HELPERS
# ==========================================================

def safe_string(value):
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    try:
        if hasattr(value, "strftime"):
            return value.strftime("%d-%b-%Y").upper()
    except Exception:
        pass

    return str(value).strip()


def normalize_column_name(value):
    text = safe_string(value)
    text = text.replace("\n", " ")
    text = text.replace("\r", " ")
    text = text.replace("\xa0", " ")
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "", text)
    return text


def normalize_case_id(value):
    text = safe_string(value)
    text = text.strip().upper()
    text = re.sub(r"\s+", "", text)
    return text


def normalize_file_name(value):
    text = safe_string(value)
    text = text.upper().strip()
    return text


def normalize_folder_text(value):
    text = safe_string(value)
    text = text.upper()
    text = text.replace("_", " ")
    text = text.replace("-", " ")
    text = text.replace(".", " ")
    text = re.sub(r"\s+", " ", text)
    text = text.strip()
    return text


def latest_excel_files(folder_path):
    if not os.path.exists(folder_path):
        logger.warning(f"Excel folder does not exist: {folder_path}")
        return []

    files = []
    files.extend(glob.glob(os.path.join(folder_path, "*.xlsx")))
    files.extend(glob.glob(os.path.join(folder_path, "*.xls")))

    files = [
        file for file in files
        if not os.path.basename(file).startswith("~$")
    ]

    files.sort(
        key=lambda path: os.path.getmtime(path),
        reverse=True
    )

    return files


def get_excel_engine(excel_file):
    extension = os.path.splitext(excel_file)[1].lower()

    if extension == ".xlsx":
        return "openpyxl"

    if extension == ".xls":
        return "xlrd"

    return None


# ==========================================================
# DATE HELPERS
# ==========================================================

def parse_received_date(value):
    if value is None:
        return None

    try:
        if pd.isna(value):
            return None
    except Exception:
        pass

    if isinstance(value, datetime):
        return value

    if hasattr(value, "to_pydatetime"):
        try:
            return value.to_pydatetime()
        except Exception:
            pass

    if hasattr(value, "strftime"):
        try:
            return value
        except Exception:
            pass

    text = str(value).strip()

    if not text:
        return None

    text = text.upper()
    text = text.replace(".", "-")
    text = re.sub(r"\s+", " ", text)

    date_formats = [
        "%d-%b-%Y",
        "%d-%B-%Y",
        "%d %b %Y",
        "%d %B %Y",
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%m/%d/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M:%S",
        "%d-%m-%Y",
        "%m-%d-%Y"
    ]

    for fmt in date_formats:
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            pass

    try:
        parsed = pd.to_datetime(text, errors="coerce")
        if not pd.isna(parsed):
            return parsed.to_pydatetime()
    except Exception:
        pass

    return None


def get_date_key(value):
    dt = parse_received_date(value)

    if not dt:
        return ""

    return dt.strftime("%Y-%m-%d")


def format_received_date(value):
    dt = parse_received_date(value)

    if not dt:
        return safe_string(value)

    return dt.strftime("%d-%b-%Y").upper()


def build_exact_date_folder_paths(base_folder, received_date):
    dt = parse_received_date(received_date)

    if not dt:
        return []

    year_folder = dt.strftime("%Y")
    year = dt.strftime("%Y")
    month_short = dt.strftime("%b").upper()
    month_full = dt.strftime("%B").upper()

    day_no_zero = str(dt.day)
    day_zero = dt.strftime("%d")

    month_folder_options = [
        f"{month_short} {year}",
        f"{month_full} {year}"
    ]

    date_folder_options = [
        f"{day_no_zero} {month_short} {year}",
        f"{day_zero} {month_short} {year}",
        f"{day_no_zero} {month_full} {year}",
        f"{day_zero} {month_full} {year}",
        f"{day_no_zero}-{month_short}-{year}",
        f"{day_zero}-{month_short}-{year}",
        f"{day_no_zero}-{month_full}-{year}",
        f"{day_zero}-{month_full}-{year}",
        dt.strftime("%Y-%m-%d"),
        dt.strftime("%d-%m-%Y"),
        dt.strftime("%m-%d-%Y")
    ]

    possible_paths = []

    for month_folder in month_folder_options:
        for date_folder in date_folder_options:
            possible_paths.append(
                os.path.join(
                    base_folder,
                    year_folder,
                    month_folder,
                    date_folder
                )
            )

    return possible_paths


def folder_name_matches_received_date(folder_name, received_date):
    folder_dt = parse_received_date(folder_name)
    received_dt = parse_received_date(received_date)

    if folder_dt and received_dt:
        return folder_dt.strftime("%Y-%m-%d") == received_dt.strftime("%Y-%m-%d")

    return False


def find_existing_date_folder_dynamic(base_folder, received_date):
    if not os.path.exists(base_folder):
        logger.warning(f"Audio base folder does not exist: {base_folder}")
        return ""

    exact_paths = build_exact_date_folder_paths(
        base_folder,
        received_date
    )

    for folder_path in exact_paths:
        if os.path.exists(folder_path) and os.path.isdir(folder_path):
            logger.info(f"Date folder found by exact path: {folder_path}")
            return folder_path

    received_dt = parse_received_date(received_date)

    if not received_dt:
        return ""

    received_year = received_dt.strftime("%Y")
    received_month_short = received_dt.strftime("%b").upper()

    expected_1 = f"{received_dt.day} {received_month_short} {received_year}"
    expected_2 = f"{received_dt.day:02d} {received_month_short} {received_year}"

    for root, dirs, files in os.walk(base_folder):
        for folder_name in dirs:
            folder_path = os.path.join(root, folder_name)

            if folder_name_matches_received_date(folder_name, received_date):
                logger.info(f"Date folder found by parsed dynamic search: {folder_path}")
                return folder_path

            normalized_folder_name = normalize_folder_text(folder_name)

            if normalized_folder_name in [
                normalize_folder_text(expected_1),
                normalize_folder_text(expected_2)
            ]:
                logger.info(f"Date folder found by normalized dynamic search: {folder_path}")
                return folder_path

    logger.warning(
        f"Date folder not found dynamically for received date: {received_date} | "
        f"Base folder: {base_folder}"
    )

    return ""


# ==========================================================
# CASE ID EXTRACTION
# ==========================================================

def extract_case_id_from_text(value):
    """
    Extract proper Case ID from text.

    Required format:
    WORD-WORD-YEAR-NUMBER

    Regex used:
    \\b[A-Z]+-[A-Z]+-\\d{4}-\\d+(?=\\D|$)

    Examples:
    ADV-US-2026-0999 15 JUL 2026 OBFU call
    -> ADV-US-2026-0999

    ADV-US-2026-1000-IN-15-JUL2
    -> ADV-US-2026-1000

    ADV-US-2026-1001FU 01 15-Jul-2026
    -> ADV-US-2026-1001
    """

    text = safe_string(value)

    if not text:
        return ""

    # Important:
    # Do not remove spaces before regex.
    # If spaces are removed, ADV-US-2026-0999 15 becomes ADV-US-2026-099915.
    text = text.upper().strip()

    match = re.search(
        r"\b[A-Z]+-[A-Z]+-\d{4}-\d+(?=\D|$)",
        text
    )

    if match:
        return match.group(0).strip().upper()

    return ""


def extract_case_id_from_audio_file_name(audio_file_name):
    file_name_without_extension = os.path.splitext(audio_file_name)[0]
    return extract_case_id_from_text(file_name_without_extension)


# ==========================================================
# EXCEL READING
# ==========================================================

def find_header_row(excel_file):
    engine = get_excel_engine(excel_file)

    preview_df = pd.read_excel(
        excel_file,
        header=None,
        dtype=str,
        engine=engine
    )

    max_rows_to_scan = min(30, len(preview_df))

    for row_index in range(max_rows_to_scan):
        row_values = []

        for value in preview_df.iloc[row_index].tolist():
            normalized_value = normalize_column_name(value)

            if normalized_value:
                row_values.append(normalized_value)

        has_case_id = any(
            item in [
                "casenumber",
                "caseno",
                "caseid",
                "case"
            ]
            for item in row_values
        )

        has_received_date = any(
            item in [
                "casereceiveddate",
                "receiveddate",
                "reciveddate",
                "casecreateddate",
                "createddate"
            ]
            for item in row_values
        )

        if has_case_id and has_received_date:
            return row_index

    return None


def find_columns(df):
    case_id_column = None
    received_date_column = None

    for col in df.columns:
        normalized_col = normalize_column_name(col)

        if normalized_col in [
            "casenumber",
            "caseno",
            "caseid",
            "case"
        ]:
            case_id_column = col

        elif normalized_col in [
            "casereceiveddate",
            "receiveddate",
            "reciveddate",
            "casecreateddate",
            "createddate"
        ]:
            received_date_column = col

    return {
        "case_id_column": case_id_column,
        "received_date_column": received_date_column
    }


def extract_cases_from_excel_with_header(excel_file, site_name, header_row):
    engine = get_excel_engine(excel_file)

    df = pd.read_excel(
        excel_file,
        header=header_row,
        dtype=str,
        engine=engine
    )

    df.columns = [
        safe_string(col)
        for col in df.columns
    ]

    columns = find_columns(df)

    case_id_column = columns["case_id_column"]
    received_date_column = columns["received_date_column"]

    if not case_id_column:
        logger.warning(f"Case ID column not found in file: {excel_file}")
        return []

    if not received_date_column:
        logger.warning(f"Received Date column not found in file: {excel_file}")
        return []

    logger.info(f"Case ID column: {case_id_column}")
    logger.info(f"Received Date column: {received_date_column}")

    cases = []

    for index, row in df.iterrows():
        case_id = extract_case_id_from_text(
            row.get(case_id_column, "")
        )

        received_date_raw = row.get(
            received_date_column,
            ""
        )

        date_key = get_date_key(received_date_raw)

        if not case_id or not date_key:
            continue

        cases.append(
            {
                "site_name": site_name,
                "case_id": case_id,
                "received_date_raw": received_date_raw,
                "received_date": format_received_date(received_date_raw),
                "date_key": date_key,
                "source_excel_file": excel_file,
                "raw_row_data": row.to_dict(),
            }
        )

    return cases


def extract_cases_from_excel_without_header(excel_file, site_name):
    """
    Fallback logic for Clinivo Excel files without headers.

    It scans every row and finds:
    1. First valid Case ID in the row
    2. First valid date in the row
    """

    engine = get_excel_engine(excel_file)

    df = pd.read_excel(
        excel_file,
        header=None,
        dtype=str,
        engine=engine
    )

    cases = []

    for index, row in df.iterrows():
        row_values = row.tolist()

        case_id = ""
        received_date_raw = ""

        for value in row_values:
            extracted_case_id = extract_case_id_from_text(value)

            if extracted_case_id:
                case_id = extracted_case_id
                break

        for value in row_values:
            parsed_date = parse_received_date(value)

            if parsed_date:
                received_date_raw = value
                break

        date_key = get_date_key(received_date_raw)

        if not case_id or not date_key:
            continue

        cases.append(
            {
                "site_name": site_name,
                "case_id": case_id,
                "received_date_raw": received_date_raw,
                "received_date": format_received_date(received_date_raw),
                "date_key": date_key,
                "source_excel_file": excel_file,
                "raw_row_data": {
                    str(col_index): value
                    for col_index, value in enumerate(row_values)
                },
            }
        )

    return cases


def extract_cases_from_excel(excel_file, site_name):
    logger.info("-" * 100)
    logger.info(f"Reading Clinivo Excel: {excel_file}")

    header_row = find_header_row(excel_file)

    if header_row is not None:
        logger.info(f"Header row found at Excel row: {header_row + 1}")

        cases = extract_cases_from_excel_with_header(
            excel_file,
            site_name,
            header_row
        )
    else:
        logger.warning(
            "Header row not found. Using fallback mode: scan rows for Case ID and Date."
        )

        cases = extract_cases_from_excel_without_header(
            excel_file,
            site_name
        )

    logger.info(f"Cases extracted from file: {len(cases)}")

    return cases


def extract_all_cases():
    all_site_data = {}

    for site_name, site_config in SITE_CONFIG.items():
        excel_folder = site_config["excel_folder"]
        excel_files = latest_excel_files(excel_folder)

        logger.info("=" * 100)
        logger.info(f"Excel extraction started for site: {site_name}")
        logger.info(f"Excel folder: {excel_folder}")
        logger.info(f"Excel files found: {len(excel_files)}")

        site_cases = []

        if not excel_files:
            logger.warning(f"No Excel files found for site: {site_name}")
            all_site_data[site_name] = []
            continue

        for excel_file in excel_files:
            cases = extract_cases_from_excel(
                excel_file,
                site_name
            )

            site_cases.extend(cases)

        all_site_data[site_name] = site_cases

        # ==========================================================
        # NEW: Store every extracted case into clinevo_case_record.
        # Phase 5. This does not filter/change any case - all cases are
        # stored, exactly like site_cases used by the rest of the logic.
        # ==========================================================
        if db_helpers is not None:
            try:
                enterprise_name = site_name.replace("MICC", "").strip()
                db_helpers.insert_clinevo_case_records(
                    enterprise_name,
                    site_name,
                    site_cases,
                )
            except Exception as db_error:
                logger.warning(
                    f"DB insert for clinevo_case_record failed ({site_name}): {db_error}"
                )

    return all_site_data

# ==========================================================
# AUDIO FILE CHECK
# ==========================================================

def list_audio_files(date_folder):
    if not date_folder:
        return []

    if not os.path.exists(date_folder):
        return []

    audio_files = []

    for root, dirs, files in os.walk(date_folder):
        for file_name in files:
            if file_name.lower().endswith(SUPPORTED_AUDIO_EXTENSIONS):
                audio_files.append(
                    {
                        "file_name": file_name,
                        "file_path": os.path.join(root, file_name),
                        "folder_path": root
                    }
                )

    return audio_files


def group_cases_by_received_date(cases):
    grouped = {}

    for case_item in cases:
        date_key = case_item["date_key"]

        if date_key not in grouped:
            grouped[date_key] = {
                "received_date": case_item["received_date"],
                "received_date_raw": case_item["received_date_raw"],
                "case_ids": []
            }

        grouped[date_key]["case_ids"].append(case_item["case_id"])

    return grouped


def check_audio_case_id_present_in_excel(site_name, cases):
    """
    Final logic:

    Base = Audio file.

    For each audio file:
    1. Extract Case ID from audio file name.
    2. Count that Case ID in Clinivo Excel for the same received date.
    3. If Excel Case ID Count = 0:
       Status = Missing in Clinivo Excel
    4. If Excel Case ID Count = 1:
       Status = Present in Clinivo Excel
    5. If Excel Case ID Count > 1:
       Status = Present in Clinivo Excel - Duplicate Found
    """

    report_rows = []

    config = SITE_CONFIG.get(site_name, {})
    audio_base_folder = config.get("audio_folder", "")

    grouped_cases = group_cases_by_received_date(cases)

    for date_key, date_data in grouped_cases.items():
        received_date = date_data["received_date"]
        received_date_raw = date_data["received_date_raw"]
        excel_case_ids = date_data["case_ids"]

        excel_case_ids_normalized = [
            normalize_case_id(case_id)
            for case_id in excel_case_ids
            if normalize_case_id(case_id)
        ]

        excel_counter = Counter(excel_case_ids_normalized)

        logger.info("-" * 100)
        logger.info(f"Site: {site_name}")
        logger.info(f"Received Date: {received_date}")
        logger.info(f"Total Excel Case ID rows for date: {len(excel_case_ids_normalized)}")
        logger.info(f"Unique Excel Case IDs for date: {len(excel_counter)}")

        date_folder = find_existing_date_folder_dynamic(
            audio_base_folder,
            received_date_raw
        )

        if not date_folder:
            report_rows.append(
                {
                    "Received Date": received_date,
                    "Audio File Name": "",
                    "Audio Folder Path": "",
                    "Extracted Case ID": "",
                    "Excel Case ID Count": 0,
                    "Status": "Date Folder Missing",
                    "Remarks": "Audio date folder not found"
                }
            )
            continue

        logger.info(f"Using date folder: {date_folder}")

        audio_files = list_audio_files(date_folder)

        audio_files.sort(
            key=lambda item: normalize_file_name(item["file_name"])
        )

        if not audio_files:
            report_rows.append(
                {
                    "Received Date": received_date,
                    "Audio File Name": "",
                    "Audio Folder Path": date_folder,
                    "Extracted Case ID": "",
                    "Excel Case ID Count": 0,
                    "Status": "No Audio Files",
                    "Remarks": "No audio files found in date folder"
                }
            )
            continue

        for audio_item in audio_files:
            audio_file_name = audio_item["file_name"]
            audio_folder_path = audio_item["folder_path"]

            extracted_case_id = extract_case_id_from_audio_file_name(
                audio_file_name
            )

            if not extracted_case_id:
                excel_count = 0
                status = "Case ID Not Found in Audio File Name"
                remarks = "Unable to extract Case ID from audio file name"
            else:
                excel_count = excel_counter.get(extracted_case_id, 0)

                if excel_count == 0:
                    status = "Missing in Clinivo Excel"
                    remarks = "Extracted Case ID is not found in Clinivo Excel"
                elif excel_count == 1:
                    status = "Present in Clinivo Excel"
                    remarks = "Extracted Case ID is available in Clinivo Excel"
                else:
                    status = "Present in Clinivo Excel - Duplicate Found"
                    remarks = "Extracted Case ID is available more than once in Clinivo Excel"

            report_rows.append(
                {
                    "Received Date": received_date,
                    "Audio File Name": audio_file_name,
                    "Audio Folder Path": audio_folder_path,
                    "Extracted Case ID": extracted_case_id if extracted_case_id else "Not Found",
                    "Excel Case ID Count": excel_count,
                    "Status": status,
                    "Remarks": remarks
                }
            )

    return report_rows


# ==========================================================
# REPORT
# ==========================================================

def create_empty_report_dataframe():
    return pd.DataFrame(
        columns=[
            "Received Date",
            "Audio File Name",
            "Audio Folder Path",
            "Extracted Case ID",
            "Excel Case ID Count",
            "Status",
            "Remarks"
        ]
    )


def write_report(site_report_data):
    os.makedirs(
        REPORT_FOLDER,
        exist_ok=True
    )

    with pd.ExcelWriter(
        REPORT_FILE,
        engine="openpyxl"
    ) as writer:
        for site_name, report_rows in site_report_data.items():
            sheet_name = SITE_CONFIG[site_name]["sheet_name"]

            report_df = pd.DataFrame(report_rows)

            if report_df.empty:
                report_df = create_empty_report_dataframe()

            report_df = report_df[
                [
                    "Received Date",
                    "Audio File Name",
                    "Audio Folder Path",
                    "Extracted Case ID",
                    "Excel Case ID Count",
                    "Status",
                    "Remarks"
                ]
            ]

            report_df.to_excel(
                writer,
                sheet_name=sheet_name,
                index=False
            )

    style_report(REPORT_FILE)

    logger.info(f"Report generated: {os.path.abspath(REPORT_FILE)}")


def style_report(file_path):
    workbook = load_workbook(file_path)

    header_fill = PatternFill(
        start_color="1F4E78",
        end_color="1F4E78",
        fill_type="solid"
    )

    header_font = Font(
        color="FFFFFF",
        bold=True
    )

    present_fill = PatternFill(
        start_color="C6EFCE",
        end_color="C6EFCE",
        fill_type="solid"
    )

    missing_fill = PatternFill(
        start_color="FFC7CE",
        end_color="FFC7CE",
        fill_type="solid"
    )

    duplicate_fill = PatternFill(
        start_color="FFEB9C",
        end_color="FFEB9C",
        fill_type="solid"
    )

    warning_fill = PatternFill(
        start_color="FCE4D6",
        end_color="FCE4D6",
        fill_type="solid"
    )

    header_alignment = Alignment(
        horizontal="center",
        vertical="center",
        wrap_text=True
    )

    normal_alignment = Alignment(
        horizontal="left",
        vertical="center",
        wrap_text=True
    )

    center_alignment = Alignment(
        horizontal="center",
        vertical="center",
        wrap_text=True
    )

    thin_border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9")
    )

    status_fill_map = {
        "Present in Clinivo Excel": present_fill,
        "Present in Clinivo Excel - Duplicate Found": duplicate_fill,
        "Missing in Clinivo Excel": missing_fill,
        "Case ID Not Found in Audio File Name": warning_fill,
        "Date Folder Missing": warning_fill,
        "No Audio Files": warning_fill
    }

    for sheet in workbook.worksheets:
        sheet.freeze_panes = "A2"

        if sheet.max_row >= 1 and sheet.max_column >= 1:
            sheet.auto_filter.ref = sheet.dimensions

        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = header_alignment
            cell.border = thin_border

        sheet.row_dimensions[1].height = 32

        status_col = None
        count_col = None

        for col_num in range(1, sheet.max_column + 1):
            header_value = sheet.cell(row=1, column=col_num).value

            if header_value == "Status":
                status_col = col_num

            if header_value == "Excel Case ID Count":
                count_col = col_num

        for row_num in range(2, sheet.max_row + 1):
            sheet.row_dimensions[row_num].height = 24

            for col_num in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=row_num, column=col_num)
                cell.border = thin_border
                cell.alignment = normal_alignment

            if count_col:
                sheet.cell(row=row_num, column=count_col).alignment = center_alignment

            if status_col:
                status_cell = sheet.cell(row=row_num, column=status_col)
                status_value = status_cell.value

                status_cell.alignment = center_alignment
                status_cell.font = Font(bold=True)

                status_fill = status_fill_map.get(status_value)

                if status_fill:
                    status_cell.fill = status_fill

        for col_num in range(1, sheet.max_column + 1):
            column_letter = get_column_letter(col_num)
            header_value = sheet.cell(row=1, column=col_num).value

            if header_value == "Received Date":
                sheet.column_dimensions[column_letter].width = 18
            elif header_value == "Audio File Name":
                sheet.column_dimensions[column_letter].width = 45
            elif header_value == "Audio Folder Path":
                sheet.column_dimensions[column_letter].width = 60
            elif header_value == "Extracted Case ID":
                sheet.column_dimensions[column_letter].width = 24
            elif header_value == "Excel Case ID Count":
                sheet.column_dimensions[column_letter].width = 20
            elif header_value == "Status":
                sheet.column_dimensions[column_letter].width = 35
            elif header_value == "Remarks":
                sheet.column_dimensions[column_letter].width = 55
            else:
                max_length = 0

                for row_num in range(1, sheet.max_row + 1):
                    value = sheet.cell(row=row_num, column=col_num).value

                    if value is not None:
                        max_length = max(max_length, len(str(value)))

                sheet.column_dimensions[column_letter].width = min(max_length + 3, 80)

    workbook.save(file_path)


# ==========================================================
# MAIN
# ==========================================================


def process_clinivo_case_check():

    logger.info("=" * 100)
    logger.info("PROCESS STARTED | AUDIO FILE CASE ID PRESENT IN CLINIVO EXCEL CHECK")
    logger.info("=" * 100)

    all_site_cases = extract_all_cases()

    site_report_data = {}

    for site_name in SITE_CONFIG.keys():
        cases = all_site_cases.get(site_name, [])

        logger.info("=" * 100)
        logger.info(f"Processing site: {site_name}")
        logger.info(f"Total cases extracted from Clinivo Excel: {len(cases)}")

        if not cases:
            site_report_data[site_name] = []
            continue

        site_report_rows = check_audio_case_id_present_in_excel(
            site_name,
            cases
        )

        site_report_data[site_name] = site_report_rows

        # ==========================================================
        # NEW: Store the audio-vs-case-id validation outcome for this
        # site into clinevo_case_audio_result. Phase 5.
        # ==========================================================
        if db_helpers is not None:
            try:
                enterprise_name = site_name.replace("MICC", "").strip()
                db_helpers.insert_clinevo_case_audio_results(
                    enterprise_name,
                    site_name,
                    site_report_rows,
                )
            except Exception as db_error:
                logger.warning(
                    f"DB insert for clinevo_case_audio_result failed ({site_name}): {db_error}"
                )

    write_report(site_report_data)

    logger.info("=" * 100)
    logger.info("PROCESS COMPLETED | AUDIO FILE CASE ID PRESENT IN CLINIVO EXCEL CHECK")
    logger.info(f"Report file: {os.path.abspath(REPORT_FILE)}")
    logger.info("=" * 100)


if __name__ == "__main__":
    process_clinivo_case_check()