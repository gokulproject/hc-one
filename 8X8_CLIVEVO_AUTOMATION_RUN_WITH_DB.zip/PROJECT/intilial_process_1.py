import config
import asyncio
import subprocess
import os
import logging
from datetime import datetime
import re

from playwright.async_api import (
    async_playwright,
    expect,
    Page,
    Browser,
    TimeoutError as PlaywrightTimeoutError
)

try:
    import db_helpers
except Exception:
    db_helpers = None



# =====================================================
# CONFIGURATION
# Source of truth is config.py.
# Do not edit values in this file.
# =====================================================

USERNAME = config.USERNAME
PASSWORD = config.PASSWORD

DATE_RANGE = config.DATE_RANGE
INPUT_FROM_DATERANGE = config.INPUT_FROM_DATERANGE
INPUT_TO_DATERANGE = config.INPUT_TO_DATERANGE

TIME_ZONE = config.TIME_ZONE

SITE_FILTER_1 = config.SITE_FILTER_1
SITE_FILTER_2 = config.SITE_FILTER_2

SITE_FILTER_1_DOWNLOAD_FOLDER = str(
    config.ADVAGEN_EXCEL_FOLDER
)

SITE_FILTER_2_DOWNLOAD_FOLDER = str(
    config.VALIDUS_EXCEL_FOLDER
)

ANALYTICS_URL = config.ANALYTICS_URL
CHROME_DEBUG_URL = config.CHROME_DEBUG_URL
CHROME_EXE_PATH = config.CHROME_EXE_PATH
CHROME_USER_DATA_DIR = config.CHROME_USER_DATA_DIR

config.create_required_folders()

# os.makedirs(SITE_FILTER_1_DOWNLOAD_FOLDER, exist_ok=True)
# os.makedirs(SITE_FILTER_2_DOWNLOAD_FOLDER, exist_ok=True)

SCREENSHOT_FOLDER = str(
    config.PROCESS1_SCREENSHOT_FOLDER
)

# =====================================================
# LOGGING
# =====================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)


# =====================================================
# START CHROME
# =====================================================

async def start_chrome():

    try:

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            await browser.close()

            logger.info("Chrome already running")

            return True

    except Exception:

        logger.info("Starting Chrome")

        subprocess.Popen([
        CHROME_EXE_PATH,
        "--remote-debugging-port=9222",
        f"--user-data-dir={CHROME_USER_DATA_DIR}",
        "--start-maximized",
        "--no-first-run"
        ])

        for i in range(20):

            await asyncio.sleep(1)

            try:

                async with async_playwright() as p:

                    browser = await p.chromium.connect_over_cdp(
                        CHROME_DEBUG_URL
                    )

                    await browser.close()

                    logger.info("Chrome Started")

                    return True

            except Exception:

                logger.info(
                    f"Waiting Chrome Startup {i+1}/20"
                )

        return False

# =====================================================
# LOGIN
# =====================================================

async def login(page: Page):

    try:

        logger.info("Opening Login Page")

        await page.goto(
            "https://sso.8x8.com/v2/login",
            wait_until="domcontentloaded",
            timeout=60000
        )

        username_box = page.get_by_role(
            "textbox",
            name="Username / Email"
        )

        await expect(
            username_box
        ).to_be_visible()

        await username_box.fill(USERNAME)

        logger.info("Username Entered")

        continue_btn = page.get_by_role(
            "button",
            name="Continue"
        )

        await continue_btn.click()

        password_box = page.locator(
            'input[type="password"]'
        )

        await expect(
            password_box
        ).to_be_visible()

        await password_box.fill(PASSWORD)

        logger.info("Password Entered")

        login_btn = page.get_by_role(
            "button",
            name="Login"
        )

        await login_btn.click()

        logger.info("Login Clicked")

        await page.wait_for_timeout(5000)

        if "/mfa" in page.url:

            logger.error(
                "MFA Authentication Required"
            )

            await take_screenshot(
                page,
                "mfa_authentication"
            )

            raise Exception(
                "MFA Required"
            )

        logger.info("Login Completed")

    except Exception as e:

        logger.error(f"Login Failed : {e}")

        await take_screenshot(
            page,
            "login_error"
        )

        raise

# =====================================================
# ENSURE LOGIN
# =====================================================

async def ensure_login(page):

    try:

        logger.info("Checking Login Status")

        await page.goto(
            ANALYTICS_URL,
            wait_until="domcontentloaded",
            timeout=60000
        )

        await page.wait_for_timeout(5000)

        try:

            await expect(
                page.get_by_text(
                    "My Applications",
                    exact=False
                )
            ).to_be_visible(
                timeout=10000
            )

            logger.info(
                "Already Logged In"
            )

            return

        except Exception:

            logger.info(
                "Login Required"
            )

        await login(page)

        await page.goto(
            ANALYTICS_URL,
            wait_until="domcontentloaded"
        )

        await expect(
            page.get_by_text(
                "My Applications",
                exact=False
            )
        ).to_be_visible()

        logger.info("Login Successful")

    except Exception as e:

        logger.error(
            f"Ensure Login Failed : {e}"
        )

        raise

# =====================================================
# OPEN ANALYTICS
# =====================================================

async def open_analytics(page):

    try:

        logger.info(
            "Opening Analytics For 8x8 Work"
        )

        async with page.expect_popup(
            timeout=120000
        ) as popup:

            await page.get_by_role(
                "link",
                name="Analytics for 8x8 Work"
            ).click()

        analytics_page = await popup.value

        await analytics_page.wait_for_load_state(
            "domcontentloaded"
        )

        await expect(
            analytics_page.locator(
                'iframe[title="Company Summary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        logger.info(
            "Analytics Page Opened"
        )

        return analytics_page

    except Exception as e:

        logger.error(
            f"Analytics Opening Failed : {e}"
        )

        raise
        
# ======================================================
# caputure the date range after date range clicked 
# =====================================================
async def capture_selected_date_range(frame):

    try:

        logger.info(
            "Capturing selected From and To date"
        )

        header = frame.locator(
            '[data-test-id="voaheader.CompanySummary"]'
        )

        await expect(
            header
        ).to_be_visible(
            timeout=30000
        )

        # Wait for UI to update after DATE_RANGE click
        await asyncio.sleep(1)

        header_text = await header.inner_text()

        cleaned_text = (
            header_text
            .replace("\n", "")
            .replace(" ", "")
        )

        logger.info(
            f"Company Summary Date Text : {cleaned_text}"
        )

        # Capture all dates from header text
        # Example text:
        # Company Summary07/08/202607/08/202600:0024:00America/New_Yorknavitasinc
        date_values = re.findall(
            r"\d{2}/\d{2}/\d{4}",
            cleaned_text
        )

        logger.info(
            f"Date Values Found : {date_values}"
        )

        if len(date_values) >= 2:

            from_date_raw = date_values[0]
            to_date_raw = date_values[1]

            # Convert MM/DD/YYYY to DD-MON-YYYY
            from_date = datetime.strptime(
                from_date_raw,
                "%m/%d/%Y"
            ).strftime(
                "%d-%b-%Y"
            ).upper()

            to_date = datetime.strptime(
                to_date_raw,
                "%m/%d/%Y"
            ).strftime(
                "%d-%b-%Y"
            ).upper()

            logger.info(
                f"Captured Date Period | From : {from_date} | To : {to_date}"
            )

            return from_date, to_date

        logger.warning(
            "Unable to find From and To dates in Company Summary header"
        )

        return None, None

    except Exception as e:

        logger.error(
            f"Capture Selected Date Range Failed : {e}"
        )

        raise

       
      

# =====================================================
# CUSTOM DATE PICKER FUNCTIONS
# =====================================================

def parse_custom_input_date(date_text):

    date_text = date_text.strip()

    supported_formats = [
        "%d-%m-%Y",
        "%d-%b-%Y",
        "%d-%B-%Y"
    ]

    for date_format in supported_formats:

        try:

            return datetime.strptime(
                date_text,
                date_format
            ).date()

        except ValueError:

            pass

    raise ValueError(
        f"Invalid date format : {date_text}. Use DD-MM-YYYY or DD-MON-YYYY. Example: 16-07-2026 or 16-JUL-2026"
    )


def get_expected_output_date(date_value):

    return date_value.strftime(
        "%d-%b-%Y"
    ).upper()


def get_calendar_input_date(date_value):

    return date_value.strftime(
        "%m/%d/%Y"
    )


def get_calendar_month_label(date_value):

    return date_value.strftime(
        "%b %Y"
    )


async def get_calendar_display_dates(frame):

    try:

        date_display_wrapper = frame.locator(
            ".rdrDateDisplayWrapper"
        ).first

        await expect(
            date_display_wrapper
        ).to_be_visible(
            timeout=30000
        )

        result = await date_display_wrapper.evaluate(
            """
            (root) => {

                const wrapperText = root.textContent
                    ? root.textContent.replace(/\\s+/g, "").trim()
                    : "";

                const fromMatch = wrapperText.match(/From(\\d{2}\\/\\d{2}\\/\\d{4})/);
                const toMatch = wrapperText.match(/To(\\d{2}\\/\\d{2}\\/\\d{4})/);

                return {
                    fromDate: fromMatch ? fromMatch[1] : null,
                    toDate: toMatch ? toMatch[1] : null,
                    wrapperText: wrapperText
                };
            }
            """
        )

        logger.info(
            f"Calendar Display Dates Current State : {result}"
        )

        return result

    except Exception as e:

        logger.error(
            f"Get Calendar Display Dates Failed : {e}"
        )

        raise


async def wait_calendar_display_dates(frame, expected_from_date, expected_to_date):

    try:

        logger.info(
            f"Waiting Calendar Display Dates | Expected From : {expected_from_date} | Expected To : {expected_to_date}"
        )

        last_result = None

        for attempt in range(20):

            result = await get_calendar_display_dates(
                frame
            )

            last_result = result

            if result["fromDate"] == expected_from_date and result["toDate"] == expected_to_date:

                logger.info(
                    f"Calendar Display Date Validation Passed | From : {expected_from_date} | To : {expected_to_date}"
                )

                return True

            logger.info(
                f"Calendar Display Not Updated Yet | Attempt : {attempt + 1}/20 | Current : {result}"
            )

            await asyncio.sleep(0.5)

        raise Exception(
            f"Calendar Display Date Validation Failed. "
            f"Expected From : {expected_from_date}, Expected To : {expected_to_date}, "
            f"Last Result : {last_result}"
        )

    except Exception as e:

        logger.error(
            f"Wait Calendar Display Dates Failed : {e}"
        )

        raise


async def click_date_display_item(frame, label_text):

    try:

        logger.info(
            f"Clicking Calendar Date Field : {label_text}"
        )

        date_display_wrapper = frame.locator(
            ".rdrDateDisplayWrapper"
        ).first

        await expect(
            date_display_wrapper
        ).to_be_visible(
            timeout=30000
        )

        result = await date_display_wrapper.evaluate(
            """
            (root, labelText) => {

                const dateRegex = /\\d{2}\\/\\d{2}\\/\\d{4}/;

                const allElements = Array.from(
                    root.querySelectorAll("div, span, button, input")
                );

                const matchingBlocks = allElements.filter(element => {

                    const text = element.textContent
                        ? element.textContent.replace(/\\s+/g, "").trim()
                        : "";

                    return text.startsWith(labelText) &&
                           dateRegex.test(text);

                });

                if (matchingBlocks.length === 0) {
                    throw new Error(
                        "No matching date field found for : " + labelText
                    );
                }

                const targetBlock = matchingBlocks[matchingBlocks.length - 1];

                const dateElement = Array.from(
                    targetBlock.querySelectorAll("span, button, input, div")
                ).find(element => {

                    const text = element.textContent
                        ? element.textContent.trim()
                        : "";

                    const value = element.value
                        ? element.value.trim()
                        : "";

                    return dateRegex.test(text) || dateRegex.test(value);

                });

                if (!dateElement) {
                    throw new Error(
                        "Date value element not found for : " + labelText
                    );
                }

                const currentDateText = dateElement.textContent
                    ? dateElement.textContent.trim()
                    : dateElement.value;

                targetBlock.click();
                dateElement.click();

                return {
                    label: labelText,
                    currentDateText: currentDateText,
                    wrapperText: root.textContent.replace(/\\s+/g, "").trim()
                };
            }
            """,
            label_text
        )

        logger.info(
            f"Calendar Date Field Clicked Successfully : {result}"
        )

        await asyncio.sleep(0.7)

    except Exception as e:

        logger.error(
            f"Click Calendar Date Field Failed For {label_text} : {e}"
        )

        raise


async def select_calendar_month_year(frame, target_date):

    try:

        year_value = str(
            target_date.year
        )

        month_value = str(
            target_date.month - 1
        )

        expected_month_label = get_calendar_month_label(
            target_date
        )

        logger.info(
            f"Selecting Calendar Month/Year | Year : {year_value} | Month Value : {month_value} | Expected Month : {expected_month_label}"
        )

        year_select = frame.locator(
            ".rdrYearPicker select"
        ).first

        month_select = frame.locator(
            ".rdrMonthPicker select"
        ).first

        await expect(
            year_select
        ).to_be_visible(
            timeout=30000
        )

        await expect(
            month_select
        ).to_be_visible(
            timeout=30000
        )

        year_exists = await year_select.evaluate(
            """
            (select, yearValue) => {
                return Array.from(select.options).some(option => option.value === yearValue);
            }
            """,
            year_value
        )

        if not year_exists:

            available_years = await year_select.evaluate(
                """
                (select) => {
                    return Array.from(select.options).map(option => option.value);
                }
                """
            )

            raise Exception(
                f"Year {year_value} not available in calendar dropdown. Available Years : {available_years}"
            )

        await year_select.select_option(
            value=year_value
        )

        logger.info(
            f"Calendar Year Selected : {year_value}"
        )

        await asyncio.sleep(0.3)

        await month_select.select_option(
            value=month_value
        )

        logger.info(
            f"Calendar Month Selected : {target_date.strftime('%B')}"
        )

        await asyncio.sleep(0.7)

        first_month = frame.locator(
            ".rdrMonth"
        ).first

        await expect(
            first_month
        ).to_be_visible(
            timeout=30000
        )

        await expect(
            first_month.get_by_text(
                expected_month_label,
                exact=True
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Calendar First Month Validation Passed : {expected_month_label}"
        )

    except Exception as e:

        logger.error(
            f"Select Calendar Month/Year Failed : {e}"
        )

        raise


async def click_calendar_day_from_first_month(frame, target_date):

    try:

        expected_month_label = get_calendar_month_label(
            target_date
        )

        day_text = str(
            target_date.day
        )

        logger.info(
            f"Picking Calendar Date | Month : {expected_month_label} | Day : {day_text}"
        )

        first_month = frame.locator(
            ".rdrMonth"
        ).first

        await expect(
            first_month
        ).to_be_visible(
            timeout=30000
        )

        await expect(
            first_month.get_by_text(
                expected_month_label,
                exact=True
            )
        ).to_be_visible(
            timeout=30000
        )

        active_day_buttons = first_month.locator(
            "button.rdrDay:not(.rdrDayPassive):not(.rdrDayDisabled)"
        ).filter(
            has_text=re.compile(
                rf"^{day_text}$"
            )
        )

        await expect(
            active_day_buttons.first
        ).to_be_visible(
            timeout=30000
        )

        await active_day_buttons.first.click()

        logger.info(
            f"Calendar Date Picked Successfully | Month : {expected_month_label} | Day : {day_text}"
        )

        await asyncio.sleep(1.2)

    except Exception as e:

        logger.error(
            f"Click Calendar Day Failed For {target_date} : {e}"
        )

        raise


async def select_month_year_and_pick_date(frame, target_date):

    try:

        await select_calendar_month_year(
            frame,
            target_date
        )

        await click_calendar_day_from_first_month(
            frame,
            target_date
        )

    except Exception as e:

        logger.error(
            f"Select Month/Year And Pick Date Failed For {target_date} : {e}"
        )

        raise

# ====================================================

async def select_custom_date_range_from_calendar(page, frame):

    """
    Final custom date picker function.

    This function supports:
    1. Same date
       Example:
       From 16-07-2026
       To   16-07-2026

    2. Normal range
       Example:
       From 11-07-2026
       To   16-07-2026

    3. Reverse input order
       Example:
       From 16-07-2026
       To   11-07-2026

       In reverse input order, script will still click:
       First  : 16-07-2026
       Second : 11-07-2026

       But final UI/header validation will expect:
       From : 11-JUL-2026
       To   : 16-JUL-2026

       because date range UI normalizes range from earlier date to later date.
    """

    try:

        logger.info(
            "Custom Date Range Selection Started"
        )

        logger.info(
            f"Custom Date Input Values | INPUT_FROM_DATERANGE : {INPUT_FROM_DATERANGE} | INPUT_TO_DATERANGE : {INPUT_TO_DATERANGE}"
        )

        # ============================================
        # Parse input dates
        # ============================================

        input_from_date = parse_custom_input_date(
            INPUT_FROM_DATERANGE
        )

        input_to_date = parse_custom_input_date(
            INPUT_TO_DATERANGE
        )

        # ============================================
        # Click order dates
        # These are the exact dates user entered.
        # First click INPUT_FROM_DATERANGE.
        # Second click INPUT_TO_DATERANGE.
        # ============================================

        first_click_date = input_from_date
        second_click_date = input_to_date

        # ============================================
        # Final validation dates
        # Date range UI will always normalize:
        # earlier date = From
        # later date   = To
        # ============================================

        final_from_date = min(
            input_from_date,
            input_to_date
        )

        final_to_date = max(
            input_from_date,
            input_to_date
        )

        expected_first_click_calendar = get_calendar_input_date(
            first_click_date
        )

        expected_second_click_calendar = get_calendar_input_date(
            second_click_date
        )

        expected_final_from_calendar = get_calendar_input_date(
            final_from_date
        )

        expected_final_to_calendar = get_calendar_input_date(
            final_to_date
        )

        expected_final_from_header = get_expected_output_date(
            final_from_date
        )

        expected_final_to_header = get_expected_output_date(
            final_to_date
        )

        logger.info(
            f"Click Order | First Click : {get_expected_output_date(first_click_date)} | Second Click : {get_expected_output_date(second_click_date)}"
        )

        logger.info(
            f"Expected Final Calendar Display | From : {expected_final_from_calendar} | To : {expected_final_to_calendar}"
        )

        logger.info(
            f"Expected Final Header Range | From : {expected_final_from_header} | To : {expected_final_to_header}"
        )

        # ============================================
        # FIRST DATE SELECTION
        # This starts the range.
        # Example:
        # If first click is 16-07-2026,
        # calendar usually shows:
        # From 07/16/2026
        # To   07/16/2026
        # ============================================

        logger.info(
            "FIRST Date Selection Started"
        )

        await click_date_display_item(
            frame,
            "From"
        )

        await select_month_year_and_pick_date(
            frame,
            first_click_date
        )

        await wait_calendar_display_dates(
            frame,
            expected_first_click_calendar,
            expected_first_click_calendar
        )

        logger.info(
            f"FIRST Date Selected And Intermediate Calendar Range Validated | From : {expected_first_click_calendar} | To : {expected_first_click_calendar}"
        )

        await asyncio.sleep(0.7)

        # ============================================
        # SECOND DATE SELECTION
        # This completes the range.
        # If second click date is earlier than first click date,
        # UI will normalize final range automatically.
        # ============================================

        logger.info(
            "SECOND Date Selection Started"
        )

        await click_date_display_item(
            frame,
            "To"
        )

        await select_month_year_and_pick_date(
            frame,
            second_click_date
        )

        await wait_calendar_display_dates(
            frame,
            expected_final_from_calendar,
            expected_final_to_calendar
        )

        logger.info(
            f"SECOND Date Selected And Final Calendar Display Validated | From : {expected_final_from_calendar} | To : {expected_final_to_calendar}"
        )

        await asyncio.sleep(2)

        # ============================================
        # FINAL HEADER VALIDATION
        # ============================================

        captured_from_date, captured_to_date = await capture_selected_date_range(
            frame
        )

        logger.info(
            f"Final Header Validation | Expected From : {expected_final_from_header}, Captured From : {captured_from_date} | Expected To : {expected_final_to_header}, Captured To : {captured_to_date}"
        )

        if captured_from_date != expected_final_from_header or captured_to_date != expected_final_to_header:

            await take_screenshot(
                page,
                "custom_date_validation_failed"
            )

            raise Exception(
                f"Custom Date Range Header Validation Failed. "
                f"Expected : {expected_final_from_header} to {expected_final_to_header}, "
                f"Captured : {captured_from_date} to {captured_to_date}"
            )

        logger.info(
            f"Custom Date Range Confirmed Successfully | From : {captured_from_date} | To : {captured_to_date}"
        )

        return captured_from_date, captured_to_date

    except Exception as e:

        logger.error(
            f"Custom Date Range Selection Failed : {e}"
        )

        await take_screenshot(
            page,
            "custom_date_range_error"
        )

        raise

# =====================================================
# DATE RANGE SELECTOR FUNCTION
# =====================================================

async def select_date_range(page):

    """
    Select Company Summary date range.

    Mode 1:
    DATE_RANGE = "Yesterday"
    It selects preset date and captures selected From and To date from 8x8 UI.

    Mode 2:
    DATE_RANGE = ""
    It selects custom From and To date using calendar picker.

    Always returns:
        from_date, to_date
    """

    try:

        frame = page.frame_locator(
            'iframe[title="Company Summary"]'
        )

        await expect(
            page.locator(
                'iframe[title="Company Summary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        await expect(
            frame.locator(
                '[data-test-id="voaheader.CompanySummary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        # ============================================
        # TIMEZONE VALIDATION
        # ============================================

        timezone = frame.locator(
            '[data-test-id="timezone-select.toggle"]'
        )

        await expect(
            timezone
        ).to_be_visible(
            timeout=30000
        )

        timezone_text = await timezone.text_content()

        logger.info(
            f"Current Timezone : {timezone_text}"
        )

        if timezone_text is None or TIME_ZONE not in timezone_text:

            logger.info(
                f"Timezone mismatch. Expected : {TIME_ZONE}, Actual : {timezone_text}"
            )

            await timezone.click()

            logger.info(
                "Timezone dropdown clicked"
            )

            search_box = frame.get_by_role(
                "textbox",
                name="Search"
            )

            await expect(
                search_box
            ).to_be_visible(
                timeout=30000
            )

            await search_box.click()

            await search_box.fill(
                TIME_ZONE
            )

            logger.info(
                f"Timezone search filled : {TIME_ZONE}"
            )

            timezone_option = frame.locator(
                f'[data-test-id="menu-item.{TIME_ZONE}"]'
            ).get_by_text(
                TIME_ZONE
            )

            await expect(
                timezone_option
            ).to_be_visible(
                timeout=30000
            )

            await timezone_option.click()

            logger.info(
                f"Timezone selected : {TIME_ZONE}"
            )

            await expect(
                timezone
            ).to_contain_text(
                TIME_ZONE,
                timeout=30000
            )

            logger.info(
                f"Timezone Verified After Selection : {TIME_ZONE}"
            )

        else:

            logger.info(
                f"Timezone Already Correct : {TIME_ZONE}"
            )

        # ============================================
        # OPEN DATE SELECTOR
        # ============================================

        date_button = frame.locator(
            '[data-test-id="voaheader.CompanySummary"] [data-test-id="BUTTON"]'
        )

        await expect(
            date_button
        ).to_be_visible(
            timeout=120000
        )

        logger.info(
            "Date Selector Visible"
        )

        await date_button.click()

        logger.info(
            "Date Selector Clicked"
        )

        # ============================================
        # VERIFY PRESET DATE OPTIONS
        # ============================================

        available_dates = [
            "Today",
            "Yesterday",
            "Last 7 days",
            "Last 30 days",
            "This week",
            "Last week",
            "This month",
            "Last month",
        ]

        for item in available_dates:

            await expect(
                frame.get_by_role(
                    "button",
                    name=item
                )
            ).to_be_visible(
                timeout=30000
            )

            logger.info(
                f"Verified Date Option : {item}"
            )

        # ============================================
        # PRESET DATE RANGE MODE
        # DATE_RANGE has value.
        # Example:
        # DATE_RANGE = "Yesterday"
        # ============================================

        if DATE_RANGE.strip():

            logger.info(
                f"Preset Date Range Mode Enabled : {DATE_RANGE}"
            )

            if DATE_RANGE not in available_dates:

                raise Exception(
                    f"Invalid DATE_RANGE : {DATE_RANGE}. Available Date Options : {available_dates}"
                )

            await frame.get_by_role(
                "button",
                name=DATE_RANGE
            ).click()

            logger.info(
                f"Selected Date Range Clicked : {DATE_RANGE}"
            )

            from_date, to_date = await capture_selected_date_range(
                frame
            )

            logger.info(
                f"Final Date Filter Period | Range : {DATE_RANGE} | From : {from_date} | To : {to_date}"
            )

            return from_date, to_date

        # ============================================
        # CUSTOM DATE RANGE MODE
        # DATE_RANGE is empty.
        # Example:
        # DATE_RANGE = ""
        # ============================================

        else:

            logger.info(
                f"Custom Date Range Mode Enabled | From : {INPUT_FROM_DATERANGE} | To : {INPUT_TO_DATERANGE}"
            )

            from_date, to_date = await select_custom_date_range_from_calendar(
                page,
                frame
            )

            logger.info(
                f"Final Custom Date Filter Period Confirmed | From : {from_date} | To : {to_date}"
            )

            return from_date, to_date

    except Exception as e:

        logger.error(
            f"Date Range Failed : {e}"
        )

        await take_screenshot(
            page,
            "date_range_error"
        )

        raise
# =====================================================
# SIDEBAR
# =====================================================

async def open_sidebar(page):

    try:

        await page.locator(
            "#navbar"
        ).click()

        logger.info(
            "Navbar Clicked"
        )

        toggle = page.get_by_role(
            "button",
            name="Toggle sidebar"
        )

        if await toggle.count() > 0:

            await toggle.click()

            logger.info(
                "Sidebar Toggled"
            )

    except Exception as e:

        logger.error(
            f"Sidebar Failed : {e}"
        )

        raise
# =====================================================
# CDR PAGE
# =====================================================

async def open_call_detail_records(page):

    try:

        await page.locator("#navbar").click()

        logger.info(
            "Navbar Clicked"
        )

        await page.locator(
            "#CallReportMenu"
        ).click()

        logger.info(
            "Call Report Opened"
        )

        cdr = page.locator(
            "#SideBarCDR"
        )

        await expect(
            cdr
        ).to_be_visible(
            timeout=30000
        )

        await cdr.click()

        logger.info(
            "Call Detail Records Clicked"
        )

    except Exception as e:

        logger.error(
            f"CDR Open Failed : {e}"
        )

        raise


# =====================================================
# FILTER
# =====================================================

# =====================================================
# FILTER
# =====================================================

async def apply_site_filter(page, site_filter):

    try:

        logger.info(
            f"Applying Site Filter : {site_filter}"
        )

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.locator(
                '[data-test-id="multiple-select.trigger"]'
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Filter dropdown visible"
        )

        await expect(
            frame.get_by_text(
                "Search or filter"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "Search or filter"
        ).click()

        logger.info(
            "Search Filter Opened"
        )

        await expect(
            frame.get_by_text(
                "Filter by Sites"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "Filter by Sites"
        ).click()

        logger.info(
            "Sites Filter Selected"
        )

        await expect(
            frame.get_by_text(
                "contains"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "contains Operator will match"
        ).click()

        logger.info(
            "Contains Operator Selected"
        )

        # ============================================
        # Select Site
        # If site is not found, skip this site only
        # ============================================

        site_option = (
            frame
            .locator(
                '[data-test-id="multiple-select.dropdown"] div'
            )
            .filter(
                has_text=site_filter
            )
            .nth(2)
        )

        try:

            await expect(
                site_option
            ).to_be_visible(
                timeout=30000
            )

        except Exception:

            logger.warning(
                f"Site Filter Not Found / Not Visible : {site_filter}. Skipping this site."
            )

            await take_screenshot(
                page,
                f"site_filter_not_found_{site_filter.replace(' ', '_')}"
            )

            try:

                await page.keyboard.press(
                    "Escape"
                )

                logger.info(
                    "Closed filter dropdown using Escape"
                )

            except Exception:

                logger.warning(
                    "Unable to close filter dropdown using Escape"
                )

            return False

        await site_option.click()

        logger.info(
            f"Site Selected : {site_filter}"
        )

        textbox = frame.get_by_role(
            "textbox"
        ).first

        await expect(
            textbox
        ).to_be_visible(
            timeout=30000
        )

        await expect(
            textbox
        ).to_have_value(
            site_filter,
            timeout=30000
        )

        logger.info(
            f"Textbox Validation Passed : {site_filter}"
        )

        finish_btn = frame.get_by_role(
            "button",
            name="Finish"
        )

        await expect(
            finish_btn
        ).to_be_visible(
            timeout=30000
        )

        await finish_btn.click()

        logger.info(
            "Finish Button Clicked"
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Filter Applied Successfully : {site_filter}"
        )

        return True

    except Exception as e:

        logger.error(
            f"Filter Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"filter_error_{site_filter.replace(' ', '_')}"
        )

        raise
# ======================================
# reset the filter 
# =======================================        
        
async def reset_site_filter(page, site_filter):

    try:

        logger.info(
            f"Resetting Site Filter : {site_filter}"
        )

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Existing Filter Found : Sites contains {site_filter}"
        )

        
        
        reject_btn = frame.locator(
            '[data-test-id="reject"]'
        ).first

        await expect(
            reject_btn
        ).to_be_visible(
            timeout=30000
        )


        await reject_btn.click()

        logger.info(
            f"Reject Button Clicked For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).not_to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Filter Reset Completed : {site_filter}"
        )

    except Exception as e:

        logger.error(
            f"Reset Filter Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"reset_filter_error_{site_filter.replace(' ', '_')}"
        )

        raise
# =====================================================
# SEARCH
# =====================================================
async def execute_search(page, site_filter):

    try:

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Verified Applied Filter : Sites contains {site_filter}"
        )

        search_btn = frame.locator(
            '[data-test-id="voaReports.cdr.search"]'
        )

        await expect(
            search_btn
        ).to_be_visible(
            timeout=30000
        )

        await search_btn.click()

        logger.info(
            f"Search Button Clicked For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                "Call Records"
            )
        ).to_be_visible(
            timeout=60000
        )

        logger.info(
            f"Search Completed For : {site_filter}"
        )

    except Exception as e:

        logger.error(
            f"Search Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"search_error_{site_filter.replace(' ', '_')}"
        )

        raise

# =====================================================
# DOWNLOAD
# =====================================================
async def download_excel(page, site_filter, download_folder):

    try:

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        download_btn = frame.locator(
            '[data-test-id="download"]'
        )

        await expect(
            download_btn
        ).to_be_visible(
            timeout=30000
        )

        await download_btn.click()

        logger.info(
            f"Download Menu Opened For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                "XLSX"
            )
        ).to_be_visible(
            timeout=30000
        )

        async with page.expect_download(
            timeout=120000
        ) as download_info:

            await frame.get_by_text(
                "XLSX",
                exact=True
            ).click()

        download = await download_info.value

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        safe_site_name = site_filter.replace(
            " ",
            "_"
        )

        file_path = os.path.join(
            download_folder,
            f"{safe_site_name}_Customer_Call_Details_{timestamp}.xlsx"
        )

        await download.save_as(
            file_path
        )

        logger.info(
            f"Excel Saved For {site_filter} : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Download Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"download_error_{site_filter.replace(' ', '_')}"
        )

        raise

# ===========================================
# clear the old excel 
# =============================================
async def clear_old_excel_files(folder_path, folder_name):

    try:

        logger.info(
            f"Clearing old Excel files from : {folder_name}"
        )

        if not os.path.exists(folder_path):

            os.makedirs(
                folder_path,
                exist_ok=True
            )

            logger.info(
                f"Folder created : {folder_path}"
            )

            return

        excel_extensions = (
            ".xlsx",
            ".xls"
        )

        deleted_count = 0
        skipped_count = 0

        for file_name in os.listdir(folder_path):

            file_path = os.path.join(
                folder_path,
                file_name
            )

            if os.path.isfile(file_path) and file_name.lower().endswith(
                excel_extensions
            ):

                try:

                    os.remove(
                        file_path
                    )

                    deleted_count += 1

                    logger.info(
                        f"Deleted Old Excel File : {file_name}"
                    )

                except PermissionError:

                    skipped_count += 1

                    logger.warning(
                        f"Skipped Locked Excel File : {file_name}. Please close it if you want to delete."
                    )

                except OSError as e:

                    skipped_count += 1

                    logger.warning(
                        f"Skipped Excel File : {file_name}. Reason : {e}"
                    )

        logger.info(
            f"Old Excel Clear Completed For {folder_name}. Deleted : {deleted_count}, Skipped : {skipped_count}"
        )

    except Exception as e:

        logger.error(
            f"Failed To Clear Old Excel Files From {folder_name} : {e}"
        )

        raise


# =====================================================
# ANALYTICS FLOW
# =====================================================
# =====================================================
# ANALYTICS FLOW
# =====================================================

async def analytics_flow(page):

    try:

        # ============================================
        # Clear Old Excel Files Before Current Run
        # ============================================

        await clear_old_excel_files(
            SITE_FILTER_1_DOWNLOAD_FOLDER,
            SITE_FILTER_1
        )

        await clear_old_excel_files(
            SITE_FILTER_2_DOWNLOAD_FOLDER,
            SITE_FILTER_2
        )

        logger.info(
            "Old Excel Files Cleared From Both Site Folders"
        )

        # ============================================
        # Open Analytics Page
        # ============================================

        analytics_page = await open_analytics(
            page
        )

        # ============================================
        # Select Date Range and Capture Selected Dates
        # ============================================

        selected_from_date, selected_to_date = await select_date_range(
            analytics_page
        )

        logger.info(
            f"Selected 8x8 Date Range Captured | From : {selected_from_date} | To : {selected_to_date}"
        )

        # ============================================
        # TEST STOP BLOCK
        # Keep this commented for full flow.
        # Uncomment only when testing date selection.
        # ============================================

        # logger.info(
        #     "TEST STOP : Date selector completed successfully. Stopping execution here."
        # )
        #
        # return {
        #     "file_path_1": None,
        #     "file_path_2": None,
        #     "selected_from_date": selected_from_date,
        #     "selected_to_date": selected_to_date,
        # }

        # ============================================
        # Open Sidebar and CDR Page
        # ============================================

        await open_sidebar(
            analytics_page
        )

        await open_call_detail_records(
            analytics_page
        )

        file_path_1 = None
        file_path_2 = None

        # ============================================
        # First Site - Advagen MICC
        # ============================================

        site_1_applied = await apply_site_filter(
            analytics_page,
            SITE_FILTER_1
        )

        if site_1_applied:

            await execute_search(
                analytics_page,
                SITE_FILTER_1
            )

            file_path_1 = await download_excel(
                analytics_page,
                SITE_FILTER_1,
                SITE_FILTER_1_DOWNLOAD_FOLDER
            )

            logger.info(
                f"First Site Excel Download Completed : {file_path_1}"
            )

            if db_helpers is not None:
                try:
                    db_helpers.insert_8x8_download_status(
                        site_name=SITE_FILTER_1,
                        file_path=file_path_1,
                        download_folder=SITE_FILTER_1_DOWNLOAD_FOLDER,
                        date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                        date_range_value=config.DATE_RANGE or "",
                        report_from_date=selected_from_date,
                        report_to_date=selected_to_date,
                        custom_from_date=config.CUSTOM_FROM_DATE,
                        custom_to_date=config.CUSTOM_TO_DATE,
                        status="SUCCESS" if file_path_1 else "FAILED",
                        remarks="",
                    )
                except Exception as db_error:
                    logger.warning(f"DB insert for 8x8 download status failed: {db_error}")

            await reset_site_filter(
                analytics_page,
                SITE_FILTER_1
            )

        else:

            logger.warning(
                f"Skipping Search and Download For : {SITE_FILTER_1}"
            )

            if db_helpers is not None:
                try:
                    db_helpers.insert_8x8_download_status(
                        site_name=SITE_FILTER_1,
                        file_path=None,
                        download_folder=SITE_FILTER_1_DOWNLOAD_FOLDER,
                        date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                        date_range_value=config.DATE_RANGE or "",
                        report_from_date=selected_from_date,
                        report_to_date=selected_to_date,
                        custom_from_date=config.CUSTOM_FROM_DATE,
                        custom_to_date=config.CUSTOM_TO_DATE,
                        status="SKIPPED",
                        remarks="Site filter could not be applied",
                    )
                except Exception as db_error:
                    logger.warning(f"DB insert for 8x8 download status failed: {db_error}")

        # ============================================
        # Second Site - Validus MICC
        # ============================================

        site_2_applied = await apply_site_filter(
            analytics_page,
            SITE_FILTER_2
        )

        if site_2_applied:

            await execute_search(
                analytics_page,
                SITE_FILTER_2
            )

            file_path_2 = await download_excel(
                analytics_page,
                SITE_FILTER_2,
                SITE_FILTER_2_DOWNLOAD_FOLDER
            )

            logger.info(
                f"Second Site Excel Download Completed : {file_path_2}"
            )

            if db_helpers is not None:
                try:
                    db_helpers.insert_8x8_download_status(
                        site_name=SITE_FILTER_2,
                        file_path=file_path_2,
                        download_folder=SITE_FILTER_2_DOWNLOAD_FOLDER,
                        date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                        date_range_value=config.DATE_RANGE or "",
                        report_from_date=selected_from_date,
                        report_to_date=selected_to_date,
                        custom_from_date=config.CUSTOM_FROM_DATE,
                        custom_to_date=config.CUSTOM_TO_DATE,
                        status="SUCCESS" if file_path_2 else "FAILED",
                        remarks="",
                    )
                except Exception as db_error:
                    logger.warning(f"DB insert for 8x8 download status failed: {db_error}")

        else:

            logger.warning(
                f"Skipping Search and Download For : {SITE_FILTER_2}"
            )

            if db_helpers is not None:
                try:
                    db_helpers.insert_8x8_download_status(
                        site_name=SITE_FILTER_2,
                        file_path=None,
                        download_folder=SITE_FILTER_2_DOWNLOAD_FOLDER,
                        date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                        date_range_value=config.DATE_RANGE or "",
                        report_from_date=selected_from_date,
                        report_to_date=selected_to_date,
                        custom_from_date=config.CUSTOM_FROM_DATE,
                        custom_to_date=config.CUSTOM_TO_DATE,
                        status="SKIPPED",
                        remarks="Site filter could not be applied",
                    )
                except Exception as db_error:
                    logger.warning(f"DB insert for 8x8 download status failed: {db_error}")

        logger.info(
            "Analytics Flow Completed"
        )

        # ============================================
        # Close Analytics Page
        # ============================================

        await analytics_page.close()

        logger.info(
            "Analytics Page Closed"
        )

        logger.info(
            f"Current URL : {page.url}"
        )

        await page.bring_to_front()

        logger.info(
            "Returned To Main Apps Page"
        )

        # ============================================
        # Return Downloaded Files and Selected Date
        # This is used by master_main.py for CLINEVO SQL date
        # ============================================

        return {
            "file_path_1": file_path_1,
            "file_path_2": file_path_2,
            "selected_from_date": selected_from_date,
            "selected_to_date": selected_to_date,
        }

    except Exception as e:

        logger.error(
            f"Analytics Flow Failed : {e}"
        )

        raise
# =====================================================
# SCREENSHOT UTILITY
# =====================================================

SCREENSHOT_FOLDER = r"D:\UI AUTOMATIONS PROJECTS\1- CALLER UI AUTOMATION\TESTING\process 1\SCREENSHOT"

os.makedirs(
    SCREENSHOT_FOLDER,
    exist_ok=True
)

async def take_screenshot(page, step_name="screenshot"):

    try:

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        file_path = os.path.join(
            SCREENSHOT_FOLDER,
            f"{step_name}_{timestamp}.png"
        )

        await page.screenshot(
            path=file_path,
            full_page=True
        )

        logger.info(
            f"Screenshot Saved : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Screenshot Failed : {e}"
        )

        return None
# =====================================================
# MAIN
# =====================================================

# =====================================================
# MAIN
# =====================================================

async def main():

    browser = None

    try:

        logger.info(
            "AUTOMATION STARTED"
        )

        if not await start_chrome():

            logger.error(
                "Chrome Startup Failed"
            )

            return None

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            if browser.contexts:

                context = browser.contexts[0]

            else:

                context = await browser.new_context(
                    # -----------
                    # viewport={
                    #     "width": 1920,
                    #     "height": 1080
                    # },
                    # record_video_dir="videos",
                    # record_video_size={
                    #     "width": 1920,
                    #     "height": 1080
                    # }
                    # -----------
                )

            if context.pages:

                page = context.pages[0]

            else:

                page = await context.new_page()

            await ensure_login(
                page
            )

            result = await analytics_flow(
                page
            )

            logger.info(
                f"SUCCESS : {result}"
            )

            return result

    except PlaywrightTimeoutError as e:

        logger.error(
            f"Timeout Error : {e}"
        )

        return None

    except Exception as e:

        logger.error(
            f"Automation Failed : {e}"
        )

        return None

    finally:

        logger.info(
            "Automation Finished"
        )





# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    asyncio.run(main())