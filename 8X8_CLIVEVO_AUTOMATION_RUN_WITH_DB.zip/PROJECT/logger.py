"""
logger.py

Centralized logging for the 8x8 + CLINEVO automation project.

Purpose:
    - Configure file logging and console logging with one consistent format.
    - Provide a module-wise logger via get_logger(module_name).
    - Never raise if logging setup fails for any reason - automation must
      continue to work even if this file has a problem.

This file does NOT replace any existing logging.basicConfig() calls already
present inside intilial_process_1.py, intilial_process_2.py,
excel_extration_callids.py, call_info_ui.py, validation_report.py or
extract_clinivo_excel_check.py. Those files keep working exactly as before.

This file is additive:
    - master_main.py, database_manager.py, db_helpers.py and email_manager.py
      use get_logger() from this file.
    - Optionally, any process file can also import get_logger() from here
      without changing its existing logging.basicConfig() call.
"""

import logging
import sys
from pathlib import Path

try:
    import config
except Exception:
    config = None

LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"

_CONFIGURED = False


def _resolve_log_dir() -> Path:

    if config is not None and hasattr(config, "LOG_DIR"):
        try:
            return Path(config.LOG_DIR)
        except Exception:
            pass

    return Path(__file__).resolve().parent / "logs"


def _resolve_log_file() -> Path:

    if config is not None and hasattr(config, "MASTER_LOG_FILE"):
        try:
            return Path(config.MASTER_LOG_FILE)
        except Exception:
            pass

    return _resolve_log_dir() / "master_single_execution.log"


def configure_root_logging(force: bool = False) -> None:
    """
    Configures root logging once per process.

    Safe to call multiple times - only configures the first time
    unless force=True.
    """

    global _CONFIGURED

    if _CONFIGURED and not force:
        return

    try:
        log_dir = _resolve_log_dir()
        log_dir.mkdir(parents=True, exist_ok=True)

        log_file = _resolve_log_file()

        logging.basicConfig(
            level=logging.INFO,
            format=LOG_FORMAT,
            handlers=[
                logging.FileHandler(log_file, encoding="utf-8"),
                logging.StreamHandler(sys.stdout),
            ],
            force=True,
        )

        _CONFIGURED = True

    except Exception as error:
        # Fall back to basic console logging only - never crash automation
        # because of a logging configuration problem.
        try:
            logging.basicConfig(
                level=logging.INFO,
                format=LOG_FORMAT,
                force=True,
            )
        except Exception:
            pass

        print(f"[logger.py] WARNING: failed to configure file logging: {error}")


def get_logger(module_name: str) -> logging.Logger:
    """
    Returns a module-wise logger.

    Example:
        logger = get_logger(__name__)
    """

    configure_root_logging(force=False)

    return logging.getLogger(module_name)
