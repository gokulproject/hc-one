

# =====================================
"""
MASTER configuration for 8x8 automation + CLINEVO automation.

Purpose:
    Edit only this file for:
    1. Paths
    2. Credentials
    3. Date range settings
    4. Output folders
    5. Run options

Important:
    Do not edit dates, folders, usernames, passwords, or report paths
    inside intilial_process_1.py, intilial_process_2.py,
    excel_extration_callids.py, validation_report.py,
    or extract_clinivo_excel_check.py.

Date logic:
    If DATE_RANGE has value:
        Example: DATE_RANGE = "Yesterday"
        8x8 will select preset date.
        intilial_process_1.py will capture actual From and To date from 8x8 UI.
        master_main.py will pass captured date to CLINEVO SQL report.

    If DATE_RANGE is empty:
        Example: DATE_RANGE = ""
        8x8 will use CUSTOM_FROM_DATE and CUSTOM_TO_DATE.
        CLINEVO SQL report will use the same custom date range.
"""

from pathlib import Path
from datetime import datetime

# ==========================================================
# BASE FOLDERS
# ==========================================================
# BASE_DIR means the folder where this config.py file is present.
# All automation output folders are created under DATA_DIR.

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"

MASTER_LOG_FILE = LOG_DIR / "master_single_execution.log"

# ==========================================================
# COMMON DATE RANGE SETTINGS
# ==========================================================
# This date section controls both:
# 1. 8x8 date filter
# 2. CLINEVO SQL report date range
#
# Preset mode:
#     DATE_RANGE = "Yesterday"
#     DATE_RANGE = "Last 7 days"
#
# Custom mode:
#     DATE_RANGE = ""
#
# Recommended date format:
#     DD-MON-YYYY
#     Example: 17-JUL-2026

DATE_RANGE = ""

CUSTOM_FROM_DATE = "20-JUL-2026"
CUSTOM_TO_DATE = "20-JUL-2026"

#NOTE :
#But strictly follow the DD-MON-YYYY FORMAT BCZ IT WILL AVOUD CONFUSE IN CLINIVO .

def normalize_date_to_dd_mon_yyyy(date_text: str) -> str:
    """
    Converts accepted date formats into DD-MON-YYYY.

    Accepted input examples:
        17-JUL-2026
        

    Output example:
        17-JUL-2026
    """

    date_text = str(date_text).strip().upper()

    supported_formats = [
        "%d-%m-%Y",
        "%d-%b-%Y",
        "%d-%B-%Y",
    ]

    for date_format in supported_formats:

        try:

            return datetime.strptime(
                date_text,
                date_format
            ).strftime(
                "%d-%b-%Y"
            ).upper()

        except ValueError:

            pass

    raise ValueError(
        f"Invalid date format : {date_text}. "
        "Use DD-MM-YYYY or DD-MON-YYYY. "
        "Example: 17-07-2026 or 17-JUL-2026 "
    )


def validate_common_date_range() -> None:
    """
    Validates only the date format.

    Note:
        This function does not block reverse date input.
        If CUSTOM_FROM_DATE is greater than CUSTOM_TO_DATE,
        intilial_process_1.py custom calendar logic can still normalize
        the date range in the 8x8 UI.
    """

    normalize_date_to_dd_mon_yyyy(
        CUSTOM_FROM_DATE
    )

    normalize_date_to_dd_mon_yyyy(
        CUSTOM_TO_DATE
    )


# 8x8 custom date picker values.
# These are used only when DATE_RANGE = "".
INPUT_FROM_DATERANGE = normalize_date_to_dd_mon_yyyy(
    CUSTOM_FROM_DATE
)

INPUT_TO_DATERANGE = normalize_date_to_dd_mon_yyyy(
    CUSTOM_TO_DATE
)

# Default CLINEVO SQL report dates.
# If DATE_RANGE has a preset value, master_main.py will override these
# with the captured From and To date from 8x8 UI.
REPORT_FROM_DATE = INPUT_FROM_DATERANGE
REPORT_TO_DATE = INPUT_TO_DATERANGE

# ==========================================================
# 8x8 OUTPUT FOLDERS
# ==========================================================
# 8x8 downloaded Excel, generated JSON, final report, and screenshots.

EIGHTX8_DIR = DATA_DIR / "8x8"

EIGHTX8_EXCEL_DIR = EIGHTX8_DIR / "excel"
EIGHTX8_JSON_DIR = EIGHTX8_DIR / "json"
EIGHTX8_REPORT_DIR = EIGHTX8_DIR / "reports"
EIGHTX8_SCREENSHOT_DIR = EIGHTX8_DIR / "screenshots"

ADVAGEN_EXCEL_FOLDER = EIGHTX8_EXCEL_DIR / "Advagen MICC"
VALIDUS_EXCEL_FOLDER = EIGHTX8_EXCEL_DIR / "Validus MICC"

PROCESS1_SCREENSHOT_FOLDER = EIGHTX8_SCREENSHOT_DIR / "process1"
PROCESS2_SCREENSHOT_FOLDER = EIGHTX8_SCREENSHOT_DIR / "process2"

CALL_IDS_JSON = EIGHTX8_JSON_DIR / "call_ids.json"
UI_CAPTURE_JSON = EIGHTX8_JSON_DIR / "ui_capture.json"

FINAL_REPORT_FILE = EIGHTX8_REPORT_DIR / "Recording_Validation_Report.xlsx"

# ==========================================================
# 8x8 SETTINGS
# ==========================================================
# Credentials and browser settings for 8x8 automation.

USERNAME = "udhayaprakash.gajendhiran"
PASSWORD = "@Udha"

ANALYTICS_URL = "https://apps.8x8.com/"
APP_URL = "https://apps.8x8.com/"
RECORDINGS_URL = "https://admin.8x8.com/recordings"

CHROME_DEBUG_URL = "http://127.0.0.1:9222"
CHROME_EXE_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_USER_DATA_DIR = r"C:\temp\chrome-debug"

TIME_ZONE = "America/New_York"

SITE_FILTER_1 = "Advagen MICC"
SITE_FILTER_2 = "Validus MICC"

SITE_ORDER = [
    SITE_FILTER_1,
    SITE_FILTER_2,
]

# ==========================================================
# LOCAL RECORDING FOLDERS
# ==========================================================
# These folders contain local audio recordings.
# validation_report.py and extract_clinivo_excel_check.py use these paths.

ADVAGEN_RECORDING_PATH = Path(
    r"D:\UI AUTOMATIONS PROJECTS\1- CALLER UI AUTOMATION\TESTING\Documents\MICC\Advagen MICC\Call recordings"
)

VALIDUS_RECORDING_PATH = Path(
    r"D:\UI AUTOMATIONS PROJECTS\1- CALLER UI AUTOMATION\TESTING\Documents\MICC\Validus MICC\Call recordings"
)

SITE_PATHS = {
    SITE_FILTER_1: ADVAGEN_RECORDING_PATH,
    SITE_FILTER_2: VALIDUS_RECORDING_PATH,
}

AUDIO_EXTENSIONS = (
    ".wav",
    ".mp3",
    ".m4a",
    ".wma",
    ".aac",
    ".ogg",
    ".flac",
)

# Size comparison tolerance for validation_report.py.
# 0.02 means 2 percent tolerance.
SIZE_TOLERANCE = 0.02

# ==========================================================
# CLINEVO OUTPUT FOLDERS
# ==========================================================
# CLINEVO downloaded Excel, CLINEVO reports, and screenshots.

CLINEVO_DIR = DATA_DIR / "clinevo"

CLINEVO_EXCEL_DIR = CLINEVO_DIR / "excel"
CLINEVO_REPORT_DIR = CLINEVO_DIR / "reports"
CLINEVO_SCREENSHOT_DIR = CLINEVO_DIR / "screenshots"

ADVAGEN_CLINEVO_EXCEL_FOLDER = CLINEVO_EXCEL_DIR / "Advagen excel"
VALIDUS_CLINEVO_EXCEL_FOLDER = CLINEVO_EXCEL_DIR / "Validus excel"

CLINEVO_REPORT_FOLDER = CLINEVO_REPORT_DIR / "Clinevo_Case_Check_Report"
CLINEVO_REPORT_FILE = CLINEVO_REPORT_FOLDER / "Clinevo_Case_File_Check_Report.xlsx"

# ==========================================================
# CLINEVO SETTINGS
# ==========================================================
# Credentials and enterprise details for CLINEVO automation.
#
# Important:
#     Do not define REPORT_FROM_DATE and REPORT_TO_DATE here again.
#     They are already defined in the common date range section above.

LOGIN_URL = "https://octp.clinevotech.com/clinevo/#/login"

CLINEVO_USERNAME = "UDHAYAPRAKASHG"
CLINEVO_PASSWORD = "@Navi" 

CLINEVO_ENTERPRISE_1 = "Advagen"
CLINEVO_ENTERPRISE_2 = "Validus"

ADVAGEN_LOCAL_DOCUMENT_FOLDER = ADVAGEN_RECORDING_PATH
VALIDUS_LOCAL_DOCUMENT_FOLDER = VALIDUS_RECORDING_PATH

# This config can be used by CLINEVO report checking scripts.
# local_base_folder and audio_folder both point to local recordings.
CLINEVO_SITE_CONFIG = {
    "Advagen MICC": {
        "excel_folder": str(ADVAGEN_CLINEVO_EXCEL_FOLDER),
        "local_base_folder": str(ADVAGEN_LOCAL_DOCUMENT_FOLDER),
        "audio_folder": str(ADVAGEN_LOCAL_DOCUMENT_FOLDER),
        "sheet_name": "Advagen",
    },
    "Validus MICC": {
        "excel_folder": str(VALIDUS_CLINEVO_EXCEL_FOLDER),
        "local_base_folder": str(VALIDUS_LOCAL_DOCUMENT_FOLDER),
        "audio_folder": str(VALIDUS_LOCAL_DOCUMENT_FOLDER),
        "sheet_name": "Validus",
    },
}

SUPPORTED_LOCAL_FILE_EXTENSIONS = (
    ".pdf",
    ".doc",
    ".docx",
    ".xlsx",
    ".xls",
    ".csv",
    ".txt",
    ".msg",
    ".eml",
    ".wav",
    ".mp3",
    ".m4a",
    ".wma",
    ".aac",
    ".ogg",
    ".flac",
)

# ==========================================================
# RUN OPTIONS
# ==========================================================
# Use these switches to enable or disable complete flows.

RUN_8X8 = True
RUN_CLINEVO = True

CLEAR_OLD_EXCEL_BEFORE_RUN = True
CLEAR_OLD_JSON_BEFORE_RUN = True

# ==========================================================
# DATABASE SETTINGS (MySQL / caller_automation)
# ==========================================================
# These settings connect the automation to the caller_automation MySQL
# database described in "CALLEER AUTOMATION REFERANCE SCHEMA .txt".
#
# Set ENABLE_DB_LOGGING = False to run the automation exactly like before,
# with zero database dependency (JSON files remain the only data source).
#
# Set ENABLE_DB_LOGGING = True to turn on:
#   - execution tracking (automation_process_status, execution_step_log)
#   - Excel download tracking
#   - audit_by_call_id / ui_needed_call_items as the primary data source
#   - ui_capture_record / recording_validation_result storage
#   - clinevo_case_record / clinevo_case_audio_result storage
#   - sql_update_audit, screenshot_log, error_log
#   - email_config / email_status

ENABLE_DB_LOGGING = True

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "your_mysql_password",
    "database": "caller_automation",
}

# ==========================================================
# EMAIL NOTIFICATION SETTINGS
# ==========================================================
# Actual SMTP host/port/credentials/recipients live in the email_config
# MySQL table (see schema). DEFAULT_EMAIL_CONFIG_NAME selects which
# email_config row (config_name column) to use.
#
# If ENABLE_DB_LOGGING = False or MySQL is unreachable, email_manager.py
# falls back to FALLBACK_EMAIL_CONFIG below (optional). Leave it as None
# to simply skip sending email when DB is unavailable.

ENABLE_EMAIL_NOTIFICATION = True
DEFAULT_EMAIL_CONFIG_NAME = "DEFAULT_SMTP"

EMAIL_SEND_SUCCESS = True
EMAIL_SEND_FAILURE = True
EMAIL_ATTACH_OUTPUT_REPORTS = True

# Optional local fallback used ONLY when the email_config DB table is not
# reachable. Fill this in if you want email to work even with DB disabled.
# Leave as None to skip email sending whenever DB is unavailable.
FALLBACK_EMAIL_CONFIG = None
# Example:
# FALLBACK_EMAIL_CONFIG = {
#     "smtp_host": "smtp.office365.com",
#     "smtp_port": 587,
#     "smtp_username": "your_email@company.com",
#     "smtp_password": "your_password_or_app_password",
#     "from_email": "your_email@company.com",
#     "to_emails": "person1@company.com,person2@company.com",
#     "cc_emails": "",
#     "bcc_emails": "",
#     "use_ssl": False,
#     "use_tls": True,
# }

# ==========================================================
# OUTPUT ZIP / FILE NAMING SETTINGS
# ==========================================================
# After every run, master_main.py builds one ZIP containing source Excel
# files, output reports, and important screenshots.
# Historical reports and ZIP files are NEVER deleted automatically.

OUTPUT_ZIP_DIR = DATA_DIR / "automation_output_zips"

# ==========================================================
# REQUIRED FOLDER CREATION
# ==========================================================
# master_main.py and each process can call this safely.
# It creates all required output folders if they do not already exist.

def create_required_folders() -> None:
    folders = [
        DATA_DIR,
        LOG_DIR,

        EIGHTX8_DIR,
        EIGHTX8_EXCEL_DIR,
        EIGHTX8_JSON_DIR,
        EIGHTX8_REPORT_DIR,
        EIGHTX8_SCREENSHOT_DIR,

        ADVAGEN_EXCEL_FOLDER,
        VALIDUS_EXCEL_FOLDER,

        PROCESS1_SCREENSHOT_FOLDER,
        PROCESS2_SCREENSHOT_FOLDER,

        CLINEVO_DIR,
        CLINEVO_EXCEL_DIR,
        CLINEVO_REPORT_DIR,
        CLINEVO_REPORT_FOLDER,
        CLINEVO_SCREENSHOT_DIR,

        ADVAGEN_CLINEVO_EXCEL_FOLDER,
        VALIDUS_CLINEVO_EXCEL_FOLDER,

        OUTPUT_ZIP_DIR,
    ]

    for folder in folders:

        folder.mkdir(
            parents=True,
            exist_ok=True
        )