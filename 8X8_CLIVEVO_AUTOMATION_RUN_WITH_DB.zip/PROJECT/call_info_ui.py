import os
import re
import json
import asyncio
import logging
import subprocess
from datetime import datetime

from playwright.async_api import async_playwright, expect

try:
    import db_helpers
except Exception:
    db_helpers = None


# ==========================================================
# CONFIGURATION
# ==========================================================

APP_URL = "https://apps.8x8.com/"
RECORDINGS_URL = "https://admin.8x8.com/recordings"

CALL_IDS_JSON = "call_ids.json"
UI_CAPTURE_JSON = "ui_capture.json"

SCREENSHOT_FOLDER = "Process2_Screenshots"

CHROME_DEBUG_URL = "http://127.0.0.1:9222"
CHROME_EXE_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_USER_DATA_DIR = r"C:\temp\chrome-debug"

SITE_ORDER = [
    "Advagen MICC",
    "Validus MICC"
]

FILTER_ADD_BUTTON = (
    '[data-test-id="FILTER_LIST_ADD_NEW_FILTER_BUTTON"]'
)

FILTER_NAME_SEARCH_INPUT = (
    '[data-test-id="FILTER_LIST_ADD_NEW_FILTER_SEARCH_INPUT_FIELD"]'
)

FILTER_VALUE_SEARCH_INPUT = (
    '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_VALUES_SELECTION_INPUT_FIELD"]'
)

FILTER_VALUE_CHECKBOX = (
    '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_VALUES_CHECKBOX"]'
)

FILTER_APPLY_BUTTON = (
    '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_BOTTOM_ACTIONS_APPLY_FILTER"]'
)

FILTER_DROPDOWN_CONTAINER = (
    '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_CONTAINER"]'
)

PLAYER_DURATION_LOCATOR = (
    '[data-test-id="PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION"]'
)

os.makedirs(SCREENSHOT_FOLDER, exist_ok=True)


# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)


# ==========================================================
# NORMALIZE HELPERS
# ==========================================================

def normalize_call_id(value):
    if value is None:
        return ""

    text = str(value).strip()

    if text.endswith(".0"):
        text = text[:-2]

    text = re.sub(r"\D", "", text)

    return text


def normalize_size_text(size_text):
    if not size_text:
        return ""

    text = str(size_text).replace("\n", " ").replace(",", "").strip()

    match = re.search(
        r"(\d+(?:\.\d+)?)\s*(KB|MB|GB)",
        text,
        re.IGNORECASE
    )

    if not match:
        return text

    return f"{match.group(1)} {match.group(2).upper()}"


def normalize_duration_text(duration_text):
    if not duration_text:
        return ""

    text = str(duration_text).strip().replace(".", ":")

    match_hms = re.search(
        r"\b\d{1,2}:\d{1,2}:\d{1,2}\b",
        text
    )

    if match_hms:
        hours, minutes, seconds = match_hms.group(0).split(":")
        return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

    match_ms = re.search(
        r"\b\d{1,2}:\d{1,2}\b",
        text
    )

    if match_ms:
        minutes, seconds = match_ms.group(0).split(":")
        return f"00:{int(minutes):02d}:{int(seconds):02d}"

    return text


def is_zero_duration(duration_text):
    return normalize_duration_text(duration_text) == "00:00:00"


def safe_file_text(value):
    value = str(value or "")
    value = re.sub(r"[^A-Za-z0-9]+", "_", value)
    value = value.strip("_")

    if not value:
        return "NA"

    return value[:120]


def get_value(item, keys, default=""):
    if not isinstance(item, dict):
        return default

    for key in keys:
        if key in item and item.get(key) not in [None, ""]:
            return item.get(key)

    return default


def extract_size_candidates(text):
    if not text:
        return []

    matches = re.findall(
        r"\b\d+(?:\.\d+)?\s*(?:KB|MB|GB)\b",
        text,
        re.IGNORECASE
    )

    return [normalize_size_text(item) for item in matches]


# ==========================================================
# LOAD CALL IDS FROM JSON
# ==========================================================
def load_call_id_records():
    """
    Loads Call IDs from call_ids.json.

    IMPORTANT:
    Process 2 must read ui_needed_call_items first because it contains:
    - call_id
    - source_excel_site
    - excel_date_time
    - excel_date
    - answered
    - excel_row_sequence

    call_ids is only fallback because it contains only plain Call IDs.
    """

    # ==========================================================
    # NEW: Prefer ui_needed_call_items from MySQL (Phase 3).
    # If DB is disabled/unreachable or has no rows for this execution,
    # fall back to call_ids.json exactly as before - no behaviour change.
    # ==========================================================
    if db_helpers is not None:
        try:
            db_records = db_helpers.fetch_ui_needed_call_items()
        except Exception as db_error:
            logger.warning(f"DB fetch for ui_needed_call_items failed: {db_error}")
            db_records = []

        if db_records:
            logger.info(
                f"Call ID records loaded from MySQL (ui_needed_call_items): "
                f"{len(db_records)}"
            )
            return db_records

    if not os.path.exists(CALL_IDS_JSON):
        raise FileNotFoundError(
            f"{CALL_IDS_JSON} not found. Run Process 1 first."
        )

    with open(CALL_IDS_JSON, "r", encoding="utf-8") as file:
        data = json.load(file)

    records = []

    def build_record_from_dict(item, fallback_site=""):
        call_id = normalize_call_id(
            get_value(
                item,
                [
                    "call_id",
                    "Call ID",
                    "CALL ID",
                    "value",
                    "Value",
                    "interaction_id",
                    "Interaction ID"
                ],
                ""
            )
        )

        source_excel_site = get_value(
            item,
            [
                "source_excel_site",
                "Source Excel Site",
                "site",
                "Site"
            ],
            fallback_site
        )

        return {
            "call_id": call_id,
            "source_excel_site": source_excel_site,
            "excel_date_time": get_value(
                item,
                [
                    "excel_date_time",
                    "Excel Date Time",
                    "date_time",
                    "Date Time",
                    "call_date_time",
                    "Call Date Time"
                ],
                ""
            ),
            "excel_date": get_value(
                item,
                [
                    "excel_date",
                    "Excel Date",
                    "excel_date_only",
                    "Excel Date Only",
                    "date",
                    "Date",
                    "call_date",
                    "Call Date"
                ],
                ""
            ),
            "excel_row_sequence": get_value(
                item,
                [
                    "excel_row_sequence",
                    "Excel Row Sequence",
                    "row_sequence",
                    "Row Sequence"
                ],
                ""
            ),
            "answered": get_value(
                item,
                [
                    "answered",
                    "Answered"
                ],
                ""
            ),
            "status": get_value(
                item,
                [
                    "status",
                    "Status"
                ],
                ""
            ),
            "remarks": get_value(
                item,
                [
                    "remarks",
                    "Remarks"
                ],
                ""
            )
        }

    def build_record_from_string(call_id, site=""):
        """
        Fallback only. This will not have Excel date.
        This is used only if ui_needed_call_items is missing.
        """
        return {
            "call_id": normalize_call_id(call_id),
            "source_excel_site": site,
            "excel_date_time": "",
            "excel_date": "",
            "excel_row_sequence": "",
            "answered": "",
            "status": "",
            "remarks": ""
        }

    def extract_items_from_site_value(site_value):
        """
        Extracts Call ID records from Process 1 output.

        Priority:
        1. ui_needed_call_items  -> correct, contains Excel date/time
        2. records/items/data    -> fallback structured records
        3. call_ids              -> final fallback only, no Excel date
        """

        if isinstance(site_value, list):
            return site_value

        if isinstance(site_value, dict):
            possible_keys = [
                "ui_needed_call_items",
                "records",
                "items",
                "data",
                "answered_call_ids",
                "answeredCallIds",
                "rows",
                "calls",
                "call_ids",
                "callIds",
                "answered"
            ]

            for key in possible_keys:
                if key in site_value and isinstance(site_value.get(key), list):
                    logger.info(f"Using '{key}' from call_ids.json")
                    return site_value.get(key)

            collected = []

            for value in site_value.values():
                if isinstance(value, list):
                    collected.extend(value)

                elif isinstance(value, dict):
                    collected.extend(
                        extract_items_from_site_value(value)
                    )

                elif isinstance(value, (str, int, float)):
                    collected.append(value)

            return collected

        if isinstance(site_value, (str, int, float)):
            return [site_value]

        return []

    def add_item_to_records(item, site=""):
        if isinstance(item, dict):
            records.append(
                build_record_from_dict(
                    item,
                    fallback_site=site
                )
            )

        elif isinstance(item, (str, int, float)):
            records.append(
                build_record_from_string(
                    item,
                    site=site
                )
            )

        else:
            logger.warning(f"Unsupported call ID item skipped: {item}")

    if isinstance(data, list):
        for item in data:
            add_item_to_records(item)

    elif isinstance(data, dict):
        for site in SITE_ORDER:
            if site not in data:
                continue

            site_value = data.get(site)
            site_items = extract_items_from_site_value(site_value)

            logger.info(
                f"Site '{site}' items extracted from JSON: {len(site_items)}"
            )

            for item in site_items:
                add_item_to_records(item, site=site)

        for site, site_value in data.items():
            if site in SITE_ORDER:
                continue

            site_items = extract_items_from_site_value(site_value)

            if site_items:
                logger.info(
                    f"Additional site '{site}' items extracted from JSON: {len(site_items)}"
                )

            for item in site_items:
                add_item_to_records(item, site=site)

    else:
        raise ValueError(
            f"Unsupported {CALL_IDS_JSON} format. Expected list or dictionary."
        )

    cleaned_records = []

    for item in records:
        call_id = str(item.get("call_id", "")).strip()

        if not call_id:
            continue

        cleaned_records.append(item)

    logger.info(f"Call ID records loaded from JSON: {len(cleaned_records)}")

    return cleaned_records

    def build_record_from_string(call_id, site=""):
        return {
            "call_id": normalize_call_id(call_id),
            "source_excel_site": site,
            "excel_date_time": "",
            "excel_date": "",
            "excel_row_sequence": "",
            "answered": "",
            "status": "",
            "remarks": ""
        }

    def extract_items_from_site_value(site_value):
        if isinstance(site_value, list):
            return site_value

        if isinstance(site_value, dict):
            possible_keys = [
                "records",
                "call_ids",
                "callIds",
                "items",
                "data",
                "ui_needed_call_items",
                "answered_call_ids",
                "answeredCallIds",
                "answered",
                "calls",
                "rows"
            ]

            for key in possible_keys:
                if key in site_value and isinstance(site_value.get(key), list):
                    return site_value.get(key)

            collected = []

            for value in site_value.values():
                if isinstance(value, list):
                    collected.extend(value)
                elif isinstance(value, dict):
                    collected.extend(extract_items_from_site_value(value))
                elif isinstance(value, (str, int, float)):
                    collected.append(value)

            return collected

        if isinstance(site_value, (str, int, float)):
            return [site_value]

        return []

    def add_item_to_records(item, site=""):
        if isinstance(item, dict):
            records.append(
                build_record_from_dict(
                    item,
                    fallback_site=site
                )
            )

        elif isinstance(item, (str, int, float)):
            records.append(
                build_record_from_string(
                    item,
                    site=site
                )
            )

        else:
            logger.warning(f"Unsupported call ID item skipped: {item}")

    if isinstance(data, list):
        for item in data:
            add_item_to_records(item)

    elif isinstance(data, dict):
        for site in SITE_ORDER:
            if site not in data:
                continue

            site_value = data.get(site)
            site_items = extract_items_from_site_value(site_value)

            logger.info(
                f"Site '{site}' items extracted from JSON: {len(site_items)}"
            )

            for item in site_items:
                add_item_to_records(item, site=site)

        for site, site_value in data.items():
            if site in SITE_ORDER:
                continue

            site_items = extract_items_from_site_value(site_value)

            if site_items:
                logger.info(
                    f"Additional site '{site}' items extracted from JSON: {len(site_items)}"
                )

            for item in site_items:
                add_item_to_records(item, site=site)

    else:
        raise ValueError(
            f"Unsupported {CALL_IDS_JSON} format. Expected list or dictionary."
        )

    cleaned_records = []

    for item in records:
        call_id = str(item.get("call_id", "")).strip()

        if not call_id:
            continue

        cleaned_records.append(item)

    logger.info(f"Call ID records loaded from JSON: {len(cleaned_records)}")

    return cleaned_records


# ==========================================================
# JSON SAVE / SCREENSHOT
# ==========================================================

def save_ui_records(ui_records):
    with open(UI_CAPTURE_JSON, "w", encoding="utf-8") as file:
        json.dump(
            ui_records,
            file,
            indent=4,
            ensure_ascii=False
        )

    logger.info(
        f"UI capture JSON updated: {UI_CAPTURE_JSON} | Records: {len(ui_records)}"
    )

    # ==========================================================
    # NEW: Store the same records in ui_capture_record (+ screenshot_log
    # for any record that has a screenshot_path). Phase 4.
    # JSON above remains the backward-compatible fallback source.
    # ==========================================================
    if db_helpers is not None:
        try:
            db_helpers.insert_ui_capture_records(ui_records)
        except Exception as db_error:
            logger.warning(f"DB insert for ui_capture_record failed: {db_error}")


async def capture_process2_screenshot(page, site, call_id, status):
    os.makedirs(SCREENSHOT_FOLDER, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    screenshot_path = os.path.join(
        SCREENSHOT_FOLDER,
        (
            f"{safe_file_text(site)}_"
            f"{safe_file_text(call_id)}_"
            f"{safe_file_text(status)}_"
            f"{timestamp}.png"
        )
    )

    try:
        await page.screenshot(
            path=screenshot_path,
            full_page=True
        )

        logger.info(f"Screenshot captured: {screenshot_path}")
        return screenshot_path

    except Exception as e:
        logger.warning(f"Screenshot failed: {e}")
        return ""


# ==========================================================
# CHROME DEBUG BROWSER
# ==========================================================

async def get_or_start_chrome_context(playwright):
    try:
        logger.info(f"Trying to connect Chrome debug browser: {CHROME_DEBUG_URL}")

        browser = await playwright.chromium.connect_over_cdp(
            CHROME_DEBUG_URL
        )

        logger.info("Connected to existing Chrome debug browser")

    except Exception as e:
        logger.warning(
            f"Chrome debug connection failed. Starting Chrome. Error: {e}"
        )

        if not os.path.exists(CHROME_EXE_PATH):
            raise FileNotFoundError(
                f"Chrome executable not found: {CHROME_EXE_PATH}"
            )

        os.makedirs(CHROME_USER_DATA_DIR, exist_ok=True)

        chrome_args = [
            CHROME_EXE_PATH,
            "--remote-debugging-port=9222",
            f"--user-data-dir={CHROME_USER_DATA_DIR}",
            "--start-maximized",
            "--no-first-run"
        ]

        subprocess.Popen(
            chrome_args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        logger.info("Chrome started with remote debugging. Waiting to connect...")

        await asyncio.sleep(8)

        browser = await playwright.chromium.connect_over_cdp(
            CHROME_DEBUG_URL
        )

        logger.info("Connected to newly started Chrome debug browser")

    if browser.contexts:
        context = browser.contexts[0]
    else:
        context = await browser.new_context()

    if context.pages:
        page = context.pages[0]
    else:
        page = await context.new_page()

    return browser, context, page


# ==========================================================
# UI HELPERS
# ==========================================================

async def is_locator_visible(locator, timeout_ms=1000):
    try:
        return await locator.is_visible(timeout=timeout_ms)
    except Exception:
        return False


async def ensure_recordings_page(page):
    try:
        if "admin.8x8.com/recordings" not in page.url:
            logger.info(f"Navigating to recordings page: {RECORDINGS_URL}")

            await page.goto(
                RECORDINGS_URL,
                wait_until="domcontentloaded",
                timeout=60000
            )

        await page.wait_for_timeout(6000)

        logger.info("Recordings page ready")

    except Exception as e:
        logger.warning(f"Recordings page navigation issue: {e}")


# ==========================================================
# FILTER CLEAR - ESC OR CLEAR ALL ONLY
# ==========================================================

async def close_filter_popover_if_open(page):
    """
    Only closes any open filter popup/dropdown.
    Does not delete anything.
    """

    try:
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(1000)
        logger.info("Escape pressed to close open filter popover/dropdown")
        return True

    except Exception as e:
        logger.warning(f"Escape close popover skipped: {e}")
        return False


async def clear_all_filters_if_available(page):
    """
    Strict filter clear logic.

    Allowed actions:
    1. Escape
    2. Clear all

    Not allowed:
    - Delete filter
    """

    try:
        logger.info("Checking Clear all filter button")

        await close_filter_popover_if_open(page)

        clear_all_button = page.get_by_text(
            re.compile(r"^\s*Clear all\s*$", re.IGNORECASE)
        ).first

        if not await is_locator_visible(clear_all_button, timeout_ms=5000):
            logger.info("Clear all button not visible. Already clear mode.")
            return True

        try:
            is_enabled = await clear_all_button.is_enabled(timeout=3000)
        except Exception:
            is_enabled = True

        if not is_enabled:
            logger.info("Clear all button is disabled. Already clear mode.")
            return True

        await clear_all_button.click()
        logger.info("Clear all filter clicked")

        await page.wait_for_timeout(5000)

        return True

    except Exception as e:
        logger.warning(f"Clear all filter failed/skipped: {e}")
        return False


# ==========================================================
# APPLY CALL ID FILTER
# ==========================================================

async def click_add_filter(page):
    """
    Click Add filter using exact button when possible.
    Uses Escape first to close any open popup.
    """

    await close_filter_popover_if_open(page)

    add_filter_button = page.locator(
        FILTER_ADD_BUTTON
    ).first

    if await is_locator_visible(add_filter_button, timeout_ms=10000):
        await add_filter_button.click()
        logger.info("Add filter clicked")
        await page.wait_for_timeout(3000)
        return True

    fallback_button = page.get_by_text(
        re.compile(r"^\s*\+?\s*Add filter\s*$", re.IGNORECASE)
    ).first

    await expect(fallback_button).to_be_visible(timeout=30000)
    await fallback_button.click()

    logger.info("Add filter clicked using fallback")

    await page.wait_for_timeout(3000)

    return True


async def wait_for_filter_dropdown_ready(page, timeout_ms=30000):
    """
    Waits until Add filter dropdown is ready.
    """

    end_time = asyncio.get_running_loop().time() + timeout_ms / 1000

    filter_name_search_input = page.locator(
        FILTER_NAME_SEARCH_INPUT
    ).first

    call_id_option = page.get_by_text(
        re.compile(r"^\s*Call\s*ID\s*$", re.IGNORECASE)
    ).first

    while asyncio.get_running_loop().time() < end_time:
        if await is_locator_visible(filter_name_search_input, timeout_ms=1000):
            logger.info("Add filter search input is ready")
            return True

        if await is_locator_visible(call_id_option, timeout_ms=1000):
            logger.info("Call ID option is visible in Add filter dropdown")
            return True

        await page.wait_for_timeout(1000)

    logger.warning("Add filter dropdown did not become ready")
    return False


async def select_call_id_filter_name(page):
    """
    Selects filter name: Call ID.
    """

    dropdown_ready = await wait_for_filter_dropdown_ready(
        page,
        timeout_ms=30000
    )

    if not dropdown_ready:
        raise RuntimeError(
            "Add filter dropdown did not become ready after clicking Add filter."
        )

    filter_name_search_input = page.locator(
        FILTER_NAME_SEARCH_INPUT
    ).first

    if await is_locator_visible(filter_name_search_input, timeout_ms=3000):
        await filter_name_search_input.click()

    call_id_option = page.get_by_text(
        re.compile(r"^\s*Call\s*ID\s*$", re.IGNORECASE)
    ).first

    if not await is_locator_visible(call_id_option, timeout_ms=5000):
        await expect(filter_name_search_input).to_be_visible(timeout=30000)
        await filter_name_search_input.fill("")
        await filter_name_search_input.type("Call ID", delay=120)
        logger.info("Typed Call ID in Add filter search input")
        await page.wait_for_timeout(2000)

    await expect(call_id_option).to_be_visible(timeout=30000)
    await call_id_option.click()

    logger.info("Call ID filter option selected")

    await page.wait_for_timeout(2000)

    return True


async def select_first_available_call_id_checkbox(page, call_id):
    """
    Selects checkbox after entering Call ID.

    Handles:
    - normal suggestion checkbox
    - freeform checkbox when No suggestions found appears
    """

    call_id_text = str(call_id).strip()

    no_suggestions = page.get_by_text(
        re.compile(r"No suggestions found", re.IGNORECASE)
    )

    no_suggestions_visible = await is_locator_visible(
        no_suggestions,
        timeout_ms=2000
    )

    if no_suggestions_visible:
        logger.warning(
            f"No suggestions found for Call ID {call_id_text}. "
            "Selecting first available/freeform checkbox."
        )

    checkbox_candidates = []

    # 1. Exact checkbox by accessible name
    checkbox_candidates.append(
        page.get_by_role(
            "checkbox",
            name=re.compile(re.escape(call_id_text))
        ).first
    )

    # 2. Data-test-id checkbox first
    checkbox_candidates.append(
        page.locator(FILTER_VALUE_CHECKBOX).first
    )

    # 3. Data-test-id checkbox last
    checkbox_candidates.append(
        page.locator(FILTER_VALUE_CHECKBOX).last
    )

    # 4. First checkbox inside dropdown container
    dropdown_container = page.locator(
        FILTER_DROPDOWN_CONTAINER
    ).first

    checkbox_candidates.append(
        dropdown_container.locator(
            'input[type="checkbox"], [role="checkbox"]'
        ).first
    )

    # 5. First checkbox inside dialog
    dialog = page.locator('[role="dialog"]').last

    checkbox_candidates.append(
        dialog.locator(
            'input[type="checkbox"], [role="checkbox"]'
        ).first
    )

    for checkbox in checkbox_candidates:
        try:
            if not await is_locator_visible(checkbox, timeout_ms=5000):
                continue

            try:
                await checkbox.check()
                logger.info("Call ID checkbox checked")
                return True, (
                    "CALL ID CHECKBOX SELECTED WITH NO SUGGESTIONS"
                    if no_suggestions_visible
                    else "CALL ID CHECKBOX SELECTED"
                )

            except Exception as check_error:
                logger.warning(
                    f"Checkbox check failed. Trying click. Error: {check_error}"
                )

                await checkbox.click()
                logger.info("Call ID checkbox clicked")
                return True, (
                    "CALL ID CHECKBOX CLICKED WITH NO SUGGESTIONS"
                    if no_suggestions_visible
                    else "CALL ID CHECKBOX CLICKED"
                )

        except Exception:
            continue

    if no_suggestions_visible:
        return False, "NO SUGGESTIONS FOUND - CHECKBOX NOT SELECTED"

    return False, "CALL ID FILTER VALUE CHECKBOX NOT FOUND"


async def enter_call_id_filter_value(page, call_id):
    """
    Enters actual Call ID value after selecting Call ID filter.

    Handles:
    1. Normal suggestion checkbox.
    2. Freeform checkbox when 'No suggestions found' appears.
    3. Applies filter when possible so UI can show 'No matching interactions'.
    """

    call_id_text = str(call_id).strip()

    value_input = page.locator(
        FILTER_VALUE_SEARCH_INPUT
    ).first

    await expect(value_input).to_be_visible(timeout=30000)

    await value_input.click()
    await value_input.fill("")
    await value_input.type(call_id_text, delay=100)

    logger.info(f"Typed actual Call ID value: {call_id_text}")

    await page.wait_for_timeout(3000)

    checkbox_success, checkbox_remarks = await select_first_available_call_id_checkbox(
        page,
        call_id_text
    )

    if not checkbox_success:
        return False, checkbox_remarks

    await page.wait_for_timeout(2000)

    apply_button = page.locator(
        FILTER_APPLY_BUTTON
    ).first

    if not await is_locator_visible(apply_button, timeout_ms=10000):
        apply_button = page.get_by_text(
            re.compile(
                r"^\s*Apply\s*filter\s*$|^\s*Apply\s*$",
                re.IGNORECASE
            )
        ).first

    await expect(apply_button).to_be_visible(timeout=30000)

    try:
        await expect(apply_button).to_be_enabled(timeout=10000)
        logger.info("Apply button is enabled")
    except Exception:
        logger.warning(
            "Apply button not enabled yet after checkbox selection. Waiting once more."
        )
        await page.wait_for_timeout(3000)

    await apply_button.click()

    logger.info("Call ID filter applied")

    await page.wait_for_timeout(5000)

    return True, checkbox_remarks


async def apply_call_id_filter(page, call_id):
    try:
        logger.info("-" * 80)
        logger.info(f"Applying Call ID filter: {call_id}")

        await click_add_filter(page)
        await select_call_id_filter_name(page)

        value_success, value_remarks = await enter_call_id_filter_value(
            page,
            call_id
        )

        if not value_success:
            return {
                "success": False,
                "remarks": value_remarks
            }

        return {
            "success": True,
            "remarks": value_remarks
        }

    except Exception as e:
        logger.error(f"Call ID filter failed for {call_id}: {e}")

        return {
            "success": False,
            "remarks": f"Call ID filter failed. Error: {e}"
        }


async def apply_call_id_filter_with_retry(page, call_id, retry_count=1):
    """
    Retry policy:
    - Attempt filter once.
    - If failed, press Esc, Clear all, wait, retry same Call ID once.
    - If retry also failed, return failed.

    Strictly no Delete filter action is used.
    """

    last_error = ""
    total_attempts = retry_count + 1

    for attempt in range(1, total_attempts + 1):
        logger.info(
            f"Call ID filter attempt {attempt}/{total_attempts}: {call_id}"
        )

        await close_filter_popover_if_open(page)
        await clear_all_filters_if_available(page)
        await page.wait_for_timeout(2000)

        result = await apply_call_id_filter(page, call_id)

        if result.get("success"):
            logger.info(
                f"Call ID filter applied successfully on attempt {attempt}: {call_id}"
            )

            return {
                "success": True,
                "remarks": (
                    f"Call ID filter applied successfully on attempt {attempt}. "
                    f"{result.get('remarks', '')}"
                )
            }

        last_error = result.get("remarks", "")

        logger.warning(
            f"Filter attempt {attempt} failed for {call_id}: {last_error}"
        )

        if attempt <= retry_count:
            logger.info(
                "Retrying same Call ID after Escape, Clear all, and wait."
            )

            await close_filter_popover_if_open(page)
            await clear_all_filters_if_available(page)
            await page.wait_for_timeout(7000)

    return {
        "success": False,
        "remarks": (
            f"Call ID filter failed after {total_attempts} attempt(s). "
            f"Last error: {last_error}"
        )
    }


# ==========================================================
# RESULT WAIT
# ==========================================================

async def get_first_data_row(page, call_id):
    """
    Finds a usable result row after Call ID filter is applied.

    First priority:
    - row containing Call ID text

    Fallback:
    - first visible non-header data row
    """

    rows = page.locator('[role="row"]')

    try:
        row_count = await rows.count()
    except Exception:
        return None

    first_data_row = None

    for index in range(row_count):
        row = rows.nth(index)

        try:
            if not await row.is_visible(timeout=500):
                continue

            row_text = await row.inner_text(timeout=1000)
            row_text_clean = " ".join(str(row_text).split())
            lower_text = row_text_clean.lower()

            if not row_text_clean:
                continue

            if (
                "date/ time" in lower_text
                and "media type" in lower_text
                and "duration" in lower_text
            ):
                continue

            if (
                "agent" in lower_text
                and "duration" in lower_text
                and "customer" in lower_text
                and "size" in lower_text
            ):
                continue

            if "no matching interactions" in lower_text:
                continue

            if first_data_row is None:
                first_data_row = row

            if str(call_id) in row_text_clean:
                logger.info(f"Found data row containing Call ID: {call_id}")
                return row

        except Exception:
            continue

    if first_data_row is not None:
        logger.info(
            "Call ID text not found inside row, but first visible data row was found."
        )
        return first_data_row

    return None


async def wait_for_result_or_no_matching_interactions(
    page,
    call_id,
    timeout_ms=40000
):
    end_time = asyncio.get_running_loop().time() + timeout_ms / 1000

    no_matching_locator = page.get_by_text(
        re.compile(r"No matching interactions", re.IGNORECASE)
    )

    while asyncio.get_running_loop().time() < end_time:
        try:
            if await no_matching_locator.is_visible(timeout=1000):
                logger.info("No matching interactions message found")

                return {
                    "status": "NO_MATCHING_INTERACTIONS",
                    "row": None
                }
        except Exception:
            pass

        row = await get_first_data_row(page, call_id)

        if row is not None:
            return {
                "status": "RESULT_FOUND",
                "row": row
            }

        await page.wait_for_timeout(1000)

    logger.warning("Timeout waiting for result row or No matching interactions")

    return {
        "status": "TIMEOUT",
        "row": None
    }


# ==========================================================
# ROW SIZE CAPTURE
# ==========================================================

async def capture_size_from_result_row(row):
    try:
        row_text = await row.inner_text(timeout=5000)

        size_candidates = extract_size_candidates(row_text)

        if size_candidates:
            ui_size = normalize_size_text(size_candidates[-1])

            logger.info(f"UI size captured from result row: {ui_size}")

            return ui_size

        logger.warning("No size found in result row text.")

        return ""

    except Exception as e:
        logger.warning(f"Unable to capture size from result row: {e}")
        return ""


# ==========================================================
# PLAYER DURATION CAPTURE
# ==========================================================

async def wait_for_player_duration(page, timeout_ms=90000):
    """
    Captures duration only from:
    [data-test-id="PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION"]
    """

    duration_locator = page.locator(PLAYER_DURATION_LOCATOR)

    end_time = asyncio.get_running_loop().time() + timeout_ms / 1000

    last_duration = ""
    stable_count = 0
    zero_duration_seen = False

    while asyncio.get_running_loop().time() < end_time:
        try:
            locator_count = await duration_locator.count()

            logger.info(
                f"Player duration locator count: {locator_count}"
            )

            if locator_count == 0:
                logger.info("Player duration locator not found yet. Waiting...")
                await page.wait_for_timeout(2000)
                continue

            duration_element = duration_locator.first

            if not await is_locator_visible(duration_element, timeout_ms=3000):
                logger.info(
                    "Player duration locator exists but not visible yet. Waiting..."
                )
                await page.wait_for_timeout(2000)
                continue

            raw_duration = await duration_element.inner_text(timeout=3000)
            duration = normalize_duration_text(raw_duration)

            logger.info(
                "Duration captured from "
                f"PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION: {duration}"
            )

            if duration == "00:00:00":
                zero_duration_seen = True
                logger.info(
                    "Player duration is 00:00:00. Waiting for actual duration."
                )

            elif duration:
                if duration == last_duration:
                    stable_count += 1
                else:
                    last_duration = duration
                    stable_count = 1

                if stable_count >= 2:
                    logger.info(
                        f"Stable player duration confirmed: {duration}"
                    )

                    return {
                        "ui_duration": duration,
                        "zero_duration_seen": zero_duration_seen,
                        "duration_stable": True,
                        "locator_count": locator_count
                    }

        except Exception as e:
            logger.warning(f"Player duration read retry failed: {e}")

        await page.wait_for_timeout(2000)

    logger.warning(
        f"Player duration timeout. Last duration: {last_duration}"
    )

    locator_count = 0

    try:
        locator_count = await duration_locator.count()
    except Exception:
        locator_count = 0

    if last_duration:
        return {
            "ui_duration": last_duration,
            "zero_duration_seen": zero_duration_seen,
            "duration_stable": False,
            "locator_count": locator_count
        }

    return {
        "ui_duration": "00:00:00" if zero_duration_seen else "",
        "zero_duration_seen": zero_duration_seen,
        "duration_stable": False,
        "locator_count": locator_count
    }


# ==========================================================
# AUDIO INFO CAPTURE
# ==========================================================

async def open_result_row_and_capture_audio_info(page, row):
    """
    Size:
    - Captured from filtered result row.

    Duration:
    - Captured only from:
      [data-test-id="PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION"]

    Does not click audio player/duration frame.
    """

    try:
        await expect(row).to_be_visible(timeout=30000)

        ui_size = await capture_size_from_result_row(row)

        await row.click()

        logger.info("Clicked first result row to open audio info")

        await page.wait_for_timeout(5000)

        duration_info = await wait_for_player_duration(
            page,
            timeout_ms=90000
        )

        ui_duration = normalize_duration_text(
            duration_info.get("ui_duration", "")
        )

        if not ui_size and not ui_duration:
            return {
                "ui_size": "",
                "ui_duration": "",
                "status": "NO AUDIO INFO FOUND",
                "remarks": (
                    "Result row clicked, but row size and player duration "
                    "were not captured."
                )
            }

        if ui_size and is_zero_duration(ui_duration):
            return {
                "ui_size": ui_size,
                "ui_duration": ui_duration,
                "status": "UI CAPTURE PARTIAL",
                "remarks": (
                    "Audio size captured from result row, but player duration "
                    "remained 00:00:00 after waiting. Process 3 should use "
                    "size fallback carefully."
                )
            }

        if ui_size and ui_duration:
            return {
                "ui_size": ui_size,
                "ui_duration": ui_duration,
                "status": "MATCH READY",
                "remarks": (
                    "UI audio size captured from filtered result row and "
                    "duration captured successfully from "
                    "PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION."
                )
            }

        return {
            "ui_size": ui_size,
            "ui_duration": ui_duration,
            "status": "UI CAPTURE PARTIAL",
            "remarks": (
                "Audio information partially captured. "
                f"Size: {ui_size or 'Not captured'}, "
                f"Duration: {ui_duration or 'Not captured'}."
            )
        }

    except Exception as e:
        logger.error(f"Audio info capture failed: {e}")

        return {
            "ui_size": "",
            "ui_duration": "",
            "status": "AUDIO INFO NOT OPENED",
            "remarks": (
                "Result row was found and clicked, but audio information could "
                f"not be opened/captured. Error: {e}"
            )
        }


# ==========================================================
# RECORD BUILDER
# ==========================================================

def build_ui_record(
    source_item,
    ui_site,
    ui_size,
    ui_duration,
    status,
    remarks,
    screenshot_path
):
    return {
        "call_id": source_item.get("call_id", ""),
        "source_excel_site": source_item.get("source_excel_site", ""),
        "excel_date_time": source_item.get("excel_date_time", ""),
        "excel_date": source_item.get("excel_date", ""),
        "excel_row_sequence": source_item.get("excel_row_sequence", ""),
        "answered": source_item.get("answered", ""),
        "ui_item_id": source_item.get("ui_item_id"),
        "ui_site": ui_site,
        "ui_size": normalize_size_text(ui_size),
        "ui_duration": normalize_duration_text(ui_duration),
        "status": status,
        "remarks": remarks,
        "screenshot_path": screenshot_path
    }


# ==========================================================
# PROCESS 2 MAIN
# ==========================================================

async def process2():
    logger.info("=" * 100)
    logger.info("PROCESS 2 STARTED | UI CAPTURE")
    logger.info("=" * 100)

    source_records = load_call_id_records()

    logger.info(f"Total source records loaded: {len(source_records)}")

    ui_records = []

    async with async_playwright() as playwright:
        browser, context, page = await get_or_start_chrome_context(playwright)

        await ensure_recordings_page(page)

        for index, source_item in enumerate(source_records, start=1):
            call_id = source_item.get("call_id", "")
            source_excel_site = source_item.get("source_excel_site", "")

            logger.info("-" * 100)
            logger.info(
                f"SITE: {source_excel_site} | "
                f"CALL ID {index}/{len(source_records)} | VALUE: {call_id}"
            )

            if source_item.get("status") in [
                "EXCEL FILE NOT FOUND",
                "NO ANSWERED CALL IDS"
            ]:
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id or "NO_CALL_ID",
                    source_item.get("status")
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site="",
                        ui_size="",
                        ui_duration="",
                        status=source_item.get("status"),
                        remarks=source_item.get("remarks", ""),
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)
                continue

            if not call_id:
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    "EMPTY_CALL_ID",
                    "NO_CALL_ID"
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site="",
                        ui_size="",
                        ui_duration="",
                        status="NO RECORD FOUND IN UI",
                        remarks="Call ID is empty in source JSON.",
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)
                continue

            await close_filter_popover_if_open(page)
            await clear_all_filters_if_available(page)

            filter_result = await apply_call_id_filter_with_retry(
                page,
                call_id,
                retry_count=1
            )

            if not filter_result.get("success"):
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id,
                    "CALL_ID_FILTER_FAILED"
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site=source_excel_site,
                        ui_size="",
                        ui_duration="",
                        status="CALL ID FILTER FAILED",
                        remarks=filter_result.get("remarks", ""),
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)

                await close_filter_popover_if_open(page)
                await clear_all_filters_if_available(page)
                continue

            wait_result = await wait_for_result_or_no_matching_interactions(
                page,
                call_id,
                timeout_ms=40000
            )

            wait_status = wait_result.get("status")
            result_row = wait_result.get("row")

            if wait_status == "NO_MATCHING_INTERACTIONS":
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id,
                    "NO_MATCHING_INTERACTIONS"
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site=source_excel_site,
                        ui_size="",
                        ui_duration="",
                        status="NO MATCHING INTERACTIONS",
                        remarks=(
                            "Call ID filter was applied successfully, but UI displayed "
                            "'No matching interactions found'. Screenshot captured. "
                            "Filter cleared and automation continued with next Call ID."
                        ),
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)

                await close_filter_popover_if_open(page)
                await clear_all_filters_if_available(page)
                continue

            if wait_status == "TIMEOUT":
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id,
                    "NO_RECORD_FOUND_TIMEOUT"
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site=source_excel_site,
                        ui_size="",
                        ui_duration="",
                        status="NO RECORD FOUND IN UI",
                        remarks=(
                            "After applying Call ID filter, neither result row nor "
                            "'No matching interactions' message appeared within timeout. "
                            "Screenshot captured. Filter cleared and automation continued."
                        ),
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)

                await close_filter_popover_if_open(page)
                await clear_all_filters_if_available(page)
                continue

            if wait_status != "RESULT_FOUND" or result_row is None:
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id,
                    "NO_RECORD_FOUND_IN_UI"
                )

                ui_records.append(
                    build_ui_record(
                        source_item=source_item,
                        ui_site=source_excel_site,
                        ui_size="",
                        ui_duration="",
                        status="NO RECORD FOUND IN UI",
                        remarks="Unexpected UI state. No usable result row found.",
                        screenshot_path=screenshot_path
                    )
                )

                save_ui_records(ui_records)

                await close_filter_popover_if_open(page)
                await clear_all_filters_if_available(page)
                continue

            capture_result = await open_result_row_and_capture_audio_info(
                page,
                result_row
            )

            capture_status = capture_result.get("status", "")
            ui_size = capture_result.get("ui_size", "")
            ui_duration = capture_result.get("ui_duration", "")
            remarks = capture_result.get("remarks", "")

            screenshot_path = ""

            if capture_status in [
                "UI CAPTURE PARTIAL",
                "AUDIO INFO NOT OPENED",
                "NO AUDIO INFO FOUND"
            ]:
                screenshot_path = await capture_process2_screenshot(
                    page,
                    source_excel_site,
                    call_id,
                    capture_status
                )

            ui_records.append(
                build_ui_record(
                    source_item=source_item,
                    ui_site=source_excel_site,
                    ui_size=ui_size,
                    ui_duration=ui_duration,
                    status=capture_status,
                    remarks=remarks,
                    screenshot_path=screenshot_path
                )
            )

            save_ui_records(ui_records)

            await close_filter_popover_if_open(page)
            await clear_all_filters_if_available(page)

        logger.info("=" * 100)
        logger.info("PROCESS 2 COMPLETED")
        logger.info(f"UI capture file generated: {os.path.abspath(UI_CAPTURE_JSON)}")
        logger.info(f"Total UI records: {len(ui_records)}")
        logger.info("=" * 100)

        logger.info("Chrome debug browser left open.")


if __name__ == "__main__":
    asyncio.run(process2())