-- ==========================================================
-- DATABASE: caller_automation
-- Purpose:
--   Store execution tracking, application config, Excel download status,
--   8x8 Call ID audit, UI capture, validation result,
--   CLINEVO case data, SQL update audit, screenshots,
--   errors, email configuration and email sending status.
-- ==========================================================

CREATE DATABASE IF NOT EXISTS caller_automation
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE caller_automation;

-- ==========================================================
-- 1. APP CONFIG
-- Stores config.py values used by automation.
-- Sensitive values like passwords can be masked.
-- ==========================================================

CREATE TABLE IF NOT EXISTS app_config (
    config_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    config_key VARCHAR(150) NOT NULL,
    config_value TEXT,
    config_group VARCHAR(100),

    is_sensitive BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_app_config_key (config_key),
    INDEX idx_app_config_group (config_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 2. AUTOMATION PROCESS STATUS
-- One row for every master_main.py execution.
-- Tracks overall execution, 8x8 status, CLINEVO status,
-- date range mode, final report dates and total counts.
-- ==========================================================

CREATE TABLE IF NOT EXISTS automation_process_status (
    execution_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    run_name VARCHAR(150),
    run_mode VARCHAR(50),

    started_at DATETIME,
    ended_at DATETIME,

    status VARCHAR(50),
    eightx8_status VARCHAR(50),
    clinevo_status VARCHAR(50),

    date_range_mode VARCHAR(50),
    date_range_value VARCHAR(100),

    custom_from_date VARCHAR(20),
    custom_to_date VARCHAR(20),

    final_report_from_date VARCHAR(20),
    final_report_to_date VARCHAR(20),

    run_8x8 BOOLEAN DEFAULT TRUE,
    run_clinevo BOOLEAN DEFAULT TRUE,

    total_8x8_excel_downloads INT DEFAULT 0,
    total_clinevo_excel_downloads INT DEFAULT 0,

    total_call_ids INT DEFAULT 0,
    total_ui_capture_records INT DEFAULT 0,
    total_recording_validation_rows INT DEFAULT 0,

    total_clinevo_cases INT DEFAULT 0,
    total_clinevo_audio_check_rows INT DEFAULT 0,

    email_status VARCHAR(50),
    email_sent_at DATETIME,

    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_process_status (status),
    INDEX idx_process_eightx8_status (eightx8_status),
    INDEX idx_process_clinevo_status (clinevo_status),
    INDEX idx_process_date_range_mode (date_range_mode),
    INDEX idx_process_started_at (started_at),
    INDEX idx_process_email_status (email_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 3. EXECUTION STEP LOG
-- Tracks each automation step.
-- Example:
--   8x8 login started
--   8x8 Excel downloaded
--   SQL date updated
--   CLINEVO report generated
-- ==========================================================

CREATE TABLE IF NOT EXISTS execution_step_log (
    step_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    module_name VARCHAR(150),
    function_name VARCHAR(150),
    step_name VARCHAR(200),

    source_system VARCHAR(50),
    site_name VARCHAR(100),
    enterprise_name VARCHAR(100),

    started_at DATETIME,
    ended_at DATETIME,

    status VARCHAR(50),
    message TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_step_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_step_execution (execution_id),
    INDEX idx_step_status (status),
    INDEX idx_step_source_system (source_system),
    INDEX idx_step_name (step_name),
    INDEX idx_step_site (site_name),
    INDEX idx_step_enterprise (enterprise_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 4. EIGHTX8 DOWNLOADED EXCEL STATUS
-- Tracks each downloaded 8x8 Excel.
-- Includes date range mode, selected date range,
-- report from date and report to date.
-- ==========================================================

CREATE TABLE IF NOT EXISTS eightxeight_downloaded_excel_status (
    download_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    site_name VARCHAR(100),
    report_type VARCHAR(150),

    date_range_mode VARCHAR(50),
    date_range_value VARCHAR(100),

    report_from_date VARCHAR(20),
    report_to_date VARCHAR(20),

    custom_from_date VARCHAR(20),
    custom_to_date VARCHAR(20),

    file_name VARCHAR(255),
    file_path TEXT,
    download_folder TEXT,

    downloaded_at DATETIME,
    file_exists BOOLEAN DEFAULT FALSE,
    file_size_bytes BIGINT,

    status VARCHAR(50),
    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_eightxeight_download_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_eightxeight_download_execution (execution_id),
    INDEX idx_eightxeight_download_site (site_name),
    INDEX idx_eightxeight_download_status (status),
    INDEX idx_eightxeight_date_range_mode (date_range_mode),
    INDEX idx_eightxeight_report_dates (report_from_date, report_to_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 5. CLINEVO DOWNLOADED EXCEL STATUS
-- Tracks each CLINEVO Excel download.
-- Includes enterprise, report from/to date and file details.
-- ==========================================================

CREATE TABLE IF NOT EXISTS clinevo_downloaded_excel_status (
    download_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    enterprise_name VARCHAR(100),
    site_name VARCHAR(100),
    report_type VARCHAR(150),

    date_range_mode VARCHAR(50),
    date_range_value VARCHAR(100),

    report_from_date VARCHAR(20),
    report_to_date VARCHAR(20),

    custom_from_date VARCHAR(20),
    custom_to_date VARCHAR(20),

    file_name VARCHAR(255),
    file_path TEXT,
    download_folder TEXT,

    downloaded_at DATETIME,
    file_exists BOOLEAN DEFAULT FALSE,
    file_size_bytes BIGINT,

    status VARCHAR(50),
    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_clinevo_download_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_clinevo_download_execution (execution_id),
    INDEX idx_clinevo_download_enterprise (enterprise_name),
    INDEX idx_clinevo_download_site (site_name),
    INDEX idx_clinevo_download_status (status),
    INDEX idx_clinevo_date_range_mode (date_range_mode),
    INDEX idx_clinevo_report_dates (report_from_date, report_to_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 6. AUDIT BY CALL ID
-- Stores ALL rows from 8x8 Excel without filtering.
-- Important searchable fields are stored as columns.
-- Complete original Excel row is stored in raw_row_json.
-- This table is the full Excel audit.
-- ==========================================================

CREATE TABLE IF NOT EXISTS audit_by_call_id (
    audit_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    source_site VARCHAR(100),
    call_id VARCHAR(150),

    direction VARCHAR(50),

    excel_date_time VARCHAR(100),
    excel_date VARCHAR(50),

    answered VARCHAR(50),

    caller VARCHAR(150),
    callee VARCHAR(150),
    queue_name VARCHAR(150),
    agent_name VARCHAR(150),

    source_excel_file TEXT,

    raw_row_json JSON,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_audit_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_audit_execution (execution_id),
    INDEX idx_audit_call_id (call_id),
    INDEX idx_audit_site (source_site),
    INDEX idx_audit_direction (direction),
    INDEX idx_audit_excel_date (excel_date),
    INDEX idx_audit_answered (answered)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 7. UI NEEDED CALL ITEMS
-- Stores only records selected for 8x8 UI search.
-- Usually filtered from audit_by_call_id.
-- ==========================================================

CREATE TABLE IF NOT EXISTS ui_needed_call_items (
    ui_item_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,
    audit_id BIGINT,

    source_site VARCHAR(100),
    call_id VARCHAR(150),

    direction VARCHAR(50),

    excel_date_time VARCHAR(100),
    excel_date VARCHAR(50),

    answered VARCHAR(50),
    source_excel_file TEXT,

    status VARCHAR(50),
    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_ui_needed_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_ui_needed_audit
        FOREIGN KEY (audit_id)
        REFERENCES audit_by_call_id(audit_id)
        ON DELETE SET NULL,

    INDEX idx_ui_needed_execution (execution_id),
    INDEX idx_ui_needed_call_id (call_id),
    INDEX idx_ui_needed_site (source_site),
    INDEX idx_ui_needed_status (status),
    INDEX idx_ui_needed_direction (direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 8. UI CAPTURE RECORD
-- Stores what 8x8 UI returned for each Call ID.
-- Also stores raw_json for complete UI captured details.
-- ==========================================================

CREATE TABLE IF NOT EXISTS ui_capture_record (
    ui_capture_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,
    ui_item_id BIGINT,

    call_id VARCHAR(150),
    source_excel_site VARCHAR(100),

    direction VARCHAR(50),

    excel_date_time VARCHAR(100),
    excel_date VARCHAR(50),
    answered VARCHAR(50),

    ui_site VARCHAR(100),
    ui_audio_duration VARCHAR(50),
    ui_audio_size VARCHAR(50),

    ui_status VARCHAR(100),
    remarks TEXT,

    screenshot_path TEXT,

    raw_json JSON,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_ui_capture_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_ui_capture_item
        FOREIGN KEY (ui_item_id)
        REFERENCES ui_needed_call_items(ui_item_id)
        ON DELETE SET NULL,

    INDEX idx_ui_capture_execution (execution_id),
    INDEX idx_ui_capture_call_id (call_id),
    INDEX idx_ui_capture_status (ui_status),
    INDEX idx_ui_capture_site (source_excel_site),
    INDEX idx_ui_capture_direction (direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 9. RECORDING VALIDATION RESULT
-- Final 8x8 recording validation result.
-- Includes direction column for future use.
-- Includes simplified_status for non-technical reporting.
-- ==========================================================

CREATE TABLE IF NOT EXISTS recording_validation_result (
    validation_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    call_id VARCHAR(150),
    direction VARCHAR(50),

    source_excel_site VARCHAR(100),
    excel_date_time VARCHAR(100),
    answered VARCHAR(50),

    ui_site VARCHAR(100),

    ui_audio_duration VARCHAR(50),
    local_audio_duration VARCHAR(50),

    ui_audio_size VARCHAR(50),
    local_audio_size VARCHAR(50),

    folder_available VARCHAR(20),
    file_available VARCHAR(20),

    status VARCHAR(100),
    simplified_status VARCHAR(100),

    audio_file_name TEXT,
    audio_file_path TEXT,

    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_recording_validation_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_recording_validation_execution (execution_id),
    INDEX idx_recording_validation_call_id (call_id),
    INDEX idx_recording_validation_status (status),
    INDEX idx_recording_validation_simplified_status (simplified_status),
    INDEX idx_recording_validation_site (source_excel_site),
    INDEX idx_recording_validation_direction (direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 10. CLINEVO CASE RECORD
-- Stores all extracted rows from CLINEVO Excel.
-- Based on Case Number / Case ID.
-- Includes case_version for future use.
-- Full original Excel row is stored in raw_row_json.
-- ==========================================================

CREATE TABLE IF NOT EXISTS clinevo_case_record (
    clinevo_case_record_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    enterprise_name VARCHAR(100),
    site_name VARCHAR(100),

    case_number VARCHAR(150),
    case_version VARCHAR(100),

    received_date VARCHAR(50),
    date_key VARCHAR(50),

    source_excel_file TEXT,

    raw_row_json JSON,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_clinevo_case_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_clinevo_case_execution (execution_id),
    INDEX idx_clinevo_case_number (case_number),
    INDEX idx_clinevo_case_enterprise (enterprise_name),
    INDEX idx_clinevo_case_site (site_name),
    INDEX idx_clinevo_case_received_date (received_date),
    INDEX idx_clinevo_case_version (case_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 11. CLINEVO CASE AUDIO RESULT
-- Final CLINEVO case/audio validation result.
-- Shows whether audio file Case ID is present in CLINEVO Excel.
-- ==========================================================

CREATE TABLE IF NOT EXISTS clinevo_case_audio_result (
    clinevo_result_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    enterprise_name VARCHAR(100),
    site_name VARCHAR(100),

    received_date VARCHAR(50),

    audio_file_name TEXT,
    audio_folder_path TEXT,

    extracted_case_id VARCHAR(150),
    excel_case_id_count INT,

    status VARCHAR(100),
    simplified_status VARCHAR(100),

    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_clinevo_audio_result_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_clinevo_audio_execution (execution_id),
    INDEX idx_clinevo_audio_case_id (extracted_case_id),
    INDEX idx_clinevo_audio_status (status),
    INDEX idx_clinevo_audio_simplified_status (simplified_status),
    INDEX idx_clinevo_audio_site (site_name),
    INDEX idx_clinevo_audio_enterprise (enterprise_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 12. SCREENSHOT LOG
-- Stores screenshot paths for failures or evidence.
-- ==========================================================

CREATE TABLE IF NOT EXISTS screenshot_log (
    screenshot_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    source_system VARCHAR(50),
    module_name VARCHAR(150),
    function_name VARCHAR(150),
    step_name VARCHAR(200),

    site_name VARCHAR(100),
    enterprise_name VARCHAR(100),

    call_id_or_case_id VARCHAR(150),

    screenshot_path TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_screenshot_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_screenshot_execution (execution_id),
    INDEX idx_screenshot_source_system (source_system),
    INDEX idx_screenshot_step_name (step_name),
    INDEX idx_screenshot_call_case (call_id_or_case_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 13. ERROR LOG
-- Stores automation exceptions, error messages and tracebacks.
-- ==========================================================

CREATE TABLE IF NOT EXISTS error_log (
    error_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT,

    source_system VARCHAR(50),
    module_name VARCHAR(150),
    function_name VARCHAR(150),
    step_name VARCHAR(200),

    site_name VARCHAR(100),
    enterprise_name VARCHAR(100),

    call_id_or_case_id VARCHAR(150),

    error_message TEXT,
    error_trace LONGTEXT,

    screenshot_path TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_error_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE SET NULL,

    INDEX idx_error_execution (execution_id),
    INDEX idx_error_source_system (source_system),
    INDEX idx_error_step_name (step_name),
    INDEX idx_error_call_case (call_id_or_case_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 14. SQL UPDATE AUDIT
-- Tracks exactly what SQL date section was updated in CLINEVO.
-- Stores old condition, new condition, full SQL before/after,
-- enterprise, date range mode and custom/preset dates.
-- ==========================================================

CREATE TABLE IF NOT EXISTS sql_update_audit (
    sql_update_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT NOT NULL,

    enterprise_name VARCHAR(100),
    report_name VARCHAR(150),

    date_range_mode VARCHAR(50),
    date_range_value VARCHAR(100),

    custom_from_date VARCHAR(20),
    custom_to_date VARCHAR(20),

    final_report_from_date VARCHAR(20),
    final_report_to_date VARCHAR(20),

    from_datetime VARCHAR(30),
    to_datetime VARCHAR(30),

    sql_section_updated VARCHAR(200),

    old_sql_condition TEXT,
    new_sql_condition TEXT,

    full_sql_before LONGTEXT,
    full_sql_after LONGTEXT,

    update_status VARCHAR(50),
    remarks TEXT,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_sql_update_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE CASCADE,

    INDEX idx_sql_update_execution (execution_id),
    INDEX idx_sql_update_enterprise (enterprise_name),
    INDEX idx_sql_update_status (update_status),
    INDEX idx_sql_update_report_dates (final_report_from_date, final_report_to_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 15. EMAIL CONFIG
-- Stores SMTP/email sending configuration.
-- Used by Python automation to send success/failure emails.
-- To, CC and BCC emails can be stored as comma-separated values.
-- ==========================================================

CREATE TABLE IF NOT EXISTS email_config (
    email_config_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    config_name VARCHAR(150) NOT NULL,

    smtp_host VARCHAR(255) NOT NULL,
    smtp_port INT NOT NULL,

    smtp_username VARCHAR(255),
    smtp_password TEXT,

    from_email VARCHAR(255) NOT NULL,

    to_emails TEXT,
    cc_emails TEXT,
    bcc_emails TEXT,

    use_ssl BOOLEAN DEFAULT FALSE,
    use_tls BOOLEAN DEFAULT TRUE,

    is_active BOOLEAN DEFAULT TRUE,

    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_email_config_name (config_name),
    INDEX idx_email_config_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- 16. EMAIL STATUS
-- Tracks every email sending attempt for an execution.
-- Stores success/failure email status, recipients, attachments,
-- error details and sent timestamp.
-- ==========================================================

CREATE TABLE IF NOT EXISTS email_status (
    email_status_id BIGINT AUTO_INCREMENT PRIMARY KEY,

    execution_id BIGINT,
    email_config_id BIGINT,

    mail_type VARCHAR(100),
    mail_subject TEXT,

    from_email VARCHAR(255),
    to_emails TEXT,
    cc_emails TEXT,
    bcc_emails TEXT,

    attachment_included BOOLEAN DEFAULT FALSE,
    attachment_paths TEXT,
    attachment_missing_reason TEXT,

    send_status VARCHAR(50),
    sent_at DATETIME,

    error_message TEXT,
    error_trace LONGTEXT,

    remarks TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_email_status_execution
        FOREIGN KEY (execution_id)
        REFERENCES automation_process_status(execution_id)
        ON DELETE SET NULL,

    CONSTRAINT fk_email_status_config
        FOREIGN KEY (email_config_id)
        REFERENCES email_config(email_config_id)
        ON DELETE SET NULL,

    INDEX idx_email_status_execution (execution_id),
    INDEX idx_email_status_mail_type (mail_type),
    INDEX idx_email_status_send_status (send_status),
    INDEX idx_email_status_sent_at (sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- OPTIONAL DEFAULT EMAIL CONFIG SAMPLE
-- Update values before using.
-- Keep this commented if you do not want to insert sample values.
-- ==========================================================

-- INSERT INTO email_config (
--     config_name,
--     smtp_host,
--     smtp_port,
--     smtp_username,
--     smtp_password,
--     from_email,
--     to_emails,
--     cc_emails,
--     bcc_emails,
--     use_ssl,
--     use_tls,
--     is_active,
--     remarks
-- )
-- VALUES (
--     'DEFAULT_SMTP',
--     'smtp.office365.com',
--     587,
--     'your_email@company.com',
--     'your_password_or_app_password',
--     'your_email@company.com',
--     'person1@company.com,person2@company.com',
--     'manager@company.com',
--     '',
--     FALSE,
--     TRUE,
--     TRUE,
--     'Default email configuration for automation success and failure emails'
-- );


-- ==========================================================
-- FINAL CHECK QUERIES
-- ==========================================================

SELECT COUNT(*) AS table_count
FROM information_schema.tables
WHERE table_schema = 'caller_automation';

SHOW TABLES;