"""
runtime_context.py

Small shared in-memory state for ONE master_main.py execution.

Why this file exists:
    master_main.py inserts the automation_process_status row and receives
    execution_id back from MySQL. Every other process file
    (intilial_process_1.py, excel_extration_callids.py, call_info_ui.py,
    validation_report.py, intilial_process_2.py,
    extract_clinivo_excel_check.py) needs that SAME execution_id so that all
    database rows written during this run can be tied together.

    Instead of changing every function signature to pass execution_id
    around (which would touch a lot of existing working code), master_main.py
    sets it once here, and db_helpers.py reads it from here automatically.

This module holds simple process-local state only (no DB calls).
It is safe to import from anywhere.
"""

_state = {
    "execution_id": None,
    "run_name": None,
    "date_range_mode": None,
    "date_range_value": None,
    "custom_from_date": None,
    "custom_to_date": None,
    "final_report_from_date": None,
    "final_report_to_date": None,
}


def set_execution_id(execution_id):
    _state["execution_id"] = execution_id


def get_execution_id():
    return _state.get("execution_id")


def set_run_name(run_name):
    _state["run_name"] = run_name


def get_run_name():
    return _state.get("run_name")


def update_report_dates(from_date, to_date):
    _state["final_report_from_date"] = from_date
    _state["final_report_to_date"] = to_date


def get_report_dates():
    return (
        _state.get("final_report_from_date"),
        _state.get("final_report_to_date"),
    )


def set_value(key, value):
    _state[key] = value


def get_value(key, default=None):
    return _state.get(key, default)


def reset():
    for key in list(_state.keys()):
        _state[key] = None
