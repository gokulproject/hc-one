"""
database_manager.py

Low level MySQL connection manager built on pymysql.

Purpose:
    Provide one consistent, safe way for the automation to talk to the
    caller_automation MySQL database described in:
        CALLEER AUTOMATION REFERANCE SCHEMA .txt

Design goals (per follow up prompt requirements):
    - Use pymysql cursor-based implementation.
    - Use pymysql.cursors.DictCursor so rows come back as dictionaries.
    - Support context manager usage: `with DatabaseManager() as db:`
    - Connect with retry.
    - Support execute, fetch_one, fetch_all, insert_and_get_id, executemany.
    - Support commit and rollback.
    - Close connection safely, always.
    - Never raise uncaught exceptions into the calling automation code
      when ENABLE_DB_LOGGING is False - DB usage is fully optional.

This file does not contain any UI automation logic and does not change
any existing automation behaviour. It is purely additive infrastructure.
"""

import time

import pymysql
import pymysql.cursors

import config
from logger import get_logger

logger = get_logger(__name__)


class DatabaseManager:
    """
    Usage:

        from database_manager import DatabaseManager

        with DatabaseManager() as db:
            execution_id = db.insert_and_get_id(
                "INSERT INTO automation_process_status (run_name, status) "
                "VALUES (%s, %s)",
                ("RUN_1", "STARTED")
            )

            row = db.fetch_one(
                "SELECT * FROM automation_process_status WHERE execution_id = %s",
                (execution_id,)
            )
    """

    def __init__(self, db_config: dict = None, retries: int = 3, retry_delay_seconds: float = 2.0):

        self.db_config = db_config or getattr(config, "DB_CONFIG", {})
        self.retries = retries
        self.retry_delay_seconds = retry_delay_seconds
        self.connection = None

    # ------------------------------------------------------------------
    # CONNECTION HANDLING
    # ------------------------------------------------------------------

    def connect(self):

        if not self.db_config:
            raise RuntimeError(
                "DB_CONFIG is not defined in config.py. "
                "Cannot connect to MySQL."
            )

        last_error = None

        for attempt in range(1, self.retries + 1):

            try:
                self.connection = pymysql.connect(
                    host=self.db_config.get("host", "localhost"),
                    port=int(self.db_config.get("port", 3306)),
                    user=self.db_config.get("user", "root"),
                    password=self.db_config.get("password", ""),
                    database=self.db_config.get("database", "caller_automation"),
                    charset="utf8mb4",
                    cursorclass=pymysql.cursors.DictCursor,
                    autocommit=False,
                    connect_timeout=10,
                )

                logger.info(
                    "MySQL connection established | host=%s | db=%s",
                    self.db_config.get("host"),
                    self.db_config.get("database"),
                )

                return self.connection

            except Exception as error:

                last_error = error

                logger.warning(
                    "MySQL connection attempt %s/%s failed: %s",
                    attempt,
                    self.retries,
                    error,
                )

                if attempt < self.retries:
                    time.sleep(self.retry_delay_seconds)

        raise ConnectionError(
            f"Could not connect to MySQL after {self.retries} attempts: {last_error}"
        )

    def close(self):

        try:
            if self.connection is not None:
                self.connection.close()
                logger.info("MySQL connection closed")
        except Exception as error:
            logger.warning("Error closing MySQL connection: %s", error)
        finally:
            self.connection = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):

        try:
            if exc_type is None:
                self.commit()
            else:
                self.rollback()
        finally:
            self.close()

        # Do not suppress exceptions - let caller decide how to handle them.
        return False

    # ------------------------------------------------------------------
    # COMMIT / ROLLBACK
    # ------------------------------------------------------------------

    def commit(self):

        try:
            if self.connection is not None:
                self.connection.commit()
        except Exception as error:
            logger.warning("MySQL commit failed: %s", error)

    def rollback(self):

        try:
            if self.connection is not None:
                self.connection.rollback()
        except Exception as error:
            logger.warning("MySQL rollback failed: %s", error)

    # ------------------------------------------------------------------
    # CORE EXECUTION HELPERS
    # ------------------------------------------------------------------

    def execute(self, sql: str, params: tuple = None):
        """
        Runs one INSERT / UPDATE / DELETE / DDL statement.
        Returns number of affected rows.
        """

        with self.connection.cursor() as cursor:
            affected = cursor.execute(sql, params or ())
            return affected

    def executemany(self, sql: str, params_list: list):
        """
        Runs one statement against many rows of params.
        Useful for bulk inserts (e.g. audit_by_call_id).
        """

        if not params_list:
            return 0

        with self.connection.cursor() as cursor:
            affected = cursor.executemany(sql, params_list)
            return affected

    def insert_and_get_id(self, sql: str, params: tuple = None) -> int:
        """
        Runs one INSERT statement and returns the AUTO_INCREMENT id.
        """

        with self.connection.cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.lastrowid

    def fetch_one(self, sql: str, params: tuple = None):

        with self.connection.cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.fetchone()

    def fetch_all(self, sql: str, params: tuple = None):

        with self.connection.cursor() as cursor:
            cursor.execute(sql, params or ())
            return cursor.fetchall()
