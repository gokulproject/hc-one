import asyncio
import subprocess
import os
import logging
import re
from datetime import datetime
import config

from playwright.async_api import (
    async_playwright,
    expect,
    Page,
    TimeoutError as PlaywrightTimeoutError
)

try:
    import db_helpers
except Exception:
    db_helpers = None


# =====================================================
# CONFIGURATION
# Source of truth is config.py.
# Do not edit values in this file.
# =====================================================

LOGIN_URL = config.LOGIN_URL

CLINEVO_USERNAME = config.CLINEVO_USERNAME
CLINEVO_PASSWORD = config.CLINEVO_PASSWORD

CLINEVO_ENTERPRISE_1 = config.CLINEVO_ENTERPRISE_1
CLINEVO_ENTERPRISE_2 = config.CLINEVO_ENTERPRISE_2

REPORT_FROM_DATE = config.REPORT_FROM_DATE
REPORT_TO_DATE = config.REPORT_TO_DATE

CHROME_DEBUG_URL = config.CHROME_DEBUG_URL
CHROME_EXE_PATH = config.CHROME_EXE_PATH
CHROME_USER_DATA_DIR = config.CHROME_USER_DATA_DIR

SCREENSHOT_FOLDER = str(
    config.CLINEVO_SCREENSHOT_DIR
)

CLINEVO_ENTERPRISE_1_EXCEL = str(
    config.ADVAGEN_CLINEVO_EXCEL_FOLDER
)

CLINEVO_ENTERPRISE_2_EXCEL = str(
    config.VALIDUS_CLINEVO_EXCEL_FOLDER
)

config.create_required_folders()

os.makedirs(
    SCREENSHOT_FOLDER,
    exist_ok=True
)

os.makedirs(
    CLINEVO_ENTERPRISE_1_EXCEL,
    exist_ok=True
)

if CLINEVO_ENTERPRISE_2.strip():

    os.makedirs(
        CLINEVO_ENTERPRISE_2_EXCEL,
        exist_ok=True
    )
# =====================================================
# LOGGING
# =====================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)

# =====================================================
# SCREENSHOT UTILITY
# =====================================================

async def take_screenshot(page, step_name="screenshot"):

    try:

        if page.is_closed():

            logger.error(
                "Screenshot skipped because page is closed"
            )

            return None

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        file_path = os.path.join(
            SCREENSHOT_FOLDER,
            f"{step_name}_{timestamp}.png"
        )

        await page.screenshot(
            path=file_path,
            full_page=True
        )

        logger.info(
            f"Screenshot Saved : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Screenshot Failed : {e}"
        )

        return None

# =====================================================
# CAPTURE FAILURE DETAILS
# =====================================================

async def capture_failure_details(page: Page, step_name):

    try:

        logger.error(
            f"Capturing failure details for : {step_name}"
        )

        if page.is_closed():

            logger.error(
                "Cannot capture failure details because page is closed"
            )

            return

        try:

            logger.error(
                f"Failure Page URL : {page.url}"
            )

        except Exception as e:

            logger.warning(
                f"Unable to capture page URL : {e}"
            )

        try:

            page_title = await page.title()

            logger.error(
                f"Failure Page Title : {page_title}"
            )

        except Exception as e:

            logger.warning(
                f"Unable to capture page title : {e}"
            )

        try:

            body_text = await page.locator(
                "body"
            ).inner_text(
                timeout=5000
            )

            logger.error(
                f"Failure Page Body Text First 2000 Chars : {body_text[:2000]}"
            )

        except Exception as e:

            logger.warning(
                f"Unable to capture body text : {e}"
            )

        await take_screenshot(
            page,
            step_name
        )

    except Exception as e:

        logger.error(
            f"Capture failure details failed : {e}"
        )

# =====================================================
# START CHROME
# =====================================================

async def start_chrome():

    try:

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            await browser.close()

            logger.info(
                "Chrome already running"
            )

            return True

    except Exception:

        logger.info(
            "Starting Chrome"
        )

        subprocess.Popen([
            CHROME_EXE_PATH,
            "--remote-debugging-port=9222",
            f"--user-data-dir={CHROME_USER_DATA_DIR}",
            "--start-maximized",
            "--no-first-run"
        ])

        for i in range(20):

            await asyncio.sleep(1)

            try:

                async with async_playwright() as p:

                    browser = await p.chromium.connect_over_cdp(
                        CHROME_DEBUG_URL
                    )

                    await browser.close()

                    logger.info(
                        "Chrome Started"
                    )

                    return True

            except Exception:

                logger.info(
                    f"Waiting Chrome Startup {i + 1}/20"
                )

        return False

# =====================================================
# GET VALID PAGE
# =====================================================

async def get_valid_page(context):

    try:

        logger.info(
            "Finding valid browser page"
        )

        for existing_page in context.pages:

            try:

                if existing_page.is_closed():

                    continue

                current_url = existing_page.url

                if "clinevotech.com" in current_url:

                    logger.info(
                        f"Using existing Clinevo page : {current_url}"
                    )

                    await existing_page.bring_to_front()

                    return existing_page

            except Exception:

                continue

        for existing_page in context.pages:

            try:

                if existing_page.is_closed():

                    continue

                current_url = existing_page.url

                if current_url.startswith("http://") or current_url.startswith("https://"):

                    logger.info(
                        f"Using existing normal page : {current_url}"
                    )

                    await existing_page.bring_to_front()

                    return existing_page

            except Exception:

                continue

        logger.info(
            "No valid page found. Creating new page"
        )

        return await context.new_page()

    except Exception as e:

        logger.error(
            f"Get Valid Page Failed : {e}"
        )

        raise

# =====================================================
# VERIFY CLINEVO DASHBOARD
# =====================================================

async def verify_clinevo_dashboard(page: Page, enterprise_name):

    try:

        logger.info(
            f"Verifying Clinevo dashboard for enterprise : {enterprise_name}"
        )

        intake_link = page.get_by_role(
            "link",
            name=re.compile(
                rf"{re.escape(enterprise_name)}.*MICC Intake",
                re.IGNORECASE
            )
        )

        await expect(
            intake_link
        ).to_be_visible(
            timeout=60000
        )

        logger.info(
            f"Verified dashboard intake link : {enterprise_name} MICC Intake"
        )

        await expect(
            page.locator(
                "#mCSB_1"
            )
        ).to_be_visible(
            timeout=60000
        )

        logger.info(
            "Verified dashboard sidebar container : #mCSB_1"
        )

        return True

    except Exception as e:

        logger.error(
            f"Clinevo dashboard verification failed for {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"clinevo_dashboard_verification_failed_{enterprise_name}"
        )

        raise

# =====================================================
# CHECK CLINEVO LOGIN STATUS
# =====================================================

async def is_clinevo_logged_in(page: Page, enterprise_name):

    try:

        logger.info(
            f"Checking Clinevo login status from current page for : {enterprise_name}"
        )

        intake_link = page.get_by_role(
            "link",
            name=re.compile(
                rf"{re.escape(enterprise_name)}.*MICC Intake",
                re.IGNORECASE
            )
        )

        await expect(
            intake_link
        ).to_be_visible(
            timeout=10000
        )

        logger.info(
            f"Clinevo already logged in for enterprise : {enterprise_name}"
        )

        return True

    except Exception:

        logger.info(
            f"Clinevo dashboard not visible for enterprise : {enterprise_name}"
        )

        return False

# =====================================================
# CLINEVO LOGIN
# =====================================================

async def clinevo_login(page: Page, enterprise_name):

    try:

        logger.info(
            f"Opening Clinevo Login Page for enterprise : {enterprise_name}"
        )

        await page.goto(
            LOGIN_URL,
            wait_until="domcontentloaded",
            timeout=60000
        )

        await expect(
            page.get_by_text(
                "User Name"
            )
        ).to_be_visible(
            timeout=30000
        )

        await page.locator(
            "#UserName"
        ).click()

        await page.locator(
            "#UserName"
        ).fill(
            CLINEVO_USERNAME
        )

        logger.info(
            "Clinevo Username Entered"
        )

        await expect(
            page.get_by_text(
                "Password",
                exact=True
            )
        ).to_be_visible(
            timeout=30000
        )

        await page.locator(
            "#UserPwd"
        ).click()

        await page.locator(
            "#UserPwd"
        ).fill(
            CLINEVO_PASSWORD
        )

        logger.info(
            "Clinevo Password Entered"
        )

        await expect(
            page.get_by_text(
                "Enterprise Name"
            )
        ).to_be_visible(
            timeout=30000
        )

        await page.locator(
            "#enterprise"
        ).click()

        await page.locator(
            "#enterprise"
        ).fill(
            enterprise_name
        )

        logger.info(
            f"Clinevo Enterprise Entered : {enterprise_name}"
        )

        login_btn = page.get_by_role(
            "button",
            name="Log In"
        )

        await expect(
            login_btn
        ).to_be_visible(
            timeout=30000
        )

        await login_btn.click()

        logger.info(
            f"Clinevo Login Button Clicked For : {enterprise_name}"
        )

        await verify_clinevo_dashboard(
            page,
            enterprise_name
        )

        logger.info(
            f"Clinevo Login Successful For : {enterprise_name}"
        )

    except Exception as e:

        logger.error(
            f"Clinevo Login Failed For {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"clinevo_login_error_{enterprise_name}"
        )

        raise

# =====================================================
# ENSURE CLINEVO LOGIN
# =====================================================

async def ensure_clinevo_login(page: Page, enterprise_name):

    try:

        logger.info(
            f"Ensure Clinevo Login Started For : {enterprise_name}"
        )

        if await is_clinevo_logged_in(
            page,
            enterprise_name
        ):

            logger.info(
                f"Login skipped - Already logged in for : {enterprise_name}"
            )

            return

        logger.info(
            f"Not already logged in for {enterprise_name}. Opening login page"
        )

        await page.goto(
            LOGIN_URL,
            wait_until="domcontentloaded",
            timeout=60000
        )

        await page.wait_for_timeout(
            3000
        )

        if await is_clinevo_logged_in(
            page,
            enterprise_name
        ):

            logger.info(
                f"Login skipped - Existing session redirected to dashboard for : {enterprise_name}"
            )

            return

        await clinevo_login(
            page,
            enterprise_name
        )

        logger.info(
            f"Ensure Clinevo Login Completed For : {enterprise_name}"
        )

    except Exception as e:

        logger.error(
            f"Ensure Clinevo Login Failed For {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"ensure_clinevo_login_error_{enterprise_name}"
        )

        raise

# =====================================================
# ENSURE CLINEVO SIDEBAR VISIBLE
# =====================================================

async def ensure_clinevo_sidebar_visible(page: Page):

    try:

        logger.info(
            "Checking Clinevo sidebar visibility"
        )

        sidebar = page.locator(
            "#mCSB_1"
        )

        try:

            await expect(
                sidebar
            ).to_be_visible(
                timeout=5000
            )

            logger.info(
                "Clinevo sidebar already visible"
            )

            return

        except Exception:

            logger.info(
                "Sidebar not visible. Trying mobile/sidebar toggle"
            )

        toggle_btn = page.locator(
            "#mob-view a"
        )

        await expect(
            toggle_btn
        ).to_be_visible(
            timeout=30000
        )

        await toggle_btn.click()

        logger.info(
            "Sidebar toggle clicked first time"
        )

        try:

            await expect(
                sidebar
            ).to_be_visible(
                timeout=5000
            )

            logger.info(
                "Sidebar visible after first toggle click"
            )

            return

        except Exception:

            logger.info(
                "Sidebar still not visible after first click. Clicking second time"
            )

        await toggle_btn.click()

        logger.info(
            "Sidebar toggle clicked second time"
        )

        await expect(
            sidebar
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Sidebar visible after second toggle click"
        )

    except Exception as e:

        logger.error(
            f"Ensure Clinevo Sidebar Visible Failed : {e}"
        )

        await capture_failure_details(
            page,
            "clinevo_sidebar_visible_error"
        )

        raise

# =====================================================
# OPEN GENERAL LINE LISTING
# =====================================================

async def open_general_line_listing(page: Page):

    try:

        logger.info(
            "Opening General Line Listing"
        )

        await ensure_clinevo_sidebar_visible(
            page
        )

        await expect(
            page.locator(
                "#mCSB_1"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Sidebar container visible"
        )

        reports_menu = page.get_by_text(
            "Reports",
            exact=True
        )

        await expect(
            reports_menu
        ).to_be_visible(
            timeout=30000
        )

        await reports_menu.click()

        logger.info(
            "Reports clicked"
        )

        general_line_listing = page.get_by_text(
            "General Line Listing",
            exact=True
        )

        await expect(
            general_line_listing
        ).to_be_visible(
            timeout=30000
        )

        await general_line_listing.click()

        logger.info(
            "General Line Listing clicked"
        )

        await expect(
            page.get_by_text(
                "Reports > Line Listing"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Breadcrumb verified : Reports > Line Listing"
        )

        await expect(
            page.get_by_role(
                "heading",
                name="Line Listing"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Line Listing heading visible"
        )

        await expect(
            page.locator(
                ".panel-body"
            ).first
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Panel body visible"
        )

        await expect(
            page.get_by_role(
                "gridcell",
                name="Line Listing: MICC"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Line Listing: MICC gridcell visible"
        )

    except Exception as e:

        logger.error(
            f"Open General Line Listing Failed : {e}"
        )

        await capture_failure_details(
            page,
            "open_general_line_listing_error"
        )

        raise

# =====================================================
# CLICK LINE LISTING EDIT ICON
# =====================================================

async def click_line_listing_edit_icon(page: Page):

    try:

        logger.info(
            "Finding and clicking Line Listing MICC edit icon"
        )

        await expect(
            page.get_by_role(
                "gridcell",
                name=re.compile(
                    r"Line Listing: MICC",
                    re.IGNORECASE
                )
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Line Listing: MICC gridcell visible"
        )

        edit_icon = page.locator(
            "tr:nth-child(3) > td:nth-child(2) > .dx-icon-edit"
        ).first

        await expect(
            edit_icon
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Line Listing MICC edit icon visible"
        )

        await edit_icon.evaluate(
            "element => element.click()"
        )

        logger.info(
            "Line Listing MICC edit icon clicked using JavaScript"
        )

        await expect(
            page.get_by_text(
                "Sql text:"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "SQL editor opened after edit icon click"
        )

    except Exception as e:

        logger.error(
            f"Click Line Listing Edit Icon Failed : {e}"
        )

        await capture_failure_details(
            page,
            "click_line_listing_edit_icon_error"
        )

        raise
# =====================================================
# DATE FORMAT VALIDATION
# =====================================================

def validate_dd_mon_yyyy(date_text, field_name):

    try:

        if date_text is None:

            raise ValueError(
                f"{field_name} cannot be None"
            )

        date_text = str(
            date_text
        ).strip().upper()

        pattern = r"^\d{2}-[A-Z]{3}-\d{4}$"

        if not re.fullmatch(
            pattern,
            date_text
        ):

            raise ValueError(
                f"{field_name} must be in DD-MON-YYYY format. "
                f"Example : 15-JUL-2026. Actual : {date_text}"
            )

        datetime.strptime(
            date_text,
            "%d-%b-%Y"
        )

        logger.info(
            f"{field_name} format validation passed : {date_text}"
        )

        return date_text

    except Exception as e:

        logger.error(
            f"{field_name} date format validation failed : {e}"
        )

        raise
# =====================================================
# UPDATE ONLY CASE_RECEIVED_DATE DATE RANGE WITH LOG
# =====================================================

def update_sql_date_range(sql_text, from_date, to_date, enterprise_name=""):

    try:
        
        from_date = validate_dd_mon_yyyy(
            from_date,
            "REPORT_FROM_DATE"
        )

        to_date = validate_dd_mon_yyyy(
            to_date,
            "REPORT_TO_DATE"
        )


        logger.info(
            f"Updating CASE_RECEIVED_DATE Date Range | From : {from_date} | To : {to_date}"
        )

        from_datetime = f"{from_date} 00:00:00"
        to_datetime = f"{to_date} 23:59:59"

        pattern = (
            r"(CASE_RECEIVED_DATE\s+BETWEEN\s+TO_DATE\s*\(\s*')"
            r"([^']+)"
            r"('\s*,\s*'DD-MON-YYYY HH24:MI:SS'\s*\)\s+AND\s+TO_DATE\s*\(\s*')"
            r"([^']+)"
            r"(')"
        )

        old_match = re.search(
            pattern,
            sql_text,
            flags=re.IGNORECASE
        )

        if not old_match:

            logger.error(
                "CASE_RECEIVED_DATE date range not found in textarea SQL"
            )

            logger.error(
                "FULL SQL TEXT FROM TEXTAREA START"
            )

            logger.error(
                sql_text
            )

            logger.error(
                "FULL SQL TEXT FROM TEXTAREA END"
            )

            if db_helpers is not None:
                try:
                    db_helpers.insert_sql_update_audit(
                        enterprise_name=enterprise_name,
                        date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                        date_range_value=config.DATE_RANGE or "",
                        custom_from_date=config.CUSTOM_FROM_DATE,
                        custom_to_date=config.CUSTOM_TO_DATE,
                        final_report_from_date=from_date,
                        final_report_to_date=to_date,
                        from_datetime="",
                        to_datetime="",
                        old_sql_condition="",
                        new_sql_condition="",
                        full_sql_before=sql_text,
                        full_sql_after="",
                        update_status="FAILED",
                        remarks="CASE_RECEIVED_DATE date range not found in textarea SQL",
                    )
                except Exception as db_error:
                    logger.warning(f"DB insert for sql_update_audit failed: {db_error}")

            raise Exception(
                "CASE_RECEIVED_DATE date range not found in textarea SQL"
            )

        old_sql_condition = old_match.group(0)
        old_from_datetime = old_match.group(2)
        old_to_datetime = old_match.group(4)

        logger.info(
            f"OLD From DateTime : {old_from_datetime}"
        )

        logger.info(
            f"OLD To DateTime : {old_to_datetime}"
        )

        logger.info(
            f"OLD SQL Date Condition : {old_sql_condition}"
        )

        logger.info(
            f"NEW From DateTime : {from_datetime}"
        )

        logger.info(
            f"NEW To DateTime : {to_datetime}"
        )

        updated_sql, replace_count = re.subn(
            pattern,
            rf"\g<1>{from_datetime}\g<3>{to_datetime}\g<5>",
            sql_text,
            count=1,
            flags=re.IGNORECASE
        )

        new_match = re.search(
            pattern,
            updated_sql,
            flags=re.IGNORECASE
        )

        new_sql_condition = ""

        if new_match:

            new_sql_condition = new_match.group(0)

            logger.info(
                f"NEW SQL Date Condition : {new_sql_condition}"
            )

        logger.info(
            f"CASE_RECEIVED_DATE Date Range Updated Successfully. Replacement Count : {replace_count}"
        )

        if db_helpers is not None:
            try:
                db_helpers.insert_sql_update_audit(
                    enterprise_name=enterprise_name,
                    date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                    date_range_value=config.DATE_RANGE or "",
                    custom_from_date=config.CUSTOM_FROM_DATE,
                    custom_to_date=config.CUSTOM_TO_DATE,
                    final_report_from_date=from_date,
                    final_report_to_date=to_date,
                    from_datetime=from_datetime,
                    to_datetime=to_datetime,
                    old_sql_condition=old_sql_condition,
                    new_sql_condition=new_sql_condition,
                    full_sql_before=sql_text,
                    full_sql_after=updated_sql,
                    update_status="SUCCESS" if replace_count else "FAILED",
                    remarks="",
                )
            except Exception as db_error:
                logger.warning(f"DB insert for sql_update_audit failed: {db_error}")

        return updated_sql

    except Exception as e:

        logger.error(
            f"SQL Date Range Update Failed : {e}"
        )

        raise

# =====================================================
# EDIT SQL ONLY
# =====================================================

async def edit_sql_only(page: Page, from_date, to_date, enterprise_name=""):

    try:

        logger.info(
            "Editing SQL date range in textarea"
        )

        await expect(
            page.get_by_text(
                "Sql text:"
            )
        ).to_be_visible(
            timeout=30000
        )

        textarea = page.locator(
            "textarea"
        ).first

        await expect(
            textarea
        ).to_be_visible(
            timeout=30000
        )

        await page.wait_for_timeout(
            1000
        )

        sql_text = await textarea.input_value()

        if not sql_text:

            sql_text = await textarea.evaluate(
                "element => element.value || element.textContent || element.innerText || ''"
            )

        logger.info(
            f"Captured SQL Text Length : {len(sql_text)}"
        )

        updated_sql = update_sql_date_range(
            sql_text,
            from_date,
            to_date,
            enterprise_name=enterprise_name
        )

        await textarea.click()

        await textarea.fill(
            updated_sql
        )

        logger.info(
            f"SQL updated in textarea | From : {from_date} | To : {to_date}"
        )

    except Exception as e:

        logger.error(
            f"Edit SQL Failed : {e}"
        )

        await capture_failure_details(
            page,
            "edit_sql_error"
        )

        raise

# =====================================================
# SAVE, SUBMIT, DOWNLOAD EXCEL
# =====================================================

async def save_submit_and_download_excel(page: Page, enterprise_name, download_folder):

    try:

        logger.info(
            f"Saving SQL and downloading Excel for : {enterprise_name}"
        )

        save_btn = page.get_by_role(
            "button",
            name="Save"
        )

        await expect(
            save_btn
        ).to_be_visible(
            timeout=30000
        )

        await save_btn.click()

        logger.info(
            f"Save button clicked for : {enterprise_name}"
        )

        await expect(
            page.get_by_text(
                "Report Line Listing: MICC"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Report Line Listing: MICC visible"
        )

        await expect(
            page.get_by_role(
                "gridcell",
                name="Line Listing: MICC"
            )
        ).to_be_visible(
            timeout=30000
        )

        line_listing_row = page.get_by_role(
            "row",
            name=re.compile(
                r"Line Listing: MICC",
                re.IGNORECASE
            )
        )

        radio_btn = line_listing_row.get_by_role(
            "radio"
        )

        await expect(
            radio_btn
        ).to_be_visible(
            timeout=30000
        )

        await radio_btn.click()

        logger.info(
            "Line Listing: MICC radio selected"
        )

        submit_btn = page.get_by_role(
            "button",
            name="Submit"
        )

        await expect(
            submit_btn
        ).to_be_visible(
            timeout=30000
        )

        await submit_btn.click()

        logger.info(
            "Submit button clicked"
        )

        await expect(
            page.get_by_text(
                "Line Listing To ExcelCase"
            )
        ).to_be_visible(
            timeout=60000
        )

        to_excel_btn = page.get_by_role(
            "button",
            name="To Excel"
        )

        await expect(
            to_excel_btn
        ).to_be_visible(
            timeout=60000
        )

        async with page.expect_download(
            timeout=120000
        ) as download_info:

            await to_excel_btn.click()

        download = await download_info.value

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        safe_enterprise_name = enterprise_name.replace(
            " ",
            "_"
        )

        file_path = os.path.join(
            download_folder,
            f"{safe_enterprise_name}_Line_Listing_MICC_{timestamp}.xlsx"
        )

        await download.save_as(
            file_path
        )

        logger.info(
            f"Excel Saved For {enterprise_name} : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Save Submit Download Failed For {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"save_submit_download_error_{enterprise_name}"
        )

        raise

# =====================================================
# LOGOUT
# =====================================================

async def logout_and_verify_login_page(page: Page, enterprise_name):

    try:

        logger.info(
            f"Logging out from Clinevo for : {enterprise_name}"
        )

        logout_link = page.get_by_role(
            "link",
            name=""
        )

        await expect(
            logout_link
        ).to_be_visible(
            timeout=30000
        )

        await logout_link.click()

        logger.info(
            "Logout icon clicked"
        )

        yes_btn = page.get_by_role(
            "button",
            name="Yes"
        )

        await expect(
            yes_btn
        ).to_be_visible(
            timeout=30000
        )

        await yes_btn.click()

        logger.info(
            "Logout Yes clicked"
        )

        await expect(
            page.get_by_text(
                "User Name"
            )
        ).to_be_visible(
            timeout=60000
        )

        await expect(
            page.locator(
                "#UserName"
            )
        ).to_be_visible(
            timeout=60000
        )

        logger.info(
            f"Logout successful for : {enterprise_name}"
        )

    except Exception as e:

        logger.error(
            f"Logout Failed For {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"logout_error_{enterprise_name}"
        )

        raise

# =====================================================
# RUN FLOW FOR ONE ENTERPRISE
# =====================================================

async def process_2_enterprise_flow(page: Page, enterprise_name, download_folder):

    try:

        logger.info(
            f"PROCESS 2 ENTERPRISE FLOW STARTED : {enterprise_name}"
        )

        await ensure_clinevo_login(
            page,
            enterprise_name
        )

        await open_general_line_listing(
            page
        )

        await click_line_listing_edit_icon(
            page
        )
        
        logger.info(
            f"Holding execution for 10 seconds before SQL update | Enterprise : {enterprise_name} | From : {REPORT_FROM_DATE} | To : {REPORT_TO_DATE}"
        )

        await asyncio.sleep(
            10
        )

        logger.info(
            "10 seconds hold completed. Continuing SQL update."
        )

        
        await edit_sql_only(
            page,
            REPORT_FROM_DATE,
            REPORT_TO_DATE,
            enterprise_name=enterprise_name
        )

        excel_file = await save_submit_and_download_excel(
            page,
            enterprise_name,
            download_folder
        )

        if db_helpers is not None:
            try:
                db_helpers.insert_clinevo_download_status(
                    enterprise_name=enterprise_name,
                    site_name=enterprise_name,
                    file_path=excel_file,
                    download_folder=download_folder,
                    date_range_mode="PRESET" if config.DATE_RANGE else "CUSTOM",
                    date_range_value=config.DATE_RANGE or "",
                    report_from_date=REPORT_FROM_DATE,
                    report_to_date=REPORT_TO_DATE,
                    custom_from_date=config.CUSTOM_FROM_DATE,
                    custom_to_date=config.CUSTOM_TO_DATE,
                    status="SUCCESS" if excel_file else "FAILED",
                    remarks="",
                )
            except Exception as db_error:
                logger.warning(f"DB insert for clinevo download status failed: {db_error}")

        await logout_and_verify_login_page(
            page,
            enterprise_name
        )

        logger.info(
            f"PROCESS 2 ENTERPRISE FLOW COMPLETED : {enterprise_name}"
        )

        return excel_file

    except Exception as e:

        logger.error(
            f"Process 2 Enterprise Flow Failed For {enterprise_name} : {e}"
        )

        await capture_failure_details(
            page,
            f"process_2_enterprise_flow_error_{enterprise_name}"
        )

        raise

# =====================================================
# PROCESS 2 FLOW
# =====================================================

async def process_2_flow(page: Page):

    try:

        logger.info(
            "PROCESS 2 FLOW STARTED"
        )

        downloaded_files = []

        file_1 = await process_2_enterprise_flow(
            page,
            CLINEVO_ENTERPRISE_1,
            CLINEVO_ENTERPRISE_1_EXCEL
        )

        downloaded_files.append(
            file_1
        )

        if CLINEVO_ENTERPRISE_2.strip():

            file_2 = await process_2_enterprise_flow(
                page,
                CLINEVO_ENTERPRISE_2,
                CLINEVO_ENTERPRISE_2_EXCEL
            )

            downloaded_files.append(
                file_2
            )

        else:

            logger.info(
                "CLINEVO_ENTERPRISE_2 is empty. Skipping second enterprise."
            )

        logger.info(
            f"PROCESS 2 FLOW COMPLETED FOR ALL ENTERPRISES : {downloaded_files}"
        )

        return downloaded_files

    except Exception as e:

        logger.error(
            f"Process 2 Flow Failed : {e}"
        )

        await capture_failure_details(
            page,
            "process_2_flow_error"
        )

        raise

# =====================================================
# MAIN
# =====================================================

async def main():

    browser = None

    try:

        logger.info(
            "INITIAL PROCESS 2 STARTED"
        )

        if not await start_chrome():

            logger.error(
                "Chrome Startup Failed"
            )

            return

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            if browser.contexts:

                context = browser.contexts[0]

            else:

                context = await browser.new_context()

            page = await get_valid_page(
                context
            )

            if page.is_closed():

                page = await context.new_page()

            await page.bring_to_front()

            logger.info(
                f"Active Page URL Before Flow : {page.url}"
            )

            downloaded_files = await process_2_flow(
                page
            )

            logger.info(
                f"SUCCESS : Initial Process 2 Completed : {downloaded_files}"
            )

    except PlaywrightTimeoutError as e:

        logger.error(
            f"Timeout Error : {e}"
        )

    except Exception as e:

        logger.error(
            f"Automation Failed : {e}"
        )

    finally:

        logger.info(
            "Automation Finished"
        )

# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    asyncio.run(main())