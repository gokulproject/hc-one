from django import forms
from healthcheck.models import Customer, Environment, Schedule, EscalationConfig


class CustomerForm(forms.ModelForm):
    class Meta:
        model  = Customer
        fields = ["name", "code", "tenant_type", "is_active", "notes"]
        widgets = {
            "name":        forms.TextInput(attrs={"class": "form-control"}),
            "code":        forms.TextInput(attrs={"class": "form-control"}),
            "tenant_type": forms.Select(
                choices=[("Single","Single"),("Multi","Multi")],
                attrs={"class": "form-select"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }


class EnvironmentForm(forms.ModelForm):
    # Extra field for plain password input (not stored directly)
    plain_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={"class": "form-control",
                                          "placeholder": "Leave blank to keep existing"}),
        help_text="Enter new password (will be AES-256 encrypted). Leave blank to keep existing.",
    )

    class Meta:
        model  = Environment
        fields = ["customer", "env_type", "server_user", "is_active", "notes"]
        widgets = {
            "customer":   forms.Select(attrs={"class": "form-select"}),
            "env_type":   forms.Select(
                choices=[("PRD","Production"),("VAL","Validation"),("DEV","Development")],
                attrs={"class": "form-select"}),
            "server_user": forms.TextInput(attrs={"class": "form-control",
                                                   "placeholder": "DOMAIN\\\\username"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Load customer choices from healthcheck_db
        try:
            from healthcheck.models import Customer
            self.fields["customer"].queryset = Customer.objects.using("healthcheck_db").filter(is_active=True)
        except Exception:
            pass


class ScheduleForm(forms.ModelForm):
    """
    Schedule form with:
    - Selectable customer dropdown (from DB)
    - Selectable env_types dropdown
    - start_at accepts IST input (YYYY-MM-DD HH:MM:SS)
    - Cron quick-select
    """
    # IST start_at input
    start_at = forms.DateTimeField(
        required=False,
        input_formats=["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
                       "%d-%m-%Y %H:%M:%S", "%d/%m/%Y %H:%M"],
        widget=forms.DateTimeInput(
            format="%Y-%m-%d %H:%M:%S",
            attrs={
                "class":       "form-control",
                "type":        "datetime-local",
                "placeholder": "YYYY-MM-DD HH:MM:SS  (IST)",
                "id":          "id_start_at",
            }),
        help_text=(
            "<strong>Enter in IST (Asia/Kolkata).</strong> "
            "e.g. <code>2026-05-01 16:08:00</code> = 4:08 PM IST. "
            "First execution fires at exactly this time with 0 delay."
        ),
        label="Start At (IST)",
    )

    # Selectable env dropdown
    ENV_CHOICES = [
        ("",    "-- Select Environment --"),
        ("PROD","Production (PROD)"),
        ("PRD", "Production (PRD)"),
        ("VAL", "Validation (VAL)"),
        ("DEV", "Development (DEV)"),
        ("UAT", "UAT"),
    ]
    env_types = forms.ChoiceField(
        choices=ENV_CHOICES,
        widget=forms.Select(attrs={"class": "form-select"}),
        label="Environment",
    )

    # Cron quick-select with common presets
    CRON_PRESETS = [
        ("",               "-- Custom / Enter below --"),
        ("*/5 * * * *",    "Every 5 minutes"),
        ("*/10 * * * *",   "Every 10 minutes"),
        ("*/15 * * * *",   "Every 15 minutes"),
        ("*/30 * * * *",   "Every 30 minutes"),
        ("0 */1 * * *",    "Every 1 hour"),
        ("0 */2 * * *",    "Every 2 hours"),
        ("0 */4 * * *",    "Every 4 hours"),
        ("0 */6 * * *",    "Every 6 hours"),
        ("0 */12 * * *",   "Every 12 hours"),
        ("0 0 * * *",      "Every day at midnight"),
        ("0 8 * * *",      "Every day at 8 AM"),
        ("0 9 * * 1-5",    "Weekdays at 9 AM"),
        ("0 0 * * 0",      "Every Sunday midnight"),
    ]
    cron_preset = forms.ChoiceField(
        choices=CRON_PRESETS,
        required=False,
        widget=forms.Select(attrs={
            "class":    "form-select",
            "onchange": "if(this.value){document.getElementById('id_cron_expression').value=this.value;}",
        }),
        label="Cron Preset (optional)",
    )

    class Meta:
        model  = Schedule
        fields = ["customer", "env_types", "schedule_name",
                  "cron_expression", "start_at", "is_active", "notes"]
        widgets = {
            "customer": forms.Select(
                attrs={"class": "form-select", "id": "id_customer"}),
            "schedule_name": forms.TextInput(
                attrs={"class": "form-control",
                       "placeholder": "e.g. ABC Pharma Daily Check"}),
            "cron_expression": forms.TextInput(
                attrs={"class": "form-control font-monospace",
                       "placeholder": "e.g. */10 * * * *",
                       "id": "id_cron_expression"}),
            "is_active": forms.CheckboxInput(
                attrs={"class": "form-check-input"}),
            "notes": forms.TextInput(
                attrs={"class": "form-control",
                       "placeholder": "Optional notes"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Load customers from healthcheck_db
        try:
            from healthcheck.models import Customer
            qs = Customer.objects.using("healthcheck_db").filter(is_active=True).order_by("name")
            self.fields["customer"].queryset = qs
            self.fields["customer"].empty_label = "-- Select Customer --"
        except Exception:
            pass

        # If editing existing, pre-populate start_at as IST display
        if self.instance and self.instance.pk and self.instance.start_at:
            from datetime import timedelta
            ist_val = self.instance.start_at
            if hasattr(ist_val, 'tzinfo') and ist_val.tzinfo:
                ist_val = ist_val.astimezone(
                    __import__('datetime').timezone(timedelta(hours=5, minutes=30))
                ).replace(tzinfo=None)
            else:
                ist_val = ist_val + timedelta(hours=5, minutes=30)
            self.initial["start_at"] = ist_val.strftime("%Y-%m-%d %H:%M:%S")

    def clean_start_at(self):
        """Convert IST input → UTC for DB storage."""
        dt = self.cleaned_data.get("start_at")
        if dt is None:
            return None
        from datetime import timedelta, timezone as _tz
        if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
            return dt
        # Naive → IST → UTC (subtract 5:30)
        return dt - timedelta(hours=5, minutes=30)


class EscalationConfigForm(forms.ModelForm):
    class Meta:
        model  = EscalationConfig
        fields = ["threshold", "interval_hours", "max_escalations", "notify_rerun_fail"]
        widgets = {
            "threshold":       forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "interval_hours":  forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "max_escalations": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "notify_rerun_fail": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
