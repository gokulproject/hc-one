-- ============================================================
-- Health Check v8 — Complete ALTER Script
-- Generated from model code. Run ALL statements in order.
-- Server stores DATETIME in UTC. App displays in IST.
-- ============================================================

-- ── 1. schedules table ────────────────────────────────────────────────────
ALTER TABLE schedules
  ADD COLUMN IF NOT EXISTS start_at DATETIME NULL
  COMMENT 'Admin-entered IST converted to UTC. Scheduler fires at exactly this UTC time. NULL = fire immediately.'
  AFTER is_active;

-- ── 2. escalation_config table ────────────────────────────────────────────
ALTER TABLE escalation_config
  ADD COLUMN IF NOT EXISTS send_resolved_mail TINYINT(1) NOT NULL DEFAULT 0
  COMMENT '1 = send email when all issues resolved for this customer/env'
  AFTER notify_rerun_fail;

ALTER TABLE escalation_config
  ADD COLUMN IF NOT EXISTS env_mail_enabled TINYINT(1) NOT NULL DEFAULT 1
  COMMENT '0 = disable ALL escalation emails for this customer/env'
  AFTER send_resolved_mail;

-- ── 3. rerun_queue table ──────────────────────────────────────────────────
ALTER TABLE rerun_queue
  ADD COLUMN IF NOT EXISTS started_at DATETIME NULL
  COMMENT 'When this rerun attempt actually started (UTC)'
  AFTER scheduled_at;

ALTER TABLE rerun_queue
  ADD COLUMN IF NOT EXISTS last_error TEXT NULL
  COMMENT 'Error/reason why this attempt failed or was queued'
  AFTER max_attempts;

-- ── 4. execution_runs table ───────────────────────────────────────────────
ALTER TABLE execution_runs
  ADD COLUMN IF NOT EXISTS rerun_attempt INT NOT NULL DEFAULT 0
  COMMENT 'Retry attempt number (0=original, 1=first retry, 2=second...)'
  AFTER rerun_of_run_id;

ALTER TABLE execution_runs
  ADD COLUMN IF NOT EXISTS error_summary TEXT NULL
  COMMENT 'Captured when run fails/crashes/is killed mid-execution'
  AFTER completed_at;

-- ── 5. scheduler_tracker table (CREATE if missing) ────────────────────────
CREATE TABLE IF NOT EXISTS scheduler_tracker (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  schedule_id         INT UNSIGNED NULL,
  customer_id         INT UNSIGNED NOT NULL,
  env_types           VARCHAR(50)  NOT NULL,
  schedule_name       VARCHAR(200) NOT NULL DEFAULT '',
  cron_expression     VARCHAR(100) NOT NULL DEFAULT '',
  run_id              BIGINT UNSIGNED NULL,
  status              ENUM('PENDING','RUNNING','COMPLETED','FAILED','FAILED_QUEUE','SKIPPED')
                      NOT NULL DEFAULT 'PENDING',
  scheduled_fire_at   DATETIME NOT NULL COMMENT 'UTC',
  actual_start_at     DATETIME NULL,
  completed_at        DATETIME NULL,
  last_run_at         DATETIME NULL,
  next_run_at         DATETIME NULL,
  error_message       TEXT NULL,
  is_active           TINYINT(1) NOT NULL DEFAULT 1,
  triggered_by        VARCHAR(100) NOT NULL DEFAULT 'scheduler',
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_st_customer (customer_id),
  KEY idx_st_schedule (schedule_id),
  KEY idx_st_status   (status),
  KEY idx_st_fire_at  (scheduled_fire_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Every scheduler firing tracked here. Datetimes stored UTC, displayed IST.';

-- ── 6. system_config keys ─────────────────────────────────────────────────
INSERT IGNORE INTO system_config (config_key, config_value, description)
VALUES
  ('timezone',                  'Asia/Kolkata',
   'Application timezone. All DB values stored UTC, UI shows IST.'),
  ('stuck_run_timeout_minutes', '90',
   'Minutes before IN_PROGRESS run is considered stuck and marked FAILED'),
  ('rerun_max_attempts',        '3',
   'Maximum number of retry attempts for a failed run'),
  ('rerun_interval_hours',      '24',
   'Hours between rerun retry attempts');

-- ── 7. Verify everything ──────────────────────────────────────────────────
-- Run these SELECTs to confirm:
-- SHOW COLUMNS FROM schedules LIKE 'start_at';
-- SHOW COLUMNS FROM escalation_config LIKE 'send_resolved_mail';
-- SHOW COLUMNS FROM rerun_queue LIKE 'last_error';
-- SHOW COLUMNS FROM execution_runs LIKE 'rerun_attempt';
-- SHOW TABLES LIKE 'scheduler_tracker';
-- SELECT config_key, config_value FROM system_config WHERE config_key IN
--   ('timezone','rerun_max_attempts','rerun_interval_hours','stuck_run_timeout_minutes');

-- ── 8. IST ↔ UTC reference ────────────────────────────────────────────────
-- Admin enters 4:08 PM IST → DB stores 10:38 AM UTC  (IST - 5:30 = UTC)
-- DB has      10:38 AM UTC → UI shows  04:08 PM IST  (UTC + 5:30 = IST)
-- DO NOT insert IST datetimes directly into DB — always use UTC.

-- ============================================================
-- END alter_v8.sql
-- ============================================================
