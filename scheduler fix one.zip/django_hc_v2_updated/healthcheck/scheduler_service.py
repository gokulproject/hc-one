"""
healthcheck/scheduler_service.py  (v9 – IST 12h + UTC DB storage)
==================================================================
STORY:
  • MySQL stores DATETIME in UTC (server default)
  • Admin inputs start_at in IST via Admin panel
  • scheduler_service converts IST → UTC for DB writes
  • UI reads UTC from DB and displays in IST 12-hour format
  • All cron calculations done in IST, stored as UTC

KEY RULES:
  1. start_at  = admin-set IST time, first execution trigger
  2. created_at = just a timestamp, NEVER triggers execution
  3. After first run: next_run = next cron tick from last run (IST)
  4. Minute preserved: cron "43 */1 * * *" always fires at :43
  5. No popup when scheduler is stopped
"""
import logging
import threading
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger("hc.scheduler")

_scheduler       = None
_scheduler_lock  = threading.Lock()
_active_runs: dict = {}
_active_runs_lock  = threading.Lock()


# ── IST helpers (no external dependency needed) ───────────────────────────
def _now_ist():
    """Current naive IST datetime."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
    except Exception:
        return datetime.utcnow() + timedelta(hours=5, minutes=30)

def _now_utc():
    return datetime.utcnow()

def _utc_to_ist(dt):
    if dt is None: return None
    if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
        try:
            from zoneinfo import ZoneInfo
            return dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
        except Exception:
            return dt.replace(tzinfo=None) + timedelta(hours=5, minutes=30)
    return dt + timedelta(hours=5, minutes=30)

def _ist_to_utc(dt):
    if dt is None: return None
    if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
        return dt.astimezone(__import__('datetime').timezone.utc).replace(tzinfo=None)
    return dt - timedelta(hours=5, minutes=30)

def _fmt_ist_12h(dt):
    if dt is None: return "Never"
    return _utc_to_ist(dt).strftime("%d-%b-%Y %I:%M %p")

def _next_cron_utc(cron_expr: str, after_ist: datetime) -> datetime:
    """Given IST reference time, get next cron fire → return as UTC."""
    from croniter import croniter
    ci = croniter(cron_expr, after_ist)
    return _ist_to_utc(ci.get_next(datetime))


# ── DB error types ──────────────────────────────────────────────────────
def _db_err():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError: pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError: pass
    return types


def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


# ── Tracker helpers ──────────────────────────────────────────────────────
def _update_tracker(db, tracker_id: int, **kwargs):
    try:
        if not kwargs or not tracker_id: return
        sets = ", ".join(f"{k}=%s" for k in kwargs)
        vals = list(kwargs.values()) + [tracker_id]
        db.execute(
            f"UPDATE scheduler_tracker SET {sets}, updated_at=NOW() WHERE id=%s", vals)
    except Exception as e:
        logger.warning(f"tracker update: {e}")

def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, fire_at_utc,
                    triggered_by="apscheduler") -> int:
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id,customer_id,env_types,schedule_name,cron_expression,
                status,scheduled_fire_at,triggered_by,is_active,created_at,updated_at)
               VALUES(%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, fire_at_utc, triggered_by))
    except Exception as e:
        logger.warning(f"tracker insert: {e}"); return 0


# ── Execution ─────────────────────────────────────────────────────────────
def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """Run HC in background thread. COM-safe. Cleans up properly."""
    _coinit = False
    try:
        import pythoncom; pythoncom.CoInitialize(); _coinit = True
    except Exception: pass

    eng = _get_engine()
    with _active_runs_lock:
        _active_runs[run_id] = label

    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id, status="RUNNING",
                                actual_start_at=_now_utc())
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

        final = _get_status(run_id)
        logger.info(f"[Scheduler] Run #{run_id} ({label}) → {final}")

        if tracker_id:
            with eng["DBManager"]() as db:
                st = "COMPLETED" if final in ("COMPLETED","PARTIAL") else "FAILED"
                _update_tracker(db, tracker_id, status=st,
                                completed_at=_now_utc(),
                                error_message=None if st=="COMPLETED" else final)
    except Exception as exc:
        logger.error(f"[Scheduler] Run #{run_id} error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    completed_at=_now_utc(),
                                    error_message=str(exc)[:1000])
            except Exception: pass
    finally:
        with _active_runs_lock:
            _active_runs.pop(run_id, None)
        if _coinit:
            try:
                import pythoncom; pythoncom.CoUninitialize()
            except Exception: pass


def _get_status(run_id: int) -> str:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            row = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s",(run_id,))
            return row["status"] if row else "UNKNOWN"
    except Exception: return "UNKNOWN"


# ── Schedule firing ────────────────────────────────────────────────────────
def _fire_schedule(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str,
                   start_at_utc=None):
    """
    Called by APScheduler. Fires ONLY if start_at has been reached.
    start_at_utc is stored in DB as UTC.
    All comparisons and logs use IST.
    """
    eng       = _get_engine()
    label     = f"{customer_name}/{env_types}"
    now_utc   = _now_utc()
    now_ist   = _utc_to_ist(now_utc)

    # ── STRICT start_at check ─────────────────────────────────────────
    if start_at_utc is not None:
        sa_utc = start_at_utc
        if hasattr(sa_utc,'tzinfo') and sa_utc.tzinfo is not None:
            import datetime as _dt_mod
            sa_utc = sa_utc.replace(tzinfo=None)
            # was aware → keep as-is naive UTC
        if now_utc < sa_utc:
            sa_ist = _utc_to_ist(sa_utc)
            logger.info(
                f"[Scheduler] '{schedule_name}' — start_at={sa_ist.strftime('%d-%b-%Y %I:%M %p IST')} "
                f"not reached yet (now={now_ist.strftime('%I:%M %p IST')}). Skipping.")
            return

    logger.info(
        f"[Scheduler] Firing '{schedule_name}' | {label} | "
        f"IST={now_ist.strftime('%d-%b-%Y %I:%M:%S %p')}")

    tracker_id = 0
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)

            # Compute next run: cron after now_ist → store as UTC
            next_utc = _next_cron_utc(cron_expression, now_ist)
            next_ist = _utc_to_ist(next_utc)

            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now_utc)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            # Store UTC in DB — UI will convert to IST for display
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                last_run_at=now_utc,
                                next_run_at=next_utc)

        logger.info(
            f"[Scheduler] Run #{run_id} | "
            f"last={now_ist.strftime('%d-%b-%Y %I:%M %p IST')} | "
            f"next={next_ist.strftime('%d-%b-%Y %I:%M %p IST')}")
        _execute_run(run_id, label, tracker_id)

    except Exception as exc:
        if isinstance(exc, _db_err()):
            logger.error(
                f"[Scheduler] DB down for '{schedule_name}'. "
                f"Will retry next tick. {exc}")
            return
        logger.error(f"[Scheduler] Error firing '{schedule_name}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception: pass


# ── Schedule registration ──────────────────────────────────────────────────
def _load_schedules() -> list:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id,s.customer_id,s.env_types,s.cron_expression,
                          s.schedule_name,s.start_at,s.last_run_at,s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s
                   JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}"); return []


def _register_jobs(scheduler):
    """
    Register all active schedules.
    CronTrigger timezone = Asia/Kolkata (IST).
    start_at_utc passed as arg to _fire_schedule for the gate check.
    Creation time is NEVER used for triggering.
    """
    from apscheduler.triggers.cron import CronTrigger

    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try: job.remove()
            except Exception: pass

    schedules = _load_schedules()
    logger.info(f"[Scheduler] Registering {len(schedules)} schedule(s) | tz=Asia/Kolkata")

    for s in schedules:
        job_id = f"sched_{s['id']}"
        try:
            parts = s["cron_expression"].strip().split()
            if len(parts) != 5:
                logger.error(f"  ✗ [{s['id']}] Bad cron '{s['cron_expression']}'"); continue

            # IST CronTrigger — minute is preserved exactly as admin entered
            trigger = CronTrigger(
                minute=parts[0], hour=parts[1], day=parts[2],
                month=parts[3], day_of_week=parts[4],
                timezone="Asia/Kolkata")

            # start_at in DB is UTC (admin entered IST, Django admin converts to UTC)
            start_at_utc = s.get("start_at")

            # Log human-readable IST info
            if start_at_utc:
                sa_ist = _utc_to_ist(start_at_utc)
                sa_str = sa_ist.strftime("%d-%b-%Y %I:%M %p IST")
            else:
                sa_str = "Next cron tick (no start_at)"

            # next_run shows when APScheduler will fire next (IST)
            nxt = s.get("next_run_at")
            nxt_str = _utc_to_ist(nxt).strftime("%I:%M %p IST") if nxt else "TBD"

            scheduler.add_job(
                _fire_schedule, trigger=trigger, id=job_id,
                name=s["schedule_name"],
                args=[s["id"], s["customer_id"], s["env_types"],
                      s["schedule_name"], s["customer_name"],
                      s["cron_expression"], start_at_utc],
                max_instances=1, coalesce=True,
                replace_existing=True, misfire_grace_time=300)

            logger.info(
                f"  ✓ [{s['id']}] {s['schedule_name']} | "
                f"cron={s['cron_expression']} | start_at={sa_str} | next≈{nxt_str}")
        except Exception as exc:
            logger.error(f"  ✗ [{s['id']}] {s['schedule_name']}: {exc}")


# ── Lifecycle ──────────────────────────────────────────────────────────────
def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("Scheduler already running"); return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor
            _scheduler = BackgroundScheduler(
                executors={"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults={"coalesce": True, "max_instances": 1},
                timezone="Asia/Kolkata")
            _register_jobs(_scheduler)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules", name="DB schedule refresh",
                replace_existing=True)
            _scheduler.start()
            logger.info("APScheduler started | tz=Asia/Kolkata | pool=20")
            return _scheduler
        except ImportError:
            logger.error("APScheduler not installed"); return None
        except Exception as exc:
            logger.error(f"Scheduler start failed: {exc}", exc_info=True); return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("APScheduler stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler(); return start_scheduler()


def scheduler_status() -> dict:
    """Full status with IST times for UI display."""
    now_ist_str = _now_ist().strftime("%d-%b-%Y %I:%M:%S %p")
    if _scheduler is None or not _scheduler.running:
        return {"running": False, "job_count": 0, "jobs": [],
                "active_runs": [], "active_run_count": 0,
                "timezone": "Asia/Kolkata", "server_time_ist": now_ist_str}

    jobs = []
    for job in _scheduler.get_jobs():
        if not job.id.startswith("sched_"): continue
        nxt = job.next_run_time
        if nxt:
            nxt_ist = _utc_to_ist(nxt) if nxt.tzinfo else nxt
            nxt_str = nxt_ist.strftime("%d-%b-%Y %I:%M:%S %p IST")
        else:
            nxt_str = "—"
        jobs.append({"id": job.id, "name": job.name, "next_run": nxt_str})

    with _active_runs_lock:
        active = [{"run_id": rid, "label": lbl}
                  for rid, lbl in _active_runs.items()]

    return {"running": True, "job_count": len(jobs), "jobs": jobs,
            "active_runs": active, "active_run_count": len(active),
            "timezone": "Asia/Kolkata", "server_time_ist": now_ist_str}


# ── Manual run helpers ─────────────────────────────────────────────────────
def run_now_sync(schedule_id: int) -> Optional[int]:
    """Admin Run Now. Uses IST-aware next_run calc. Stores UTC in DB."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
            if not s: return None
            now_utc  = _now_utc()
            now_ist  = _utc_to_ist(now_utc)
            next_utc = _next_cron_utc(s["cron_expression"], now_ist)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))
            tracker_id = _create_tracker(
                db, schedule_id, s["customer_id"], s["env_types"],
                s["schedule_name"], s["cron_expression"],
                now_utc, triggered_by="admin:run_now")
        label = f"{s['cname']}/{s['env_types']}"
        t = threading.Thread(target=_execute_run, args=(run_id, label, tracker_id),
                             daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync: {exc}", exc_info=True); return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """Manual run for customer+env."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust  = db.fetch_one("SELECT name FROM customers WHERE id=%s",(customer_id,))
            cname = cust["name"] if cust else str(customer_id)
        label = f"{cname}/{env_types}"
        t = threading.Thread(target=_execute_run, args=(run_id, label, 0),
                             daemon=True, name=f"hc_run_{run_id}")
        t.start(); return run_id
    except Exception as exc:
        logger.error(f"run_customer_now: {exc}", exc_info=True); return None
