"""
healthcheck/views.py  (v6 final)
All Django views. Engine accessed only through engine_bridge.

Changes:
 - All engine imports use engine_bridge (fixes ModuleNotFoundError)
 - Customer/Config views removed (use Django Admin for those)
 - Escalation: full details (last mail, to/cc, customer/env)
 - Scheduler: live run count, queued jobs, pending reruns
 - Alert history: shows cc_addresses
 - Manual run + scheduler fully working
"""
import threading
from datetime import datetime, timedelta

from healthcheck.engine.core.db_manager import DBConnectionError as _DBConnErr  # DB resilience
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.http import FileResponse, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from healthcheck.models import (
    AlertHistory, Customer, DBCheckResult, Environment, EnvRunStatus,
    EscalationConfig, ExecutionLog, ExecutionRun, IssueTracker,
    MailConfig, MailRecipient, RerunQueue, RMANBackupDetail,
    RunStepLog, Schedule, SchedulerTracker, ServerCheckResult, SystemConfig, TablespaceUsage,
)

_DB = "healthcheck_db"
is_admin = user_passes_test(lambda u: u.is_staff)


def _q(qs):
    return qs.using(_DB)


def _db_safe_view(fn):
    """Decorator: catches DB connectivity errors and shows db_error.html (503)."""
    from functools import wraps
    @wraps(fn)
    def _wrapper(request, *args, **kwargs):
        from django.db.utils import OperationalError as _DjOp, InterfaceError as _DjIf
        try:
            import pymysql.err as _pe
            _catch = (ConnectionError, _DBConnErr, _DjOp, _DjIf, _pe.OperationalError, _pe.InterfaceError)
        except ImportError:
            _catch = (ConnectionError, _DBConnErr, _DjOp, _DjIf)
        try:
            return fn(request, *args, **kwargs)
        except _catch as exc:
            import logging
            logging.getLogger("hc.views").error(f"DB error in {fn.__name__}: {exc}")
            return render(request, "healthcheck/db_error.html", {"error": str(exc)}, status=503)
    return _wrapper


# ──────────────────────────────────────────────────────────────
# AUTH
# ──────────────────────────────────────────────────────────────

def login_view(request):
    from django.contrib.auth import authenticate, login
    error = None
    if request.method == "POST":
        u = authenticate(request,
                         username=request.POST.get("username"),
                         password=request.POST.get("password"))
        if u:
            login(request, u)
            return redirect(request.GET.get("next", "/healthcheck/"))
        error = "Invalid username or password."
    return render(request, "healthcheck/login.html", {"error": error})


def logout_view(request):
    from django.contrib.auth import logout
    logout(request)
    return redirect("healthcheck:login")


# ──────────────────────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    from healthcheck.scheduler_service import scheduler_status

    db_error = None
    runs = open_issues = pending_reruns = paused_escalations = []
    try:
        runs = list(_q(
            ExecutionRun.objects.select_related("customer").order_by("-id")[:20]))
        open_issues = list(_q(
            IssueTracker.objects.select_related("customer", "test_catalog")
            .filter(status__in=["OPEN", "ESCALATED"])
            .order_by("-consecutive_failures")[:20]))
        pending_reruns = list(_q(
            RerunQueue.objects.select_related("customer", "original_run")
            .filter(status__in=["PENDING", "IN_PROGRESS"])
            .order_by("scheduled_at")[:10]))
        paused_escalations = list(_q(
            EscalationConfig.objects.select_related("customer").filter(is_paused=True)))
        # Accurate counts
        open_count      = _q(IssueTracker.objects).filter(status="OPEN").count()
        escalated_count = _q(IssueTracker.objects).filter(status="ESCALATED").count()
        exhausted_rerun = _q(RerunQueue.objects).filter(status="EXHAUSTED").count()
    except Exception as exc:
        db_error = f"Health-check database unavailable: {exc}"

    sched = scheduler_status()

    return render(request, "healthcheck/dashboard.html", {
        "runs":               runs,
        "open_issues":        open_issues,
        "pending_reruns":     pending_reruns,
        "paused_escalations": paused_escalations,
        "scheduler_status":   sched,
        "db_error":           db_error,
        "open_count":         open_count      if not db_error else 0,
        "escalated_count":    escalated_count if not db_error else 0,
        "exhausted_rerun":    exhausted_rerun if not db_error else 0,
        "active_page":        "dashboard",
    })


# ──────────────────────────────────────────────────────────────
# REPORTS
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def reports_list(request):
    qs = _q(
        ExecutionRun.objects.select_related("customer")
        .filter(status__in=["COMPLETED", "PARTIAL", "FAILED"])
        .order_by("-id")
    )
    cid  = request.GET.get("customer")
    env  = request.GET.get("env")
    stat = request.GET.get("status")
    if cid:  qs = qs.filter(customer_id=cid)
    if env:  qs = qs.filter(env_types__contains=env)
    if stat: qs = qs.filter(status=stat)

    page = Paginator(qs, 20).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))

    return render(request, "healthcheck/reports_list.html", {
        "page_obj":          page,
        "customers":         customers,
        "active_page":       "reports",
        "selected_customer": cid,
        "selected_env":      env,
        "selected_status":   stat,
    })


@login_required
@_db_safe_view
def report_detail(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    env_statuses = _q(
        EnvRunStatus.objects.filter(run=run).order_by("env_type"))

    env_data   = []
    has_action = False

    for es in env_statuses:
        server_checks = list(
            _q(ServerCheckResult.objects.select_related("server")
               .filter(env_status=es)))
        db_checks_raw = list(
            _q(DBCheckResult.objects.select_related("server", "oracle_db")
               .filter(env_status=es)))

        for sc in server_checks:
            if sc.any_action(): has_action = True

        db_check_data = []
        for dc in db_checks_raw:
            if dc.any_action(): has_action = True
            db_check_data.append({
                "check":     dc,
                "ts_rows":   list(_q(TablespaceUsage.objects
                                     .filter(db_check=dc)
                                     .order_by("-used_pct"))),
                "rman_rows": list(_q(RMANBackupDetail.objects
                                     .filter(db_check=dc))),
            })

        env_data.append({
            "env_status":    es,
            "server_checks": server_checks,
            "db_checks":     db_check_data,
        })

    step_log      = _q(RunStepLog.objects.filter(run=run).order_by("step_order"))
    alerts        = _q(AlertHistory.objects.filter(run=run).order_by("-sent_at"))
    action_filter = request.GET.get("action")

    return render(request, "healthcheck/report_detail.html", {
        "run":           run,
        "env_data":      env_data,
        "step_log":      step_log,
        "alerts":        alerts,
        "has_action":    has_action,
        "action_filter": action_filter,
        "active_page":   "reports",
    })


@login_required
@_db_safe_view
def download_excel(request, run_id):
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            gen = eng["ExcelReportGenerator"](
                db, run_id, eng["SilentLogger"]())
            filepath, title = gen.generate()

        import os
        dl_date  = datetime.now().strftime("%d-%b-%Y")
        orig     = os.path.basename(filepath)
        dl_name  = orig.replace(".xlsx", f"_DL-{dl_date}.xlsx")
        return FileResponse(
            open(filepath, "rb"),
            content_type=(
                "application/vnd.openxmlformats-officedocument"
                ".spreadsheetml.sheet"),
            as_attachment=True,
            filename=dl_name,
        )
    except Exception as exc:
        messages.error(request, f"Could not generate Excel: {exc}")
        from django.urls import reverse; return redirect(reverse("healthcheck:report_detail", args=[run_id]))


# ──────────────────────────────────────────────────────────────
# LOGS
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def run_logs(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    qs  = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))
    lvl = request.GET.get("level")
    if lvl:
        qs = qs.filter(log_level=lvl)
    page = Paginator(qs, 200).get_page(request.GET.get("page", 1))
    return render(request, "healthcheck/run_logs.html", {
        "run":          run,
        "page_obj":     page,
        "level_filter": lvl,
        "log_levels":   ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        "active_page":  "reports",
    })


@login_required
@_db_safe_view
def download_logs(request, run_id):
    run  = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    logs = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))
    lines = [
        f"{log.logged_at.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} "
        f"[{log.log_level:<8}] "
        f"[{log.py_file}::{log.py_function}():L{log.py_line}] "
        f"{log.message}"
        for log in logs
    ]
    fname = (f"run_{run_id}_{run.customer.name}_"
             f"{datetime.now().strftime('%Y%m%d')}.log")
    resp = HttpResponse("\n".join(lines),
                        content_type="text/plain; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="{fname}"'
    return resp


# ──────────────────────────────────────────────────────────────
# ESCALATION  (full detail: last mail, to/cc, customer/env)
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def escalation_view(request):
    # Filter params
    sel_customer = request.GET.get("customer", "")
    sel_status   = request.GET.get("status", "")
    sel_env      = request.GET.get("env", "")

    esc_qs = _q(
        EscalationConfig.objects.select_related("customer").order_by("customer__name"))

    # Include ALL statuses including RESOLVED — let filter refine
    all_statuses = ["OPEN", "ESCALATED", "RESOLVED"]
    issues_qs = _q(
        IssueTracker.objects.select_related(
            "customer", "test_catalog", "first_failed_run", "last_failed_run")
        .filter(status__in=all_statuses)
    )
    if sel_customer:
        issues_qs = issues_qs.filter(customer_id=sel_customer)
        esc_qs    = esc_qs.filter(customer_id=sel_customer)
    if sel_status:
        issues_qs = issues_qs.filter(status=sel_status)
    else:
        # Default: show OPEN + ESCALATED (not RESOLVED unless requested)
        issues_qs = issues_qs.filter(status__in=["OPEN", "ESCALATED"])
    if sel_env:
        issues_qs = issues_qs.filter(env_type=sel_env)

    issues = list(issues_qs.order_by("-consecutive_failures", "-updated_at"))

    # Escalation config mapped by customer+env for quick lookup
    esc_map = {(ec.customer_id, ec.env_type): ec for ec in esc_qs}

    issues_with_mail = []
    for iss in issues:
        # Match last escalation mail by customer+env+alert_type
        last_mail = (
            _q(AlertHistory.objects
               .filter(
                   customer_id=iss.customer_id,
                   env_type=iss.env_type,
                   alert_type__in=["ESCALATION","RESOLVED"],
                   send_status="SENT")
               .order_by("-sent_at"))
            .first()
        )
        if not last_mail:
            last_mail = (
                _q(AlertHistory.objects
                   .filter(
                       customer_id=iss.customer_id,
                       env_type=iss.env_type,
                       alert_type__in=["ESCALATION","RESOLVED"])
                   .order_by("-sent_at"))
                .first()
            )
        esc_cfg = esc_map.get((iss.customer_id, iss.env_type))
        issues_with_mail.append({"issue": iss, "last_mail": last_mail, "esc_cfg": esc_cfg})

    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))
    open_count      = _q(IssueTracker.objects).filter(status="OPEN").count()
    escalated_count = _q(IssueTracker.objects).filter(status="ESCALATED").count()
    resolved_count  = _q(IssueTracker.objects).filter(status="RESOLVED").count()

    return render(request, "healthcheck/escalation.html", {
        "esc_configs":      list(esc_qs),
        "issues_with_mail": issues_with_mail,
        "customers":        customers,
        "sel_customer":     sel_customer,
        "sel_status":       sel_status,
        "sel_env":          sel_env,
        "open_count":       open_count,
        "escalated_count":  escalated_count,
        "resolved_count":   resolved_count,
        "active_page":      "escalation",
    })
@login_required
@is_admin
@require_POST
@_db_safe_view
def pause_escalation(request, pk):
    obj = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    hours  = int(request.POST.get("hours", 168))
    reason = request.POST.get("reason", "Manual pause")
    obj.is_paused    = True
    obj.paused_until = datetime.utcnow() + timedelta(hours=hours)
    obj.pause_reason = reason
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation paused for {obj.customer.name}/{obj.env_type} "
        f"for {hours}h.")
    return redirect("healthcheck:escalation")


@login_required
@is_admin
@require_POST
@_db_safe_view
def resume_escalation(request, pk):
    obj = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    obj.is_paused    = False
    obj.paused_until = None
    obj.pause_reason = ""
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation resumed for {obj.customer.name}/{obj.env_type}.")
    return redirect("healthcheck:escalation")


# ──────────────────────────────────────────────────────────────
# RERUN
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def rerun_view(request):
    pending = list(_q(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")
    ))
    recent_qs = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .exclude(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("-created_at")
    )
    page_obj = Paginator(recent_qs, 20).get_page(request.GET.get("page", 1))

    # Summary counts for display
    exhausted_count = _q(RerunQueue.objects).filter(status="EXHAUSTED").count()
    completed_count = _q(RerunQueue.objects).filter(status="COMPLETED").count()

    return render(request, "healthcheck/rerun.html", {
        "pending":          pending,
        "page_obj":         page_obj,
        "exhausted_count":  exhausted_count,
        "completed_count":  completed_count,
        "active_page":      "rerun",
    })


@login_required
@is_admin
@require_POST
@_db_safe_view
def trigger_rerun(request, run_id):
    from healthcheck.engine_bridge import get_engine
    from healthcheck.scheduler_service import _execute_run
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            # Get the rerun_queue entry to read correct attempt_number
            rq = db.fetch_one(
                "SELECT * FROM rerun_queue WHERE original_run_id=%s "
                "ORDER BY attempt_number DESC LIMIT 1", (run_id,))
            run = db.fetch_one(
                "SELECT * FROM execution_runs WHERE id=%s", (run_id,))
            if not run:
                messages.error(request, f"Run #{run_id} not found.")
                return redirect("healthcheck:rerun")

            cust  = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s", (run["customer_id"],))
            cname = cust["name"] if cust else str(run["customer_id"])

            # Use correct attempt number from rerun_queue (not hardcoded 1)
            cfg_row  = db.fetch_one(
                "SELECT rerun_max_attempts FROM system_config "                "WHERE config_key='rerun_max_attempts'")
            max_att  = int(cfg_row["rerun_max_attempts"]) if cfg_row else 3
            cur_att  = rq["attempt_number"] if rq else 0
            nxt_att  = cur_att + 1

            if nxt_att > max_att:
                messages.error(request,
                    f"Max rerun attempts ({max_att}) already exhausted for Run #{run_id}.")
                return redirect("healthcheck:rerun")

            new_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by,
                    rerun_of_run_id,rerun_attempt)
                   VALUES(%s,%s,'RERUN','PENDING','admin:rerun',%s,%s)""",
                (run["customer_id"], run["env_types"], run_id, nxt_att))

            # Update rerun_queue entry to IN_PROGRESS and link new run
            if rq:
                db.execute(
                    "UPDATE rerun_queue SET status='IN_PROGRESS',started_at=NOW() "                    "WHERE id=%s", (rq["id"],))
            else:
                db.insert_get_id(
                    """INSERT INTO rerun_queue
                       (original_run_id,customer_id,env_types,
                        attempt_number,max_attempts,status,scheduled_at,last_error)
                       VALUES(%s,%s,%s,%s,%s,'IN_PROGRESS',NOW(),'Manual trigger')""",
                    (run_id, run["customer_id"], run["env_types"], nxt_att, max_att))

        t = threading.Thread(
            target=_execute_run,
            args=(new_id, f"{cname}/{run['env_types']}"),
            daemon=True, name=f"hc_rerun_{new_id}")
        t.start()
        messages.success(request,
            f"Rerun #{new_id} started (attempt {nxt_att}/{max_att}).")
    except Exception as exc:
        messages.error(request, f"Error: {exc}")
    return redirect("healthcheck:rerun")


# ──────────────────────────────────────────────────────────────
# ALERT HISTORY  (shows to + cc)
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def alert_history(request):
    qs = _q(AlertHistory.objects.order_by("-sent_at"))
    alert_type = request.GET.get("type")
    cid        = request.GET.get("customer")
    if alert_type: qs = qs.filter(alert_type=alert_type)
    if cid:        qs = qs.filter(customer_id=cid)

    page      = Paginator(qs, 30).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))

    return render(request, "healthcheck/alert_history.html", {
        "page_obj":     page,
        "customers":    customers,
        "alert_types":  ["SUCCESS", "FAILURE", "ESCALATION", "RERUN_FAILURE"],
        "sel_type":     alert_type,
        "sel_customer": cid,
        "active_page":  "alerts",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Manual Run
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
@_db_safe_view
def manual_run(request):
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))
    if request.method == "POST":
        customer_id = request.POST.get("customer_id")
        env_types   = request.POST.get("env_types", "").upper().strip()
        if customer_id and env_types:
            from healthcheck.scheduler_service import run_customer_now
            run_id = run_customer_now(int(customer_id), env_types)
            if run_id:
                messages.success(
                    request,
                    f"Run #{run_id} started. Check dashboard for live status.")
                return redirect("healthcheck:dashboard")
            messages.error(request,
                           "Failed to start run. Check server logs.")
        else:
            messages.error(request, "Select customer and environment.")

    return render(request, "healthcheck/manual_run.html", {
        "customers":   customers,
        "active_page": "manual_run",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Scheduler
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
@_db_safe_view
def scheduler_view(request):
    from healthcheck.scheduler_service import scheduler_status
    from healthcheck.ist_utils import utc_to_ist, _next_cron_utc, now_utc
    from croniter import croniter
    from datetime import datetime as _dt

    schedules = list(_q(
        Schedule.objects.select_related("customer").order_by("customer__name")))
    pending_reruns = list(_q(
        RerunQueue.objects.select_related("customer")
        .filter(status__in=["PENDING","IN_PROGRESS"])
        .order_by("scheduled_at")))

    # Build future runs table — IST times
    future_runs = []
    now_utc_dt  = _dt.utcnow()
    now_ist_dt  = utc_to_ist(now_utc_dt)

    for s in schedules:
        if not s.is_active:
            continue
        try:
            ci = croniter(s.cron_expression, now_ist_dt)
            for _ in range(2):
                nxt_ist = ci.get_next(_dt)
                # Determine state based on start_at (stored UTC in DB)
                sa_utc = s.start_at
                if sa_utc:
                    sa_naive = sa_utc.replace(tzinfo=None) if hasattr(sa_utc,'tzinfo') and sa_utc.tzinfo else sa_utc
                    state = "WAITING (start_at pending)" if now_utc_dt < sa_naive else "QUEUED"
                else:
                    state = "QUEUED"
                future_runs.append({
                    "customer":      s.customer.name,
                    "env":           s.env_types,
                    "schedule_name": s.schedule_name,
                    "cron":          s.cron_expression,
                    "fire_at":       nxt_ist,          # IST datetime for template
                    "status":        state,
                })
        except Exception:
            pass
    future_runs.sort(key=lambda x: x["fire_at"])

    return render(request, "healthcheck/scheduler.html", {
        "sched_status":  scheduler_status(),
        "schedules":     schedules,
        "pending_reruns": pending_reruns,
        "future_runs":   future_runs[:20],
        "active_page":   "scheduler",
    })


@login_required
@is_admin
@require_POST
@_db_safe_view
def scheduler_action(request):
    from healthcheck.scheduler_service import (
        start_scheduler, stop_scheduler,
        restart_scheduler, run_now_sync)

    action = request.POST.get("action")
    if action == "start":
        start_scheduler()
        messages.success(request, "Scheduler started.")
    elif action == "stop":
        stop_scheduler()
        messages.success(request, "Scheduler stopped.")
    elif action == "restart":
        restart_scheduler()
        messages.success(request,
                         "Scheduler restarted — schedules reloaded from DB.")
    elif action == "run_now":
        sched_id = int(request.POST.get("schedule_id", 0))
        run_id   = run_now_sync(sched_id)
        if run_id:
            messages.success(
                request,
                f"Schedule fired — Run #{run_id} running in background.")
        else:
            messages.error(
                request, "Could not fire schedule. Check server logs.")
    return redirect("healthcheck:scheduler")


# ──────────────────────────────────────────────────────────────
# API (JSON endpoints for live polling)
# ──────────────────────────────────────────────────────────────

@login_required
@_db_safe_view
def api_run_status(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    return JsonResponse({
        "id":           run.id,
        "status":       run.status,
        "latest_step":  run.latest_step or "",
        "started_at":   run.started_at.isoformat()   if run.started_at  else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    })


@login_required
@_db_safe_view
def api_scheduler_status(request):
    from healthcheck.scheduler_service import scheduler_status
    return JsonResponse(scheduler_status())


@login_required
@_db_safe_view
def api_recent_runs(request):
    """Live dashboard data — last 20 runs."""
    runs = _q(
        ExecutionRun.objects.select_related("customer").order_by("-id")[:20])
    data = [{
        "id":           r.id,
        "customer":     r.customer.name,
        "env_types":    r.env_types,
        "status":       r.status,
        "latest_step":  r.latest_step or "",
        "started_at":   r.started_at.strftime("%Y-%m-%d %H:%M") if r.started_at else "—",
        "duration":     f"{r.duration_seconds()}s" if r.started_at and r.completed_at else "—",
    } for r in runs]
    return JsonResponse({"runs": data})


# ──────────────────────────────────────────────────────────────
# SCHEDULER TRACKER  (admin only)
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
@_db_safe_view
def scheduler_tracker(request):
    qs = _q(
        SchedulerTracker.objects
        .select_related("customer", "schedule", "run")
        .order_by("-scheduled_fire_at")
    )
    # Filters
    status_filter   = request.GET.get("status", "")
    customer_filter = request.GET.get("customer", "")
    if status_filter:
        qs = qs.filter(status=status_filter)
    if customer_filter:
        qs = qs.filter(customer_id=customer_filter)

    page      = Paginator(qs, 20).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))
    statuses  = ["PENDING", "RUNNING", "COMPLETED", "FAILED", "FAILED_QUEUE", "SKIPPED"]

    # POST: admin re-queue a failed entry
    if request.method == "POST":
        action     = request.POST.get("action")
        tracker_id = request.POST.get("tracker_id")
        if action == "requeue" and tracker_id:
            _q(SchedulerTracker.objects).filter(id=tracker_id).update(
                status="PENDING", error_message=None)
            messages.success(request, f"Tracker #{tracker_id} re-queued as PENDING.")
        elif action == "deactivate" and tracker_id:
            _q(SchedulerTracker.objects).filter(id=tracker_id).update(is_active=False)
            messages.success(request, f"Tracker #{tracker_id} deactivated.")
        return redirect("healthcheck:scheduler_tracker")

    return render(request, "healthcheck/scheduler_tracker.html", {
        "page_obj":        page,
        "customers":       customers,
        "statuses":        statuses,
        "status_filter":   status_filter,
        "customer_filter": customer_filter,
        "active_page":     "scheduler",
    })


# ──────────────────────────────────────────────────────────────
# DB HEALTH CHECK endpoint — /healthcheck/api/db-health/
# ──────────────────────────────────────────────────────────────

def api_db_health(request):
    """
    Public (no login required) lightweight DB health check.
    Returns JSON: {"ok": true/false, "error": null|string, "latency_ms": float}
    Used by load balancers, monitoring agents, and the UI banner.
    """
    from healthcheck.engine.core.db_manager import check_db_health
    result = check_db_health()
    status = 200 if result["ok"] else 503
    return JsonResponse(result, status=status)
