"""
config_loader.py
================
Loads all runtime configuration from fmwchecks database tables.

Sources:
  fmw_config        → excel_path, log_path, oracle_timeout, oracle_dll_path,
                       config_customers, config_envs
  fmw_email_config  → smtp settings, to/cc/bcc addresses
"""
import logging
import os
from dataclasses import dataclass, field
from typing import List

logger = logging.getLogger("fmw.config")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _abs(path: str) -> str:
    if not path:
        return ""
    return path if os.path.isabs(path) else os.path.join(BASE_DIR, path)


def _parse_list(raw: str) -> List[str]:
    """Comma-separated string → clean list. Empty string → empty list."""
    if not raw or not raw.strip():
        return []
    return [v.strip() for v in raw.split(",") if v.strip()]


@dataclass
class EmailConfig:
    smtp_host:  str       = ""
    smtp_port:  int       = 587
    smtp_user:  str       = ""
    smtp_pass:  str       = ""
    use_tls:    bool      = True
    from_addr:  str       = ""
    to_addrs:   List[str] = field(default_factory=list)
    cc_addrs:   List[str] = field(default_factory=list)
    bcc_addrs:  List[str] = field(default_factory=list)


@dataclass
class AppConfig:
    excel_path:       str       = ""
    log_path:         str       = ""
    oracle_timeout:   int       = 15
    oracle_dll_path:  str       = ""
    config_customers: List[str] = field(default_factory=list)  # empty = ALL
    config_envs:      List[str] = field(default_factory=list)  # empty = ALL
    email:            EmailConfig = field(default_factory=EmailConfig)


def load_config(db) -> AppConfig:
    """
    Load AppConfig from fmwchecks DB.
    db: open DBManager connected to fmwchecks schema.
    """
    cfg = AppConfig()

    # ── General config ─────────────────────────────────────────────────────
    try:
        rows = db.fetch_all("SELECT config_key, config_value FROM fmw_config")
        kv   = {r["config_key"]: r["config_value"] for r in rows}

        cfg.excel_path       = _abs(kv.get("excel_path",       "Excel"))
        cfg.log_path         = _abs(kv.get("log_path",         "Logs"))
        cfg.oracle_timeout   = int(kv.get("oracle_timeout",    "15"))
        cfg.oracle_dll_path  = _abs(kv.get("oracle_dll_path",  ""))
        cfg.config_customers = _parse_list(kv.get("config_customers", ""))
        cfg.config_envs      = _parse_list(kv.get("config_envs",      ""))

        logger.info(
            f"[STEP-2] Config loaded | "
            f"excel={cfg.excel_path} log={cfg.log_path} "
            f"timeout={cfg.oracle_timeout}s | "
            f"customers={'ALL' if not cfg.config_customers else cfg.config_customers} | "
            f"envs={'ALL' if not cfg.config_envs else cfg.config_envs}")
    except Exception as exc:
        logger.warning(f"[STEP-2] Could not load fmw_config — using defaults: {exc}")
        cfg.excel_path      = _abs("Excel")
        cfg.log_path        = _abs("Logs")
        cfg.oracle_timeout  = 15

    # ── Email config ───────────────────────────────────────────────────────
    try:
        row = db.fetch_one(
            "SELECT * FROM fmw_email_config WHERE is_active=1 ORDER BY id LIMIT 1")
        if row:
            cfg.email = EmailConfig(
                smtp_host = row.get("smtp_host",  ""),
                smtp_port = int(row.get("smtp_port", 587)),
                smtp_user = row.get("smtp_user",  ""),
                smtp_pass = row.get("smtp_pass",  ""),
                use_tls   = bool(row.get("use_tls", 1)),
                from_addr = row.get("from_addr",  ""),
                to_addrs  = _parse_list(row.get("to_addr",  "")),
                cc_addrs  = _parse_list(row.get("cc_addr",  "")),
                bcc_addrs = _parse_list(row.get("bcc_addr", "")),
            )
            logger.info(
                f"[STEP-2] Email config loaded | "
                f"smtp={cfg.email.smtp_host}:{cfg.email.smtp_port} | "
                f"to={cfg.email.to_addrs} cc={cfg.email.cc_addrs}")
        else:
            logger.warning("[STEP-2] No active email config in fmw_email_config")
    except Exception as exc:
        logger.warning(f"[STEP-2] Could not load fmw_email_config: {exc}")

    return cfg
