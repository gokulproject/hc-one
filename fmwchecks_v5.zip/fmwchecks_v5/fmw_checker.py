"""
fmw_checker.py
==============
FMW Database Connection Checker.

STRICT FLOW per requirement:
  FOR each Customer:
    Check customer exists → if not, log + skip
    FOR each Environment (DEV/VAL/PRD or filtered):
      Check environment exists → if not, log + skip
      Identify DB Server (host) from Servers table
      STEP A: DB Server connection check via WMI
        Credentials: Environments.ServerUser + Environments.ServerPwd
        IF NOT connected → log full error, mark NOT CONNECTED, skip Step B
        IF connected     → proceed to Step B
      STEP B: FMW Oracle DB connection check
        IF connected  → status COMPLETED
        IF not        → capture full error, status FAILED
      ONE ROW per environment written to fmw_connection_result

Reads from : health_check schema (READ ONLY)
Writes to  : fmwchecks schema (results + logs)

config_customers → empty = ALL active, populated = only those names
config_envs      → empty = ALL (DEV,VAL,PRD), populated = only those types
"""
import logging
import os
import sys
import time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.crypto     import decrypt_password, is_encrypted
from Common.db_manager import DBManager
from config            import HC_DB, FMWCHECKS_DB

logger = logging.getLogger("fmw.checker")

FMW_DB_TYPE  = "FMW"
ALL_ENV_TYPES = ["DEV", "VAL", "PRD"]
IST_OFFSET    = timedelta(hours=5, minutes=30)


def _now_ist() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


class FMWChecker:

    def __init__(self, run_id: int, app_cfg=None):
        self.run_id            = run_id
        self.cfg               = app_cfg
        self._oracle_timeout   = getattr(app_cfg, "oracle_timeout",   15) if app_cfg else 15
        self._oracle_dll_path  = getattr(app_cfg, "oracle_dll_path",  "") if app_cfg else ""
        self._config_customers = getattr(app_cfg, "config_customers", []) if app_cfg else []
        self._config_envs      = getattr(app_cfg, "config_envs",      []) if app_cfg else []
        self._setup_oracle_client()

    # ── Oracle client init ────────────────────────────────────────────────────
    def _setup_oracle_client(self):
        try:
            import oracledb
            dll = self._oracle_dll_path
            if dll and os.path.isdir(dll) and os.listdir(dll):
                oracledb.init_oracle_client(lib_dir=dll)
                logger.info(f"[STEP-5] Oracle thick client initialised: {dll}")
            else:
                logger.info("[STEP-5] Oracle thin client mode (no DLL path configured)")
        except Exception as exc:
            logger.warning(f"[STEP-5] Oracle client init warning: {exc}")

    # ── STEP A: DB Server check via WMI ──────────────────────────────────────
    def _check_server_wmi(self, host: str,
                           username: str, password: str) -> tuple:
        """
        Connect to Windows server via WMI using server credentials.
        Credentials from health_check.Environments (ServerUser, ServerPwd).

        Returns (connected: bool, error: str|None, duration_ms: int)
        """
        logger.info(
            f"    [STEP-5A] WMI server check → host={host} | user={username}")
        start = time.time()
        conn  = None
        try:
            import wmi

            # Handle domain\\user format (clean extra backslashes)
            clean_user = username.replace("\\\\", "\\") if username else username

            conn = wmi.WMI(
                computer = host,
                user     = clean_user,
                password = password
            )

            # Simple query to confirm WMI connection is live
            conn.Win32_OperatingSystem()

            ms = int((time.time() - start) * 1000)
            logger.info(
                f"    [STEP-5A] ✅ WMI CONNECTED | host={host} | {ms}ms")
            return True, None, ms

        except ImportError:
            # WMI not installed — fallback to socket check (non-Windows)
            ms  = int((time.time() - start) * 1000)
            err = "WMI module not available — use: pip install WMI"
            logger.warning(
                f"    [STEP-5A] WMI not available, falling back to socket | {host}")
            return self._check_server_socket(host, ms)

        except Exception as exc:
            ms  = int((time.time() - start) * 1000)
            err = str(exc)
            logger.error(
                f"    [STEP-5A] ❌ WMI NOT CONNECTED | "
                f"host={host} | user={username} | "
                f"Error: {err}")
            return False, err, ms

        finally:
            try:
                if conn:
                    del conn
            except Exception:
                pass

    def _check_server_socket(self, host: str,
                              elapsed_ms: int = 0) -> tuple:
        """
        Fallback socket check when WMI is unavailable (non-Windows).
        Returns (connected: bool, error: str|None, duration_ms: int)
        """
        import socket
        start = time.time()
        try:
            s = socket.create_connection((host, 1521), timeout=self._oracle_timeout)
            s.close()
            ms = elapsed_ms + int((time.time() - start) * 1000)
            logger.info(f"    [STEP-5A] ✅ Socket CONNECTED | {host}:1521 | {ms}ms")
            return True, None, ms
        except Exception as exc:
            ms  = elapsed_ms + int((time.time() - start) * 1000)
            err = str(exc)
            logger.error(
                f"    [STEP-5A] ❌ Socket NOT CONNECTED | "
                f"{host}:1521 | Error: {err}")
            return False, err, ms

    # ── STEP B: FMW Oracle DB connection check ────────────────────────────────
    def _check_db_connection(self, db_info: dict) -> tuple:
        """
        Try to connect to Oracle DB using oracledb.
        Returns (connected: bool, error: str|None, duration_ms: int)
        """
        import oracledb

        host    = db_info.get("db_host",    "")
        port    = int(db_info.get("db_port", 1521))
        service = db_info.get("db_service", "")
        user    = db_info.get("db_user",    "")
        pwd_raw = db_info.get("db_password","")
        name    = db_info.get("db_name",    "?")
        cname   = db_info.get("customer_name", "")
        env     = db_info.get("env_type",   "")

        # Decrypt Oracle DB password
        try:
            password = decrypt_password(pwd_raw) if is_encrypted(pwd_raw) else pwd_raw
        except Exception as de:
            logger.warning(f"    [STEP-6B] Password decrypt warning: {de} — using raw")
            password = pwd_raw

        dsn = f"{host}:{port}/{service}"
        logger.info(
            f"    [STEP-6B] FMW DB check → "
            f"{cname}/{env} | DB={name} | DSN={dsn} | user={user}")

        start = time.time()
        conn  = None
        try:
            conn = oracledb.connect(
                user     = user,
                password = password,
                dsn      = dsn,
                timeout  = self._oracle_timeout
            )
            ms = int((time.time() - start) * 1000)
            conn.close()
            conn = None
            logger.info(
                f"    [STEP-6B] ✅ FMW DB CONNECTED | "
                f"{cname}/{env} | DB={name} | {ms}ms")
            return True, None, ms

        except Exception as exc:
            ms  = int((time.time() - start) * 1000)
            err = str(exc)[:1000]
            logger.error(
                f"    [STEP-6B] ❌ FMW DB NOT CONNECTED | "
                f"{cname}/{env} | DB={name} | Error: {err}")
            return False, err, ms

        finally:
            try:
                if conn: conn.close()
            except Exception:
                pass

    # ── HC schema queries (READ ONLY) ─────────────────────────────────────────
    def _load_customers(self, db) -> list:
        """Load customers from health_check.Customers"""
        if self._config_customers:
            ph   = ",".join(["%s"] * len(self._config_customers))
            rows = db.fetch_all(
                f"""SELECT CustomerID   AS customer_id,
                           CustomerName AS customer_name
                    FROM Customers
                    WHERE CustomerName IN ({ph}) AND Status=1
                    ORDER BY CustomerName""",
                tuple(self._config_customers))
            logger.info(
                f"[STEP-3] Filtered customers: "
                f"{self._config_customers} → found {len(rows)}")
        else:
            rows = db.fetch_all(
                """SELECT CustomerID   AS customer_id,
                          CustomerName AS customer_name
                   FROM Customers
                   WHERE Status=1
                   ORDER BY CustomerName""")
            logger.info(f"[STEP-3] All active customers: {len(rows)} found")
        return rows

    def _load_envs(self, db, customer_id: int) -> list:
        """
        Load environments for a customer.
        Includes ServerUser + ServerPwd for WMI authentication.
        """
        scope = self._config_envs if self._config_envs else ALL_ENV_TYPES
        ph    = ",".join(["%s"] * len(scope))
        return db.fetch_all(
            f"""SELECT EnvID      AS env_id,
                       ServerType AS env_type,
                       ServerUser AS server_user,
                       ServerPwd  AS server_pwd
                FROM Environments
                WHERE CustomerID=%s
                  AND ServerType IN ({ph})
                  AND Status=1
                ORDER BY FIELD(ServerType,'DEV','VAL','PRD')""",
            tuple([customer_id] + scope))

    def _load_server(self, db, env_id: int) -> dict:
        """Load server details from health_check.Servers"""
        return db.fetch_one(
            """SELECT ServerID   AS server_id,
                      ServerName AS server_name,
                      Host       AS host
               FROM Servers
               WHERE EnvID=%s AND Status=1
               LIMIT 1""",
            (env_id,))

    def _load_fmw_dbs(self, db, server_id: int) -> list:
        """Load FMW Oracle databases from health_check.OracleDatabase"""
        return db.fetch_all(
            """SELECT dbid     AS db_id,
                      OrdName  AS db_name,
                      OrdName  AS db_service,
                      Port     AS db_port,
                      User     AS db_user,
                      Password AS db_password
               FROM OracleDatabase
               WHERE ServerID=%s
                 AND DatabaseType=%s
                 AND Status=1""",
            (server_id, FMW_DB_TYPE))

    # ── Save one result row (one per environment) ─────────────────────────────
    def _save_result(self, result: dict):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_connection_result
                       (run_id, customer_id, customer_name, env_type,
                        server_host, server_status, server_error,
                        db_name, db_host, db_port, db_service,
                        connection_status, error_message,
                        duration_ms, checked_at)
                       VALUES
                       (%s,%s,%s,%s, %s,%s,%s, %s,%s,%s,%s, %s,%s, %s,%s)""",
                    (result["run_id"],
                     result["customer_id"],  result["customer_name"],
                     result["env_type"],
                     result["server_host"],  result["server_status"],
                     result["server_error"],
                     result["db_name"],      result["db_host"],
                     result["db_port"],      result["db_service"],
                     result["connection_status"], result["error_message"],
                     result["duration_ms"],  result["checked_at"]))
        except Exception as exc:
            logger.error(f"[STEP-7] Failed to save result: {exc}")

    # ── Log step ──────────────────────────────────────────────────────────────
    def _log_step(self, step_no: int, step_name: str, status: str,
                  message: str = "", customer: str = "", env_type: str = ""):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     message[:2000] if message else "",
                     customer[:255] if customer else "",
                     env_type[:50]  if env_type  else ""))
        except Exception as exc:
            logger.warning(f"Step log write failed: {exc}")

    # ── MAIN LOOP ─────────────────────────────────────────────────────────────
    def run_all(self) -> list:
        """
        Full Customer → Environment → Server(WMI) → DB check loop.
        Returns list of result dicts (one per environment processed).
        """
        results   = []
        env_scope = self._config_envs if self._config_envs else ALL_ENV_TYPES

        logger.info("")
        logger.info(f"[STEP-3] Loading customers | env_scope={env_scope} | {_now_ist()}")
        self._log_step(
            3, "IDENTIFY_CUSTOMERS", "STARTED",
            f"customer_filter={'ALL' if not self._config_customers else self._config_customers} | "
            f"env_filter={'ALL' if not self._config_envs else self._config_envs}")

        # ── Step 3: Load customers ────────────────────────────────────────────
        try:
            with DBManager(cfg=HC_DB) as db:
                customers = self._load_customers(db)
        except Exception as exc:
            logger.error(
                f"[STEP-3] FATAL: Cannot load customers: {exc}", exc_info=True)
            self._log_step(3, "IDENTIFY_CUSTOMERS", "FAILED", str(exc))
            return []

        if not customers:
            logger.warning("[STEP-3] No active customers found — nothing to check")
            self._log_step(3, "IDENTIFY_CUSTOMERS", "SKIPPED",
                           "No active customers found")
            return []

        self._log_step(3, "IDENTIFY_CUSTOMERS", "COMPLETED",
                       f"{len(customers)} customer(s) found")

        # ── Customer loop ─────────────────────────────────────────────────────
        for cust in customers:
            cid   = cust["customer_id"]
            cname = cust["customer_name"]

            logger.info("")
            logger.info(f"{'─' * 60}")
            logger.info(f"[STEP-3] ▶ Customer: {cname} (ID={cid})")

            # ── Step 4: Load environments ─────────────────────────────────────
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "STARTED",
                           f"scope={env_scope}", cname)
            try:
                with DBManager(cfg=HC_DB) as db:
                    envs = self._load_envs(db, cid)
            except Exception as exc:
                logger.error(
                    f"[STEP-4] Cannot load environments for {cname}: {exc}")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "FAILED",
                               str(exc), cname)
                continue

            if not envs:
                logger.warning(
                    f"[STEP-4] No active environments ({env_scope}) "
                    f"found for '{cname}' — skipping customer")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "SKIPPED",
                               f"No active envs in {env_scope}", cname)
                continue

            env_types_found = [e["env_type"] for e in envs]
            logger.info(
                f"[STEP-4] Environments for {cname}: {env_types_found}")
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "COMPLETED",
                           f"found: {env_types_found}", cname)

            # ── Environment loop ──────────────────────────────────────────────
            for env in envs:
                env_id      = env["env_id"]
                env_type    = env["env_type"]
                srv_user_raw = env.get("server_user", "") or ""
                srv_pwd_raw  = env.get("server_pwd",  "") or ""

                # Decrypt server password for WMI
                try:
                    srv_pwd = (decrypt_password(srv_pwd_raw)
                               if is_encrypted(srv_pwd_raw)
                               else srv_pwd_raw)
                except Exception:
                    srv_pwd = srv_pwd_raw

                logger.info("")
                logger.info(
                    f"[STEP-4] ── {cname} / {env_type} "
                    f"(EnvID={env_id}) ──────────")

                # ── Identify DB Server ────────────────────────────────────────
                try:
                    with DBManager(cfg=HC_DB) as db:
                        server = self._load_server(db, env_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-5] Cannot load server for "
                        f"{cname}/{env_type}: {exc}")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "FAILED",
                                   str(exc), cname, env_type)
                    continue

                if not server:
                    logger.warning(
                        f"[STEP-5] No active DB server found for "
                        f"{cname}/{env_type} — skipping")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "SKIPPED",
                                   "No active server record in Servers table",
                                   cname, env_type)
                    continue

                server_host = server["host"]
                server_id   = server["server_id"]
                server_name = server.get("server_name", "")

                logger.info(
                    f"[STEP-5] DB Server: {server_name} "
                    f"| host={server_host} (ID={server_id}) "
                    f"| {cname}/{env_type}")
                self._log_step(5, "IDENTIFY_DB_SERVER", "COMPLETED",
                               f"server={server_name} host={server_host}",
                               cname, env_type)

                # ── STEP A: WMI Server Connection Check ───────────────────────
                logger.info(
                    f"[STEP-5A] WMI check: {cname}/{env_type} → {server_host} "
                    f"| user={srv_user_raw}")
                self._log_step(5, "DB_SERVER_WMI_CHECK", "STARTED",
                               f"host={server_host} user={srv_user_raw}",
                               cname, env_type)

                srv_ok, srv_err, srv_ms = self._check_server_wmi(
                    host     = server_host,
                    username = srv_user_raw,
                    password = srv_pwd
                )

                if not srv_ok:
                    # Server unreachable — record row, skip DB check
                    logger.error(
                        f"[STEP-5A] ❌ DB Server NOT CONNECTED: "
                        f"{cname}/{env_type} | {server_host} | {srv_err}")
                    logger.warning(
                        f"[STEP-5A] Skipping FMW DB check for "
                        f"{cname}/{env_type} — server unreachable")
                    self._log_step(5, "DB_SERVER_WMI_CHECK", "FAILED",
                                   f"NOT CONNECTED: {srv_err}",
                                   cname, env_type)

                    result = {
                        "run_id":            self.run_id,
                        "customer_id":       cid,
                        "customer_name":     cname,
                        "env_type":          env_type,
                        "server_host":       server_host,
                        "server_status":     "NOT CONNECTED",
                        "server_error":      srv_err,
                        "db_name":           "",
                        "db_host":           server_host,
                        "db_port":           1521,
                        "db_service":        "",
                        "connection_status": "FAILED",
                        "error_message":     f"DB Server unreachable: {srv_err}",
                        "duration_ms":       srv_ms,
                        "checked_at":        datetime.utcnow(),
                    }
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "COMPLETED",
                                   "Server=NOT CONNECTED | DB=SKIPPED",
                                   cname, env_type)
                    logger.info(
                        f"[STEP-5A] → Next environment "
                        f"(server down: {cname}/{env_type})")
                    continue

                # Server connected
                logger.info(
                    f"[STEP-5A] ✅ DB Server CONNECTED: "
                    f"{cname}/{env_type} | {server_host} | {srv_ms}ms")
                self._log_step(5, "DB_SERVER_WMI_CHECK", "COMPLETED",
                               f"CONNECTED | {srv_ms}ms",
                               cname, env_type)

                # ── Step 6: Load FMW databases ────────────────────────────────
                logger.info(
                    f"[STEP-6] Loading FMW DBs: "
                    f"{cname}/{env_type} | server_id={server_id}")
                self._log_step(6, "LOAD_FMW_DATABASES", "STARTED",
                               f"server_id={server_id}",
                               cname, env_type)
                try:
                    with DBManager(cfg=HC_DB) as db:
                        fmw_dbs = self._load_fmw_dbs(db, server_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-6] Cannot load FMW DBs for "
                        f"{cname}/{env_type}: {exc}")
                    self._log_step(6, "LOAD_FMW_DATABASES", "FAILED",
                                   str(exc), cname, env_type)
                    continue

                if not fmw_dbs:
                    logger.warning(
                        f"[STEP-6] No active FMW databases (type={FMW_DB_TYPE}) "
                        f"found for {cname}/{env_type} — skipping")
                    self._log_step(6, "LOAD_FMW_DATABASES", "SKIPPED",
                                   f"No active OracleDatabase rows "
                                   f"(DatabaseType={FMW_DB_TYPE})",
                                   cname, env_type)
                    continue

                logger.info(
                    f"[STEP-6] {len(fmw_dbs)} FMW DB(s) found "
                    f"for {cname}/{env_type}")
                self._log_step(6, "LOAD_FMW_DATABASES", "COMPLETED",
                               f"{len(fmw_dbs)} FMW DB(s) found",
                               cname, env_type)

                # ── STEP B: Check each FMW DB ─────────────────────────────────
                for fmw in fmw_dbs:
                    db_info = {
                        "customer_id":   cid,
                        "customer_name": cname,
                        "env_type":      env_type,
                        "db_name":       fmw["db_name"],
                        "db_host":       server_host,
                        "db_port":       fmw.get("db_port", 1521),
                        "db_service":    fmw["db_service"],
                        "db_user":       fmw["db_user"],
                        "db_password":   fmw["db_password"],
                    }

                    self._log_step(6, "FMW_DB_CONNECTION_CHECK", "STARTED",
                                   f"DB={fmw['db_name']} dsn="
                                   f"{server_host}:{fmw.get('db_port',1521)}"
                                   f"/{fmw['db_service']}",
                                   cname, env_type)

                    db_ok, db_err, db_ms = self._check_db_connection(db_info)

                    icon   = "✅" if db_ok else "❌"
                    status = "COMPLETED" if db_ok else "FAILED"

                    result = {
                        "run_id":            self.run_id,
                        "customer_id":       cid,
                        "customer_name":     cname,
                        "env_type":          env_type,
                        "server_host":       server_host,
                        "server_status":     "CONNECTED",
                        "server_error":      None,
                        "db_name":           fmw["db_name"],
                        "db_host":           server_host,
                        "db_port":           fmw.get("db_port", 1521),
                        "db_service":        fmw["db_service"],
                        "connection_status": status,
                        "error_message":     db_err,
                        "duration_ms":       db_ms,
                        "checked_at":        datetime.utcnow(),
                    }
                    self._save_result(result)
                    results.append(result)

                    self._log_step(
                        7, "CAPTURE_RESULT", status,
                        f"DB={fmw['db_name']} | "
                        f"{icon} {status} | {db_ms}ms"
                        + (f" | Error: {db_err}" if db_err else ""),
                        cname, env_type)

                    logger.info(
                        f"[STEP-7] Result: {cname}/{env_type} | "
                        f"DB={fmw['db_name']} | "
                        f"{icon} {status} | {db_ms}ms")

                # Mark env as complete
                env_results = [
                    r for r in results
                    if r["customer_name"] == cname
                    and r["env_type"] == env_type]
                env_ok = all(
                    r["connection_status"] == "COMPLETED" for r in env_results)
                self._log_step(
                    6, "FMW_DB_CONNECTION_CHECK",
                    "COMPLETED" if env_ok else "PARTIAL",
                    f"{cname}/{env_type} done",
                    cname, env_type)

                logger.info(
                    f"[STEP-6] → Next environment after {cname}/{env_type}")

            logger.info(
                f"[STEP-4] ✔ All environments done for {cname} → next customer")

        # ── Summary ───────────────────────────────────────────────────────────
        success = sum(1 for r in results if r["connection_status"] == "COMPLETED")
        failed  = len(results) - success
        logger.info("")
        logger.info(f"{'=' * 60}")
        logger.info(
            f"[STEP-7] All checks done | "
            f"total_envs={len(results)} | "
            f"success={success} | failed={failed}")
        logger.info(f"{'=' * 60}")
        return results
