"""
Common/email_manager.py
=======================
Send FMW Check report email with Excel attachment.

Subject  : FMW Database connection for {Customer Name(s)}
Attachment: FMW_DATABASE_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx
Body      : Simple plain-English format per requirement.
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta

logger = logging.getLogger("fmw.email")

IST_OFFSET = timedelta(hours=5, minutes=30)


def _now_ist_display() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%m-%Y %H:%M")


class EmailManager:

    def __init__(self, email_cfg):
        self.cfg = email_cfg

    def send_report(self,
                    subject:    str,
                    html_body:  str,
                    excel_path: str = None,
                    run_id:     int = 0) -> tuple:
        """
        Send report email with Excel attachment.
        Returns (success: bool, error_message: str|None)
        """
        to_list  = self.cfg.to_addrs
        cc_list  = self.cfg.cc_addrs
        bcc_list = self.cfg.bcc_addrs

        if not to_list:
            logger.warning(
                "[STEP-9] No TO address in fmw_email_config — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(to_list)
            if cc_list:
                msg["Cc"]  = ", ".join(cc_list)

            msg.attach(MIMEText(html_body, "html", "utf-8"))

            # Attach Excel
            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)
                logger.info(
                    f"[STEP-9] Attached: {os.path.basename(excel_path)}")

            all_recipients = to_list + cc_list + bcc_list

            with smtplib.SMTP(
                    self.cfg.smtp_host,
                    self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(
                    self.cfg.from_addr, all_recipients, msg.as_string())

            logger.info(
                f"[STEP-9] Email sent | run_id={run_id} | "
                f"to={to_list} cc={cc_list} | subject='{subject}'")
            return True, None

        except Exception as exc:
            logger.error(f"[STEP-9] Email failed: {exc}", exc_info=True)
            return False, str(exc)[:500]

    # ── Email subject builder ─────────────────────────────────────────────────
    @staticmethod
    def build_subject(results: list, run_id: int) -> str:
        """
        Subject: FMW Database connection for {Customer Name(s)}
        Multiple customers → comma-separated list.
        """
        customers = list(dict.fromkeys(
            r.get("customer_name", "") for r in results
            if r.get("customer_name")))
        cust_str = ", ".join(customers) if customers else "All Customers"
        return f"FMW Database connection for {cust_str}"

    # ── HTML body builder (simple format per requirement) ─────────────────────
    @staticmethod
    def build_html(results:   list,
                   run_id:    int,
                   timestamp: str,
                   total:     int,
                   success:   int,
                   failed:    int) -> str:
        """
        Simple email body format:
          Hi Team,
          FMW database connection check completed. Please review the attached
          report for details and take action on failed connections.
          Date and Time: DD-MM-YYYY HH:MM
          Run ID: XXXXX
          Thanks & Regards,
          RPA Team
        """
        now_display = _now_ist_display()

        if total == 0:
            summary_line = "No data was processed — no active FMW databases found."
            status_color = "#C62828"
        elif failed == 0:
            summary_line = f"All {total} FMW database connection(s) completed successfully."
            status_color = "#2E7D32"
        else:
            summary_line = (
                f"{failed} of {total} FMW database connection(s) failed. "
                f"Please review the attached report and take action.")
            status_color = "#C62828"

        # Build results table
        rows_html = ""
        for idx, r in enumerate(results, 1):
            srv_ok = r.get("server_status") == "CONNECTED"
            db_ok  = r.get("connection_status") == "COMPLETED"

            if not srv_ok:
                bg          = "#FFF8E1" if idx % 2 else "#FFF3E0"
                srv_badge   = '<span style="color:#E65100;font-weight:bold">⚠ NOT CONNECTED</span>'
                db_badge    = '<span style="color:#9E9E9E">— (skipped)</span>'
                err_display = r.get("server_error") or r.get("error_message") or "—"
            else:
                bg        = ("#E8F5E9" if db_ok else "#FFEBEE") if idx % 2 else \
                            ("#F0FAF0" if db_ok else "#FFF5F5")
                srv_badge = '<span style="color:#2E7D32;font-weight:bold">✅ CONNECTED</span>'
                db_badge  = (
                    '<span style="color:#2E7D32;font-weight:bold">✅ COMPLETED</span>'
                    if db_ok else
                    '<span style="color:#C62828;font-weight:bold">❌ FAILED</span>')
                err_display = r.get("error_message") or "—"

            rows_html += f"""
            <tr style="background:{bg}">
              <td style="padding:7px 10px;border:1px solid #e0e0e0">{idx}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0;font-weight:600">
                {r.get('customer_name','—')}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0">
                {r.get('env_type','—')}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0;text-align:center">
                {srv_badge}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0">
                {r.get('server_host','—')}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0">
                {r.get('db_name','—') if srv_ok else '—'}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0;text-align:center">
                {db_badge}</td>
              <td style="padding:7px 10px;border:1px solid #e0e0e0;
                         color:#C62828;font-size:11px">
                {err_display if not (srv_ok and db_ok) else '—'}</td>
            </tr>"""

        overall_color = "#2E7D32" if failed == 0 and total > 0 else "#C62828"

        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f4f6f8;padding:20px;margin:0">

<table width="860" cellpadding="0" cellspacing="0"
       style="background:#fff;border-radius:8px;
              box-shadow:0 2px 8px rgba(0,0,0,.1);margin:0 auto">

  <!-- Header -->
  <tr>
    <td style="background:#1565C0;padding:18px 28px;border-radius:8px 8px 0 0">
      <span style="color:#fff;font-size:18px;font-weight:700">
        🗄️ FMW Database Connection Check
      </span>
      <span style="float:right;background:#0D47A1;color:#fff;
                   padding:4px 12px;border-radius:12px;font-size:12px">
        Run #{run_id}
      </span>
    </td>
  </tr>

  <!-- Simple body -->
  <tr>
    <td style="padding:24px 28px 8px 28px;font-size:14px;color:#333;
               line-height:1.7">
      Hi Team,<br><br>
      FMW database connection check completed. Please review the attached
      report for details and take action on failed connections.<br><br>
      <strong>Date and Time:</strong> {now_display}<br>
      <strong>Run ID:</strong> {run_id}<br>
      <strong>Total Environments:</strong> {total}<br>
      <strong style="color:#2E7D32">Success: {success}</strong>
      &nbsp;&nbsp;
      <strong style="color:#C62828">Failed: {failed}</strong>
      &nbsp;&nbsp;
      <strong style="color:{overall_color}">{
        'ALL CONNECTED' if failed==0 and total>0
        else ('NO DATA' if total==0 else f'{failed} FAILED')
      }</strong>
    </td>
  </tr>

  <!-- Summary line -->
  <tr>
    <td style="padding:0 28px 16px 28px;font-size:13px;
               color:{status_color};font-weight:600">
      {summary_line}
    </td>
  </tr>

  <!-- Results table -->
  <tr>
    <td style="padding:0 28px 20px 28px">
      <table width="100%" cellpadding="0" cellspacing="0"
             style="border-collapse:collapse;font-size:12px">
        <thead>
          <tr style="background:#1565C0;color:#fff">
            <th style="padding:8px 10px;text-align:left">#</th>
            <th style="padding:8px 10px;text-align:left">Customer</th>
            <th style="padding:8px 10px;text-align:left">Env</th>
            <th style="padding:8px 10px;text-align:center">Server</th>
            <th style="padding:8px 10px;text-align:left">Server Host</th>
            <th style="padding:8px 10px;text-align:left">DB Name</th>
            <th style="padding:8px 10px;text-align:center">DB Status</th>
            <th style="padding:8px 10px;text-align:left">Error</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
    </td>
  </tr>

  <!-- Footer -->
  <tr>
    <td style="padding:16px 28px 20px 28px;font-size:13px;
               color:#333;line-height:1.7;
               border-top:1px solid #E0E0E0">
      Thanks &amp; Regards,<br>
      <strong>RPA Team</strong>
    </td>
  </tr>

  <tr>
    <td style="background:#F5F5F5;padding:10px 28px;
               text-align:center;font-size:11px;color:#9E9E9E;
               border-radius:0 0 8px 8px">
      FMW Database Check System &nbsp;|&nbsp; {timestamp}
    </td>
  </tr>

</table>
</body></html>"""
