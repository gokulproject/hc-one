"""
fmw_checker.py
==============
Core FMW database connection checker.

Reads FMW Oracle database details from HealthCheck schema:
  Tables used (READ ONLY from health_check schema):
    - customers         → CustomerID, CustomerName, Status
    - Environments      → EnvID, CustomerID, ServerType (VAL/PRD/DEV), Status
    - OracleDatabase    → dbid, ServerID→EnvID, User, Password,
                          OrdName (service/sid), Port, DatabaseType, Status
    - Servers           → ServerID, EnvID, Host, ...

  Filter: DatabaseType = 'FMW' and Status = active

Supports:
  - Multiple customers    (all active, or filtered)
  - Multiple environments (VAL / PRD / DEV — all or filtered)
  - Single customer / single env

Writes results to fmwchecks schema.
"""
import logging
import os
import sys
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.crypto     import decrypt_password, is_encrypted
from Common.db_manager import DBManager
from config            import HC_DB, FMWCHECKS_DB

logger = logging.getLogger("fmw.checker")

# DatabaseType value in HC schema that we care about
FMW_DB_TYPE = "FMW"


class FMWChecker:
    """
    Checks FMW Oracle DB connections for all active customers and environments.
    """

    def __init__(self, run_id: int, app_cfg=None):
        """
        run_id:  fmw_run.id from fmwchecks DB
        app_cfg: AppConfig loaded from fmwchecks DB (for oracle_timeout, oracle_dll_path)
        """
        self.run_id  = run_id
        self.cfg     = app_cfg
        self._oracle_timeout   = getattr(app_cfg, "oracle_timeout",  15)  if app_cfg else 15
        self._oracle_dll_path  = getattr(app_cfg, "oracle_dll_path", "")  if app_cfg else ""
        self._setup_oracle_client()

    def _setup_oracle_client(self):
        """Init Oracle thick client if DLL folder is configured and exists."""
        try:
            import oracledb
            dll = self._oracle_dll_path
            if dll and os.path.isdir(dll) and os.listdir(dll):
                oracledb.init_oracle_client(lib_dir=dll)
                logger.info(f"Oracle thick client initialised: {dll}")
            else:
                logger.info("Oracle thin client mode (no DLL folder configured)")
        except Exception as exc:
            logger.warning(f"Oracle client init warning: {exc}")

    # ── Load FMW DB list from HealthCheck schema ──────────────────────────────

    def load_fmw_databases(self) -> list:
        """
        Read all active FMW-type Oracle databases from HealthCheck schema.

        Handles the schema seen in the images:
          Customers  → CustomerID, CustomerName, Status
          Environments → EnvID, CustomerID, ServerType, Status
          Servers    → ServerID, EnvID, Host, ...
          OracleDatabase → dbid, ServerID, User, Password,
                           OrdName (service/SID), Port, DatabaseType, Status

        Returns list of dicts — one per FMW database row.
        Multiple customers and multiple envs are returned together.
        """
        logger.info("Loading FMW database list from HealthCheck schema...")
        try:
            with DBManager(cfg=HC_DB) as db:
                rows = db.fetch_all(
                    """SELECT
                         od.dbid            AS db_id,
                         c.CustomerID       AS customer_id,
                         c.CustomerName     AS customer_name,
                         e.ServerType       AS env_type,
                         od.OrdName         AS db_name,
                         s.Host             AS db_host,
                         od.Port            AS db_port,
                         od.OrdName         AS db_service,
                         od.User            AS db_user,
                         od.Password        AS db_password,
                         od.DatabaseType    AS db_type
                       FROM OracleDatabase od
                       JOIN Servers      s  ON s.ServerID  = od.ServerID
                       JOIN Environments e  ON e.EnvID     = s.EnvID
                       JOIN Customers    c  ON c.CustomerID = e.CustomerID
                       WHERE od.DatabaseType = %s
                         AND od.Status       = 1
                         AND s.Status        = 1
                         AND e.Status        = 1
                         AND c.Status        = 1
                       ORDER BY c.CustomerName, e.ServerType, od.OrdName""",
                    (FMW_DB_TYPE,))

            logger.info(
                f"Found {len(rows)} active FMW database(s) across "
                f"{len(set(r['customer_id'] for r in rows))} customer(s) and "
                f"{len(set(r['env_type'] for r in rows))} env type(s)")

            # Log breakdown
            by_customer = {}
            for r in rows:
                key = f"{r['customer_name']} / {r['env_type']}"
                by_customer[key] = by_customer.get(key, 0) + 1
            for k, v in sorted(by_customer.items()):
                logger.info(f"  {k}: {v} FMW DB(s)")

            return rows

        except Exception as exc:
            logger.error(f"Failed to load FMW databases from HealthCheck: {exc}",
                         exc_info=True)
            return []

    # ── Test one Oracle connection ────────────────────────────────────────────

    def check_connection(self, db_info: dict) -> dict:
        """
        Attempt Oracle connection for one FMW database.
        Returns result dict with status, duration_ms, error_message.
        """
        import oracledb

        name    = db_info.get("db_name",    "?")
        host    = db_info.get("db_host",    "")
        port    = int(db_info.get("db_port", 1521))
        service = db_info.get("db_service", "")
        user    = db_info.get("db_user",    "")
        pwd_raw = db_info.get("db_password","")
        cname   = db_info.get("customer_name", "")
        env     = db_info.get("env_type",   "")

        # Decrypt password if it was stored encrypted in HC DB
        password = decrypt_password(pwd_raw) if is_encrypted(pwd_raw) else pwd_raw

        dsn = f"{host}:{port}/{service}"
        logger.info(f"  Checking: {cname} / {env} | {name} | {dsn}")

        start = time.time()
        conn  = None
        try:
            conn = oracledb.connect(
                user     = user,
                password = password,
                dsn      = dsn,
                timeout  = self._oracle_timeout,
            )
            duration_ms = int((time.time() - start) * 1000)
            conn.close()
            conn = None

            logger.info(f"  ✅ SUCCESS: {cname}/{env} | {name} | {duration_ms} ms")
            return {
                "customer_id":       db_info["customer_id"],
                "customer_name":     cname,
                "env_type":          env,
                "db_name":           name,
                "db_host":           host,
                "db_port":           port,
                "db_service":        service,
                "connection_status": "SUCCESS",
                "error_message":     None,
                "duration_ms":       duration_ms,
                "checked_at":        datetime.utcnow(),
            }

        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000)
            err = str(exc)[:1000]
            logger.error(f"  ❌ FAILED:  {cname}/{env} | {name} | {err}")
            return {
                "customer_id":       db_info["customer_id"],
                "customer_name":     cname,
                "env_type":          env,
                "db_name":           name,
                "db_host":           host,
                "db_port":           port,
                "db_service":        service,
                "connection_status": "FAILED",
                "error_message":     err,
                "duration_ms":       duration_ms,
                "checked_at":        datetime.utcnow(),
            }
        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass

    # ── Save one result to fmwchecks DB ──────────────────────────────────────

    def _save_result(self, result: dict):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_connection_result
                       (run_id, customer_id, customer_name, env_type,
                        db_name, db_host, db_port, db_service,
                        connection_status, error_message,
                        duration_ms, checked_at)
                       VALUES (%s,%s,%s,%s, %s,%s,%s,%s, %s,%s, %s,%s)""",
                    (result["run_id"],
                     result["customer_id"],
                     result["customer_name"],
                     result["env_type"],
                     result["db_name"],
                     result["db_host"],
                     result["db_port"],
                     result["db_service"],
                     result["connection_status"],
                     result["error_message"],
                     result["duration_ms"],
                     result["checked_at"]))
        except Exception as exc:
            logger.error(f"Failed to save result: {exc}")

    # ── Run all checks ────────────────────────────────────────────────────────

    def run_all(self) -> list:
        """
        Check all FMW databases across all customers and environments.
        Saves each result to fmwchecks DB immediately after check.
        Returns list of all result dicts.
        """
        db_list = self.load_fmw_databases()
        if not db_list:
            logger.warning("No active FMW databases found — nothing to check")
            return []

        results = []
        for db_info in db_list:
            result          = self.check_connection(db_info)
            result["run_id"] = self.run_id
            self._save_result(result)
            results.append(result)

        success = sum(1 for r in results if r["connection_status"] == "SUCCESS")
        failed  = len(results) - success
        logger.info(
            f"FMW check complete | "
            f"total={len(results)} success={success} failed={failed}")
        return results
