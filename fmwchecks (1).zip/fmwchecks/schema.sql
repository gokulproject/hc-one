-- ============================================================
-- FMWChecks Schema
-- Creates the fmwchecks database with all required tables.
--
-- Run ONCE before first execution:
--   mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS fmwchecks
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE fmwchecks;

-- ── Email config ─────────────────────────────────────────────
-- Stores SMTP settings and recipient addresses.
-- Multiple rows supported (only is_active=1 rows are used).
CREATE TABLE IF NOT EXISTS fmw_email_config (
    id          INT           NOT NULL AUTO_INCREMENT,
    config_name VARCHAR(100)  NOT NULL DEFAULT 'default',
    smtp_host   VARCHAR(255)  NOT NULL,
    smtp_port   INT           NOT NULL DEFAULT 587,
    smtp_user   VARCHAR(255)  NOT NULL,
    smtp_pass   VARCHAR(255)  NOT NULL,
    use_tls     TINYINT(1)    NOT NULL DEFAULT 1,
    from_addr   VARCHAR(255)  NOT NULL,
    to_addr     TEXT          NOT NULL,   -- comma-separated
    cc_addr     TEXT          NULL,       -- comma-separated, optional
    bcc_addr    TEXT          NULL,       -- comma-separated, optional
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Path / general config ─────────────────────────────────────
-- Key-value store for paths and settings.
-- Keys: excel_path, log_path, oracle_timeout, oracle_dll_path
CREATE TABLE IF NOT EXISTS fmw_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value VARCHAR(500)  NOT NULL,
    description  VARCHAR(255)  NULL,
    updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Run table — one row per execution ────────────────────────
CREATE TABLE IF NOT EXISTS fmw_run (
    id            INT          NOT NULL AUTO_INCREMENT,
    status        VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',
                  -- RUNNING | COMPLETED | PARTIAL | FAILED | NO_DATA
    started_at    DATETIME     NULL,
    completed_at  DATETIME     NULL,
    total_dbs     INT          NOT NULL DEFAULT 0,
    success_count INT          NOT NULL DEFAULT 0,
    fail_count    INT          NOT NULL DEFAULT 0,
    excel_path    VARCHAR(500) NULL,
    email_status  VARCHAR(20)  NULL,       -- SENT | FAILED | SKIPPED
    email_error   TEXT         NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Connection result — one row per DB per run ───────────────
CREATE TABLE IF NOT EXISTS fmw_connection_result (
    id                 INT          NOT NULL AUTO_INCREMENT,
    run_id             INT          NOT NULL,
    customer_id        INT          NOT NULL,
    customer_name      VARCHAR(255) NOT NULL,
    env_type           VARCHAR(50)  NOT NULL,
    db_name            VARCHAR(255) NOT NULL,
    db_host            VARCHAR(255) NOT NULL,
    db_port            INT          NOT NULL DEFAULT 1521,
    db_service         VARCHAR(255) NULL,
    connection_status  VARCHAR(20)  NOT NULL,  -- SUCCESS | FAILED
    error_message      TEXT         NULL,
    duration_ms        INT          NOT NULL DEFAULT 0,
    checked_at         DATETIME     NOT NULL,
    PRIMARY KEY (id),
    KEY idx_run_id     (run_id),
    KEY idx_customer   (customer_id),
    KEY idx_status     (connection_status),
    KEY idx_checked_at (checked_at),
    CONSTRAINT fk_result_run
        FOREIGN KEY (run_id) REFERENCES fmw_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Step log — audit trail per run ──────────────────────────
CREATE TABLE IF NOT EXISTS fmw_run_log (
    id         INT          NOT NULL AUTO_INCREMENT,
    run_id     INT          NOT NULL,
    step_name  VARCHAR(100) NOT NULL,
    status     VARCHAR(20)  NOT NULL,
              -- STARTED | COMPLETED | FAILED | SKIPPED
    message    TEXT         NULL,
    logged_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_run_id (run_id),
    CONSTRAINT fk_log_run
        FOREIGN KEY (run_id) REFERENCES fmw_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- Default config data — edit values to match your environment
-- ============================================================

-- Default paths (relative paths work; absolute paths recommended)
INSERT INTO fmw_config (config_key, config_value, description) VALUES
  ('excel_path',      'Excel',            'Folder where Excel reports are saved'),
  ('log_path',        'Logs',             'Folder where log files are written'),
  ('oracle_timeout',  '15',               'Oracle connection timeout in seconds'),
  ('oracle_dll_path', 'oracledb_dll',     'Folder containing Oracle thick-client DLLs (leave empty for thin mode)')
ON DUPLICATE KEY UPDATE config_value = VALUES(config_value);


-- Default email config — update before running
INSERT INTO fmw_email_config
  (config_name, smtp_host, smtp_port, smtp_user, smtp_pass,
   use_tls, from_addr, to_addr, cc_addr, bcc_addr, is_active)
VALUES
  ('default',
   'smtp.company.com', 587,
   'alerts@company.com', 'email_password',
   1,
   'alerts@company.com',
   'team@company.com',
   '',   -- cc: comma-separated or empty
   '',   -- bcc: comma-separated or empty
   1)
ON DUPLICATE KEY UPDATE smtp_host = VALUES(smtp_host);


-- ============================================================
-- Useful queries:
--
-- View latest run:
--   SELECT * FROM fmw_run ORDER BY id DESC LIMIT 1;
--
-- View all results for latest run:
--   SELECT customer_name, env_type, db_name,
--          connection_status, duration_ms, error_message
--   FROM fmw_connection_result
--   WHERE run_id = (SELECT MAX(id) FROM fmw_run)
--   ORDER BY connection_status DESC, customer_name;
--
-- View all failed DBs across all runs:
--   SELECT r.id run_id, r.started_at,
--          cr.customer_name, cr.env_type, cr.db_name, cr.error_message
--   FROM fmw_connection_result cr
--   JOIN fmw_run r ON r.id = cr.run_id
--   WHERE cr.connection_status = 'FAILED'
--   ORDER BY r.started_at DESC;
--
-- View step logs for last run:
--   SELECT step_name, status, message, logged_at
--   FROM fmw_run_log
--   WHERE run_id = (SELECT MAX(id) FROM fmw_run)
--   ORDER BY logged_at;
--
-- Update email recipients:
--   UPDATE fmw_email_config
--   SET to_addr='person1@co.com,person2@co.com', cc_addr='mgr@co.com'
--   WHERE is_active=1;
--
-- Update Excel output path:
--   UPDATE fmw_config SET config_value='/data/reports' WHERE config_key='excel_path';
-- ============================================================
