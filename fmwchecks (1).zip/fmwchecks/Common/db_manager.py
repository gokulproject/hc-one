"""
Common/db_manager.py
====================
MySQL database wrapper.
Supports two schemas:
  - HealthCheck DB  (HC_DB)         → read customer / FMW DB details
  - FMWChecks DB    (FMWCHECKS_DB)  → write run results, config, logs
"""
import logging
import time
from typing import Dict, List, Optional

import pymysql
import pymysql.cursors
from pymysql.err import OperationalError, InterfaceError

logger = logging.getLogger("fmw.db")


class DBConnectionError(ConnectionError):
    """Raised when MySQL cannot be reached after all retries."""


class DBManager:
    """
    Wraps a single pymysql connection.

    Usage:
        with DBManager(cfg=HC_DB) as db:
            rows = db.fetch_all("SELECT * FROM oracle_databases")

        with DBManager(cfg=FMWCHECKS_DB) as db:
            db.execute("INSERT INTO fmw_run ...")
    """

    _MAX_RETRIES = 3
    _BASE_DELAY  = 2

    def __init__(self, cfg: dict):
        self._cfg  = cfg
        self._conn = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, *_):
        if exc_type is None:
            try:
                self._conn.commit()
            except Exception:
                pass
        else:
            try:
                self._conn.rollback()
            except Exception:
                pass
        self.disconnect()

    def connect(self):
        last_exc = None
        for attempt in range(1, self._MAX_RETRIES + 1):
            try:
                self._conn = pymysql.connect(
                    host            = self._cfg["host"],
                    port            = int(self._cfg.get("port", 3306)),
                    user            = self._cfg["user"],
                    password        = self._cfg["password"],
                    database        = self._cfg["database"],
                    charset         = "utf8mb4",
                    cursorclass     = pymysql.cursors.DictCursor,
                    autocommit      = False,
                    connect_timeout = 10,
                )
                logger.debug(f"Connected to {self._cfg['database']}@{self._cfg['host']}")
                return True
            except (OperationalError, InterfaceError) as e:
                last_exc = e
                logger.warning(f"DB connect attempt {attempt}/{self._MAX_RETRIES}: {e}")
                time.sleep(self._BASE_DELAY * attempt)

        raise DBConnectionError(
            f"Cannot connect to {self._cfg['database']}@{self._cfg['host']}: {last_exc}")

    def disconnect(self):
        try:
            if self._conn:
                self._conn.close()
        except Exception:
            pass
        self._conn = None

    def fetch_all(self, sql: str, params=None) -> List[Dict]:
        with self._conn.cursor() as cur:
            cur.execute(sql, params or ())
            return cur.fetchall() or []

    def fetch_one(self, sql: str, params=None) -> Optional[Dict]:
        with self._conn.cursor() as cur:
            cur.execute(sql, params or ())
            return cur.fetchone()

    def execute(self, sql: str, params=None) -> int:
        with self._conn.cursor() as cur:
            cur.execute(sql, params or ())
            self._conn.commit()
            return cur.rowcount

    def insert_get_id(self, sql: str, params=None) -> int:
        with self._conn.cursor() as cur:
            cur.execute(sql, params or ())
            self._conn.commit()
            return cur.lastrowid
