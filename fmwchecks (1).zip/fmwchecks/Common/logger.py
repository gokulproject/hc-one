"""
Common/logger.py
================
File + console logging for FMWChecks project.
Log path is read from fmwchecks DB (fmw_config.log_path).
Falls back to ./Logs if DB config not yet loaded.
"""
import logging
import os
from datetime import datetime


def setup_logging(log_dir: str = None) -> logging.Logger:
    """
    Configure root logger.
    log_dir: full path from AppConfig.log_path.
             If None, defaults to ./Logs next to this file.
    """
    if not log_dir:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Logs")

    os.makedirs(log_dir, exist_ok=True)

    date_str = datetime.now().strftime("%Y%m%d")
    log_file = os.path.join(log_dir, f"fmw_check_{date_str}.log")

    fmt = logging.Formatter(
        fmt     = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt = "%Y-%m-%d %H:%M:%S"
    )

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    if not root.handlers:
        root.addHandler(fh)
        root.addHandler(ch)
    else:
        # Replace file handler if log_dir changed after config load
        for h in list(root.handlers):
            if isinstance(h, logging.FileHandler):
                root.removeHandler(h)
                h.close()
        root.addHandler(fh)

    logger = logging.getLogger("fmw")
    logger.info(f"Logging started | file={log_file}")
    return logger


def get_logger(name: str = "fmw") -> logging.Logger:
    return logging.getLogger(name)
