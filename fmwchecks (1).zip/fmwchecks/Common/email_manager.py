"""
Common/email_manager.py
=======================
Send FMW Check report email with Excel attachment.
Email settings (SMTP, TO, CC, BCC) are read from AppConfig.email
which is loaded from fmwchecks.fmw_email_config table at runtime.

Supports:
  - Multiple TO addresses  (comma-separated in DB)
  - Multiple CC addresses  (comma-separated in DB)
  - Multiple BCC addresses (comma-separated in DB)
  - Single or multiple customers / envs in one report
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime

logger = logging.getLogger("fmw.email")


class EmailManager:

    def __init__(self, email_cfg):
        """
        email_cfg: AppConfig.email  (EmailConfig dataclass)
        """
        self.cfg = email_cfg

    def send_report(self,
                    subject:    str,
                    html_body:  str,
                    excel_path: str = None,
                    run_id:     int = 0) -> tuple:
        """
        Send report email.
        Returns (success: bool, error_message: str or None)
        """
        to_list  = self.cfg.to_addrs
        cc_list  = self.cfg.cc_addrs
        bcc_list = self.cfg.bcc_addrs

        if not to_list:
            logger.warning("No TO address configured in fmw_email_config — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(to_list)
            if cc_list:
                msg["Cc"]  = ", ".join(cc_list)
            # BCC: included in recipients but NOT in headers

            # HTML body
            msg.attach(MIMEText(html_body, "html", "utf-8"))

            # Excel attachment
            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)
                logger.info(f"Attached: {os.path.basename(excel_path)}")

            # All recipients (TO + CC + BCC)
            all_recipients = to_list + cc_list + bcc_list

            with smtplib.SMTP(self.cfg.smtp_host,
                              self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(self.cfg.from_addr, all_recipients, msg.as_string())

            logger.info(
                f"Email sent | run_id={run_id} | "
                f"to={to_list} cc={cc_list} bcc={bcc_list} | "
                f"subject='{subject}'")
            return True, None

        except Exception as exc:
            logger.error(f"Email failed: {exc}", exc_info=True)
            return False, str(exc)[:500]

    # ── HTML body builder ────────────────────────────────────────────────────

    @staticmethod
    def build_html(results:   list,
                   run_id:    int,
                   timestamp: str,
                   total:     int,
                   success:   int,
                   failed:    int) -> str:
        """
        Build HTML email body from connection results.
        Groups rows by Customer then Environment for clarity.
        """
        rows_html = ""
        for idx, r in enumerate(results, 1):
            ok     = r["connection_status"] == "SUCCESS"
            bg     = "#f0faf0" if ok else "#fff5f5"
            if idx % 2 == 0:
                bg = "#e8f5e9" if ok else "#ffebee"

            status_html = (
                '<span style="color:#2E7D32;font-weight:bold">✅ SUCCESS</span>'
                if ok else
                '<span style="color:#C62828;font-weight:bold">❌ FAILED</span>'
            )
            err = r.get("error_message") or "—"
            dur = f"{r.get('duration_ms', 0)} ms"

            rows_html += f"""
            <tr style="background:{bg}">
              <td style="padding:8px 12px;border:1px solid #e0e0e0">{idx}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0;font-weight:600">
                {r.get('customer_name','—')}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0">
                {r.get('env_type','—')}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0">
                {r.get('db_name','—')}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0">
                {r.get('db_host','—')}:{r.get('db_port','')}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0">
                {r.get('db_service','—')}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0;text-align:center">
                {status_html}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0;text-align:center;
                         color:#666">{dur}</td>
              <td style="padding:8px 12px;border:1px solid #e0e0e0;
                         color:#C62828;font-size:12px">
                {'—' if ok else err}</td>
            </tr>"""

        overall_color  = "#2E7D32" if failed == 0 else "#C62828"
        overall_status = "ALL CONNECTED ✅" if failed == 0 else f"{failed} FAILED ❌"

        return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f4f6f8;padding:20px">
<table width="960" cellpadding="0" cellspacing="0"
       style="background:#fff;border-radius:8px;
              box-shadow:0 2px 8px rgba(0,0,0,.08)">
  <tr>
    <td style="background:#1565C0;padding:20px 28px;border-radius:8px 8px 0 0">
      <span style="color:#fff;font-size:20px;font-weight:700">
        🗄️ FMW Database Connection Check Report
      </span>
      <span style="float:right;background:#0D47A1;color:#fff;padding:4px 12px;
                   border-radius:12px;font-size:13px">Run #{run_id}</span>
    </td>
  </tr>
  <tr>
    <td style="background:#E3F2FD;padding:12px 28px;border-bottom:1px solid #BBDEFB">
      <strong>Timestamp:</strong> {timestamp} &nbsp;|&nbsp;
      <strong>Total DBs:</strong> {total} &nbsp;|&nbsp;
      <strong style="color:#2E7D32">✅ Success: {success}</strong> &nbsp;|&nbsp;
      <strong style="color:#C62828">❌ Failed: {failed}</strong> &nbsp;|&nbsp;
      <strong style="color:{overall_color}">{overall_status}</strong>
    </td>
  </tr>
  <tr>
    <td style="padding:24px 28px">
      <table width="100%" cellpadding="0" cellspacing="0"
             style="border-collapse:collapse;font-size:13px">
        <thead>
          <tr style="background:#1565C0;color:#fff">
            <th style="padding:10px 12px;text-align:left">#</th>
            <th style="padding:10px 12px;text-align:left">Customer</th>
            <th style="padding:10px 12px;text-align:left">Env</th>
            <th style="padding:10px 12px;text-align:left">DB Name</th>
            <th style="padding:10px 12px;text-align:left">Host:Port</th>
            <th style="padding:10px 12px;text-align:left">Service/SID</th>
            <th style="padding:10px 12px;text-align:center">Status</th>
            <th style="padding:10px 12px;text-align:center">Duration</th>
            <th style="padding:10px 12px;text-align:left">Error</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
    </td>
  </tr>
  <tr>
    <td style="background:#F5F5F5;padding:14px 28px;border-top:1px solid #E0E0E0;
               text-align:center;font-size:12px;color:#9E9E9E;
               border-radius:0 0 8px 8px">
      FMW Database Check System &nbsp;|&nbsp; {timestamp}
    </td>
  </tr>
</table>
</body></html>"""
