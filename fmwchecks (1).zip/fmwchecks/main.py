"""
main.py
=======
FMWChecks — Entry Point

Run:
    py main.py
    python main.py

What it does:
  1. Reads connection details for all active FMW Oracle databases
     from the health_check MySQL schema (customers / environments / OracleDatabase).
  2. Attempts a connection to each Oracle DB.
  3. Saves results (SUCCESS / FAILED + error) to fmwchecks MySQL schema.
  4. Generates an Excel report (.xlsx) with all results.
  5. Emails the report to configured recipients (TO / CC / BCC).

Config lives in fmwchecks DB:
  fmw_config       → excel_path, log_path, oracle_timeout, oracle_dll_path
  fmw_email_config → smtp settings, TO, CC, BCC addresses

Only DB credentials live in config.py.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.logger   import setup_logging
from process_manager import ProcessManager


def main():
    # Initial logging to ./Logs before DB config is loaded
    logger = setup_logging()
    logger.info("FMWChecks — Starting...")

    try:
        pm = ProcessManager()
        pm.execute()
    except KeyboardInterrupt:
        logger.info("Stopped by user.")
    except Exception as exc:
        logger.critical(f"Fatal error: {exc}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
