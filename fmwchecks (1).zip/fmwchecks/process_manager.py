"""
process_manager.py
==================
Orchestrates the complete FMW Check run:
  Step 1 — Load config from fmwchecks DB (email, paths, timeouts)
  Step 2 — Setup logging to DB-configured log path
  Step 3 — Create run record in fmwchecks DB
  Step 4 — Run all FMW connection checks (read from health_check DB)
  Step 5 — Generate Excel report
  Step 6 — Send email (TO + CC + BCC from DB config)
  Step 7 — Update run record with final status

Config sources:
  health_check DB  → customers, environments, oracle databases (READ ONLY)
  fmwchecks DB     → email config, paths, oracle timeout, run results
"""
import logging
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.db_manager           import DBManager
from Common.email_manager        import EmailManager
from Common.logger               import setup_logging
from ExcelCreation.excel_manager import generate_excel
from fmw_checker                 import FMWChecker
from config                      import FMWCHECKS_DB
from config_loader               import load_config

logger = logging.getLogger("fmw.process")

IST_OFFSET = timedelta(hours=5, minutes=30)


def _now_ist_str() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


class ProcessManager:

    def __init__(self):
        self.run_id    = 0
        self.timestamp = _now_ist_str()
        self.app_cfg   = None     # loaded from DB in execute()

    # ── Step 1: Load config from fmwchecks DB ────────────────────────────────
    def _load_config(self):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                self.app_cfg = load_config(db)
            logger.info("App config loaded from fmwchecks DB")
        except Exception as exc:
            logger.warning(
                f"Could not load config from DB — using defaults: {exc}")
            from config_loader import AppConfig
            self.app_cfg = AppConfig()

    # ── Step 2: Create run record ─────────────────────────────────────────────
    def _create_run(self) -> int:
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                run_id = db.insert_get_id(
                    """INSERT INTO fmw_run
                       (status, started_at, created_at)
                       VALUES ('RUNNING', NOW(), NOW())""")
            logger.info(f"Run #{run_id} created in fmwchecks DB")
            return run_id
        except Exception as exc:
            logger.error(f"Cannot create run record: {exc}", exc_info=True)
            raise

    # ── Step 3: Update run record ─────────────────────────────────────────────
    def _update_run(self, status: str, total: int, success: int,
                    failed: int, excel_path: str,
                    email_status: str, email_error: str):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """UPDATE fmw_run SET
                         status        = %s,
                         total_dbs     = %s,
                         success_count = %s,
                         fail_count    = %s,
                         excel_path    = %s,
                         email_status  = %s,
                         email_error   = %s,
                         completed_at  = NOW()
                       WHERE id = %s""",
                    (status, total, success, failed,
                     excel_path, email_status, email_error,
                     self.run_id))
            logger.info(
                f"Run #{self.run_id} finalised | "
                f"status={status} total={total} "
                f"success={success} failed={failed}")
        except Exception as exc:
            logger.error(f"Cannot update run record: {exc}")

    # ── Step 4: Write step log ────────────────────────────────────────────────
    def _log_step(self, step: str, status: str, message: str = ""):
        logger.info(f"[STEP] {step} → {status}  {message}")
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_run_log
                       (run_id, step_name, status, message, logged_at)
                       VALUES (%s, %s, %s, %s, NOW())""",
                    (self.run_id, step, status,
                     message[:2000] if message else ""))
        except Exception as exc:
            logger.warning(f"Cannot write step log: {exc}")

    # ── Main execute ──────────────────────────────────────────────────────────
    def execute(self):
        """Full run orchestration."""

        logger.info("=" * 64)
        logger.info(f"FMW Database Check starting | {self.timestamp}")
        logger.info("=" * 64)

        # ── Load config first (before creating run record) ────────────────────
        self._load_config()

        # Re-configure logging to use DB-configured log path
        setup_logging(log_dir=self.app_cfg.log_path)

        # ── Create run record ─────────────────────────────────────────────────
        try:
            self.run_id    = self._create_run()
            self.timestamp = _now_ist_str()
        except Exception as exc:
            logger.critical(f"Cannot start run: {exc}")
            return

        excel_path   = None
        email_status = "SKIPPED"
        email_error  = None
        results      = []
        final_status = "FAILED"

        try:
            # ── Step: FMW Connection Checks ───────────────────────────────────
            self._log_step("FMW_CONNECTION_CHECK", "STARTED",
                           "Reading from health_check schema")
            checker = FMWChecker(run_id=self.run_id, app_cfg=self.app_cfg)
            results = checker.run_all()

            total   = len(results)
            success = sum(1 for r in results if r["connection_status"] == "SUCCESS")
            failed  = total - success

            self._log_step(
                "FMW_CONNECTION_CHECK", "COMPLETED",
                f"total={total} success={success} failed={failed}")

            # ── Step: Excel Generation ────────────────────────────────────────
            self._log_step("EXCEL_GENERATION", "STARTED",
                           f"output path: {self.app_cfg.excel_path}")
            try:
                excel_path = generate_excel(
                    results    = results,
                    run_id     = self.run_id,
                    timestamp  = self.timestamp,
                    excel_path = self.app_cfg.excel_path)
                self._log_step(
                    "EXCEL_GENERATION", "COMPLETED",
                    f"file={os.path.basename(excel_path)}")
            except Exception as exc:
                logger.error(f"Excel generation failed: {exc}", exc_info=True)
                self._log_step("EXCEL_GENERATION", "FAILED", str(exc)[:500])

            # ── Step: Send Email ──────────────────────────────────────────────
            self._log_step("EMAIL", "STARTED",
                           f"to={self.app_cfg.email.to_addrs} "
                           f"cc={self.app_cfg.email.cc_addrs}")
            try:
                mailer  = EmailManager(email_cfg=self.app_cfg.email)
                subject = (
                    f"✅ FMW Database Check — All Connected | Run #{self.run_id}"
                    if failed == 0 else
                    f"❌ FMW Database Check — {failed} Failed | Run #{self.run_id}"
                )
                html = EmailManager.build_html(
                    results   = results,
                    run_id    = self.run_id,
                    timestamp = self.timestamp,
                    total     = total,
                    success   = success,
                    failed    = failed)

                sent, err    = mailer.send_report(
                    subject    = subject,
                    html_body  = html,
                    excel_path = excel_path,
                    run_id     = self.run_id)

                email_status = "SENT" if sent else "FAILED"
                email_error  = err
                self._log_step("EMAIL", email_status, err or "")

            except Exception as exc:
                logger.error(f"Email step error: {exc}", exc_info=True)
                email_status = "FAILED"
                email_error  = str(exc)[:500]
                self._log_step("EMAIL", "FAILED", email_error)

            # ── Determine final status ────────────────────────────────────────
            if total == 0:
                final_status = "NO_DATA"
            elif failed == 0:
                final_status = "COMPLETED"
            elif success > 0:
                final_status = "PARTIAL"
            else:
                final_status = "FAILED"

        except Exception as exc:
            logger.critical(f"Unexpected error: {exc}", exc_info=True)
            final_status = "FAILED"
            self._log_step("PROCESS", "FAILED", str(exc)[:500])

        finally:
            suc = sum(1 for r in results if r.get("connection_status") == "SUCCESS")
            fal = sum(1 for r in results if r.get("connection_status") != "SUCCESS")
            self._update_run(
                status       = final_status,
                total        = len(results),
                success      = suc,
                failed       = fal,
                excel_path   = excel_path or "",
                email_status = email_status,
                email_error  = email_error or "")

            logger.info("=" * 64)
            logger.info(
                f"FMW Check DONE | run_id={self.run_id} | "
                f"status={final_status} | {_now_ist_str()}")
            logger.info("=" * 64)
