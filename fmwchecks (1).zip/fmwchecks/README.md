# FMWChecks — FMW Database Connection Checker

Checks Oracle FMW database connections for all active customers and environments,
generates an Excel report, and emails it to configured recipients.

---

## What it does

1. Reads all active FMW Oracle databases from the **health_check** MySQL schema
2. Attempts a TCP + Oracle connection to each database
3. Records SUCCESS or FAILED (with full error) per database
4. Generates a colour-coded Excel report
5. Emails the report with Excel attachment to TO / CC / BCC recipients
6. Saves all results and logs to the **fmwchecks** MySQL schema

Supports any number of customers and environments (VAL / PRD / DEV) — all active ones are checked automatically.

---

## Project structure

```
fmwchecks/
├── main.py                  ← entry point: py main.py
├── config.py                ← DB credentials only (HC_DB + FMWCHECKS_DB)
├── config_loader.py         ← reads runtime config from fmwchecks DB
├── process_manager.py       ← orchestrates all 6 steps
├── fmw_checker.py           ← connects to Oracle DBs, records results
├── schema.sql               ← creates fmwchecks DB + all tables + default config
├── requirements.txt
├── Common/
│   ├── db_manager.py        ← MySQL wrapper (HC_DB + FMWCHECKS_DB)
│   ├── email_manager.py     ← SMTP email with Excel attachment
│   ├── logger.py            ← file + console logging
│   └── crypto.py            ← AES-256 password decryption (same key as HC)
├── ExcelCreation/
│   └── excel_manager.py     ← openpyxl Excel report generator
├── Logs/                    ← log files written here (configurable)
├── Excel/                   ← Excel reports saved here (configurable)
└── oracledb_dll/            ← Oracle thick client DLLs (optional)
```

---

## Setup

### Step 1 — Install Python dependencies

```bash
pip install -r requirements.txt
```

### Step 2 — Create the fmwchecks schema

```bash
mysql -u root -p < schema.sql
```

This creates the `fmwchecks` database with these tables:
- `fmw_email_config` — SMTP settings and TO/CC/BCC recipients
- `fmw_config` — excel_path, log_path, oracle_timeout, oracle_dll_path
- `fmw_run` — one row per execution
- `fmw_connection_result` — one row per DB per run
- `fmw_run_log` — step audit trail per run

### Step 3 — Edit config.py (DB credentials only)

```python
HC_DB = {
    "host":     "your-mysql-host",
    "user":     "your-user",
    "password": "your-password",
    "database": "health_check",    # exact name of your HC schema
}

FMWCHECKS_DB = {
    "host":     "your-mysql-host",
    "user":     "your-user",
    "password": "your-password",
    "database": "fmwchecks",
}

ENC_KEY = "your-32-char-key-matching-HC-project"
```

### Step 4 — Configure email in fmwchecks DB

```sql
UPDATE fmwchecks.fmw_email_config
SET
  smtp_host  = 'smtp.yourcompany.com',
  smtp_port  = 587,
  smtp_user  = 'alerts@yourcompany.com',
  smtp_pass  = 'your-smtp-password',
  use_tls    = 1,
  from_addr  = 'alerts@yourcompany.com',
  to_addr    = 'person1@co.com,person2@co.com',  -- comma-separated
  cc_addr    = 'manager@co.com',                  -- optional
  bcc_addr   = ''                                 -- optional
WHERE is_active = 1;
```

### Step 5 — Configure paths in fmwchecks DB (optional)

Defaults work out of the box (./Excel and ./Logs relative to project folder).
To change:

```sql
-- Custom Excel output folder
UPDATE fmwchecks.fmw_config
SET config_value = 'C:\\Reports\\FMW'
WHERE config_key = 'excel_path';

-- Custom log folder
UPDATE fmwchecks.fmw_config
SET config_value = 'C:\\Logs\\FMW'
WHERE config_key = 'log_path';

-- Oracle connection timeout (seconds)
UPDATE fmwchecks.fmw_config
SET config_value = '20'
WHERE config_key = 'oracle_timeout';

-- Oracle thick client DLL path (leave empty for thin mode)
UPDATE fmwchecks.fmw_config
SET config_value = 'C:\\oracle\\instantclient'
WHERE config_key = 'oracle_dll_path';
```

### Step 6 — Run

```bash
py main.py
# or
python main.py
```

---

## What is read from health_check schema

**READ ONLY — nothing is written back to health_check.**

| Table | Columns used | Purpose |
|---|---|---|
| `Customers` | CustomerID, CustomerName, Status | Customer list |
| `Environments` | EnvID, CustomerID, ServerType, Status | VAL/PRD/DEV per customer |
| `Servers` | ServerID, EnvID, Host, Status | Server host per environment |
| `OracleDatabase` | dbid, ServerID, User, Password, OrdName, Port, DatabaseType, Status | FMW DB details |

Filter applied: `DatabaseType = 'FMW'` and all Status = 1 (active).

All active customers and all their active environments are checked automatically. No filter needed — add or remove customers in HC DB and this tool picks them up on next run.

---

## What is written to fmwchecks schema

| Table | Written |
|---|---|
| `fmw_run` | One row per execution — status, counts, excel path, email status |
| `fmw_connection_result` | One row per DB per run — host, port, status, error, duration |
| `fmw_run_log` | Step-by-step audit trail per run |

---

## Run outcomes

| Outcome | Meaning | Email subject |
|---|---|---|
| COMPLETED | All DBs connected | ✅ FMW Database Check — All Connected |
| PARTIAL | Some connected, some failed | ❌ FMW Database Check — N Failed |
| FAILED | All DBs failed | ❌ FMW Database Check — N Failed |
| NO_DATA | No active FMW DBs found in HC schema | ❌ with note |

---

## Multiple customers / environments

No configuration needed. The tool automatically:
- Checks ALL active customers in health_check.Customers
- Checks ALL active environments (VAL / PRD / DEV) per customer
- Checks ALL active FMW Oracle databases per environment

To limit to specific customers or envs, filter in health_check schema:
```sql
-- Temporarily disable a customer
UPDATE health_check.Customers SET Status=0 WHERE CustomerID=5;
```

---

## Adding email recipients

```sql
-- Add more TO addresses
UPDATE fmwchecks.fmw_email_config
SET to_addr = 'person1@co.com,person2@co.com,person3@co.com'
WHERE is_active = 1;

-- Add CC
UPDATE fmwchecks.fmw_email_config
SET cc_addr = 'mgr1@co.com,mgr2@co.com'
WHERE is_active = 1;
```

---

## Log file location

Logs are written to the path configured in `fmw_config.log_path` (default: `./Logs/`).
File name: `fmw_check_YYYYMMDD.log`
New file created each day.

---

## Useful queries

```sql
-- Latest run summary
SELECT id, status, total_dbs, success_count, fail_count,
       started_at, completed_at, email_status
FROM fmwchecks.fmw_run
ORDER BY id DESC LIMIT 5;

-- All results from latest run
SELECT customer_name, env_type, db_name,
       connection_status, duration_ms, error_message
FROM fmwchecks.fmw_connection_result
WHERE run_id = (SELECT MAX(id) FROM fmwchecks.fmw_run)
ORDER BY connection_status DESC, customer_name, env_type;

-- All failures across all runs
SELECT r.id run_id, r.started_at,
       cr.customer_name, cr.env_type, cr.db_name, cr.error_message
FROM fmwchecks.fmw_connection_result cr
JOIN fmwchecks.fmw_run r ON r.id = cr.run_id
WHERE cr.connection_status = 'FAILED'
ORDER BY r.started_at DESC;

-- Step log for latest run
SELECT step_name, status, message, logged_at
FROM fmwchecks.fmw_run_log
WHERE run_id = (SELECT MAX(id) FROM fmwchecks.fmw_run)
ORDER BY logged_at;
```

---

## Oracle thin vs thick client

- **Thin mode (default):** No DLLs needed. Leave `oracle_dll_path` empty in `fmw_config`.
- **Thick mode:** Copy Oracle Instant Client DLLs to `oracledb_dll/` folder (or any folder), then set `oracle_dll_path` in `fmw_config`.
