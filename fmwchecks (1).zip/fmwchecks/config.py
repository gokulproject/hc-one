"""
config.py
=========
Minimal configuration for FMWChecks project.

Only two things live here:
  1. HC_DB     — connection to HealthCheck MySQL schema (read-only: customers, oracle_databases)
  2. FMWCHECKS_DB — connection to fmwchecks MySQL schema (read/write: results, config, logs)

Everything else (email, paths, timeout) is read from the fmwchecks database:
  fmw_email_config table  → SMTP, TO, CC, BCC addresses
  fmw_config table        → excel_path, log_path, oracle_timeout, oracle_dll_path

AES encryption key for Oracle passwords stored in HealthCheck DB:
  Set via environment variable HC_ENC_KEY, or edit ENC_KEY below.
"""
import os

# ── HealthCheck DB (READ ONLY — source of customer/FMW DB details) ────────────
HC_DB = {
    "host":     os.getenv("HC_DB_HOST",     "localhost"),
    "port":     int(os.getenv("HC_DB_PORT", "3306")),
    "user":     os.getenv("HC_DB_USER",     "root"),
    "password": os.getenv("HC_DB_PASS",     "your_hc_password"),
    "database": os.getenv("HC_DB_NAME",     "health_check"),   # HC schema name
}

# ── FMWChecks DB (READ/WRITE — stores results, config, logs) ──────────────────
FMWCHECKS_DB = {
    "host":     os.getenv("FMW_DB_HOST",    "localhost"),
    "port":     int(os.getenv("FMW_DB_PORT","3306")),
    "user":     os.getenv("FMW_DB_USER",    "root"),
    "password": os.getenv("FMW_DB_PASS",    "your_fmw_password"),
    "database": os.getenv("FMW_DB_NAME",    "fmwchecks"),      # new schema
}

# ── AES Encryption Key (must match HealthCheck project key) ───────────────────
# Set via env: set HC_ENC_KEY=<your-32-char-key>
# Or edit directly (must be exactly 32 characters):
ENC_KEY = os.getenv("HC_ENC_KEY", "3cb950cf5dd21c4d4e3618ddf3f317b2")

# ── Project base directory (do not change) ────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
