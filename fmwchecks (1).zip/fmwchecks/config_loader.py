"""
config_loader.py
================
Loads all runtime configuration from fmwchecks database tables.
Called once at startup by ProcessManager before any checks run.

Sources:
  fmw_config        → excel_path, log_path, oracle_timeout, oracle_dll_path
  fmw_email_config  → smtp settings, to/cc/bcc addresses

Returns a plain dataclass (AppConfig) so the rest of the code
never touches the DB for config lookups.
"""
import logging
import os
from dataclasses import dataclass, field
from typing import List

logger = logging.getLogger("fmw.config")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _abs(path: str) -> str:
    """Convert relative path to absolute using project BASE_DIR."""
    if not path:
        return ""
    if os.path.isabs(path):
        return path
    return os.path.join(BASE_DIR, path)


@dataclass
class EmailConfig:
    smtp_host:  str = ""
    smtp_port:  int = 587
    smtp_user:  str = ""
    smtp_pass:  str = ""
    use_tls:    bool = True
    from_addr:  str = ""
    to_addrs:   List[str] = field(default_factory=list)   # parsed list
    cc_addrs:   List[str] = field(default_factory=list)
    bcc_addrs:  List[str] = field(default_factory=list)


@dataclass
class AppConfig:
    excel_path:      str = ""
    log_path:        str = ""
    oracle_timeout:  int = 15
    oracle_dll_path: str = ""
    email:           EmailConfig = field(default_factory=EmailConfig)


def _parse_addrs(raw: str) -> List[str]:
    """Split comma-separated email string into clean list."""
    if not raw:
        return []
    return [a.strip() for a in raw.split(",") if a.strip()]


def load_config(db) -> AppConfig:
    """
    Load AppConfig from fmwchecks DB.
    db: an open DBManager instance connected to fmwchecks schema.
    Returns AppConfig with sensible defaults if rows are missing.
    """
    cfg = AppConfig()

    # ── General config ────────────────────────────────────────────────────────
    try:
        rows = db.fetch_all("SELECT config_key, config_value FROM fmw_config")
        kv   = {r["config_key"]: r["config_value"] for r in rows}

        cfg.excel_path      = _abs(kv.get("excel_path",      "Excel"))
        cfg.log_path        = _abs(kv.get("log_path",        "Logs"))
        cfg.oracle_timeout  = int(kv.get("oracle_timeout",   "15"))
        cfg.oracle_dll_path = _abs(kv.get("oracle_dll_path", "oracledb_dll"))

        logger.debug(
            f"Config loaded | excel={cfg.excel_path} "
            f"log={cfg.log_path} timeout={cfg.oracle_timeout}s")
    except Exception as exc:
        logger.warning(f"Could not load fmw_config — using defaults: {exc}")
        cfg.excel_path      = _abs("Excel")
        cfg.log_path        = _abs("Logs")
        cfg.oracle_timeout  = 15
        cfg.oracle_dll_path = _abs("oracledb_dll")

    # ── Email config ──────────────────────────────────────────────────────────
    try:
        row = db.fetch_one(
            "SELECT * FROM fmw_email_config WHERE is_active=1 ORDER BY id LIMIT 1")
        if row:
            cfg.email = EmailConfig(
                smtp_host  = row.get("smtp_host",  ""),
                smtp_port  = int(row.get("smtp_port", 587)),
                smtp_user  = row.get("smtp_user",  ""),
                smtp_pass  = row.get("smtp_pass",  ""),
                use_tls    = bool(row.get("use_tls", 1)),
                from_addr  = row.get("from_addr",  ""),
                to_addrs   = _parse_addrs(row.get("to_addr",  "")),
                cc_addrs   = _parse_addrs(row.get("cc_addr",  "")),
                bcc_addrs  = _parse_addrs(row.get("bcc_addr", "")),
            )
            logger.debug(
                f"Email config loaded | smtp={cfg.email.smtp_host}:{cfg.email.smtp_port} "
                f"to={cfg.email.to_addrs} cc={cfg.email.cc_addrs}")
        else:
            logger.warning("No active email config found in fmw_email_config")
    except Exception as exc:
        logger.warning(f"Could not load fmw_email_config: {exc}")

    return cfg
