"""
ExcelCreation/excel_manager.py
==============================
Generate Excel report for FMW Database Check results.
Excel output path is read from AppConfig.excel_path
(loaded from fmwchecks.fmw_config table at runtime).

Columns:
  # | Customer | Environment | DB Name | Host | Port | Service/SID |
  Status | Duration (ms) | Error Details | Checked At
"""
import logging
import os
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger("fmw.excel")

# ── Colours ───────────────────────────────────────────────────────────────────
BLUE_DARK  = "1565C0"
BLUE_MED   = "0D47A1"
BLUE_LIGHT = "E3F2FD"
GREEN_BG   = "E8F5E9"
GREEN_BG2  = "F0FAF0"
RED_BG     = "FFEBEE"
RED_BG2    = "FFF5F5"
GREY_ROW   = "F9F9F9"
WHITE      = "FFFFFF"
GREEN_TEXT = "2E7D32"
RED_TEXT   = "C62828"
GREY_TEXT  = "9E9E9E"


def _side():
    return Side(style="thin", color="BDBDBD")


def _border():
    s = _side()
    return Border(left=s, right=s, top=s, bottom=s)


def generate_excel(results:    list,
                   run_id:     int,
                   timestamp:  str,
                   excel_path: str) -> str:
    """
    Generate Excel report and save to excel_path directory.
    excel_path: full directory path from AppConfig.excel_path
    Returns full path of saved .xlsx file.
    """
    os.makedirs(excel_path, exist_ok=True)

    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"FMW_Check_Run{run_id}_{date_str}.xlsx"
    filepath = os.path.join(excel_path, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = "FMW Connection Results"

    total   = len(results)
    success = sum(1 for r in results if r["connection_status"] == "SUCCESS")
    failed  = total - success

    # ── Row 1: Title ──────────────────────────────────────────────────────────
    ws.merge_cells("A1:K1")
    tc            = ws["A1"]
    tc.value      = f"FMW Database Connection Check Report  |  Run #{run_id}  |  {timestamp}"
    tc.font       = Font(name="Calibri", size=14, bold=True, color="FFFFFF")
    tc.fill       = PatternFill("solid", fgColor=BLUE_DARK)
    tc.alignment  = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # ── Row 2: Summary ────────────────────────────────────────────────────────
    ws.merge_cells("A2:K2")
    sc            = ws["A2"]
    sc.value      = (f"Total: {total}   |   ✅ Success: {success}   |   ❌ Failed: {failed}"
                     + ("   |   ALL CONNECTED" if failed == 0 else f"   |   {failed} FAILED"))
    sc.font       = Font(name="Calibri", size=11, bold=True,
                         color=GREEN_TEXT if failed == 0 else RED_TEXT)
    sc.fill       = PatternFill("solid", fgColor=BLUE_LIGHT)
    sc.alignment  = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # ── Row 3: Headers ────────────────────────────────────────────────────────
    headers    = ["#", "Customer", "Environment", "DB Name",
                  "Host", "Port", "Service/SID",
                  "Status", "Duration (ms)", "Error Details", "Checked At (IST)"]
    col_widths = [5,    22,         14,            22,
                  26,    7,          18,
                  12,    14,         46,             22]

    for col, (h, w) in enumerate(zip(headers, col_widths), 1):
        cell           = ws.cell(row=3, column=col, value=h)
        cell.font      = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill      = PatternFill("solid", fgColor=BLUE_MED)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border    = _border()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[3].height = 20

    # ── Data rows ─────────────────────────────────────────────────────────────
    from datetime import timedelta
    IST_OFFSET = timedelta(hours=5, minutes=30)

    for idx, r in enumerate(results, 1):
        row_num = idx + 3
        ok      = r["connection_status"] == "SUCCESS"

        # Alternate shading: even rows slightly darker
        if ok:
            bg = GREEN_BG if idx % 2 == 0 else GREEN_BG2
        else:
            bg = RED_BG  if idx % 2 == 0 else RED_BG2

        # Checked at — convert UTC to IST for display
        checked_raw = r.get("checked_at")
        if checked_raw:
            checked_ist = checked_raw + IST_OFFSET
            checked_str = checked_ist.strftime("%d-%b-%Y %I:%M:%S %p IST")
        else:
            checked_str = ""

        values = [
            idx,
            r.get("customer_name", ""),
            r.get("env_type",      ""),
            r.get("db_name",       ""),
            r.get("db_host",       ""),
            r.get("db_port",       ""),
            r.get("db_service",    ""),
            "SUCCESS" if ok else "FAILED",
            r.get("duration_ms",   0),
            r.get("error_message", "") if not ok else "",
            checked_str,
        ]

        for col, val in enumerate(values, 1):
            cell           = ws.cell(row=row_num, column=col, value=val)
            cell.font      = Font(name="Calibri", size=10)
            cell.fill      = PatternFill("solid", fgColor=bg)
            cell.border    = _border()
            cell.alignment = Alignment(vertical="center", wrap_text=True)

            # Status column — bold coloured text
            if col == 8:
                cell.font      = Font(name="Calibri", size=10, bold=True,
                                      color=GREEN_TEXT if ok else RED_TEXT)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Duration — right-aligned
            if col == 9:
                cell.alignment = Alignment(horizontal="right", vertical="center")

            # Error — red italic
            if col == 10 and not ok:
                cell.font = Font(name="Calibri", size=9, italic=True, color=RED_TEXT)

        ws.row_dimensions[row_num].height = 18

    # ── Freeze rows 1–3 so header stays visible while scrolling ──────────────
    ws.freeze_panes = "A4"

    # ── Auto-filter on header row ─────────────────────────────────────────────
    ws.auto_filter.ref = f"A3:K{3 + total}"

    wb.save(filepath)
    logger.info(f"Excel saved: {filepath}")
    return filepath
