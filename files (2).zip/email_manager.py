"""
Common/email_manager.py
=======================
Send DB connection check report email with HTML body and Excel attachment.
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

log = logging.getLogger("checker.email")


class EmailManager:

    def __init__(self, email_cfg):
        self.cfg = email_cfg

    # ── Send ─────────────────────────────────────────────────────────────────

    def send_report(self, subject, html_body, excel_path=None, run_id=0):
        """Send email with HTML body and Excel attachment.
        Returns (success: bool, error_msg: str|None).
        """
        if not self.cfg.to_addrs:
            log.warning("  No TO address configured — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(self.cfg.to_addrs)
            if self.cfg.cc_addrs:
                msg["Cc"]  = ", ".join(self.cfg.cc_addrs)

            # HTML body
            msg.attach(MIMEText(html_body, "html", "utf-8"))

            # Excel attachment
            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)

            all_to = self.cfg.to_addrs + self.cfg.cc_addrs + self.cfg.bcc_addrs
            with smtplib.SMTP(self.cfg.smtp_host, self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(self.cfg.from_addr, all_to, msg.as_string())

            log.info(f"  Email sent  |  run_id={run_id}  |  to={self.cfg.to_addrs}")
            return True, None

        except Exception as e:
            log.error(f"  Email failed: {e}")
            return False, str(e)[:500]

    # ── Subject ──────────────────────────────────────────────────────────────

    @staticmethod
    def build_subject(results, run_id, db_label="FMW"):
        customers = list(dict.fromkeys(
            r.get("customer_name", "") for r in results if r.get("customer_name")))
        cust_str = ", ".join(customers) if customers else "All Customers"
        return f"{db_label} DB Connection Check — {cust_str} — Run #{run_id}"

    # ── HTML body ─────────────────────────────────────────────────────────────

    @staticmethod
    def build_body(results, run_id, started, ended,
                   total, success, failed, skipped,
                   tcp_err=0, pwd_err=0, unk_err=0, db_label="FMW"):
        """
        Build a short, simple HTML email body:
        Line 1 — status summary (counts)
        Line 2 — overall result line
        Plus Run ID and Date/Time.
        Full details are in the attached Excel report.
        """

        if total == 0:
            result_color = "#856404"
            result_text  = "No active environments or databases were found for this run."
        elif failed == 0 and skipped == 0:
            result_color = "#155724"
            result_text  = "All database connections were successful."
        elif success == 0:
            result_color = "#721c24"
            result_text  = "No connections were successful. Please review the attached report urgently."
        else:
            result_color = "#856404"
            result_text  = "Some connections failed or were skipped. Please review the attached report."

        html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Calibri,Arial,sans-serif;font-size:14px;color:#222;
             line-height:1.6;max-width:680px;margin:0;padding:24px;">

  <p style="margin:0 0 14px 0;">Hi Team,</p>

  <p style="margin:0 0 4px 0;">
    Total: {total} &nbsp;|&nbsp; Connected: {success} &nbsp;|&nbsp;
    Not Connected: {failed} &nbsp;|&nbsp; Skipped: {skipped}
  </p>
  <p style="margin:0 0 14px 0;font-weight:600;color:{result_color};">
    {result_text}
  </p>

  <p style="margin:0 0 4px 0;color:#555;">
    Run ID: <strong>#{run_id}</strong> &nbsp;|&nbsp; Date &amp; Time: <strong>{started}</strong>
  </p>

  <p style="margin:18px 0 0 0;">
    Please refer to the attached {db_label} Excel report for full details.
  </p>

  <p style="margin:24px 0 0 0;">
    Thanks &amp; Regards,<br>
    <strong>RPA Team</strong>
  </p>

</body>
</html>"""

        return html
