import os
import logging
import sys
from django.apps import AppConfig

logger = logging.getLogger("hc.scheduler")

# Management commands that must NEVER start the scheduler thread.
# qcluster is the critical one — it is a long-running process that loads
# all apps, so without this guard the scheduler thread starts inside the
# qcluster process and appears in its output.
_SKIP_COMMANDS = {
    "qcluster",        # Django Q worker  ← the main reason for this guard
    "qmonitor",        # Django Q monitor
    "qinfo",           # Django Q info
    "migrate",
    "makemigrations",
    "shell",
    "shell_plus",
    "collectstatic",
    "check",
    "test",
    "createsuperuser",
    "changepassword",
    "dumpdata",
    "loaddata",
    "dbshell",
    "inspectdb",
    "showmigrations",
    "sqlmigrate",
}


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """
        Start the background HC scheduler thread ONLY when running as a
        web server (runserver / gunicorn / uvicorn / waitress).

        Explicitly blocked:
        - qcluster / qmonitor / qinfo  → Django Q worker processes
        - migrate, shell, test, etc.   → management commands
        - runserver reloader parent    → only the child (RUN_MAIN=true) starts it

        The HC scheduler is 0% connected to Django Q or qcluster.
        qcluster runs your project-level tasks only.
        HC schedules are stored in the `schedules` table and triggered
        exclusively by the hc_scheduler daemon thread inside the web process.
        """
        argv = sys.argv

        # Detect which management command is running
        # sys.argv[0] is manage.py, sys.argv[1] is the command name
        if len(argv) >= 2:
            command = argv[1].lower()
            if command in _SKIP_COMMANDS:
                logger.debug(
                    f"[HealthcheckConfig.ready] Skipping scheduler start "
                    f"— running under '{command}'")
                return

        # Also block via env var (for custom launchers / CI)
        if os.environ.get("HC_SKIP_SCHEDULER") == "1":
            return

        # Dev runserver: skip the reloader parent, only start in the child
        is_runserver = len(argv) >= 2 and argv[1] == "runserver"
        if is_runserver and os.environ.get("RUN_MAIN") != "true":
            return

        # All clear — start the scheduler thread
        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
            logger.info(
                "[HealthcheckConfig.ready] HC scheduler thread started "
                "(web process only, independent of qcluster).")
        except Exception as exc:
            logger.warning(
                f"[HealthcheckConfig.ready] Could not start scheduler: {exc}")
