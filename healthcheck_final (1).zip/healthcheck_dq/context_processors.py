# def ectd_app_context(request):
    # app_slug = 'ectd'
    # app_slug='healthchekapp'
    # return {
        # 'app_slug': app_slug,
        # 'target_app': {'slug': app_slug},
    # }
    
# def healthcheck_context(request):
    # app_slug='healthcheck'
    # return {
        # 'app_slug': app_slug,
        # 'target_app': {'slug': app_slug},
    # }
'''   



def healthcheck_context(request):
    """
    Global HealthCheck context
    Available in all templates
    """
    app_slug = "healthcheck"
    user = request.user

    return {
        # App identity
        "app_slug": app_slug,
        "target_app": {"slug": app_slug},

        # ✅ Admin flags (used by navbar & templates)
        "is_platform_admin": (
            user.is_authenticated and user.is_staff
        ),
        "is_healthcheck_admin": (
            user.is_authenticated and is_healthcheck_admin(user)
        ),
    }
    '''
# ✅ Import from views.py (same app)
from .views import is_healthcheck_admin


def healthcheck_context(request):
    user = request.user
    app_slug = "healthcheck"

    return {
        "app_slug": app_slug,
        "target_app": {"slug": app_slug},

        # ✅ HealthCheck admin (from views.py)
        "is_healthcheck_admin": (
            is_healthcheck_admin(user)
            if user.is_authenticated else False
        ),

        # ✅ Platform admin (old logic preserved)
        "is_platform_admin": getattr(user, "is_platform_admin", False),
    }