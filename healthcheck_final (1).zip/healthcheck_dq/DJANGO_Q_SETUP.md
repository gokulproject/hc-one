# Healthcheck App — Setup Guide (v12, Self-contained)

## How it works

The healthcheck scheduler runs **entirely inside your Django process** as a
background daemon thread.  No qcluster, no Celery, no Redis, no external
worker of any kind is needed.

```
Django process (runserver / gunicorn / uvicorn / waitress)
│
├── Main thread          ← HTTP as normal
│
└── hc_scheduler (daemon thread)   ← starts automatically in apps.py
        │
        every 60 s:
        ├── reads your `schedules` table
        ├── fires any schedule whose next_run_at ≤ now
        │       └── spawns hc_run_<id> thread → RunLauncher → checks run
        ├── polls rerun_queue for failed-run retries
        └── every 10 min: recovers stuck runs
```

---

## 1. Install dependencies

```bash
pip install croniter        # cron expression parsing
# django-q2 is NOT needed — do NOT install it
```

---

## 2. settings.py — minimum required block

```python
INSTALLED_APPS = [
    # ...your other apps...
    'healthcheck',          # ← add this
    # do NOT add 'django_q' — it is not used
]

# Healthcheck database connection
DATABASES = {
    'default': { ... },         # your normal Django DB
    'healthcheck_db': {
        'ENGINE':   'django.db.backends.mysql',
        'NAME':     'your_hc_db_name',
        'USER':     'your_hc_user',
        'PASSWORD': 'your_hc_password',
        'HOST':     'your_hc_host',
        'PORT':     '3306',
    },
}

# Healthcheck file output (Excel reports, run logs)
HEALTHCHECK_LOG_PATH = '/path/to/hc/logs'        # optional
HEALTHCHECK_REPORT_PATH = '/path/to/hc/reports'  # optional
```

That is ALL. No Q_CLUSTER block. No broker config.

---

## 3. If you previously had Django Q installed

Remove these from settings.py:

```python
# DELETE these if present:
# 'django_q'  ← remove from INSTALLED_APPS
# Q_CLUSTER = { ... }  ← delete the whole block
```

Uninstall the package (optional but clean):

```bash
pip uninstall django-q2 -y
```

If Django Q migrations were run, the `django_q_*` tables remain in your DB
harmlessly — the healthcheck app never touches them.

---

## 4. Run migrations

```bash
python manage.py migrate
```

---

## 5. Start Django — that's it

```bash
python manage.py runserver
# or
gunicorn your_project.wsgi
# or
uvicorn your_project.asgi:application
```

The scheduler thread starts automatically. You will see in the logs:

```
[Sched] Started | tz=Asia/Kolkata | IST=12-May-2026 10:00:00 AM
[Sched] Loaded 3 active schedule(s)
```

No second terminal. No `python manage.py qcluster`.

---

## 6. Verify it is running

Open the Django admin → Healthcheck → Scheduler Status.
The "Scheduler Running" badge should be green.

Or check logs — every 60 s you will see:

```
[Sched] Tick #N at 2026-05-12 04:30:00
[Sched] Loaded 3 active schedule(s)
```

---

## 7. Admin: Run Now

The "Run Now" button in the Scheduler admin fires a run immediately in a
background thread — no qcluster needed.

---

## Scheduler behaviour

| Situation | What happens |
|-----------|-------------|
| Django restarts | Scheduler thread restarts automatically in apps.py |
| A run crashes | Stuck-run recovery marks it FAILED within 10 min |
| A run fails | Rerun queue retries it after `rerun_interval_hours` |
| You add a new schedule in admin | Picked up within 5 min (next cache refresh) |
| Django Q is installed in the project | Ignored — healthcheck never calls it |

