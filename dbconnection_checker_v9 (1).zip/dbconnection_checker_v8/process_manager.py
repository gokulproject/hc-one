"""
process_manager.py
==================
Orchestrates the Oracle DB connection check run.

Steps:
  1  Process Start
  2  Connect databases + load config
  3  Load customers
  4  Load environments
  5  Map DB server
  6  Oracle DB connection check
  7  Capture results
  8  Generate Excel
  9  Send email
  10 Process end

Manual stop (Ctrl+C) is caught — run is marked FAILED with end time captured.
"""
import logging
import os
import signal
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.db_manager           import DBManager
from Common.email_manager        import EmailManager
from Common.logger               import setup_logging, get_log_file_path
from ExcelCreation.excel_manager import generate_excel
from checker                     import Checker
from config                      import FMWCHECKS_DB
from config_loader               import load_config

log = logging.getLogger("checker.process")
IST = timedelta(hours=5, minutes=30)


def _ist(dt: datetime = None) -> str:
    dt = dt or datetime.utcnow()
    return (dt + IST).strftime("%d-%b-%Y %I:%M:%S %p IST")


class ProcessManager:

    def __init__(self):
        self.run_id   = 0
        self.app_cfg  = None
        self._started = datetime.utcnow()

    # ─────────────────────────────────────────────────────────────────────────
    # DB helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _create_run(self, db_type_label: str) -> int:
        with DBManager(cfg=FMWCHECKS_DB) as db:
            run_id = db.insert_get_id(
                "INSERT INTO process_run "
                "(status, db_type, execution_start_at, created_at) "
                "VALUES ('RUNNING', %s, NOW(), NOW())",
                (db_type_label,))
        log.info(f"Run #{run_id} created  |  db_type = {db_type_label}")
        return run_id

    def _finish_run(self, status, total, success, failed, skipped,
                    excel_path, log_file, email_status, email_error):
        """Update run record with final status, end time and all counts."""
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """UPDATE process_run SET
                           status             = %s,
                           execution_end_at   = NOW(),
                           total_envs         = %s,
                           success_count      = %s,
                           fail_count         = %s,
                           skipped_count      = %s,
                           excel_path         = %s,
                           log_file           = %s,
                           email_sent_status  = %s,
                           email_sent_error   = %s
                       WHERE id = %s""",
                    (status, total, success, failed, skipped,
                     excel_path or "", log_file or "",
                     email_status, email_error or "",
                     self.run_id))
        except Exception as e:
            log.error(f"Could not update run record: {e}")

    def _log_step(self, step_no, step_name, status,
                  message="", customer="", env_type=""):
        parts = [f"[Step {step_no}] {step_name} — {status}"]
        if message:  parts.append(message)
        if customer: parts.append(f"customer={customer}")
        if env_type: parts.append(f"env={env_type}")
        log.info("  |  ".join(parts))
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO process_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     (message or "")[:2000],
                     (customer or "")[:255],
                     (env_type or "")[:50]))
        except Exception as e:
            log.warning(f"Step log write failed: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # Main
    # ─────────────────────────────────────────────────────────────────────────

    def execute(self):

        # ── Step 1: Start ─────────────────────────────────────────────────────
        log.info("=" * 60)
        log.info(f"  Oracle DB Connection Checker  —  Started at {_ist()}")
        log.info("=" * 60)

        # ── Step 2: Connect databases + load config ───────────────────────────
        log.info("")
        log.info("[Step 2]  Connecting to databases ...")

        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                self.app_cfg = load_config(db)
            log.info("          dbconnection_checker DB  —  OK")
        except Exception as e:
            log.critical(f"          Cannot connect to dbconnection_checker DB: {e}")
            return

        try:
            from config import HC_DB
            with DBManager(cfg=HC_DB) as db:
                db.fetch_one("SELECT 1")
            log.info("          health_check DB (read-only)  —  OK")
        except Exception as e:
            log.critical(f"          Cannot connect to health_check DB: {e}")
            return

        db_type_label = ",".join(self.app_cfg.config_dbtype)

        try:
            self.run_id  = self._create_run(db_type_label)
            self._started = datetime.utcnow()
        except Exception as e:
            log.critical(f"          Cannot create run record: {e}")
            return

        # Switch to per-run log file
        setup_logging(log_dir=self.app_cfg.log_path, run_id=self.run_id)
        log_file = get_log_file_path(self.app_cfg.log_path, run_id=self.run_id)
        log.info(f"          Log file   : {log_file}")
        log.info(f"          DB type    : {db_type_label}")
        log.info(f"          Customers  : {'ALL' if not self.app_cfg.config_customers else self.app_cfg.config_customers}")
        log.info(f"          Envs       : {'ALL' if not self.app_cfg.config_envs else self.app_cfg.config_envs}")
        log.info(f"          Oracle DLL : {self.app_cfg.oracle_dll_path or '(not set — thin mode)'}")

        self._log_step(2, "CONNECT_DATABASES", "COMPLETED",
                       f"health_check (RO) + dbconnection_checker ready  |  db_type={db_type_label}")

        # Shared state for finally block
        excel_path   = None
        email_status = "SKIPPED"
        email_error  = None
        results      = []
        final_status = "FAILED"

        try:
            # ── Steps 3-7: Check loop ─────────────────────────────────────────
            log.info("")
            checker = Checker(run_id=self.run_id, app_cfg=self.app_cfg)
            results = checker.run_all()
            db_label = checker.db_label

            total   = len(results)
            success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
            failed  = sum(1 for r in results if r.get("connection_status") == "FAILED")
            skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")
            tcp_err = sum(1 for r in results if r.get("error_type") == "TCP_TIMEOUT")
            pwd_err = sum(1 for r in results if r.get("error_type") == "PASSWORD")
            unk_err = sum(1 for r in results
                          if r.get("error_type") == "UNKNOWN"
                          and r.get("connection_status") == "FAILED")

            log.info("")
            log.info(f"[Step 7]  Results captured")
            log.info(f"          Total        : {total}")
            log.info(f"          Connected    : {success}")
            log.info(f"          Not connected: {failed}")
            log.info(f"          Skipped      : {skipped}")
            if failed:
                log.info(f"          Error types  — TCP timeout: {tcp_err}  |  Password: {pwd_err}  |  Unknown: {unk_err}")

            self._log_step(7, "CAPTURE_RESULTS", "COMPLETED",
                           f"total={total} connected={success} "
                           f"not_connected={failed} skipped={skipped}")

            # ── Step 8: Excel ─────────────────────────────────────────────────
            log.info("")
            log.info("[Step 8]  Generating Excel report ...")
            try:
                excel_path = generate_excel(
                    results    = results,
                    run_id     = self.run_id,
                    timestamp  = _ist(self._started),
                    excel_path = self.app_cfg.excel_path,
                    db_label   = db_label)
                log.info(f"          Saved : {excel_path}")
                self._log_step(8, "EXCEL_GENERATION", "COMPLETED",
                               f"file={os.path.basename(excel_path)}")
            except Exception as e:
                log.error(f"          Excel generation failed: {e}", exc_info=True)
                self._log_step(8, "EXCEL_GENERATION", "FAILED", str(e)[:500])

            # ── Step 9: Email ─────────────────────────────────────────────────
            log.info("")
            log.info("[Step 9]  Sending email ...")
            try:
                mailer  = EmailManager(email_cfg=self.app_cfg.email)
                subject = EmailManager.build_subject(results, self.run_id, db_label)
                body    = EmailManager.build_body(
                    results   = results,
                    run_id    = self.run_id,
                    started   = _ist(self._started),
                    ended     = _ist(),
                    total     = total,
                    success   = success,
                    failed    = failed,
                    skipped   = skipped,
                    tcp_err   = tcp_err,
                    pwd_err   = pwd_err,
                    unk_err   = unk_err,
                    db_label  = db_label)
                sent, err    = mailer.send_report(subject, body, excel_path, self.run_id)
                email_status = "SENT" if sent else "FAILED"
                email_error  = err
                if sent:
                    log.info(f"          Sent to : {self.app_cfg.email.to_addrs}")
                else:
                    log.error(f"          Email failed : {err}")
                self._log_step(9, "EMAIL", email_status,
                               f"to={self.app_cfg.email.to_addrs}"
                               + (f"  |  error={err}" if err else ""))
            except Exception as e:
                log.error(f"          Email error: {e}", exc_info=True)
                email_status = "FAILED"
                email_error  = str(e)[:500]
                self._log_step(9, "EMAIL", "FAILED", email_error)

            # Determine final status
            if total == 0:
                final_status = "NO_DATA"
            elif success == total:
                final_status = "COMPLETED"
            elif success == 0:
                final_status = "FAILED" if failed > 0 else "SKIPPED"
            else:
                final_status = "PARTIAL"

        except KeyboardInterrupt:
            # Manual stop — mark FAILED, capture end time
            final_status = "FAILED"
            log.warning("")
            log.warning("  Stopped manually (Ctrl+C)  —  run marked FAILED")
            self._log_step(0, "PROCESS", "FAILED", "Stopped manually by user (KeyboardInterrupt)")
            raise   # re-raise so main() can exit cleanly

        except Exception as e:
            final_status = "FAILED"
            log.critical(f"  Unexpected error: {e}", exc_info=True)
            self._log_step(0, "PROCESS", "FAILED", str(e)[:500])

        finally:
            suc = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
            fal = sum(1 for r in results if r.get("connection_status") == "FAILED")
            skp = sum(1 for r in results if r.get("connection_status") == "SKIPPED")

            self._finish_run(
                status       = final_status,
                total        = len(results),
                success      = suc,
                failed       = fal,
                skipped      = skp,
                excel_path   = excel_path,
                log_file     = log_file,
                email_status = email_status,
                email_error  = email_error)

            # ── Step 10: Done ─────────────────────────────────────────────────
            log.info("")
            log.info("=" * 60)
            log.info(f"  Run #{self.run_id}  —  {final_status}")
            log.info(f"  Started  : {_ist(self._started)}")
            log.info(f"  Ended    : {_ist()}")
            log.info(f"  Total    : {len(results)}  |  Connected: {suc}  |  Not connected: {fal}  |  Skipped: {skp}")
            log.info(f"  Excel    : {excel_path or 'N/A'}")
            log.info(f"  Email    : {email_status}")
            log.info("=" * 60)
            self._log_step(10, "PROCESS_COMPLETED", final_status,
                           f"total={len(results)} connected={suc} "
                           f"not_connected={fal} skipped={skp}  |  "
                           f"email={email_status}  |  log={log_file}")
