"""
Common/logger.py — Logging setup for DB Connection Checker.

Log format:
  2026-06-15 10:30:00  INFO     [Step 2]  Connect databases — COMPLETED
  2026-06-15 10:30:01  INFO     Customer: Acme Corp (ID=3)
  2026-06-15 10:30:02  ERROR    NOT CONNECTED — ORA-12170: TNS timeout

Two phases:
  Startup  → setup_logging()           → Logs/checker_YYYYMMDD.log
  Per-run  → setup_logging(run_id=N)   → Logs/checker_run_N_YYYYMMDD.log
"""
import logging
import os
from datetime import datetime

LOG_FORMAT      = "%(asctime)s  %(levelname)-8s %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _filename(run_id=None) -> str:
    date = datetime.now().strftime("%Y%m%d")
    return f"checker_run_{run_id}_{date}.log" if run_id else f"checker_{date}.log"


def setup_logging(log_dir: str = None, run_id: int = None) -> logging.Logger:
    """
    Configure logging. Call at startup, then again once run_id is known.
    Switches the file handler to a per-run file on the second call.
    """
    if not log_dir:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Logs")

    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, _filename(run_id))
    fmt      = logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # Replace any existing file handler
    for h in list(root.handlers):
        if isinstance(h, logging.FileHandler):
            root.removeHandler(h)
            h.close()

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    root.addHandler(fh)

    # Console — INFO+ — added once only
    if not any(isinstance(h, logging.StreamHandler)
               and not isinstance(h, logging.FileHandler)
               for h in root.handlers):
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(fmt)
        root.addHandler(ch)

    return logging.getLogger("checker")


def get_log_file_path(log_dir: str, run_id: int = None) -> str:
    if not log_dir:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Logs")
    return os.path.join(log_dir, _filename(run_id))
