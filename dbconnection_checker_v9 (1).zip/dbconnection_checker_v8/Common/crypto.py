"""
Common/crypto.py
================
AES-256-CBC password decryption.
Same algorithm as HealthCheck project — uses same key.
"""
import base64
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ENC_KEY


def _get_key() -> bytes:
    key = ENC_KEY.encode("utf-8") if isinstance(ENC_KEY, str) else ENC_KEY
    if len(key) != 32:
        raise ValueError(f"ENC_KEY must be 32 bytes. Got {len(key)}.")
    return key


def decrypt_password(ciphertext: str) -> str:
    """Decrypt AES-256-CBC base64-encoded password from HC DB."""
    if not ciphertext:
        return ""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        key    = _get_key()
        raw    = base64.b64decode(ciphertext)
        iv     = raw[:16]
        ct     = raw[16:]
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv),
                        backend=default_backend())
        dec    = cipher.decryptor()
        padded = dec.update(ct) + dec.finalize()
        pad_len = padded[-1]
        return padded[:-pad_len].decode("utf-8")
    except Exception:
        # If decryption fails assume plain text
        return ciphertext


def is_encrypted(value: str) -> bool:
    try:
        decoded = base64.b64decode(value)
        return len(decoded) >= 32
    except Exception:
        return False
