"""
Common/email_manager.py — Send DB connection check report email.
Plain-text body, Excel attachment.
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

log = logging.getLogger("checker.email")


class EmailManager:

    def __init__(self, email_cfg):
        self.cfg = email_cfg

    def send_report(self, subject, body, excel_path=None, run_id=0):
        """Send email with Excel attachment. Returns (success, error_msg)."""
        if not self.cfg.to_addrs:
            log.warning("  No TO address configured — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(self.cfg.to_addrs)
            if self.cfg.cc_addrs:
                msg["Cc"]  = ", ".join(self.cfg.cc_addrs)

            msg.attach(MIMEText(body, "plain", "utf-8"))

            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)

            all_to = self.cfg.to_addrs + self.cfg.cc_addrs + self.cfg.bcc_addrs
            with smtplib.SMTP(self.cfg.smtp_host, self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(self.cfg.from_addr, all_to, msg.as_string())

            log.info(f"  Email sent  |  run_id={run_id}  |  to={self.cfg.to_addrs}")
            return True, None

        except Exception as e:
            log.error(f"  Email failed: {e}")
            return False, str(e)[:500]

    @staticmethod
    def build_subject(results, run_id, db_label="FMW"):
        customers = list(dict.fromkeys(
            r.get("customer_name", "") for r in results if r.get("customer_name")))
        cust_str = ", ".join(customers) if customers else "All Customers"
        return f"{db_label} DB Connection Check — {cust_str} — Run #{run_id}"

    @staticmethod
    def build_body(results, run_id, started, ended,
                   total, success, failed, skipped,
                   tcp_err=0, pwd_err=0, unk_err=0, db_label="FMW"):

        if total == 0:
            overall = "No data — no active environments or databases found."
        elif failed == 0 and skipped == 0:
            overall = "All connections successful."
        elif success == 0:
            overall = "No connections were successful. Please review the report urgently."
        else:
            overall = "Some connections failed or were skipped. Please review the report."

        lines = [
            f"Hi Team,",
            f"",
            f"Please find the {db_label} Oracle DB connection check report attached.",
            f"",
            f"Run ID       : {run_id}",
            f"Started      : {started}",
            f"Ended        : {ended}",
            f"",
            f"Results",
            f"-------",
            f"Total        : {total}",
            f"Connected    : {success}",
            f"Not Connected: {failed}",
            f"Skipped      : {skipped}",
        ]

        if failed:
            lines += [
                f"",
                f"Error Breakdown",
                f"---------------",
                f"TCP Timeout  : {tcp_err}",
                f"Password     : {pwd_err}",
                f"Unknown      : {unk_err}",
            ]

        lines += [
            f"",
            f"Overall      : {overall}",
            f"",
            f"Thanks & Regards,",
            f"RPA Team",
        ]

        return "\n".join(lines)
