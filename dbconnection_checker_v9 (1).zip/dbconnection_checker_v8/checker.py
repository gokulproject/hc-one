"""
checker.py — Oracle DB connection check logic.

Flow per customer/environment:
  1. Load customer from health_check.Customers (read-only)
  2. Load environments from health_check.Environments (read-only)
  3. Map DB server from health_check.Servers (ServerName='DB Server')
  4. Load Oracle DBs from health_check.OracleDatabase (filtered by db_type)
  5. Connect using oracledb — thick if oracle_dll_path set, else thin
  6. Classify any error: TCP_TIMEOUT | PASSWORD | UNKNOWN
  7. Write one row per Oracle DB to process_db_connection_result

No WMI. No connection timeout configured (OS/driver default applies).
"""
import logging
import os
import sys
import time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.crypto     import decrypt_password, is_encrypted
from Common.db_manager import DBManager
from config            import HC_DB, FMWCHECKS_DB

log = logging.getLogger("checker.checker")

ALL_ENV_TYPES = ["DEV", "VAL", "PRD"]
IST           = timedelta(hours=5, minutes=30)

# ── Error classification ──────────────────────────────────────────────────────
_TCP_KEYWORDS = [
    "ora-12170", "ora-12541", "ora-12543", "ora-12547",
    "tns-12535", "tns-12606", "tns-12609",
    "connection timed out", "timed out", "timeout",
    "connect timeout", "tcp", "network adapter",
    "no listener", "unable to connect to oracle",
]
_PWD_KEYWORDS = [
    "ora-28001", "ora-28002", "ora-28003", "ora-28000", "ora-28009",
    "ora-01017", "ora-01005",
    "invalid username/password", "logon denied",
    "password expired", "password has expired", "account is locked",
]

ERROR_TCP = "TCP_TIMEOUT"
ERROR_PWD = "PASSWORD"
ERROR_UNK = "UNKNOWN"


def classify_error(msg: str) -> str:
    if not msg:
        return ERROR_UNK
    lower = msg.lower()
    if any(k in lower for k in _TCP_KEYWORDS):
        return ERROR_TCP
    if any(k in lower for k in _PWD_KEYWORDS):
        return ERROR_PWD
    return ERROR_UNK


class Checker:

    def __init__(self, run_id: int, app_cfg=None):
        self.run_id  = run_id
        self.cfg     = app_cfg
        self._dll    = getattr(app_cfg, "oracle_dll_path",  "") if app_cfg else ""
        self._custs  = getattr(app_cfg, "config_customers", []) if app_cfg else []
        self._envs   = getattr(app_cfg, "config_envs",      []) if app_cfg else []
        self.db_types = getattr(app_cfg, "config_dbtype", ["FMW"]) if app_cfg else ["FMW"]
        self.db_label = getattr(app_cfg, "report_label", "/".join(self.db_types)) \
            if app_cfg else "/".join(self.db_types)
        self._thick  = False
        self._init_oracle_client()

    # ── FMW query execution ──────────────────────────────────────────────────

    # ── Oracle client init ────────────────────────────────────────────────────

    def _init_oracle_client(self):
        try:
            import oracledb
            dll = self._dll
            if not dll or not dll.strip():
                log.warning("  Oracle DLL path not set in app_config — running in THIN mode")
                log.warning("  Set oracle_dll_path to the Instant Client folder to enable thick mode")
                return
            if not os.path.isdir(dll):
                log.warning(f"  Oracle DLL path not found: {dll} — running in THIN mode")
                return
            if not os.listdir(dll):
                log.warning(f"  Oracle DLL folder is empty: {dll} — running in THIN mode")
                return
            oracledb.init_oracle_client(lib_dir=dll)
            self._thick = True
            log.info(f"  Oracle THICK mode initialised  |  path = {dll}")
        except Exception as e:
            log.warning(f"  Oracle client init failed ({e}) — running in THIN mode")

    # ── Oracle DB connection check + FMW query (single connection) ───────────

    def _check_db(self, info: dict) -> tuple:
        """
        Open ONE Oracle connection per DB entry.
        - Checks connectivity (records duration).
        - If db_type is FMW and connection succeeded, executes the FMW query
          on the SAME open connection before closing it.
        - Connection is closed exactly once in the finally block.

        Returns (connected, error_msg, error_type, duration_ms, fmw_query_rows).
        fmw_query_rows is a list of dicts {USERNAME, ACCOUNT_STATUS, EXPIRY_DATE};
        always [] for non-FMW or failed connections.
        """
        import oracledb

        host    = info["db_host"]
        port    = int(info.get("db_port", 1521))
        service = info["db_service"]
        user    = info["db_user"]
        raw_pwd = info["db_password"]
        name    = info["db_name"]
        cname   = info["customer_name"]
        env     = info["env_type"]
        dtype   = info.get("db_type", "").upper()

        try:
            pwd = decrypt_password(raw_pwd) if is_encrypted(raw_pwd) else raw_pwd
        except Exception as e:
            log.warning(f"    Password decrypt warning ({e}) — using raw value")
            pwd = raw_pwd

        dsn  = f"{host}:{port}/{service}"
        mode = "THICK" if self._thick else "THIN"
        log.info(f"    Connecting  {cname} / {env} / {name}  [{dtype}]  {dsn}  ({mode})")

        start        = time.time()
        conn         = None
        fmw_rows     = []

        try:
            conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
            ms   = int((time.time() - start) * 1000)
            log.info(f"    CONNECTED   {cname} / {env} / {name}  ({ms} ms)")

            # ── FMW query on the SAME open connection ─────────────────────────
            if dtype == "FMW":
                fmw_query = getattr(self.cfg, "fmw_query", "") if self.cfg else ""
                if not fmw_query:
                    log.warning("    FMW query not configured in app_config — skipping")
                else:
                    try:
                        log.info(f"    FMW Query  {cname} / {env} / {name}  —  executing OAM user query")
                        cursor = conn.cursor()
                        cursor.execute(fmw_query)
                        cols = [desc[0].upper() for desc in cursor.description]
                        for row in cursor.fetchall():
                            row_dict = {}
                            for col, val in zip(cols, row):
                                if hasattr(val, "strftime"):
                                    row_dict[col] = val.strftime("%d-%b-%Y")
                                else:
                                    row_dict[col] = str(val) if val is not None else ""
                            fmw_rows.append(row_dict)
                        log.info(f"    FMW Query  {cname} / {env} / {name}  —  {len(fmw_rows)} OAM account(s) returned")
                    except Exception as qe:
                        log.error(f"    FMW Query  {cname} / {env} / {name}  —  query failed: {qe}")
                        fmw_rows = []

            return True, None, "", ms, fmw_rows

        except Exception as e:
            ms       = int((time.time() - start) * 1000)
            err      = str(e)
            err_type = classify_error(err)
            log.error(f"    FAILED      {cname} / {env} / {name}  ({ms} ms)  [{err_type}]")
            log.error(f"                {err}")
            return False, err, err_type, ms, []

        finally:
            # Single close — connection opened exactly once above
            if conn:
                try:   conn.close()
                except Exception: pass

    # ── health_check reads (READ ONLY) ────────────────────────────────────────

    def _customers(self, db):
        if self._custs:
            ph = ",".join(["%s"] * len(self._custs))
            rows = db.fetch_all(
                f"SELECT CustomerID AS customer_id, CustomerName AS customer_name "
                f"FROM Customers WHERE CustomerName IN ({ph}) AND Status=1 "
                f"ORDER BY CustomerName",
                tuple(self._custs))
        else:
            rows = db.fetch_all(
                "SELECT CustomerID AS customer_id, CustomerName AS customer_name "
                "FROM Customers WHERE Status=1 ORDER BY CustomerName")
        log.info(f"  Customers loaded  :  {len(rows)} found"
                 + (f"  (filter: {self._custs})" if self._custs else "  (all active)"))
        return rows

    def _envs_for(self, db, cid):
        scope = self._envs or ALL_ENV_TYPES
        ph    = ",".join(["%s"] * len(scope))
        return db.fetch_all(
            f"SELECT EnvID AS env_id, ServerType AS env_type "
            f"FROM Environments "
            f"WHERE CustomerID=%s AND ServerType IN ({ph}) AND Status=1 "
            f"ORDER BY FIELD(ServerType,'DEV','VAL','PRD')",
            tuple([cid] + scope))

    def _server_for(self, db, env_id):
        return db.fetch_one(
            "SELECT ServerID AS server_id, ServerName AS server_name, Host AS host "
            "FROM Servers "
            "WHERE EnvID=%s AND ServerName='DB Server' AND Status=1 LIMIT 1",
            (env_id,))

    def _oracle_dbs(self, db, server_id):
        ph = ",".join(["%s"] * len(self.db_types))
        return db.fetch_all(
            f"SELECT dbid AS db_id, OrdName AS db_name, OrdName AS db_service, "
            f"Port AS db_port, User AS db_user, Password AS db_password, "
            f"DatabaseType AS db_type "
            f"FROM OracleDatabase "
            f"WHERE ServerID=%s AND DatabaseType IN ({ph}) AND Status=1",
            tuple([server_id] + self.db_types))

    # ── Result helpers ────────────────────────────────────────────────────────

    def _row(self, cid, cname, env_type,
             server_id=0, server_name="", server_host="",
             db_name="", db_type=None, db_host="", db_port=0, db_service="",
             status="SKIPPED", error="", error_type="", ms=0) -> dict:
        return {
            "run_id": self.run_id, "customer_id": cid,
            "customer_name": cname, "env_type": env_type,
            "server_id": server_id, "server_name": server_name,
            "server_host": server_host,
            "db_name": db_name,
            "db_type": db_type if db_type is not None else "/".join(self.db_types),
            "db_host": db_host, "db_port": db_port, "db_service": db_service,
            "connection_status": status, "error_message": error,
            "error_type": error_type, "duration_ms": ms,
            "checked_at": datetime.utcnow(),
        }

    def _save(self, result: dict):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    "INSERT INTO process_db_connection_result "
                    "(run_id,customer_id,customer_name,env_type,"
                    "server_id,server_name,server_host,"
                    "db_name,db_type,db_host,db_port,db_service,"
                    "connection_status,error_message,error_type,"
                    "duration_ms,checked_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                    (result["run_id"],
                     result["customer_id"], result["customer_name"], result["env_type"],
                     result["server_id"],   result["server_name"],   result["server_host"],
                     result["db_name"],     result["db_type"],       result["db_host"],
                     result["db_port"],     result["db_service"],
                     result["connection_status"], result["error_message"],
                     result["error_type"],  result["duration_ms"],   result["checked_at"]))
        except Exception as e:
            log.error(f"  DB write failed: {e}")

    def _save_fmw_results(self, run_id: int, result: dict, fmw_rows: list):
        """
        Persist each FMW query row to fmw_query_result table.
        Computes action_required + reason at this point so the DB record is self-contained.
        Called only for FMW db_type entries; fmw_rows may be empty (stored as-is).
        """
        customer_name = result.get("customer_name", "")
        env_type      = result.get("env_type",      "")
        server_host   = result.get("server_host",   "")
        db_name       = result.get("db_name",       "")
        db_type       = result.get("db_type",       "")
        conn_ref      = f"{server_host} / {db_name} / {db_type}"

        if not fmw_rows:
            # No accounts returned — still write one row to capture the event
            try:
                with DBManager(cfg=FMWCHECKS_DB) as db:
                    db.execute(
                        "INSERT INTO fmw_query_result "
                        "(run_id, customer_name, env_type, server_db_info, "
                        " username, account_status, expiry_date, "
                        " action_required, reason, queried_at) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())",
                        (run_id, customer_name, env_type, conn_ref,
                         "", "", "", "No", "", ))
            except Exception as e:
                log.error(f"  fmw_query_result write failed (no-rows): {e}")
            return

        for frow in fmw_rows:
            expiry = frow.get("EXPIRY_DATE", "") or ""
            expiry_set = expiry.strip().upper() not in ("", "NULL", "NONE")
            action_required = "Yes" if expiry_set else "No"
            reason          = expiry.strip() if expiry_set else ""
            try:
                with DBManager(cfg=FMWCHECKS_DB) as db:
                    db.execute(
                        "INSERT INTO fmw_query_result "
                        "(run_id, customer_name, env_type, server_db_info, "
                        " username, account_status, expiry_date, "
                        " action_required, reason, queried_at) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())",
                        (run_id, customer_name, env_type, conn_ref,
                         frow.get("USERNAME",       ""),
                         frow.get("ACCOUNT_STATUS", ""),
                         expiry,
                         action_required,
                         reason))
            except Exception as e:
                log.error(f"  fmw_query_result write failed: {e}")

    def _log_step(self, no, name, status, msg="", cust="", env=""):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    "INSERT INTO process_run_log "
                    "(run_id,step_no,step_name,status,message,customer,env_type,logged_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())",
                    (self.run_id, no, name, status,
                     (msg  or "")[:2000],
                     (cust or "")[:255],
                     (env  or "")[:50]))
        except Exception as e:
            log.warning(f"  Step log write failed: {e}")

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run_all(self) -> list:
        results   = []
        env_scope = self._envs or ALL_ENV_TYPES

        log.info(f"[Step 3]  Loading customers  |  db_types={self.db_types}  |  envs={env_scope}")
        self._log_step(3, "IDENTIFY_CUSTOMERS", "STARTED",
                       f"customer_filter={'ALL' if not self._custs else self._custs}  |  "
                       f"env_filter={'ALL' if not self._envs else self._envs}  |  "
                       f"db_type={self.db_types}")

        try:
            with DBManager(cfg=HC_DB) as db:
                customers = self._customers(db)
        except Exception as e:
            log.error(f"  Cannot load customers: {e}")
            self._log_step(3, "IDENTIFY_CUSTOMERS", "FAILED", str(e))
            return []

        if not customers:
            log.warning("  No active customers found")
            self._log_step(3, "IDENTIFY_CUSTOMERS", "SKIPPED", "No active customers")
            return []

        self._log_step(3, "IDENTIFY_CUSTOMERS", "COMPLETED",
                       f"{len(customers)} customer(s) found")

        for cust in customers:
            cid   = cust["customer_id"]
            cname = cust["customer_name"]

            log.info("")
            log.info(f"  ── Customer: {cname}  (ID={cid})")

            # Load environments
            try:
                with DBManager(cfg=HC_DB) as db:
                    envs = self._envs_for(db, cid)
            except Exception as e:
                log.error(f"    Cannot load environments: {e}")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "FAILED", str(e), cname)
                continue

            if not envs:
                msg = f"No active environments found (filter={env_scope})"
                log.warning(f"    {msg}")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "SKIPPED", msg, cname)
                r = self._row(cid, cname, ",".join(env_scope),
                              error=msg, status="SKIPPED")
                self._save(r); results.append(r)
                continue

            log.info(f"    Environments : {[e['env_type'] for e in envs]}")
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "COMPLETED",
                           f"found: {[e['env_type'] for e in envs]}", cname)

            for env in envs:
                env_id   = env["env_id"]
                env_type = env["env_type"]

                log.info(f"    ── Env: {env_type}  (EnvID={env_id})")

                # Map DB server
                try:
                    with DBManager(cfg=HC_DB) as db:
                        server = self._server_for(db, env_id)
                except Exception as e:
                    log.error(f"      Server lookup failed: {e}")
                    self._log_step(5, "MAP_DB_SERVER", "FAILED", str(e), cname, env_type)
                    r = self._row(cid, cname, env_type,
                                  error=f"Server lookup failed: {e}", status="SKIPPED")
                    self._save(r); results.append(r)
                    continue

                if not server:
                    msg = "No active 'DB Server' row in health_check.Servers"
                    log.warning(f"      {msg}")
                    self._log_step(5, "MAP_DB_SERVER", "SKIPPED", msg, cname, env_type)
                    r = self._row(cid, cname, env_type, error=msg, status="SKIPPED")
                    self._save(r); results.append(r)
                    continue

                server_id   = server["server_id"]
                server_name = server["server_name"]
                server_host = server["host"]
                log.info(f"      DB Server  :  {server_name}  |  host={server_host}  (ID={server_id})")
                self._log_step(5, "MAP_DB_SERVER", "COMPLETED",
                               f"name={server_name} id={server_id} host={server_host}",
                               cname, env_type)

                # Load Oracle DBs
                try:
                    with DBManager(cfg=HC_DB) as db:
                        dbs = self._oracle_dbs(db, server_id)
                except Exception as e:
                    log.error(f"      Oracle DB lookup failed: {e}")
                    self._log_step(6, "LOAD_DB_TYPES", "FAILED", str(e), cname, env_type)
                    r = self._row(cid, cname, env_type,
                                  server_id=server_id, server_name=server_name,
                                  server_host=server_host, db_host=server_host,
                                  error=f"DB lookup failed: {e}", status="SKIPPED")
                    self._save(r); results.append(r)
                    continue

                if not dbs:
                    msg = f"No active Oracle DB found for db_type={self.db_types}"
                    log.warning(f"      {msg}")
                    self._log_step(6, "LOAD_DB_TYPES", "SKIPPED", msg, cname, env_type)
                    r = self._row(cid, cname, env_type,
                                  server_id=server_id, server_name=server_name,
                                  server_host=server_host, db_host=server_host,
                                  error=msg, status="SKIPPED")
                    self._save(r); results.append(r)
                    continue

                log.info(f"      Oracle DBs : {len(dbs)} found  (type={self.db_types})")
                self._log_step(6, "LOAD_DB_TYPES", "COMPLETED",
                               f"{len(dbs)} DB(s)", cname, env_type)

                # Check each Oracle DB
                for tdb in dbs:
                    info = {
                        "customer_id": cid, "customer_name": cname,
                        "env_type": env_type,
                        "db_name":    tdb["db_name"],
                        "db_type":    tdb.get("db_type", ""),
                        "db_host":    server_host,
                        "db_port":    tdb.get("db_port", 1521),
                        "db_service": tdb["db_service"],
                        "db_user":    tdb["db_user"],
                        "db_password": tdb["db_password"],
                    }
                    ok, err, err_type, ms, fmw_query_rows = self._check_db(info)
                    status = "COMPLETED" if ok else "FAILED"

                    r = {
                        "run_id":            self.run_id,
                        "customer_id":       cid,
                        "customer_name":     cname,
                        "env_type":          env_type,
                        "server_id":         server_id,
                        "server_name":       server_name,
                        "server_host":       server_host,
                        "db_name":           tdb["db_name"],
                        "db_type":           tdb.get("db_type", ""),
                        "db_host":           server_host,
                        "db_port":           tdb.get("db_port", 1521),
                        "db_service":        tdb["db_service"],
                        "connection_status": status,
                        "error_message":     err or "",
                        "error_type":        err_type if not ok else "",
                        "duration_ms":       ms,
                        "checked_at":        datetime.utcnow(),
                        "fmw_query_rows":    fmw_query_rows,
                    }
                    self._save(r)

                    # Persist FMW query rows to dedicated table (FMW db_type only)
                    if tdb.get("db_type", "").upper() == "FMW" and ok:
                        self._save_fmw_results(self.run_id, r, fmw_query_rows)

                    results.append(r)
                    self._log_step(7, "DB_CONNECTION_CHECK", status,
                                   f"DB={tdb['db_name']}  |  {ms}ms"
                                   + (f"  |  [{err_type}] {err}" if err else ""),
                                   cname, env_type)

        # Summary
        s = sum(1 for r in results if r["connection_status"] == "COMPLETED")
        f = sum(1 for r in results if r["connection_status"] == "FAILED")
        k = sum(1 for r in results if r["connection_status"] == "SKIPPED")
        log.info("")
        log.info(f"[Step 7]  Check complete  —  {len(results)} total  |  "
                 f"connected={s}  |  not_connected={f}  |  skipped={k}")
        return results
