-- ============================================================
-- dbconnection_checker  —  ALTER SCRIPT  v8  →  v9
--
-- What this script does:
--   1. Adds 'fmw_query' row to app_config           (config-driven query)
--   2. Creates new table fmw_query_result            (stores FMW OAM query
--      results per run with action_required + reason)
--
-- Run ONCE on an existing v8 installation:
--   mysql -u root -p dbconnection_checker < dbconnection_checker_alter_v8_to_v9.sql
--
-- Safe to run multiple times (IF NOT EXISTS / ON DUPLICATE KEY UPDATE).
-- Does NOT touch or drop any existing v8 tables or columns.
-- ============================================================

USE dbconnection_checker;

-- ─────────────────────────────────────────────────────────────
-- 1. App Config — add fmw_query key
--    The value stores the exact SELECT that must be executed
--    against FMW Oracle DBs.  Do NOT modify the SQL value.
-- ─────────────────────────────────────────────────────────────
INSERT INTO app_config (config_key, config_value, description)
VALUES (
    'fmw_query',
    'SELECT USERNAME, ACCOUNT_STATUS, EXPIRY_DATE FROM DBA_USERS WHERE USERNAME LIKE ''%OAM%''',
    'FMW OAM user expiry query — executed only for FMW db_type on the same connection used for the connectivity check. Do NOT modify the SELECT statement or WHERE clause.'
)
ON DUPLICATE KEY UPDATE
    description = VALUES(description);
-- NOTE: ON DUPLICATE KEY intentionally does NOT overwrite config_value,
--       so any admin-customised query is preserved on re-run.


-- ─────────────────────────────────────────────────────────────
-- 2. New table: fmw_query_result
--    One row per OAM account returned by the FMW query,
--    per run_id / customer / environment.
--    Non-FMW database types are never written here.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fmw_query_result (
    id               INT           NOT NULL AUTO_INCREMENT,

    -- Run reference
    run_id           INT           NOT NULL
                     COMMENT 'FK → process_run.id',

    -- Scope
    customer_name    VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'Customer name (denormalised for reporting)',
    env_type         VARCHAR(50)   NOT NULL DEFAULT ''
                     COMMENT 'DEV | VAL | PRD',

    -- Connection context (single display column for Excel report)
    server_db_info   VARCHAR(500)  NOT NULL DEFAULT ''
                     COMMENT 'Server Host / DB Name / DB Type — display string',

    -- OAM account detail (from DBA_USERS query)
    username         VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.USERNAME',
    account_status   VARCHAR(100)  NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.ACCOUNT_STATUS',
    expiry_date      VARCHAR(50)   NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.EXPIRY_DATE (formatted string, empty if NULL)',

    -- Validation result (Customer/Environment + account level)
    action_required  VARCHAR(3)    NOT NULL DEFAULT 'No'
                     COMMENT 'Yes if expiry_date is not null/empty, else No',
    reason           VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'EXPIRY_DATE value when action_required=Yes, else empty',

    queried_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                     COMMENT 'When the FMW query was executed for this run',

    PRIMARY KEY (id),
    KEY idx_fmw_run_id        (run_id),
    KEY idx_fmw_customer      (customer_name),
    KEY idx_fmw_env           (env_type),
    KEY idx_fmw_action        (action_required),
    KEY idx_fmw_queried_at    (queried_at),

    CONSTRAINT fk_fmw_result_run
        FOREIGN KEY (run_id) REFERENCES process_run (id)
        ON DELETE CASCADE

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='FMW OAM user expiry query results — one row per account per run';
