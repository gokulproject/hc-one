"""
main.py — Oracle DB Connection Checker entry point.
Run: python main.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.logger   import setup_logging
from process_manager import ProcessManager


def main():
    logger = setup_logging()
    logger.info("Oracle DB Connection Checker — Starting ...")
    try:
        pm = ProcessManager()
        pm.execute()
    except KeyboardInterrupt:
        logger.info("Stopped by user.")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
