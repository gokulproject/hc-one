"""
ExcelCreation/excel_manager.py
==============================
Generate Excel report for Oracle DB Connection Check.

Sheet 1 — DB Connection Check (16 columns):
  # | Customer | Environment | Server Name | Server ID | Server Host |
  DB Name | DB Type | DSN | DB Connection Status |
  Duration (ms) | Error | Error Type | Checked At (IST) |
  Expired (Action Required) | Reason (if yes)

Dynamic sheets — one per Customer + Environment (FMW db_type only):
  Sheet name : "CustomerName - ENV"
  Row 2      : FMW query read from app_config
  Columns    : Server Host / DB Name / DB Type | USERNAME | ACCOUNT_STATUS |
               EXPIRY_DATE | Action Required

Expiry / Action Required rules (FMW db_type only):
  DB CONNECTED   + EXPIRY_DATE has a date  → Yes   | Reason: the date value
  DB CONNECTED   + all EXPIRY_DATE empty   → No    | Reason: blank
  DB NOT CONNECTED or SKIPPED              → blank | Reason: blank
  Non-FMW db_type (any status)             → blank | Reason: blank
"""
import logging
import os
from datetime import datetime, timedelta

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

log      = logging.getLogger("checker.excel")
IST      = timedelta(hours=5, minutes=30)
LAST_COL = 16   # 14 original + 2 expiry columns

# ── Palette ───────────────────────────────────────────────────────────────────
HDR_DARK   = "1565C0"
HDR_MED    = "0D47A1"
HDR_GREEN  = "1B5E20"
SUMM_BG    = "E3F2FD"
GREEN_BG   = "E8F5E9";  GREEN_BG2 = "F1F8E9"
RED_BG     = "FFEBEE";  RED_BG2   = "FFF5F5"
AMBER_BG   = "FFF8E1";  AMBER_BG2 = "FFFDE7"
C_GREEN    = "2E7D32"
C_RED      = "C62828"
C_AMBER    = "E65100"
C_BLUE     = "0D47A1"
C_WHITE    = "FFFFFF"
C_DARK_RED = "B71C1C"
C_DARK_GRN = "1B5E20"

STATUS_LABEL = {
    "COMPLETED": "DB CONNECTED",
    "FAILED":    "DB NOT CONNECTED",
    "SKIPPED":   "SKIPPED",
}
STATUS_COLOR = {
    "COMPLETED": C_GREEN,
    "FAILED":    C_RED,
    "SKIPPED":   C_AMBER,
}
ERR_LABEL = {
    "TCP_TIMEOUT": "TCP Connection Timeout",
    "PASSWORD":    "Password Expired / Invalid Username or Password",
    "UNKNOWN":     "Unknown / Other Error",
    "":            "",
}
ERR_COLOR = {"TCP_TIMEOUT": C_RED, "PASSWORD": C_AMBER, "UNKNOWN": C_BLUE, "": ""}

_DEFAULT_FMW_QUERY = (
    "SELECT USERNAME, ACCOUNT_STATUS, EXPIRY_DATE "
    "FROM DBA_USERS WHERE USERNAME LIKE '%OAM%'"
)


def _border():
    s = Side(style="thin", color="BDBDBD")
    return Border(left=s, right=s, top=s, bottom=s)


def _ist(dt) -> str:
    return (dt + IST).strftime("%d-%b-%Y %I:%M:%S %p IST") if dt else ""


def _col(n):
    return get_column_letter(n)


# ── Expiry helpers ────────────────────────────────────────────────────────────

def _is_expiry_set(val) -> bool:
    """True only when EXPIRY_DATE contains an actual date string."""
    if val is None:
        return False
    return str(val).strip().upper() not in ("", "NULL", "NONE")


def _compute_expiry_status(fmw_query_rows: list) -> tuple:
    """
    Called only for CONNECTED FMW entries.
    Returns (expired_str, action_required_str, reason_str).
    """
    if not fmw_query_rows:
        return "No", "No", ""
    for row in fmw_query_rows:
        expiry = row.get("EXPIRY_DATE", "")
        if _is_expiry_set(expiry):
            return "Yes", "Yes", str(expiry).strip()
    return "No", "No", ""


def _build_expiry_map(results: list) -> dict:
    """
    Map (customer_name, env_type) -> (expired, action_required, reason).
    Built ONLY from FMW entries where connection_status == COMPLETED.
    FAILED / SKIPPED entries are excluded — their columns stay blank.
    """
    env_rows: dict = {}
    for r in results:
        if r.get("db_type", "").upper() != "FMW":
            continue
        if r.get("connection_status") != "COMPLETED":
            continue
        key = (r.get("customer_name", ""), r.get("env_type", ""))
        env_rows.setdefault(key, []).extend(r.get("fmw_query_rows", []))
    return {key: _compute_expiry_status(rows) for key, rows in env_rows.items()}


# ── Sheet 1: DB Connection Check ─────────────────────────────────────────────

def _write_connection_sheet(ws, results, run_id, timestamp, db_label, expiry_map):
    total   = len(results)
    success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
    failed  = sum(1 for r in results if r.get("connection_status") == "FAILED")
    skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")
    tcp_err = sum(1 for r in results if r.get("error_type") == "TCP_TIMEOUT")
    pwd_err = sum(1 for r in results if r.get("error_type") == "PASSWORD")
    unk_err = sum(1 for r in results
                  if r.get("error_type") == "UNKNOWN"
                  and r.get("connection_status") == "FAILED")

    if total == 0:
        summary, summ_color = "No data processed", C_RED
    elif failed == 0 and skipped == 0:
        summary, summ_color = "ALL CONNECTED  ✅", C_GREEN
    elif success == 0:
        summary, summ_color = (
            f"NO SUCCESSFUL CONNECTIONS  ❌   "
            f"Not Connected: {failed}  |  Skipped: {skipped}"), C_RED
    else:
        summary, summ_color = (
            f"PARTIAL  ⚠    Connected: {success}  |  "
            f"Not Connected: {failed}  |  Skipped: {skipped}"), C_AMBER

    last_letter = _col(LAST_COL)

    # Row 1 — Title
    ws.merge_cells(f"A1:{last_letter}1")
    c = ws["A1"]
    c.value     = f"{db_label} Oracle DB Connection Check  |  Run #{run_id}  |  {timestamp}"
    c.font      = Font(name="Calibri", size=13, bold=True, color=C_WHITE)
    c.fill      = PatternFill("solid", fgColor=HDR_DARK)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26

    # Row 2 — Summary bar
    ws.merge_cells(f"A2:{last_letter}2")
    c = ws["A2"]
    err_part = (
        f"  |  Errors — TCP: {tcp_err}  |  Password: {pwd_err}  |  Unknown: {unk_err}"
        if failed else "")
    c.value = (
        f"Total: {total}   ✅ Connected: {success}   ❌ Not Connected: {failed}"
        f"   ⚠ Skipped: {skipped}{err_part}   —   {summary}")
    c.font      = Font(name="Calibri", size=10, bold=True, color=summ_color)
    c.fill      = PatternFill("solid", fgColor=SUMM_BG)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 20

    # Row 3 — Headers
    headers = [
        "#", "Customer", "Environment", "Server Name", "Server ID",
        "Server Host", "DB Name", "DB Type", "DSN (Host:Port/Service)",
        "DB Connection Status", "Duration (ms)", "Error", "Error Type",
        "Checked At (IST)",
        "Expired\n(Action Required)", "Reason\n(if yes)",
    ]
    widths = [4, 22, 13, 18, 10, 22, 20, 11, 32, 20, 13, 45, 35, 24, 18, 45]

    for col, (h, w) in enumerate(zip(headers, widths), 1):
        c           = ws.cell(row=3, column=col, value=h)
        c.font      = Font(name="Calibri", size=10, bold=True, color=C_WHITE)
        c.fill      = PatternFill("solid", fgColor=HDR_MED)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = _border()
        ws.column_dimensions[_col(col)].width = w
    ws.row_dimensions[3].height = 30

    ws.auto_filter.ref = f"A3:{last_letter}{3 + max(total, 1)}"

    for idx, r in enumerate(results, 1):
        row      = idx + 3
        stat     = r.get("connection_status", "SKIPPED")
        err_type = r.get("error_type", "") or ""

        bg = (GREEN_BG if idx % 2 else GREEN_BG2) if stat == "COMPLETED" else \
             (RED_BG   if idx % 2 else RED_BG2)   if stat == "FAILED"    else \
             (AMBER_BG if idx % 2 else AMBER_BG2)

        h   = r.get("db_host",    "") or ""
        p   = r.get("db_port",    1521) or 1521
        svc = r.get("db_service", "") or ""
        dsn = f"{h}:{p}/{svc}" if h else ""

        # ── Expiry columns ────────────────────────────────────────────────────
        # Rule: only FMW + COMPLETED gets a value.
        # NOT CONNECTED or SKIPPED → both columns blank (query never ran).
        # Non-FMW → both columns blank (not applicable).
        db_type_val = r.get("db_type", "").upper()
        if db_type_val == "FMW" and stat == "COMPLETED":
            key = (r.get("customer_name", ""), r.get("env_type", ""))
            expired_str, action_str, reason_str = expiry_map.get(key, ("No", "No", ""))
            expiry_display = f"{expired_str} / {action_str}"
        else:
            expiry_display = ""
            reason_str     = ""

        values = [
            idx,
            r.get("customer_name",  "") or "",
            r.get("env_type",       "") or "",
            r.get("server_name",    "") or "",
            r.get("server_id",      "") or "",
            r.get("server_host",    "") or "",
            r.get("db_name",        "") or "—",
            r.get("db_type",        "") or "",
            dsn,
            STATUS_LABEL.get(stat, stat),
            r.get("duration_ms",    0),
            r.get("error_message",  "") or "",
            ERR_LABEL.get(err_type, err_type),
            _ist(r.get("checked_at")),
            expiry_display,
            reason_str,
        ]

        for col, val in enumerate(values, 1):
            c           = ws.cell(row=row, column=col, value=val)
            c.font      = Font(name="Calibri", size=10)
            c.fill      = PatternFill("solid", fgColor=bg)
            c.border    = _border()
            c.alignment = Alignment(vertical="center", wrap_text=True)

            if col == 10:   # DB Connection Status
                c.font      = Font(name="Calibri", size=10, bold=True,
                                   color=STATUS_COLOR.get(stat, C_RED))
                c.alignment = Alignment(horizontal="center", vertical="center")

            if col == 11:   # Duration — right-align
                c.alignment = Alignment(horizontal="right", vertical="center")

            if col == 12 and val:   # Error — italic
                c.font = Font(name="Calibri", size=9, italic=True,
                              color=STATUS_COLOR.get(stat, C_RED))

            if col == 13 and val:   # Error Type — bold coloured
                c.font = Font(name="Calibri", size=9, bold=True,
                              color=ERR_COLOR.get(err_type, C_BLUE))

            # Expired / Action Required — only style when there is a value
            if col == 15 and expiry_display:
                if expiry_display.startswith("Yes"):
                    c.font = Font(name="Calibri", size=10, bold=True, color=C_DARK_RED)
                else:
                    c.font = Font(name="Calibri", size=10, bold=True, color=C_DARK_GRN)
                c.alignment = Alignment(horizontal="center", vertical="center")

            # Reason — italic red only when there is a date value
            if col == 16 and reason_str:
                c.font = Font(name="Calibri", size=9, italic=True, color=C_DARK_RED)

        ws.row_dimensions[row].height = 20

    ws.freeze_panes = "A4"


# ── Dynamic per-Customer/Env sheets (FMW only) ───────────────────────────────

def _safe_sheet_name(name: str) -> str:
    """Sanitise to a valid Excel sheet name (max 31 chars, no illegal chars)."""
    for ch in r"\/:*?[]":
        name = name.replace(ch, " ")
    return name[:31].strip()


def _write_fmw_env_sheet(ws, cname: str, env_type: str,
                         env_results: list, run_id, timestamp, fmw_query: str):
    """
    One sheet per Customer + Environment (FMW db_type only).

    Columns: Server Host / DB Name / DB Type | USERNAME | ACCOUNT_STATUS |
             EXPIRY_DATE | Action Required

    Row 2: FMW query text read from app_config (passed in via fmw_query param).

    connection_status != COMPLETED (FAILED or SKIPPED):
      -> USERNAME / ACCOUNT_STATUS / EXPIRY_DATE -> blank
      -> Action Required -> blank  (query never ran — no data to show)

    connection_status == COMPLETED:
      -> rows from fmw_query_rows written
      -> Action Required = Yes (expiry date found) / No (all empty)
    """
    SHEET_COLS  = 5
    last_letter = _col(SHEET_COLS)

    # Row 1 — Title
    ws.merge_cells(f"A1:{last_letter}1")
    c = ws["A1"]
    c.value     = (f"{cname}  |  {env_type}  |  "
                   f"FMW OAM Account Expiry  |  Run #{run_id}  |  {timestamp}")
    c.font      = Font(name="Calibri", size=12, bold=True, color=C_WHITE)
    c.fill      = PatternFill("solid", fgColor=HDR_GREEN)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 24

    # Row 2 — FMW query from app_config
    ws.merge_cells(f"A2:{last_letter}2")
    c = ws["A2"]
    c.value     = f"FMW Query : {fmw_query}"
    c.font      = Font(name="Calibri", size=9, italic=True, color="37474F")
    c.fill      = PatternFill("solid", fgColor="E8F5E9")
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 16

    # Row 3 — Headers
    headers = [
        "Server Host / DB Name / DB Type",
        "USERNAME", "ACCOUNT_STATUS", "EXPIRY_DATE", "Action Required",
    ]
    widths = [40, 26, 20, 22, 18]

    for col, (h, w) in enumerate(zip(headers, widths), 1):
        c           = ws.cell(row=3, column=col, value=h)
        c.font      = Font(name="Calibri", size=10, bold=True, color=C_WHITE)
        c.fill      = PatternFill("solid", fgColor=HDR_GREEN)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = _border()
        ws.column_dimensions[_col(col)].width = w
    ws.row_dimensions[3].height = 22

    # Build data rows
    data_rows = []
    for r in env_results:
        conn_info = (f"{r.get('server_host', '') or ''} / "
                     f"{r.get('db_name',     '') or ''} / "
                     f"{r.get('db_type',     '') or ''}")
        stat      = r.get("connection_status", "FAILED")
        fmw_rows  = r.get("fmw_query_rows", [])

        if stat != "COMPLETED":
            # DB not connected or skipped — query never ran — all OAM columns blank
            data_rows.append({
                "conn_info":      conn_info,
                "USERNAME":       "",
                "ACCOUNT_STATUS": "",
                "EXPIRY_DATE":    "",
                "action":         "",       # blank — not applicable
            })
        elif fmw_rows:
            for frow in fmw_rows:
                expiry = frow.get("EXPIRY_DATE", "") or ""
                data_rows.append({
                    "conn_info":      conn_info,
                    "USERNAME":       frow.get("USERNAME",       ""),
                    "ACCOUNT_STATUS": frow.get("ACCOUNT_STATUS", ""),
                    "EXPIRY_DATE":    expiry,
                    "action":         "Yes" if _is_expiry_set(expiry) else "No",
                })
        else:
            # Connected but zero OAM accounts returned by query
            data_rows.append({
                "conn_info":      conn_info,
                "USERNAME":       "",
                "ACCOUNT_STATUS": "",
                "EXPIRY_DATE":    "",
                "action":         "No",
            })

    ws.auto_filter.ref = f"A3:{last_letter}{3 + max(len(data_rows), 1)}"

    for idx, dr in enumerate(data_rows, 1):
        row      = idx + 3
        bg       = "E8F5E9" if idx % 2 else "F1F8E9"
        expiry   = dr["EXPIRY_DATE"]
        has_date = _is_expiry_set(expiry)
        action   = dr["action"]

        for col, val in enumerate(
            [dr["conn_info"], dr["USERNAME"], dr["ACCOUNT_STATUS"], expiry, action], 1
        ):
            c           = ws.cell(row=row, column=col, value=val)
            c.font      = Font(name="Calibri", size=10)
            c.fill      = PatternFill("solid", fgColor=bg)
            c.border    = _border()
            c.alignment = Alignment(vertical="center", wrap_text=True)

            # EXPIRY_DATE — highlight red bold only when a real date present
            if col == 4 and has_date:
                c.font      = Font(name="Calibri", size=10, bold=True, color=C_DARK_RED)
                c.alignment = Alignment(horizontal="center", vertical="center")

            # ACCOUNT_STATUS — colour by value
            if col == 3 and val:
                up = str(val).upper()
                if "EXPIRED" in up or "LOCKED" in up:
                    c.font = Font(name="Calibri", size=10, bold=True, color=C_RED)
                else:
                    c.font = Font(name="Calibri", size=10, color=C_DARK_GRN)

            # Action Required — only style when not blank
            if col == 5 and action:
                if action == "Yes":
                    c.font = Font(name="Calibri", size=10, bold=True, color=C_DARK_RED)
                else:
                    c.font = Font(name="Calibri", size=10, bold=True, color=C_DARK_GRN)
                c.alignment = Alignment(horizontal="center", vertical="center")

        ws.row_dimensions[row].height = 20

    ws.freeze_panes = "A4"

    if not data_rows:
        ws.merge_cells(f"A4:{last_letter}4")
        c = ws["A4"]
        c.value     = f"No FMW OAM accounts found for {cname} / {env_type}."
        c.font      = Font(name="Calibri", size=10, italic=True, color=C_AMBER)
        c.alignment = Alignment(horizontal="center", vertical="center")


# ── Public entry point ────────────────────────────────────────────────────────

def generate_excel(results, run_id, timestamp, excel_path,
                   db_label="FMW", fmw_query: str = "") -> str:
    """
    Generate the Excel report.

    Parameters
    ----------
    results    : list of result dicts from checker.py
    run_id     : int
    timestamp  : formatted IST timestamp string for titles
    excel_path : folder to save the file
    db_label   : display label (from app_config.report_label)
    fmw_query  : the FMW query from app_config — shown in row 2 of each
                 Customer-Env sheet so auditors can see exactly what ran
    """
    os.makedirs(excel_path, exist_ok=True)

    label    = (db_label or "FMW").upper().replace("/", "_").replace(" ", "_")
    date_str = datetime.now().strftime("%d-%m-%y")
    filename = f"{label}_CONNECTION_CHECKS_{date_str}-{run_id}.xlsx"
    filepath = os.path.join(excel_path, filename)

    query_text = fmw_query.strip() if fmw_query else _DEFAULT_FMW_QUERY

    # Expiry map — built only from CONNECTED FMW entries
    expiry_map = _build_expiry_map(results)

    wb = Workbook()

    # ── Sheet 1: DB Connection Check ─────────────────────────────────────────
    ws1 = wb.active
    ws1.title = "DB Connection Check"
    _write_connection_sheet(ws1, results, run_id, timestamp, db_label, expiry_map)

    # ── Dynamic sheets: one per Customer + Environment (FMW db_type only) ────
    env_groups: dict = {}
    for r in results:
        if r.get("db_type", "").upper() != "FMW":
            continue
        key = (r.get("customer_name", "") or "", r.get("env_type", "") or "")
        env_groups.setdefault(key, []).append(r)

    used_names: dict = {}
    for (cname, env_type), env_results in env_groups.items():
        safe_name = _safe_sheet_name(f"{cname} - {env_type}")
        if safe_name in used_names:
            used_names[safe_name] += 1
            safe_name = _safe_sheet_name(f"{safe_name} ({used_names[safe_name]})")
        else:
            used_names[safe_name] = 1

        ws = wb.create_sheet(title=safe_name)
        _write_fmw_env_sheet(ws, cname, env_type, env_results,
                             run_id, timestamp, query_text)
        log.info(f"  FMW sheet   : '{safe_name}'  ({len(env_results)} DB entry(s))")

    wb.save(filepath)
    log.info(f"  Excel saved : {filepath}")
    return filepath
