"""
Common/email_manager.py
=======================
Send DB connection check report email with HTML body and Excel attachment.
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

log = logging.getLogger("checker.email")


class EmailManager:

    def __init__(self, email_cfg):
        self.cfg = email_cfg

    # ── Send ─────────────────────────────────────────────────────────────────

    def send_report(self, subject, html_body, excel_path=None, run_id=0):
        """Send email with HTML body and Excel attachment.
        Returns (success: bool, error_msg: str|None).
        """
        if not self.cfg.to_addrs:
            log.warning("  No TO address configured — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(self.cfg.to_addrs)
            if self.cfg.cc_addrs:
                msg["Cc"]  = ", ".join(self.cfg.cc_addrs)

            # HTML body
            msg.attach(MIMEText(html_body, "html", "utf-8"))

            # Excel attachment
            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)

            all_to = self.cfg.to_addrs + self.cfg.cc_addrs + self.cfg.bcc_addrs
            with smtplib.SMTP(self.cfg.smtp_host, self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(self.cfg.from_addr, all_to, msg.as_string())

            log.info(f"  Email sent  |  run_id={run_id}  |  to={self.cfg.to_addrs}")
            return True, None

        except Exception as e:
            log.error(f"  Email failed: {e}")
            return False, str(e)[:500]

    # ── Subject ──────────────────────────────────────────────────────────────

    @staticmethod
    def build_subject(results, run_id, db_label="FMW"):
        customers = list(dict.fromkeys(
            r.get("customer_name", "") for r in results if r.get("customer_name")))
        cust_str = ", ".join(customers) if customers else "All Customers"
        return f"{db_label} DB Connection Check — {cust_str} — Run #{run_id}"

    # ── HTML body ─────────────────────────────────────────────────────────────

    @staticmethod
    def build_body(results, run_id, started, ended,
                   total, success, failed, skipped,
                   tcp_err=0, pwd_err=0, unk_err=0, db_label="FMW"):
        """
        Build a clean, simple HTML email body.
        No boxes or heavy styling — readable in all email clients.
        """

        # Overall status line
        if total == 0:
            alert_color = "#856404"
            alert_text  = "No active environments or databases were found for this run."
        elif failed == 0 and skipped == 0:
            alert_color = "#155724"
            alert_text  = "All database connections were successful."
        elif success == 0:
            alert_color = "#721c24"
            alert_text  = (f"No connections were successful. "
                           f"All {failed} connection(s) failed. "
                           f"Please review the attached report urgently.")
        else:
            alert_color = "#856404"
            alert_text  = (f"{failed} connection(s) failed or were skipped. "
                           f"Please review the attached report.")

        # Customer + environment list from results
        cust_env_lines = ""
        seen = {}
        for r in results:
            cname = r.get("customer_name", "") or ""
            env   = r.get("env_type",      "") or ""
            stat  = r.get("connection_status", "")
            key   = (cname, env)
            if key not in seen:
                seen[key] = stat
        for (cname, env), stat in seen.items():
            if stat == "COMPLETED":
                dot = "&#9679;"
                col = "#155724"
            elif stat == "FAILED":
                dot = "&#9679;"
                col = "#721c24"
            else:
                dot = "&#9679;"
                col = "#856404"
            cust_env_lines += (
                f'<tr>'
                f'<td style="padding:3px 12px 3px 0;color:{col};">{dot}</td>'
                f'<td style="padding:3px 16px 3px 0;font-weight:600;">{cname}</td>'
                f'<td style="padding:3px 16px 3px 0;">{env}</td>'
                f'<td style="padding:3px 0;color:{col};">'
                f'{"Connected" if stat == "COMPLETED" else "Not Connected" if stat == "FAILED" else "Skipped"}'
                f'</td>'
                f'</tr>\n'
            )

        # Error breakdown rows (only if failures exist)
        error_section = ""
        if failed:
            error_section = f"""
<p style="margin:18px 0 6px 0;font-size:14px;font-weight:600;color:#333;">Error Breakdown</p>
<table style="border-collapse:collapse;font-size:14px;color:#333;">
  <tr><td style="padding:3px 24px 3px 0;">TCP Timeout</td><td style="font-weight:600;">{tcp_err}</td></tr>
  <tr><td style="padding:3px 24px 3px 0;">Password / Auth</td><td style="font-weight:600;">{pwd_err}</td></tr>
  <tr><td style="padding:3px 24px 3px 0;">Unknown</td><td style="font-weight:600;">{unk_err}</td></tr>
</table>"""

        html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Calibri,Arial,sans-serif;font-size:14px;color:#222;
             line-height:1.6;max-width:680px;margin:0;padding:24px;">

  <p style="margin:0 0 18px 0;">Hi Team,</p>

  <p style="margin:0 0 14px 0;">
    Please find the <strong>{db_label} Oracle DB Connection Check</strong> report attached
    for your review. The report covers all configured customers and environments
    for this run.
  </p>

  <table style="border-collapse:collapse;font-size:14px;color:#333;margin-bottom:18px;">
    <tr>
      <td style="padding:3px 24px 3px 0;color:#555;">Date &amp; Time</td>
      <td style="font-weight:600;">{started}</td>
    </tr>
    <tr>
      <td style="padding:3px 24px 3px 0;color:#555;">Run ID</td>
      <td style="font-weight:600;">#{run_id}</td>
    </tr>
    <tr>
      <td style="padding:3px 24px 3px 0;color:#555;">Completed At</td>
      <td style="font-weight:600;">{ended}</td>
    </tr>
  </table>

  <p style="margin:0 0 6px 0;font-size:14px;font-weight:600;color:#333;">Summary</p>
  <table style="border-collapse:collapse;font-size:14px;color:#333;margin-bottom:18px;">
    <tr><td style="padding:3px 24px 3px 0;">Total Checked</td><td style="font-weight:600;">{total}</td></tr>
    <tr><td style="padding:3px 24px 3px 0;">Connected</td><td style="font-weight:600;color:#155724;">{success}</td></tr>
    <tr><td style="padding:3px 24px 3px 0;">Not Connected</td><td style="font-weight:600;color:#721c24;">{failed}</td></tr>
    <tr><td style="padding:3px 24px 3px 0;">Skipped</td><td style="font-weight:600;color:#856404;">{skipped}</td></tr>
  </table>

  {error_section}

  <p style="margin:18px 0 6px 0;font-size:14px;font-weight:600;color:#333;">
    Customer &amp; Environment Status
  </p>
  <table style="border-collapse:collapse;font-size:14px;color:#333;margin-bottom:18px;">
    {cust_env_lines}
  </table>

  <p style="margin:18px 0 14px 0;font-weight:600;color:{alert_color};">
    {alert_text}
  </p>

  <p style="margin:0 0 4px 0;">
    Please refer to the attached Excel report for full details including
    connection duration, error type, and FMW OAM account expiry status
    per customer and environment.
  </p>

  <p style="margin:24px 0 0 0;">
    Thanks &amp; Regards,<br>
    <strong>RPA Team</strong>
  </p>

</body>
</html>"""

        return html
