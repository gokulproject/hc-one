-- ============================================================
-- dbconnection_checker  —  Full Schema  (v9)
-- Oracle DB Connection Checker
--
-- Fresh install:
--   mysql -u root -p < dbconnection_checker_schema_v8.sql
--
-- Upgrading from v8:
--   mysql -u root -p dbconnection_checker < dbconnection_checker_alter_v8_to_v9.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS dbconnection_checker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE dbconnection_checker;

-- ── Email config ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_config (
    id          INT           NOT NULL AUTO_INCREMENT,
    config_name VARCHAR(100)  NOT NULL DEFAULT 'default',
    smtp_host   VARCHAR(255)  NOT NULL,
    smtp_port   INT           NOT NULL DEFAULT 587,
    smtp_user   VARCHAR(255)  NOT NULL,
    smtp_pass   VARCHAR(255)  NOT NULL,
    use_tls     TINYINT(1)    NOT NULL DEFAULT 1,
    from_addr   VARCHAR(255)  NOT NULL,
    to_addr     TEXT          NOT NULL,
    cc_addr     TEXT          NULL,
    bcc_addr    TEXT          NULL,
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='SMTP and recipient configuration for report emails';


-- ── App config ────────────────────────────────────────────────────────────────
-- Keys: excel_path, log_path, oracle_dll_path,
--       config_customers, config_envs, config_dbtype,
--       report_label, fmw_query
CREATE TABLE IF NOT EXISTS app_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value VARCHAR(2000) NOT NULL DEFAULT '',
    description  VARCHAR(500)  NULL,
    updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Application configuration key-value store';


-- ── Process run — one row per execution ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS process_run (
    id                  INT          NOT NULL AUTO_INCREMENT,
    status              VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',
                        -- RUNNING | COMPLETED | PARTIAL | FAILED | SKIPPED | NO_DATA
    db_type             VARCHAR(100) NULL,

    execution_start_at  DATETIME     NULL COMMENT 'When the run started',
    execution_end_at    DATETIME     NULL COMMENT 'When the run ended',

    total_envs          INT          NOT NULL DEFAULT 0 COMMENT 'Total Oracle DB rows processed',
    success_count       INT          NOT NULL DEFAULT 0 COMMENT 'DB CONNECTED',
    fail_count          INT          NOT NULL DEFAULT 0 COMMENT 'DB NOT CONNECTED',
    skipped_count       INT          NOT NULL DEFAULT 0 COMMENT 'SKIPPED',

    excel_path          VARCHAR(500) NULL COMMENT 'Full path to generated Excel file',
    log_file            VARCHAR(500) NULL COMMENT 'Full path to per-run log file',

    email_sent_status   VARCHAR(20)  NULL COMMENT 'SENT | FAILED | SKIPPED',
    email_sent_error    TEXT         NULL COMMENT 'Error detail if email failed',

    created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='One row per checker execution run';


-- ── Oracle DB connection result — one row per Oracle DB ──────────────────────
CREATE TABLE IF NOT EXISTS process_db_connection_result (
    id                 INT           NOT NULL AUTO_INCREMENT,
    run_id             INT           NOT NULL,
    customer_id        INT           NOT NULL,
    customer_name      VARCHAR(255)  NOT NULL,
    env_type           VARCHAR(50)   NOT NULL,

    -- DB Server (from health_check.Servers)
    server_id          INT           NOT NULL DEFAULT 0,
    server_name        VARCHAR(255)  NOT NULL DEFAULT '',
    server_host        VARCHAR(255)  NOT NULL DEFAULT '',

    -- Oracle DB (from health_check.OracleDatabase)
    db_name            VARCHAR(255)  NOT NULL DEFAULT '',
    db_type            VARCHAR(50)   NOT NULL DEFAULT '',
    db_host            VARCHAR(255)  NOT NULL DEFAULT '',
    db_port            INT           NOT NULL DEFAULT 1521,
    db_service         VARCHAR(255)  NOT NULL DEFAULT '',

    -- Connection result
    connection_status  VARCHAR(20)   NOT NULL DEFAULT 'FAILED',
                       -- COMPLETED | FAILED | SKIPPED
    error_message      TEXT          NULL,
    error_type         VARCHAR(30)   NOT NULL DEFAULT '',
                       -- TCP_TIMEOUT | PASSWORD | UNKNOWN | (empty if connected)

    duration_ms        INT           NOT NULL DEFAULT 0,
    checked_at         DATETIME      NOT NULL,

    PRIMARY KEY (id),
    KEY idx_run_id     (run_id),
    KEY idx_customer   (customer_id),
    KEY idx_env        (env_type),
    KEY idx_db_type    (db_type),
    KEY idx_db_status  (connection_status),
    KEY idx_error_type (error_type),
    KEY idx_checked_at (checked_at),
    CONSTRAINT fk_result_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Oracle DB connection check result per DB entry per run';


-- ── FMW query result — one row per OAM account per FMW DB per run ────────────
-- Populated only when db_type = FMW and connection_status = COMPLETED.
-- FAILED / SKIPPED connections do not write here (query never executed).
CREATE TABLE IF NOT EXISTS fmw_query_result (
    id               INT           NOT NULL AUTO_INCREMENT,

    run_id           INT           NOT NULL COMMENT 'FK → process_run.id',

    customer_name    VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'Customer name (denormalised for reporting)',
    env_type         VARCHAR(50)   NOT NULL DEFAULT ''
                     COMMENT 'DEV | VAL | PRD',

    server_db_info   VARCHAR(500)  NOT NULL DEFAULT ''
                     COMMENT 'Server Host / DB Name / DB Type — display string',

    -- OAM account detail (from DBA_USERS query)
    username         VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.USERNAME',
    account_status   VARCHAR(100)  NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.ACCOUNT_STATUS',
    expiry_date      VARCHAR(50)   NOT NULL DEFAULT ''
                     COMMENT 'DBA_USERS.EXPIRY_DATE (formatted string, empty if NULL)',

    -- Validation result
    action_required  VARCHAR(3)    NOT NULL DEFAULT 'No'
                     COMMENT 'Yes if expiry_date is not null/empty, else No',
    reason           VARCHAR(255)  NOT NULL DEFAULT ''
                     COMMENT 'EXPIRY_DATE value when action_required=Yes, else empty',

    queried_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                     COMMENT 'When the FMW query was executed',

    PRIMARY KEY (id),
    KEY idx_fmw_run_id     (run_id),
    KEY idx_fmw_customer   (customer_name),
    KEY idx_fmw_env        (env_type),
    KEY idx_fmw_action     (action_required),
    KEY idx_fmw_queried_at (queried_at),
    CONSTRAINT fk_fmw_result_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='FMW OAM user expiry query results — one row per account per run';


-- ── Step audit log ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS process_run_log (
    id         INT          NOT NULL AUTO_INCREMENT,
    run_id     INT          NOT NULL,
    step_no    INT          NOT NULL DEFAULT 0,
    step_name  VARCHAR(100) NOT NULL,
    status     VARCHAR(20)  NOT NULL,
    message    TEXT         NULL,
    customer   VARCHAR(255) NULL,
    env_type   VARCHAR(50)  NULL,
    logged_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_run_id  (run_id),
    KEY idx_log_step_no (step_no),
    CONSTRAINT fk_log_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Step-level audit log per run';


-- ── Default app_config rows ───────────────────────────────────────────────────
INSERT INTO app_config (config_key, config_value, description) VALUES
  ('excel_path',
   'Excel',
   'Folder where Excel reports are saved'),

  ('log_path',
   'Logs',
   'Folder where log files are written'),

  ('oracle_dll_path',
   '',
   'Oracle Instant Client folder path (empty = thin mode, WARNING logged)'),

  ('config_customers',
   '',
   'Comma-separated customer names to check; empty = ALL active customers'),

  ('config_envs',
   '',
   'Comma-separated environments to check e.g. DEV,VAL,PRD; empty = ALL'),

  ('config_dbtype',
   'FMW',
   'Database type to check e.g. FMW; comma-separated for multiple types'),

  ('report_label',
   'FMW',
   'Display label used in Excel title and email subject; keep in sync with config_dbtype'),

  ('fmw_query',
   'SELECT USERNAME, ACCOUNT_STATUS, EXPIRY_DATE FROM DBA_USERS WHERE USERNAME LIKE ''%OAM%''',
   'FMW OAM user expiry query — executed on the same connection used for the connectivity check (FMW db_type only). The SELECT and WHERE clause must not be modified. Update only the LIKE pattern if needed.')

ON DUPLICATE KEY UPDATE description = VALUES(description);
-- Note: ON DUPLICATE KEY does NOT overwrite config_value to preserve admin changes.


-- ── Default email_config row ──────────────────────────────────────────────────
INSERT INTO email_config
  (config_name, smtp_host, smtp_port, smtp_user, smtp_pass,
   use_tls, from_addr, to_addr, cc_addr, bcc_addr, is_active)
VALUES
  ('default', 'smtp.company.com', 587,
   'alerts@company.com', 'email_password', 1,
   'alerts@company.com', 'team@company.com', '', '', 1)
ON DUPLICATE KEY UPDATE smtp_host = VALUES(smtp_host);
