# DB Connection Checker — v9

Automated Oracle DB connectivity checker with FMW OAM account expiry validation.
Runs on a schedule, checks all configured customers and environments, generates an
Excel report, and sends an HTML email with the report attached.

---

## What it does

1. Loads configuration from MySQL `app_config` table
2. Reads all active customers, environments, and Oracle DB entries from `health_check` DB
3. For each Oracle DB entry — opens **one** connection:
   - Records connectivity status and duration
   - If `db_type = FMW` and connection succeeded — runs the FMW OAM query on the
     **same open connection**, then closes it
4. Saves results to MySQL (`process_db_connection_result`, `fmw_query_result`)
5. Generates Excel report (see below)
6. Sends HTML email with Excel attached

---

## Excel report structure

### Sheet 1 — DB Connection Check
One row per Oracle DB entry. Columns:

| # | Customer | Environment | Server Name | Server ID | Server Host | DB Name | DB Type | DSN | DB Connection Status | Duration (ms) | Error | Error Type | Checked At (IST) | Expired (Action Required) | Reason (if yes) |

**Expired / Action Required rules:**

| Condition | Expired Column | Reason Column |
|---|---|---|
| Non-FMW db_type | blank | blank |
| FMW + NOT CONNECTED | blank | blank |
| FMW + SKIPPED | blank | blank |
| FMW + CONNECTED + EXPIRY_DATE has a date | Yes / Yes | the date value |
| FMW + CONNECTED + all EXPIRY_DATE empty | No / No | blank |

### Dynamic sheets — one per Customer + Environment (FMW only)
Sheet name: `CustomerName - ENV` e.g. `Acme Corp - PRD`

Row 2 shows the exact FMW query read from `app_config.fmw_query`.

Columns: `Server Host / DB Name / DB Type | USERNAME | ACCOUNT_STATUS | EXPIRY_DATE | Action Required`

**Action Required per row:**

| Condition | Value |
|---|---|
| DB not connected or skipped | blank |
| EXPIRY_DATE has a date | Yes (red) |
| EXPIRY_DATE empty / null | No (green) |

---

## Database tables

| Table | Purpose |
|---|---|
| `app_config` | All application settings including `fmw_query` |
| `email_config` | SMTP and recipient settings |
| `process_run` | One row per execution run |
| `process_db_connection_result` | One row per Oracle DB checked per run |
| `fmw_query_result` | One row per OAM account per FMW DB per run (CONNECTED only) |
| `process_run_log` | Step-level audit log per run |

---

## FMW query

Stored in `app_config` under key `fmw_query`. Read at startup — never hardcoded.

```sql
SELECT USERNAME, ACCOUNT_STATUS, EXPIRY_DATE
FROM DBA_USERS
WHERE USERNAME LIKE '%OAM%'
```

- Executed only when `db_type = FMW` **and** connection succeeded
- Runs on the **same connection** used for the connectivity check — no second connect
- SELECT-only — no changes made to the Oracle DB
- To change the filter, update `config_value` in `app_config` for key `fmw_query`
- Column names `USERNAME`, `ACCOUNT_STATUS`, `EXPIRY_DATE` must remain in the SELECT

---

## Install — fresh

```bash
mysql -u root -p < dbconnection_checker_schema_v8.sql
```

## Upgrade from v8

```bash
mysql -u root -p dbconnection_checker < dbconnection_checker_alter_v8_to_v9.sql
```

---

## Configuration

Update `app_config` table rows:

| Key | Default | Description |
|---|---|---|
| `excel_path` | `Excel` | Folder for Excel reports |
| `log_path` | `Logs` | Folder for log files |
| `oracle_dll_path` | _(empty)_ | Oracle Instant Client path; empty = thin mode |
| `config_customers` | _(empty)_ | Comma-separated customers; empty = ALL |
| `config_envs` | _(empty)_ | Comma-separated envs e.g. `DEV,VAL,PRD`; empty = ALL |
| `config_dbtype` | `FMW` | DB type to check |
| `report_label` | `FMW` | Label shown in Excel and email |
| `fmw_query` | SELECT … | FMW OAM expiry query |

Update `email_config` table for SMTP host, credentials, and recipients.

---

## Files changed in v9

| File | Change |
|---|---|
| `config_loader.py` | Added `fmw_query` field to `AppConfig` |
| `checker.py` | Merged FMW query into same Oracle connection; added `_save_fmw_results` |
| `ExcelCreation/excel_manager.py` | Dynamic per-Customer/Env sheets; expiry columns; blank for failed/skipped |
| `Common/email_manager.py` | HTML email body replacing plain text |
| `process_manager.py` | Passes `fmw_query` to `generate_excel` |
| `dbconnection_checker_schema_v8.sql` | Full schema v9 including `fmw_query_result` table |
| `dbconnection_checker_alter_v8_to_v9.sql` | Alter-only script for existing v8 installs |
