import os
import logging
import sys
from django.apps import AppConfig

logger = logging.getLogger("hc.scheduler")


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """
        Called once when Django starts.
        Starts the built-in background scheduler thread.

        Guard against double-start:
        - Django's dev runserver spawns a *reloader* parent and a *worker* child.
          The child sets RUN_MAIN=true; we only start in the child.
        - In production (gunicorn/uvicorn/waitress) RUN_MAIN is absent → always start.
        - Management commands (migrate, shell, collectstatic) are skipped via
          DJANGO_MANAGEMENT_COMMAND=1.

        No qcluster or external worker is needed.
        The scheduler runs inside this process as a daemon thread.
        """
        # Skip in management commands
        if os.environ.get("DJANGO_MANAGEMENT_COMMAND") == "1":
            return

        is_runserver = "runserver" in " ".join(sys.argv)
        run_main     = os.environ.get("RUN_MAIN")

        # Dev reloader parent process – skip (child will start it)
        if is_runserver and run_main != "true":
            return

        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
            logger.info(
                "[HealthcheckConfig.ready] Scheduler thread started successfully.")
        except Exception as e:
            logger.warning(f"Could not start scheduler thread on startup: {e}")
