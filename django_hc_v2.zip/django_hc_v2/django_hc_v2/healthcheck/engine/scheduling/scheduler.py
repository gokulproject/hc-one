"""
scheduling/scheduler.py  (v6)
==============================
Long-running scheduler loop.

v6 change: Scheduler-level events (fired, completed, next-run) are
now written to execution_logs via RunLogger — the same table and same
format used by manual runs.  The scheduler's own _log() still prints
to console so you can see the [SCHEDULER] prefix output as well.

Console format (unchanged):
  [SCHEDULER] 2026-04-20 01:00:00 | MMS/DEV | Run #8 COMPLETED in 48s

DB execution_logs (new in v6):
  run_id=8, log_level=INFO, py_file=scheduler.py, message="Scheduled run fired"
  run_id=8, log_level=INFO, py_file=scheduler.py, message="Scheduled run COMPLETED in 48s"
"""
import time
import traceback
from datetime import datetime, timedelta

from croniter import croniter

from core.config import ConfigLoader
from core.db_manager import DBManager
from core.logger import RunLogger, SilentLogger
from scheduling.run_launcher import RunLauncher

POLL_SECONDS = 60


class HealthCheckScheduler:

    def __init__(self):
        self._running = True
        self._tick    = 0

    def _log(self, msg: str):
        """Print to console with [SCHEDULER] prefix."""
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[SCHEDULER] {ts} | {msg}", flush=True)

    def _db_log(self, db, run_id: int, level: str, msg: str, cfg=None):
        """
        Write a single log row to execution_logs for scheduler-level events.
        Uses a minimal direct insert so we don't need a full RunLogger instance.
        """
        try:
            log_dir = cfg.log_output_path if cfg else "."
            db.execute_many(
                """INSERT INTO execution_logs
                   (run_id, log_level, py_file, py_module, py_function,
                    py_line, message, logged_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(3))""",
                [(run_id, level.upper(), "scheduler.py", "scheduler",
                  "_db_log", 0, msg)])
        except Exception:
            pass  # Never crash scheduler because of logging

    def start(self):
        self._log("Started. Press Ctrl+C to stop.")
        while self._running:
            try:
                self._tick += 1
                self._log(f"Tick #{self._tick}")
                self._do_tick()
            except Exception as exc:
                self._log(f"ERROR in tick: {exc}\n{traceback.format_exc()}")
            time.sleep(POLL_SECONDS)

    def stop(self):
        self._running = False

    def _do_tick(self):
        with DBManager() as db:
            cfg = ConfigLoader.load(db)
            self._fire_schedules(db, cfg)
            self._process_reruns(db, cfg)
            self._purge_logs(db, cfg)

    # ------------------------------------------------------------------ #
    # Fire scheduled runs
    # ------------------------------------------------------------------ #

    def _fire_schedules(self, db, cfg):
        schedules = db.fetch_all(
            """SELECT s.*, c.name AS cname, c.code AS ccode
               FROM schedules s JOIN customers c ON c.id=s.customer_id
               WHERE s.is_active=1 AND c.is_active=1""")
        now = datetime.now()
        for sched in schedules:
            try:
                cron = croniter(sched["cron_expression"], now - timedelta(minutes=1))
                due  = cron.get_next(datetime)
                last = sched["last_run_at"]
                if now >= due and (last is None or last < due):
                    self._log(
                        f"{sched['cname']}/{sched['env_types']} | "
                        f"{sched['schedule_name']} | Firing")

                    run_id = db.insert_get_id(
                        """INSERT INTO execution_runs
                           (schedule_id, customer_id, env_types,
                            run_type, status, triggered_by)
                           VALUES (%s,%s,%s,'SCHEDULED','PENDING','scheduler')""",
                        (sched["id"], sched["customer_id"], sched["env_types"]))

                    self._log(
                        f"{sched['cname']}/{sched['env_types']} | Run #{run_id} started")

                    # Log scheduler fire event to execution_logs
                    self._db_log(db, run_id, "INFO",
                                 f"Scheduled run fired by scheduler | "
                                 f"schedule='{sched['schedule_name']}' "
                                 f"cron='{sched['cron_expression']}' "
                                 f"customer='{sched['cname']}' "
                                 f"env_types='{sched['env_types']}'",
                                 cfg)

                    t0 = time.time()
                    # RunLauncher uses RunLogger internally — all run steps
                    # are already logged to execution_logs by the launcher
                    RunLauncher(db, run_id, cfg).launch()
                    elapsed = int(time.time() - t0)

                    final  = db.fetch_one(
                        "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
                    status = final["status"] if final else "UNKNOWN"
                    self._log(
                        f"{sched['cname']}/{sched['env_types']} | "
                        f"Run #{run_id} {status} in {elapsed}s")

                    # Log completion event to execution_logs
                    self._db_log(db, run_id, "INFO",
                                 f"Scheduled run {status} in {elapsed}s | "
                                 f"schedule='{sched['schedule_name']}'",
                                 cfg)

                    nxt = croniter(sched["cron_expression"], now).get_next(datetime)
                    db.execute(
                        "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                        (now, nxt, sched["id"]))
                    self._log(
                        f"{sched['cname']}/{sched['env_types']} | "
                        f"Next run: {nxt.strftime('%Y-%m-%d %H:%M')}")

            except Exception as exc:
                self._log(
                    f"Error processing schedule id={sched['id']}: {exc}\n"
                    f"{traceback.format_exc()}")

    # ------------------------------------------------------------------ #
    # Process rerun queue
    # ------------------------------------------------------------------ #

    def _process_reruns(self, db, cfg):
        pending = db.fetch_all(
            """SELECT rq.*, c.name AS cname
               FROM rerun_queue rq
               JOIN customers c ON c.id=rq.customer_id
               WHERE rq.status='PENDING' AND rq.scheduled_at<=NOW()
               ORDER BY rq.scheduled_at""")
        if not pending:
            return
        self._log(f"Processing {len(pending)} pending rerun(s)")

        for entry in pending:
            try:
                db.execute(
                    "UPDATE rerun_queue SET status='IN_PROGRESS', started_at=NOW() WHERE id=%s",
                    (entry["id"],))

                run_id = db.insert_get_id(
                    """INSERT INTO execution_runs
                       (customer_id, env_types, run_type, status, triggered_by,
                        rerun_of_run_id, rerun_attempt)
                       VALUES (%s,%s,'RERUN','PENDING','scheduler_rerun',%s,%s)""",
                    (entry["customer_id"], entry["env_types"],
                     entry["original_run_id"], entry["attempt_number"]))

                self._log(
                    f"{entry['cname']}/{entry['env_types']} | "
                    f"Rerun attempt {entry['attempt_number']}/{entry['max_attempts']} "
                    f"→ Run #{run_id}")

                # Log rerun fire event to execution_logs
                self._db_log(db, run_id, "INFO",
                             f"Rerun attempt {entry['attempt_number']}/{entry['max_attempts']} "
                             f"fired by scheduler | original_run_id={entry['original_run_id']} "
                             f"customer='{entry['cname']}' env_types='{entry['env_types']}'",
                             cfg)

                t0 = time.time()
                RunLauncher(db, run_id, cfg).launch()
                elapsed = int(time.time() - t0)

                final  = db.fetch_one(
                    "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
                status = final["status"] if final else "UNKNOWN"
                run_ok = status in ("COMPLETED", "PARTIAL")

                # Log rerun completion to execution_logs
                self._db_log(db, run_id, "INFO" if run_ok else "WARNING",
                             f"Rerun {status} in {elapsed}s",
                             cfg)

                db.execute(
                    "UPDATE rerun_queue SET status='COMPLETED', completed_at=NOW() WHERE id=%s",
                    (entry["id"],))
                self._log(
                    f"{entry['cname']}/{entry['env_types']} | "
                    f"Rerun #{run_id} {status} in {elapsed}s")

                if not run_ok and entry["attempt_number"] < entry["max_attempts"]:
                    nxt_sched = datetime.now() + timedelta(hours=cfg.rerun_interval_hours)
                    db.execute(
                        """INSERT INTO rerun_queue
                           (original_run_id, customer_id, env_types,
                            attempt_number, max_attempts, status, scheduled_at)
                           VALUES (%s,%s,%s,%s,%s,'PENDING',%s)""",
                        (entry["original_run_id"], entry["customer_id"],
                         entry["env_types"],
                         entry["attempt_number"] + 1, entry["max_attempts"],
                         nxt_sched))
                    self._log(
                        f"{entry['cname']}/{entry['env_types']} | "
                        f"Next rerun at {nxt_sched.strftime('%Y-%m-%d %H:%M')}")

                elif not run_ok:
                    db.execute(
                        """UPDATE rerun_queue SET status='EXHAUSTED'
                           WHERE original_run_id=%s AND status='COMPLETED'""",
                        (entry["original_run_id"],))
                    self._log(
                        f"{entry['cname']}/{entry['env_types']} | "
                        f"All {entry['max_attempts']} reruns exhausted "
                        f"for original run #{entry['original_run_id']}")

                    from notifications.email_service import EmailService
                    customer = db.fetch_one(
                        "SELECT name FROM customers WHERE id=%s", (entry["customer_id"],))
                    cname = customer["name"] if customer else str(entry["customer_id"])
                    EmailService(db, SilentLogger()).send_rerun_exhausted(
                        run_id=entry["original_run_id"],
                        customer_id=entry["customer_id"],
                        customer_name=cname,
                        env_types=entry["env_types"],
                        max_attempts=entry["max_attempts"])

            except Exception as exc:
                self._log(
                    f"Rerun entry id={entry['id']} error: {exc}")
                try:
                    db.execute(
                        "UPDATE rerun_queue SET last_error=%s WHERE id=%s",
                        (str(exc)[:1000], entry["id"]))
                except Exception:
                    pass

    # ------------------------------------------------------------------ #
    # Log purge
    # ------------------------------------------------------------------ #

    def _purge_logs(self, db, cfg):
        try:
            n = db.execute(
                "DELETE FROM execution_logs WHERE logged_at < DATE_SUB(NOW(), INTERVAL %s DAY)",
                (cfg.log_retention_days,))
            if n:
                self._log(f"Purged {n} old log rows (>{cfg.log_retention_days}d)")
        except Exception as exc:
            self._log(f"Log purge failed: {exc}")
