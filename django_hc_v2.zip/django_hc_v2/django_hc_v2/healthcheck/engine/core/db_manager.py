"""
core/db_manager.py
==================
MySQL database connection and query execution.

Features:
  - DictCursor: all rows returned as dicts (access by column name, not index)
  - Auto-reconnect on fetch after idle
  - insert_environment() / insert_oracle_db() auto-encrypt passwords
  - get_config() and get_oracle_query() convenience helpers
"""
import time
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

import pymysql
import pymysql.cursors

from core.config import DB_CONFIG
from utils.crypto import encrypt_password


class DBManager:
    """
    Wraps a single pymysql connection.

    Usage (explicit):
        db = DBManager()
        db.connect()
        rows = db.fetch_all("SELECT * FROM customers WHERE is_active=1")
        db.disconnect()

    Usage (context manager - preferred):
        with DBManager() as db:
            rows = db.fetch_all(...)
    """

    def __init__(self):
        self._conn: Optional[pymysql.Connection] = None
        self._cursor = None

    # ------------------------------------------------------------------ #
    # Connection management
    # ------------------------------------------------------------------ #

    def connect(self, retries: int = 3, delay: int = 5) -> bool:
        """
        Connect to MySQL.  Retries `retries` times with `delay` seconds between.
        Raises ConnectionError after all attempts fail.
        """
        last_exc = None
        for attempt in range(1, retries + 1):
            try:
                self._conn = pymysql.connect(
                    host=DB_CONFIG.host,
                    port=DB_CONFIG.port,
                    user=DB_CONFIG.user,
                    password=DB_CONFIG.password,
                    database=DB_CONFIG.name,
                    charset="utf8mb4",
                    cursorclass=pymysql.cursors.DictCursor,
                    autocommit=False,
                    connect_timeout=15,
                    read_timeout=60,
                    write_timeout=60,
                )
                self._cursor = self._conn.cursor()
                return True
            except Exception as exc:
                last_exc = exc
                if attempt < retries:
                    time.sleep(delay)

        raise ConnectionError(
            f"Cannot connect to MySQL ({DB_CONFIG.host}:{DB_CONFIG.port}/{DB_CONFIG.name}) "
            f"after {retries} attempts. Last error: {last_exc}"
        ) from last_exc

    def disconnect(self):
        """Close cursor and connection, silently ignoring errors."""
        try:
            if self._cursor:
                self._cursor.close()
        except Exception:
            pass
        try:
            if self._conn:
                self._conn.close()
        except Exception:
            pass
        finally:
            self._conn = None
            self._cursor = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False  # Do not suppress exceptions

    def _ensure_connected(self):
        """Ping and reconnect if the connection was dropped."""
        try:
            self._conn.ping(reconnect=True)
        except Exception:
            self.connect()

    # ------------------------------------------------------------------ #
    # Query helpers
    # ------------------------------------------------------------------ #

    def fetch_all(self, sql: str, params: Optional[tuple] = None) -> List[Dict]:
        """Execute SELECT, return all rows as list of dicts."""
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        return self._cursor.fetchall()

    def fetch_one(self, sql: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """Execute SELECT, return first row as dict or None."""
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        return self._cursor.fetchone()

    def execute(self, sql: str, params: Optional[tuple] = None) -> int:
        """
        Execute INSERT / UPDATE / DELETE.
        Returns number of affected rows.
        Auto-commits after execution.
        """
        self._ensure_connected()
        affected = self._cursor.execute(sql, params or ())
        self._conn.commit()
        return affected

    def execute_many(self, sql: str, data: List[tuple]) -> int:
        """
        Bulk INSERT / UPDATE using executemany.
        Returns total affected rows.
        Auto-commits after execution.
        """
        if not data:
            return 0
        self._ensure_connected()
        affected = self._cursor.executemany(sql, data)
        self._conn.commit()
        return affected

    def insert_get_id(self, sql: str, params: Optional[tuple] = None) -> int:
        """
        Execute INSERT and return the auto-generated primary key (lastrowid).
        """
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        self._conn.commit()
        return self._cursor.lastrowid

    @contextmanager
    def transaction(self):
        """
        Context manager for explicit multi-statement transactions.
        Commits on success, rolls back on exception.

        Usage:
            with db.transaction():
                db.execute(sql1)
                db.execute(sql2)
        """
        try:
            yield self
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    # ------------------------------------------------------------------ #
    # Config / query helpers
    # ------------------------------------------------------------------ #

    def get_config(self, key: str, default: str = "") -> str:
        """
        Fetch a single value from system_config by key.
        Returns `default` if the key does not exist.
        """
        row = self.fetch_one(
            "SELECT config_value FROM system_config WHERE config_key=%s",
            (key,),
        )
        return row["config_value"] if row else default

    def get_oracle_query(self, query_key: str) -> str:
        """
        Fetch Oracle SQL from oracle_queries by logical key.
        Raises ValueError if the key is not found or inactive.
        """
        row = self.fetch_one(
            "SELECT query_sql FROM oracle_queries WHERE query_key=%s AND is_active=1",
            (query_key,),
        )
        if not row:
            raise ValueError(
                f"Oracle query key '{query_key}' not found in oracle_queries table. "
                f"Add it with the correct SQL, or check is_active=1."
            )
        return row["query_sql"]

    # ------------------------------------------------------------------ #
    # Password-encrypting insert helpers
    # ------------------------------------------------------------------ #

    def insert_environment(
        self,
        customer_id: int,
        env_type: str,
        server_user: str,
        plain_password: str,
    ) -> int:
        """
        Insert a row into `environments`, automatically encrypting the password.
        Returns the new environment id.

        Example:
            env_id = db.insert_environment(1, 'PRD', 'DOMAIN\\\\svc', 'MyPlainPass')
        """
        encrypted = encrypt_password(plain_password)
        return self.insert_get_id(
            """INSERT INTO environments (customer_id, env_type, server_user, server_pwd)
               VALUES (%s, %s, %s, %s)""",
            (customer_id, env_type, server_user, encrypted),
        )

    def insert_oracle_database(
        self,
        server_id: int,
        db_name: str,
        db_type: str,
        db_user: str,
        plain_password: str,
        port: int = 1521,
    ) -> int:
        """
        Insert a row into `oracle_databases`, automatically encrypting the password.
        Returns the new database id.

        Example:
            db_id = db.insert_oracle_database(1, 'ARGUS', 'Argus', 'argus_user', 'pass')
        """
        encrypted = encrypt_password(plain_password)
        return self.insert_get_id(
            """INSERT INTO oracle_databases
               (server_id, db_name, db_type, db_user, db_pwd, port)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (server_id, db_name, db_type, db_user, encrypted, port),
        )

    def update_environment_password(self, env_id: int, plain_password: str):
        """Update the password for an existing environment row."""
        encrypted = encrypt_password(plain_password)
        self.execute(
            "UPDATE environments SET server_pwd=%s WHERE id=%s",
            (encrypted, env_id),
        )

    def update_oracle_db_password(self, db_id: int, plain_password: str):
        """Update the password for an existing oracle_databases row."""
        encrypted = encrypt_password(plain_password)
        self.execute(
            "UPDATE oracle_databases SET db_pwd=%s WHERE id=%s",
            (encrypted, db_id),
        )
