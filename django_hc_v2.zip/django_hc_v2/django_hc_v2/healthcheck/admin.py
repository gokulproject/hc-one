"""
healthcheck/admin.py
Full Django admin for all HC tables.
Bootstrap-style admin via django-jazzmin or vanilla admin with custom CSS.
"""
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from healthcheck.models import (
    Customer, Environment, Server, OracleDatabase,
    TestCatalog, TestOverride, MailConfig, MailRecipient,
    MailTemplate, SystemConfig, EscalationConfig, Schedule,
    ExecutionRun, EnvRunStatus, ExecutionLog, ServerCheckResult,
    DBCheckResult, TablespaceUsage, RMANBackupDetail,
    IssueTracker, AlertHistory, RerunQueue, RunStepLog,
)

_DB = "healthcheck_db"


class HCAdmin(admin.ModelAdmin):
    """Base admin that reads/writes to healthcheck_db."""

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)

    def save_model(self, request, obj, form, change):
        obj.save(using=_DB)

    def delete_model(self, request, obj):
        obj.delete(using=_DB)

    def delete_queryset(self, request, queryset):
        queryset.using(_DB).delete()


# ──────────────────────────────────────────────────────────────
# Customer & related
# ──────────────────────────────────────────────────────────────

class EnvironmentInline(admin.TabularInline):
    model   = Environment
    extra   = 1
    fields  = ["env_type", "server_user", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


class ServerInline(admin.TabularInline):
    model   = Server
    extra   = 1
    fields  = ["server_role", "server_name", "host", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


@admin.register(Customer)
class CustomerAdmin(HCAdmin):
    list_display    = ["name", "code", "tenant_type", "is_active", "created_at"]
    list_filter     = ["is_active", "tenant_type"]
    search_fields   = ["name", "code"]
    inlines         = [EnvironmentInline]
    list_editable   = ["is_active"]


@admin.register(Environment)
class EnvironmentAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "server_user", "is_active"]
    list_filter   = ["env_type", "is_active"]
    search_fields = ["customer__name", "server_user"]
    inlines       = [ServerInline]

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields["server_pwd"].help_text = (
            "AES-256 encrypted. Use 'python manage.py encrypt_password' "
            "to encrypt a plain password.")
        return form


@admin.register(Server)
class ServerAdmin(HCAdmin):
    list_display   = ["server_name", "server_role", "host", "is_active"]
    list_filter    = ["server_role", "is_active"]
    search_fields  = ["server_name", "host"]


@admin.register(OracleDatabase)
class OracleDatabaseAdmin(HCAdmin):
    list_display   = ["db_name", "db_type", "server", "port", "is_active"]
    list_filter    = ["db_type", "is_active"]
    search_fields  = ["db_name"]


# ──────────────────────────────────────────────────────────────
# Test catalog
# ──────────────────────────────────────────────────────────────

@admin.register(TestCatalog)
class TestCatalogAdmin(HCAdmin):
    list_display  = ["id", "test_name", "category", "server_role", "db_type", "is_active"]
    list_filter   = ["category", "server_role", "db_type", "is_active"]
    list_editable = ["is_active"]
    ordering      = ["display_order"]


@admin.register(TestOverride)
class TestOverrideAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "test_catalog", "is_active", "reason"]
    list_filter   = ["is_active", "env_type"]
    search_fields = ["customer__name", "test_catalog__test_name"]


# ──────────────────────────────────────────────────────────────
# Mail config
# ──────────────────────────────────────────────────────────────

@admin.register(MailConfig)
class MailConfigAdmin(HCAdmin):
    list_display  = ["config_name", "smtp_host", "smtp_port", "from_address", "is_active"]
    list_editable = ["is_active"]


@admin.register(MailRecipient)
class MailRecipientAdmin(HCAdmin):
    list_display  = ["alert_type", "customer", "to_addresses_short", "is_active"]
    list_filter   = ["alert_type", "is_active"]

    def to_addresses_short(self, obj):
        return obj.to_addresses[:60]
    to_addresses_short.short_description = "TO Addresses"


@admin.register(MailTemplate)
class MailTemplateAdmin(HCAdmin):
    list_display  = ["template_key", "subject_template", "is_active"]
    list_editable = ["is_active"]


# ──────────────────────────────────────────────────────────────
# System config
# ──────────────────────────────────────────────────────────────

@admin.register(SystemConfig)
class SystemConfigAdmin(HCAdmin):
    list_display  = ["config_key", "config_value_short", "config_group"]
    list_filter   = ["config_group"]
    search_fields = ["config_key"]

    def config_value_short(self, obj):
        return obj.config_value[:60]
    config_value_short.short_description = "Value"


# ──────────────────────────────────────────────────────────────
# Escalation
# ──────────────────────────────────────────────────────────────

@admin.register(EscalationConfig)
class EscalationConfigAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "threshold", "interval_hours",
                     "is_paused", "paused_until"]
    list_filter   = ["is_paused", "env_type"]
    list_editable = ["is_paused"]


# ──────────────────────────────────────────────────────────────
# Schedules
# ──────────────────────────────────────────────────────────────

@admin.register(Schedule)
class ScheduleAdmin(HCAdmin):
    list_display  = ["schedule_name", "customer", "env_types",
                     "cron_expression", "is_active", "last_run_at", "next_run_at"]
    list_filter   = ["is_active"]
    list_editable = ["is_active"]
    search_fields = ["schedule_name", "customer__name"]


# ──────────────────────────────────────────────────────────────
# Execution runs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionRun)
class ExecutionRunAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "run_type", "status_badge",
                     "triggered_by", "started_at", "duration_display", "latest_step"]
    list_filter   = ["status", "run_type"]
    search_fields = ["customer__name"]
    readonly_fields = ["started_at", "completed_at", "error_summary", "latest_step"]
    ordering      = ["-id"]

    def status_badge(self, obj):
        colors = {
            "COMPLETED": "success", "FAILED": "danger",
            "PARTIAL": "warning", "IN_PROGRESS": "info",
            "PENDING": "secondary",
        }
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"

    def duration_display(self, obj):
        s = obj.duration_seconds()
        return f"{s}s" if s is not None else "—"
    duration_display.short_description = "Duration"


# ──────────────────────────────────────────────────────────────
# Logs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionLog)
class ExecutionLogAdmin(HCAdmin):
    list_display   = ["logged_at", "run_id", "log_level", "py_file", "py_function", "message_short"]
    list_filter    = ["log_level"]
    search_fields  = ["message", "py_file", "py_function"]
    readonly_fields = ["run", "logged_at", "py_file", "py_module",
                       "py_function", "py_line", "message"]

    def message_short(self, obj):
        return obj.message[:80]
    message_short.short_description = "Message"


# ──────────────────────────────────────────────────────────────
# Check results
# ──────────────────────────────────────────────────────────────

@admin.register(ServerCheckResult)
class ServerCheckResultAdmin(HCAdmin):
    list_display   = ["id", "server", "connection_ok", "disk_space_action",
                      "win_update_action", "checked_at"]
    list_filter    = ["connection_ok"]
    readonly_fields = [f.name for f in ServerCheckResult._meta.fields]


@admin.register(DBCheckResult)
class DBCheckResultAdmin(HCAdmin):
    list_display   = ["id", "oracle_db", "connection_ok", "tablespace_action",
                      "rman_action", "checked_at"]
    list_filter    = ["connection_ok", "rman_action"]
    readonly_fields = [f.name for f in DBCheckResult._meta.fields]


@admin.register(TablespaceUsage)
class TablespaceUsageAdmin(HCAdmin):
    list_display  = ["tablespace_name", "used_pct", "used_space_kb", "total_space_kb"]
    list_filter   = []
    search_fields = ["tablespace_name"]


@admin.register(RMANBackupDetail)
class RMANBackupDetailAdmin(HCAdmin):
    list_display  = ["start_time", "end_time", "backup_type", "status"]


# ──────────────────────────────────────────────────────────────
# Issue tracker
# ──────────────────────────────────────────────────────────────

@admin.register(IssueTracker)
class IssueTrackerAdmin(HCAdmin):
    list_display   = ["customer", "env_type", "test_catalog", "consecutive_failures",
                      "total_failures", "status_badge", "last_escalated_at"]
    list_filter    = ["status", "env_type"]
    search_fields  = ["customer__name", "test_catalog__test_name"]

    def status_badge(self, obj):
        colors = {"OPEN": "warning", "ESCALATED": "danger", "RESOLVED": "success"}
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Alert history
# ──────────────────────────────────────────────────────────────

@admin.register(AlertHistory)
class AlertHistoryAdmin(HCAdmin):
    list_display   = ["sent_at", "alert_type", "customer_name", "env_type",
                      "subject_short", "send_status_badge"]
    list_filter    = ["alert_type", "send_status"]
    search_fields  = ["subject", "customer_name"]
    readonly_fields = [f.name for f in AlertHistory._meta.fields]

    def subject_short(self, obj):
        return obj.subject[:60]
    subject_short.short_description = "Subject"

    def send_status_badge(self, obj):
        c = "success" if obj.send_status == "SENT" else "danger"
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.send_status)
    send_status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Rerun queue
# ──────────────────────────────────────────────────────────────

@admin.register(RerunQueue)
class RerunQueueAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "attempt_number",
                     "max_attempts", "status", "scheduled_at"]
    list_filter   = ["status"]


# ──────────────────────────────────────────────────────────────
# Run step log
# ──────────────────────────────────────────────────────────────

@admin.register(RunStepLog)
class RunStepLogAdmin(HCAdmin):
    list_display   = ["run_id", "step_order", "step_name", "status",
                      "started_at", "completed_at", "duration_ms"]
    list_filter    = ["status"]
    readonly_fields = [f.name for f in RunStepLog._meta.fields]


@admin.register(EnvRunStatus)
class EnvRunStatusAdmin(HCAdmin):
    list_display   = ["run_id", "customer", "env_type", "status",
                      "started_at", "completed_at"]
    list_filter    = ["status", "env_type"]
    readonly_fields = [f.name for f in EnvRunStatus._meta.fields]
