"""
healthcheck/views.py  (v6 final)
All Django views. Engine accessed only through engine_bridge.

Changes:
 - All engine imports use engine_bridge (fixes ModuleNotFoundError)
 - Customer/Config views removed (use Django Admin for those)
 - Escalation: full details (last mail, to/cc, customer/env)
 - Scheduler: live run count, queued jobs, pending reruns
 - Alert history: shows cc_addresses
 - Manual run + scheduler fully working
"""
import threading
from datetime import datetime, timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.http import FileResponse, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from healthcheck.models import (
    AlertHistory, Customer, DBCheckResult, Environment, EnvRunStatus,
    EscalationConfig, ExecutionLog, ExecutionRun, IssueTracker,
    MailConfig, MailRecipient, RerunQueue, RMANBackupDetail,
    RunStepLog, Schedule, ServerCheckResult, SystemConfig, TablespaceUsage,
)

_DB = "healthcheck_db"
is_admin = user_passes_test(lambda u: u.is_staff)


def _q(qs):
    return qs.using(_DB)


# ──────────────────────────────────────────────────────────────
# AUTH
# ──────────────────────────────────────────────────────────────

def login_view(request):
    from django.contrib.auth import authenticate, login
    error = None
    if request.method == "POST":
        u = authenticate(request,
                         username=request.POST.get("username"),
                         password=request.POST.get("password"))
        if u:
            login(request, u)
            return redirect(request.GET.get("next", "/"))
        error = "Invalid username or password."
    return render(request, "healthcheck/login.html", {"error": error})


def logout_view(request):
    from django.contrib.auth import logout
    logout(request)
    return redirect("/login/")


# ──────────────────────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    from healthcheck.scheduler_service import scheduler_status

    runs = _q(
        ExecutionRun.objects.select_related("customer").order_by("-id")[:20]
    )
    open_issues = _q(
        IssueTracker.objects.select_related("customer", "test_catalog")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")[:20]
    )
    pending_reruns = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")[:10]
    )
    paused_escalations = _q(
        EscalationConfig.objects.select_related("customer").filter(is_paused=True)
    )
    sched = scheduler_status()

    return render(request, "healthcheck/dashboard.html", {
        "runs":               runs,
        "open_issues":        open_issues,
        "pending_reruns":     pending_reruns,
        "paused_escalations": paused_escalations,
        "scheduler_status":   sched,
        "active_page":        "dashboard",
    })


# ──────────────────────────────────────────────────────────────
# REPORTS
# ──────────────────────────────────────────────────────────────

@login_required
def reports_list(request):
    qs = _q(
        ExecutionRun.objects.select_related("customer")
        .filter(status__in=["COMPLETED", "PARTIAL", "FAILED"])
        .order_by("-id")
    )
    cid  = request.GET.get("customer")
    env  = request.GET.get("env")
    stat = request.GET.get("status")
    if cid:  qs = qs.filter(customer_id=cid)
    if env:  qs = qs.filter(env_types__contains=env)
    if stat: qs = qs.filter(status=stat)

    page = Paginator(qs, 20).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))

    return render(request, "healthcheck/reports_list.html", {
        "page_obj":          page,
        "customers":         customers,
        "active_page":       "reports",
        "selected_customer": cid,
        "selected_env":      env,
        "selected_status":   stat,
    })


@login_required
def report_detail(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    env_statuses = _q(
        EnvRunStatus.objects.filter(run=run).order_by("env_type"))

    env_data   = []
    has_action = False

    for es in env_statuses:
        server_checks = list(
            _q(ServerCheckResult.objects.select_related("server")
               .filter(env_status=es)))
        db_checks_raw = list(
            _q(DBCheckResult.objects.select_related("server", "oracle_db")
               .filter(env_status=es)))

        for sc in server_checks:
            if sc.any_action(): has_action = True

        db_check_data = []
        for dc in db_checks_raw:
            if dc.any_action(): has_action = True
            db_check_data.append({
                "check":     dc,
                "ts_rows":   list(_q(TablespaceUsage.objects
                                     .filter(db_check=dc)
                                     .order_by("-used_pct"))),
                "rman_rows": list(_q(RMANBackupDetail.objects
                                     .filter(db_check=dc))),
            })

        env_data.append({
            "env_status":    es,
            "server_checks": server_checks,
            "db_checks":     db_check_data,
        })

    step_log      = _q(RunStepLog.objects.filter(run=run).order_by("step_order"))
    alerts        = _q(AlertHistory.objects.filter(run=run).order_by("-sent_at"))
    action_filter = request.GET.get("action")

    return render(request, "healthcheck/report_detail.html", {
        "run":           run,
        "env_data":      env_data,
        "step_log":      step_log,
        "alerts":        alerts,
        "has_action":    has_action,
        "action_filter": action_filter,
        "active_page":   "reports",
    })


@login_required
def download_excel(request, run_id):
    from healthcheck.engine_bridge import get_engine
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            gen = eng["ExcelReportGenerator"](
                db, run_id, eng["SilentLogger"]())
            filepath, title = gen.generate()

        import os
        dl_date  = datetime.now().strftime("%d-%b-%Y")
        orig     = os.path.basename(filepath)
        dl_name  = orig.replace(".xlsx", f"_DL-{dl_date}.xlsx")
        return FileResponse(
            open(filepath, "rb"),
            content_type=(
                "application/vnd.openxmlformats-officedocument"
                ".spreadsheetml.sheet"),
            as_attachment=True,
            filename=dl_name,
        )
    except Exception as exc:
        messages.error(request, f"Could not generate Excel: {exc}")
        return redirect("report_detail", run_id=run_id)


# ──────────────────────────────────────────────────────────────
# LOGS
# ──────────────────────────────────────────────────────────────

@login_required
def run_logs(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    qs  = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))
    lvl = request.GET.get("level")
    if lvl:
        qs = qs.filter(log_level=lvl)
    page = Paginator(qs, 200).get_page(request.GET.get("page", 1))
    return render(request, "healthcheck/run_logs.html", {
        "run":          run,
        "page_obj":     page,
        "level_filter": lvl,
        "log_levels":   ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        "active_page":  "reports",
    })


@login_required
def download_logs(request, run_id):
    run  = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    logs = _q(ExecutionLog.objects.filter(run=run).order_by("logged_at"))
    lines = [
        f"{log.logged_at.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} "
        f"[{log.log_level:<8}] "
        f"[{log.py_file}::{log.py_function}():L{log.py_line}] "
        f"{log.message}"
        for log in logs
    ]
    fname = (f"run_{run_id}_{run.customer.name}_"
             f"{datetime.now().strftime('%Y%m%d')}.log")
    resp = HttpResponse("\n".join(lines),
                        content_type="text/plain; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="{fname}"'
    return resp


# ──────────────────────────────────────────────────────────────
# ESCALATION  (full detail: last mail, to/cc, customer/env)
# ──────────────────────────────────────────────────────────────

@login_required
def escalation_view(request):
    issues = _q(
        IssueTracker.objects.select_related(
            "customer", "test_catalog",
            "first_failed_run", "last_failed_run")
        .filter(status__in=["OPEN", "ESCALATED"])
        .order_by("-consecutive_failures")
    )
    esc_configs = _q(
        EscalationConfig.objects.select_related("customer").all())

    # Last escalation mail per customer/env
    last_mails = {}
    for issue in issues:
        key = (issue.customer_id, issue.env_type)
        if key not in last_mails:
            mail = _q(
                AlertHistory.objects
                .filter(alert_type="ESCALATION",
                        customer_id=issue.customer_id,
                        env_type=issue.env_type)
                .order_by("-sent_at")
                .first()
            )
            last_mails[key] = mail

    # Attach last_mail to each issue
    issues_with_mail = []
    for issue in issues:
        key = (issue.customer_id, issue.env_type)
        issues_with_mail.append({
            "issue":     issue,
            "last_mail": last_mails.get(key),
        })

    return render(request, "healthcheck/escalation.html", {
        "issues_with_mail": issues_with_mail,
        "esc_configs":      esc_configs,
        "active_page":      "escalation",
    })


@login_required
@is_admin
@require_POST
def pause_escalation(request, pk):
    obj = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    hours  = int(request.POST.get("hours", 168))
    reason = request.POST.get("reason", "Manual pause")
    obj.is_paused    = True
    obj.paused_until = datetime.utcnow() + timedelta(hours=hours)
    obj.pause_reason = reason
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation paused for {obj.customer.name}/{obj.env_type} "
        f"for {hours}h.")
    return redirect("escalation")


@login_required
@is_admin
@require_POST
def resume_escalation(request, pk):
    obj = get_object_or_404(_q(EscalationConfig.objects), pk=pk)
    obj.is_paused    = False
    obj.paused_until = None
    obj.pause_reason = ""
    obj.save(using=_DB)
    messages.success(
        request,
        f"Escalation resumed for {obj.customer.name}/{obj.env_type}.")
    return redirect("escalation")


# ──────────────────────────────────────────────────────────────
# RERUN
# ──────────────────────────────────────────────────────────────

@login_required
def rerun_view(request):
    pending = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")
    )
    recent = _q(
        RerunQueue.objects.select_related("customer", "original_run")
        .exclude(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("-created_at")[:20]
    )
    return render(request, "healthcheck/rerun.html", {
        "pending":     pending,
        "recent":      recent,
        "active_page": "rerun",
    })


@login_required
@is_admin
@require_POST
def trigger_rerun(request, run_id):
    from healthcheck.engine_bridge import get_engine
    from healthcheck.scheduler_service import _execute_run
    eng = get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run = db.fetch_one(
                "SELECT * FROM execution_runs WHERE id=%s", (run_id,))
            if not run:
                messages.error(request, f"Run #{run_id} not found.")
                return redirect("rerun")
            cust = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s",
                (run["customer_id"],))
            cname = cust["name"] if cust else str(run["customer_id"])
            new_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by,
                    rerun_of_run_id,rerun_attempt)
                   VALUES(%s,%s,'RERUN','PENDING','admin:rerun',%s,1)""",
                (run["customer_id"], run["env_types"], run_id))

        t = threading.Thread(
            target=_execute_run,
            args=(new_id, f"{cname}/{run['env_types']}"),
            daemon=True, name=f"hc_rerun_{new_id}")
        t.start()
        messages.success(request,
                         f"Rerun #{new_id} started in background.")
    except Exception as exc:
        messages.error(request, f"Error: {exc}")
    return redirect("rerun")


# ──────────────────────────────────────────────────────────────
# ALERT HISTORY  (shows to + cc)
# ──────────────────────────────────────────────────────────────

@login_required
def alert_history(request):
    qs = _q(AlertHistory.objects.order_by("-sent_at"))
    alert_type = request.GET.get("type")
    cid        = request.GET.get("customer")
    if alert_type: qs = qs.filter(alert_type=alert_type)
    if cid:        qs = qs.filter(customer_id=cid)

    page      = Paginator(qs, 30).get_page(request.GET.get("page", 1))
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))

    return render(request, "healthcheck/alert_history.html", {
        "page_obj":     page,
        "customers":    customers,
        "alert_types":  ["SUCCESS", "FAILURE", "ESCALATION", "RERUN_FAILURE"],
        "sel_type":     alert_type,
        "sel_customer": cid,
        "active_page":  "alerts",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Manual Run
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def manual_run(request):
    customers = _q(Customer.objects.filter(is_active=True).order_by("name"))
    if request.method == "POST":
        customer_id = request.POST.get("customer_id")
        env_types   = request.POST.get("env_types", "").upper().strip()
        if customer_id and env_types:
            from healthcheck.scheduler_service import run_customer_now
            run_id = run_customer_now(int(customer_id), env_types)
            if run_id:
                messages.success(
                    request,
                    f"Run #{run_id} started. Check dashboard for live status.")
                return redirect("dashboard")
            messages.error(request,
                           "Failed to start run. Check server logs.")
        else:
            messages.error(request, "Select customer and environment.")

    return render(request, "healthcheck/manual_run.html", {
        "customers":   customers,
        "active_page": "manual_run",
    })


# ──────────────────────────────────────────────────────────────
# ADMIN: Scheduler
# ──────────────────────────────────────────────────────────────

@login_required
@is_admin
def scheduler_view(request):
    from healthcheck.scheduler_service import scheduler_status
    schedules = _q(
        Schedule.objects.select_related("customer").order_by("customer__name"))
    pending_reruns = _q(
        RerunQueue.objects.select_related("customer")
        .filter(status__in=["PENDING", "IN_PROGRESS"])
        .order_by("scheduled_at")
    )
    return render(request, "healthcheck/scheduler.html", {
        "sched_status":  scheduler_status(),
        "schedules":     schedules,
        "pending_reruns": pending_reruns,
        "active_page":   "scheduler",
    })


@login_required
@is_admin
@require_POST
def scheduler_action(request):
    from healthcheck.scheduler_service import (
        start_scheduler, stop_scheduler,
        restart_scheduler, run_now_sync)

    action = request.POST.get("action")
    if action == "start":
        start_scheduler()
        messages.success(request, "Scheduler started.")
    elif action == "stop":
        stop_scheduler()
        messages.success(request, "Scheduler stopped.")
    elif action == "restart":
        restart_scheduler()
        messages.success(request,
                         "Scheduler restarted — schedules reloaded from DB.")
    elif action == "run_now":
        sched_id = int(request.POST.get("schedule_id", 0))
        run_id   = run_now_sync(sched_id)
        if run_id:
            messages.success(
                request,
                f"Schedule fired — Run #{run_id} running in background.")
        else:
            messages.error(
                request, "Could not fire schedule. Check server logs.")
    return redirect("scheduler")


# ──────────────────────────────────────────────────────────────
# API (JSON endpoints for live polling)
# ──────────────────────────────────────────────────────────────

@login_required
def api_run_status(request, run_id):
    run = get_object_or_404(
        _q(ExecutionRun.objects.select_related("customer")), id=run_id)
    return JsonResponse({
        "id":           run.id,
        "status":       run.status,
        "latest_step":  run.latest_step or "",
        "started_at":   run.started_at.isoformat()   if run.started_at  else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    })


@login_required
def api_scheduler_status(request):
    from healthcheck.scheduler_service import scheduler_status
    return JsonResponse(scheduler_status())


@login_required
def api_recent_runs(request):
    """Live dashboard data — last 20 runs."""
    runs = _q(
        ExecutionRun.objects.select_related("customer").order_by("-id")[:20])
    data = [{
        "id":           r.id,
        "customer":     r.customer.name,
        "env_types":    r.env_types,
        "status":       r.status,
        "latest_step":  r.latest_step or "",
        "started_at":   r.started_at.strftime("%Y-%m-%d %H:%M") if r.started_at else "—",
        "duration":     f"{r.duration_seconds()}s" if r.started_at and r.completed_at else "—",
    } for r in runs]
    return JsonResponse({"runs": data})
