"""
django_hc/settings.py
Two databases:
  - default       : Django auth, sessions, admin (SQLite for dev)
  - healthcheck_db: hc_v5 MySQL (all HC tables, managed=False)
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY",
    "django-insecure-hc-v6-change-in-production-abc123xyz")

DEBUG = os.environ.get("DJANGO_DEBUG", "True") == "True"

ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "*").split(",")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "healthcheck",
]

MIDDLEWARE = [
    "healthcheck.middleware.DBConnectionMiddleware",   # ← must be first to catch DB errors
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "django_hc.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "django_hc.wsgi.application"
ASGI_APPLICATION  = "django_hc.asgi.application"

# ──────────────────────────────────────────────────────────────
# DATABASES
# default       → Django internals (SQLite, safe to delete)
# healthcheck_db → MySQL hc_v5 (all HC data)
# ──────────────────────────────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    },
    "healthcheck_db": {
        "ENGINE": "django.db.backends.mysql",
        "NAME":    os.environ.get("HC_DB_NAME",     "hc_v5"),
        "USER":    os.environ.get("HC_DB_USER",     "hc_user"),
        "PASSWORD":os.environ.get("HC_DB_PASSWORD", ""),
        "HOST":    os.environ.get("HC_DB_HOST",     "localhost"),
        "PORT":    os.environ.get("HC_DB_PORT",     "3306"),
        # CONN_MAX_AGE=0 → each request opens a fresh connection and closes it
        # immediately on completion, so no connection idles while holding a lock.
        "CONN_MAX_AGE": 0,
        "OPTIONS": {
            "charset": "utf8mb4",
            # Keep strict mode AND set a short lock-wait timeout so Django ORM
            # writes (admin saves) never block the scheduler's concurrent UPDATE
            # on the same schedules row for longer than 15 s.
            # Previously this was missing → Django used the MySQL global default
            # (innodb_lock_wait_timeout = 50 s), which caused error 1205 because
            # the scheduler's pymysql connection timed out waiting for Django's
            # admin-save transaction to release its row lock.
            "init_command": (
                "SET sql_mode='STRICT_TRANS_TABLES', "
                "innodb_lock_wait_timeout=15"
            ),
        },
        # Do NOT wrap every request in a transaction; admin saves are committed
        # immediately by HCAdmin.save_model(obj.save(using=_DB)).  Wrapping in
        # ATOMIC_REQUESTS keeps the row lock open for the entire HTTP round-trip
        # (including template rendering) and dramatically widens the window in
        # which the scheduler's UPDATE hits error 1205.
        "ATOMIC_REQUESTS": False,
    },
}

DATABASE_ROUTERS = ["healthcheck.db_router.HCRouter"]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE     = "Asia/Kolkata"
USE_I18N      = True
USE_TZ        = True

STATIC_URL  = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "/healthcheck/login/"
LOGIN_REDIRECT_URL = "/healthcheck/"
LOGOUT_REDIRECT_URL = "/healthcheck/login/"

# HC engine env vars (used by engine/core/config.py)
HC_ENC_KEY = os.environ.get("HC_ENC_KEY", "default-32-byte-key-change-me!!")

# Install pymysql as MySQLdb replacement (no C extension needed)
try:
    import pymysql
    pymysql.install_as_MySQLdb()
except ImportError:
    pass  # Will fail clearly on missing package

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{asctime} [{levelname}] {name}: {message}",
            "style": "{",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "verbose",
        },
    },
    "loggers": {
        "hc.scheduler": {"handlers": ["console"], "level": "INFO", "propagate": False},
        "django": {"handlers": ["console"], "level": "WARNING"},
    },
}
