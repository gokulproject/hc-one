# Health Check v6 — Django Setup Guide

## Quick Start

```bash
# 1. Create DB (first time only)
mysql -u admin -p < healthcheck/engine/fresh_schema.sql
mysql -u admin -p hc_v5 < healthcheck/engine/alter_v6.sql

# 2. Install Python deps
pip install -r requirements.txt

# 3. Set environment variables
export HC_DB_HOST=your-rds-host.amazonaws.com
export HC_DB_NAME=hc_v5
export HC_DB_USER=admin
export HC_DB_PASSWORD=YourPassword
export DJANGO_SECRET_KEY=your-secret-key-change-in-production

# 4. Django setup (uses SQLite for auth/sessions)
python manage.py migrate
python manage.py createsuperuser

# 5. Run
python manage.py runserver
```

Open: http://localhost:8000/

---

## Project Structure

```
django_hc/
├── manage.py
├── requirements.txt
├── SETUP.md
│
├── django_hc/           ← Django project config
│   ├── settings.py      ← Dual DB setup
│   └── urls.py
│
└── healthcheck/         ← Single Django app (all HC code)
    ├── engine/          ← hcv6 engine (unchanged)
    │   ├── core/
    │   ├── checks/
    │   ├── notifications/
    │   ├── reports/
    │   ├── scheduling/
    │   └── utils/
    ├── models.py         ← Django models (managed=False, point to hc_v5)
    ├── views.py          ← All views
    ├── urls.py           ← URL routing
    ├── admin.py          ← Django admin for ALL HC tables
    ├── forms.py          ← Forms for customer/env/schedule
    ├── db_router.py      ← Routes HC models to healthcheck_db
    ├── scheduler_service.py  ← APScheduler wrapper (async, no extra tables)
    └── templates/healthcheck/
        ├── base.html     ← Bootstrap 5 sidebar layout
        ├── dashboard.html
        ├── reports_list.html
        ├── report_detail.html  ← Full check results + tablespace + RMAN
        ├── run_logs.html
        ├── escalation.html
        ├── rerun.html
        ├── scheduler.html
        ├── manual_run.html
        ├── customer_list.html
        ├── customer_form.html
        ├── environment_form.html
        └── config_list.html
```

---

## Databases

| Database | Purpose | Migrations |
|----------|---------|------------|
| `default` (SQLite) | Django auth, sessions, admin | `python manage.py migrate` |
| `healthcheck_db` (MySQL hc_v5) | All HC data | Managed by `fresh_schema.sql` / `alter_v6.sql` |

The `HCRouter` in `db_router.py` ensures HC models never touch the default DB.

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `HC_DB_HOST` | localhost | MySQL host |
| `HC_DB_NAME` | hc_v5 | MySQL database name |
| `HC_DB_USER` | admin | MySQL user |
| `HC_DB_PASSWORD` | — | MySQL password |
| `HC_ENC_KEY` | (built-in) | AES encryption key for passwords |
| `DJANGO_SECRET_KEY` | (insecure default) | **Change in production** |
| `DJANGO_DEBUG` | True | Set to False in production |

---

## User Roles

| Role | Access |
|------|--------|
| Regular user | Dashboard, Reports (view+download), Escalations, Reruns |
| Staff (`is_staff=True`) | All above + Manual Run, Scheduler control, Customer management, Config |

---

## Encrypt a Password

```bash
python manage.py encrypt_password
# Enter plain password → copy encrypted value → store in DB
```

Or use the engine directly:
```python
from healthcheck.engine.utils.crypto import encrypt_password
encrypted = encrypt_password("MyPlainPassword")
```

---

## Scheduler (APScheduler)

The scheduler starts automatically when Django starts (`apps.py`).
It uses `BackgroundScheduler` with an **in-memory job store** — no extra DB tables needed.
Up to 20 schedules can run simultaneously in separate threads.

Schedule control:
- **Start/Stop/Restart** from the Scheduler page (admin only)
- **Run Now** fires any schedule immediately
- Schedules refresh from DB every 5 minutes automatically

---

## Django Admin

Go to: http://localhost:8000/admin/

All HC tables are fully editable from Django Admin including:
- Customers, Environments, Servers, Oracle DBs
- Test Catalog (enable/disable globally)
- Test Overrides (per customer/env)
- Mail Config, Recipients, Templates
- System Config
- Escalation Config
- Schedules
- Execution Runs, Logs, Step Logs
- Issue Tracker, Alert History, Rerun Queue

A "Django Admin" link is in the sidebar for staff users.

---

## Fresh Database (from hcdata.sql)

```bash
# Load existing data
mysql -u admin -p hc_v5 < healthcheck/engine/fresh_schema.sql

# Apply v6 additions (run_step_log, latest_step column)
mysql -u admin -p hc_v5 < healthcheck/engine/alter_v6.sql
```

The MMS/DEV customer and environment from hcdata.sql are included.
Re-encrypt the oracle_databases password:
```bash
python manage.py encrypt_password
# Then: UPDATE oracle_databases SET db_pwd='...' WHERE db_name='MMSDDB';
```
