"""
healthcheck/middleware.py
=========================
Global middleware that catches database connectivity errors and
returns a clean maintenance page instead of a raw Django 500.

Handles:
  - pymysql OperationalError / InterfaceError
  - Django's django.db.utils.OperationalError
  - Our custom DBConnectionError
  - Any ConnectionError from the engine layer

The scheduler and engine continue running even when this middleware
intercepts errors — only the HTTP response is affected.
"""
import logging

from django.http import HttpResponse
from django.template import loader, TemplateDoesNotExist

logger = logging.getLogger("hc.middleware")

_DB_ERROR_TYPES = (
    ConnectionError,          # base class covers DBConnectionError
)

# Try to import DB-specific error types gracefully
try:
    import pymysql.err as _pe
    _DB_ERROR_TYPES += (_pe.OperationalError, _pe.InterfaceError)
except ImportError:
    pass

try:
    from django.db.utils import OperationalError as _dj_op, \
                                 InterfaceError   as _dj_if
    _DB_ERROR_TYPES += (_dj_op, _dj_if)
except ImportError:
    pass


_MAINTENANCE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Health Check — Database Unavailable</title>
<link rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
  body {{ background:#f4f8fb; display:flex; align-items:center;
          justify-content:center; min-height:100vh; }}
  .card {{ max-width:520px; border:none;
           box-shadow:0 2px 16px rgba(0,58,95,.15); border-radius:12px; }}
  .header-bar {{ background:#003A5F; color:#fff;
                 border-radius:12px 12px 0 0; padding:1.4rem 1.6rem; }}
</style>
</head>
<body>
  <div class="card w-100 mx-3">
    <div class="header-bar">
      <h5 class="mb-0">&#9888; Health Check — Database Unavailable</h5>
    </div>
    <div class="card-body p-4">
      <p class="mb-2">
        The health-check database is temporarily unreachable.<br>
        The monitoring engine and scheduler are still running in the background.
      </p>
      <div class="alert alert-warning py-2 small mb-3">
        <strong>Error:</strong> {error}
      </div>
      <p class="text-muted small mb-3">
        This page will refresh automatically every 30 seconds.<br>
        Contact your DBA if the issue persists beyond a few minutes.
      </p>
      <a href="javascript:location.reload()"
         class="btn btn-sm text-white" style="background:#003A5F">
        &#8635; Retry Now
      </a>
    </div>
  </div>
  <script>setTimeout(()=>location.reload(), 30000);</script>
</body>
</html>
"""


class DBConnectionMiddleware:
    """
    Process-exception middleware.
    Catches DB connectivity errors from any view and returns a 503
    maintenance page with auto-refresh.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_exception(self, request, exception):
        if isinstance(exception, _DB_ERROR_TYPES):
            err_msg = str(exception)
            logger.error(
                f"[DBMiddleware] DB connection error on {request.path}: {err_msg}")

            # Try to render a nice template if available, else use inline HTML
            try:
                tpl = loader.get_template("healthcheck/db_error.html")
                html = tpl.render({"error": err_msg}, request)
            except TemplateDoesNotExist:
                html = _MAINTENANCE_HTML.format(error=err_msg)

            return HttpResponse(html, status=503,
                                content_type="text/html; charset=utf-8")

        return None   # let other exceptions propagate normally
