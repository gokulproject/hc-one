from django import forms
from healthcheck.models import Customer, Environment, Schedule, EscalationConfig


class CustomerForm(forms.ModelForm):
    class Meta:
        model  = Customer
        fields = ["name", "code", "tenant_type", "is_active", "notes"]
        widgets = {
            "name":        forms.TextInput(attrs={"class": "form-control"}),
            "code":        forms.TextInput(attrs={"class": "form-control"}),
            "tenant_type": forms.Select(
                choices=[("Single","Single"),("Multi","Multi")],
                attrs={"class": "form-select"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }


class EnvironmentForm(forms.ModelForm):
    # Extra field for plain password input (not stored directly)
    plain_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={"class": "form-control",
                                          "placeholder": "Leave blank to keep existing"}),
        help_text="Enter new password (will be AES-256 encrypted). Leave blank to keep existing.",
    )

    class Meta:
        model  = Environment
        fields = ["customer", "env_type", "server_user", "is_active", "notes"]
        widgets = {
            "customer":   forms.Select(attrs={"class": "form-select"}),
            "env_type":   forms.Select(
                choices=[("PRD","Production"),("VAL","Validation"),("DEV","Development")],
                attrs={"class": "form-select"}),
            "server_user": forms.TextInput(attrs={"class": "form-control",
                                                   "placeholder": "DOMAIN\\\\username"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Load customer choices from healthcheck_db
        try:
            from healthcheck.models import Customer
            self.fields["customer"].queryset = Customer.objects.using("healthcheck_db").filter(is_active=True)
        except Exception:
            pass


class ScheduleForm(forms.ModelForm):
    ENV_CHOICES = [
        ("PRD", "Production (PRD)"),
        ("VAL", "Validation (VAL)"),
        ("DEV", "Development (DEV)"),
        ("PRD,VAL", "PRD + VAL"),
        ("PRD,VAL,DEV", "PRD + VAL + DEV"),
    ]

    CRON_CHOICES = [
        ("", "── Custom (type below) ──"),
        ("0 */1 * * *",  "Every 1 hour"),
        ("0 */2 * * *",  "Every 2 hours"),
        ("0 */4 * * *",  "Every 4 hours"),
        ("0 */6 * * *",  "Every 6 hours"),
        ("0 */12 * * *", "Every 12 hours"),
        ("0 0 * * *",    "Daily at midnight"),
        ("0 8 * * *",    "Daily at 8:00 AM"),
        ("0 18 * * *",   "Daily at 6:00 PM"),
        ("0 8 * * 1-5",  "Weekdays at 8:00 AM"),
        ("0 0 * * 0",    "Weekly (Sunday midnight)"),
        ("*/5 * * * *",  "Every 5 minutes"),
        ("*/10 * * * *", "Every 10 minutes"),
        ("*/15 * * * *", "Every 15 minutes"),
        ("*/30 * * * *", "Every 30 minutes"),
    ]

    env_types = forms.ChoiceField(
        choices=ENV_CHOICES,
        widget=forms.Select(attrs={"class": "form-select"}),
        help_text="Select the environment(s) this schedule runs against.",
    )

    cron_preset = forms.ChoiceField(
        choices=CRON_CHOICES,
        required=False,
        label="Cron Preset",
        widget=forms.Select(attrs={
            "class": "form-select",
            "onchange": "if(this.value){document.getElementById('id_cron_expression').value=this.value}",
        }),
        help_text="Choose a preset or type a custom cron expression below.",
    )

    start_at = forms.DateTimeField(
        required=False,
        widget=forms.DateTimeInput(attrs={
            "class": "form-control",
            "type": "datetime-local",
        }),
        help_text=(
            "First execution time (IST). Leave blank to fire at next cron tick. "
            "Format: YYYY-MM-DD HH:MM"
        ),
        label="Start At (IST)",
    )

    class Meta:
        model  = Schedule
        fields = ["customer", "env_types", "schedule_name",
                  "cron_expression", "start_at", "is_active", "notes"]
        widgets = {
            "customer":        forms.Select(attrs={"class": "form-select"}),
            "schedule_name":   forms.TextInput(attrs={"class": "form-control"}),
            "cron_expression": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "e.g. 0 1 * * 0  (every Sunday at 1 AM IST)",
                "id": "id_cron_expression",
            }),
            "is_active":       forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":           forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try:
            from healthcheck.models import Customer
            self.fields["customer"].queryset = Customer.objects.using("healthcheck_db").filter(is_active=True)
        except Exception:
            pass
        # If editing, pre-populate env_types as choice; fall back to text if not in list
        if self.instance and self.instance.pk:
            existing_env = self.instance.env_types
            choices = [c[0] for c in self.ENV_CHOICES]
            if existing_env not in choices:
                # Add as custom option so it round-trips
                self.fields["env_types"].choices = self.ENV_CHOICES + [(existing_env, existing_env)]
            if self.instance.start_at:
                from healthcheck.ist_utils import utc_to_ist
                ist_val = utc_to_ist(self.instance.start_at)
                self.fields["start_at"].initial = ist_val.strftime("%Y-%m-%dT%H:%M")

    def clean_start_at(self):
        """Accept IST input → convert to UTC for DB storage."""
        dt = self.cleaned_data.get("start_at")
        if dt is None:
            return None
        from datetime import timedelta
        IST_OFFSET = timedelta(hours=5, minutes=30)
        import django.utils.timezone as djtz
        if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
            return dt
        return dt - IST_OFFSET  # naive IST → naive UTC


class EscalationConfigForm(forms.ModelForm):
    class Meta:
        model  = EscalationConfig
        fields = ["threshold", "interval_hours", "max_escalations", "notify_rerun_fail"]
        widgets = {
            "threshold":       forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "interval_hours":  forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "max_escalations": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "notify_rerun_fail": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
