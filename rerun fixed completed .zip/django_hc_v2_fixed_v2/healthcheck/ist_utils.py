"""
healthcheck/ist_utils.py
========================
Central IST (Asia/Kolkata) timezone utilities used by views, scheduler,
templates, and API.

Story:
  - MySQL server stores DATETIME in UTC (server local time)
  - Admin/Users see ONLY IST 12-hour format everywhere
  - All datetime inputs from admin panel are IST → stored as UTC in DB
  - All datetime outputs from DB are UTC → converted to IST for display
"""
from datetime import datetime, timedelta, timezone as _tz

IST_OFFSET  = timedelta(hours=5, minutes=30)
IST_TZ_NAME = "Asia/Kolkata"
IST         = _tz(IST_OFFSET, "IST")

FMT_12H  = "%d-%b-%Y %I:%M %p"   # 27-Apr-2026 04:43 PM
FMT_12HS = "%d-%b-%Y %I:%M:%S %p" # 27-Apr-2026 04:43:21 PM
FMT_DB   = "%Y-%m-%d %H:%M:%S"   # MySQL format (UTC)


def now_ist() -> datetime:
    """Return current time as naive IST datetime."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(IST_TZ_NAME)).replace(tzinfo=None)
    except Exception:
        return datetime.utcnow() + IST_OFFSET


def now_utc() -> datetime:
    """Return current UTC as naive datetime."""
    return datetime.utcnow()


def ist_to_utc(dt: datetime) -> datetime:
    """
    Convert admin-entered IST datetime → UTC for DB storage.
    Input: naive datetime treated as IST
    Output: naive datetime in UTC
    """
    if dt is None:
        return None
    if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
        # Already timezone-aware → convert to UTC
        return dt.astimezone(_tz.utc).replace(tzinfo=None)
    # Naive → treat as IST → subtract 5:30 to get UTC
    return dt - IST_OFFSET


def utc_to_ist(dt: datetime) -> datetime:
    """
    Convert DB UTC datetime → IST for display.
    Input: naive datetime from MySQL (UTC)
    Output: naive datetime in IST
    """
    if dt is None:
        return None
    if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
        try:
            from zoneinfo import ZoneInfo
            return dt.astimezone(ZoneInfo(IST_TZ_NAME)).replace(tzinfo=None)
        except Exception:
            return dt.replace(tzinfo=None) + IST_OFFSET
    # Naive → assume UTC → add 5:30
    return dt + IST_OFFSET


def fmt_ist(dt: datetime, fmt: str = FMT_12H) -> str:
    """Format a DB datetime (UTC) as IST 12-hour string."""
    if dt is None:
        return "—"
    return utc_to_ist(dt).strftime(fmt)


def fmt_ist_short(dt: datetime) -> str:
    return fmt_ist(dt, FMT_12H)


def next_run_from_start_at(cron_expression: str,
                            start_at_ist: datetime) -> datetime:
    """
    Given a start_at in IST, compute the first cron fire time.
    The cron expression tick is anchored to start_at minute exactly.

    Example:
        cron = "43 */1 * * *"  (every hour at :43)
        start_at = 4:43 PM IST
        → First fire  = 4:43 PM IST
        → Second fire = 5:43 PM IST  (cron tick, not +1h from now)

    Returns: UTC datetime for DB storage
    """
    from croniter import croniter
    # Start 1 second before start_at so croniter.get_next returns start_at itself
    base = start_at_ist - timedelta(seconds=1)
    ci   = croniter(cron_expression, base)
    nxt  = ci.get_next(datetime)
    return ist_to_utc(nxt)


def next_cron_after(cron_expression: str,
                    last_run_ist: datetime) -> datetime:
    """
    Compute next cron fire after last_run (both IST).
    Returns: UTC datetime for DB storage.
    """
    from croniter import croniter
    ci  = croniter(cron_expression, last_run_ist)
    nxt = ci.get_next(datetime)
    return ist_to_utc(nxt)


def _next_cron_utc(cron_expression: str, after_utc: datetime = None) -> datetime:
    """
    Return the next UTC datetime after `after_utc` (default: now_utc())
    computed from the cron expression interpreted in IST.
    Used by views.py scheduler_view().
    """
    try:
        from croniter import croniter
        base_utc = after_utc or now_utc()
        base_ist = utc_to_ist(base_utc)
        ci = croniter(cron_expression, base_ist)
        nxt_ist = ci.get_next(datetime)
        return ist_to_utc(nxt_ist)
    except Exception:
        return (after_utc or now_utc()) + timedelta(hours=1)
