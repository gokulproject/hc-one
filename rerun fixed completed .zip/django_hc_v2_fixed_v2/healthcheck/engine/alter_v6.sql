-- ============================================================
-- Health Check v6 — Incremental Alter Script
-- Run ONCE on top of the v5 fresh_schema (hc_v5 database).
--
--   mysql -u admin -p hc_v5 < alter_v6.sql
--
-- ONLY adds:
--   1. execution_runs.latest_step  (current step for dashboard)
--   2. run_step_log table          (step-by-step timing per run)
-- Does NOT change any existing table structure.
-- ============================================================

USE `hc_v5`;

-- ============================================================
-- 1. Add latest_step to execution_runs
--    Shows which step is currently running / last completed.
--    Updated after every step so the dashboard shows live status.
-- ============================================================
ALTER TABLE `execution_runs`
  ADD COLUMN IF NOT EXISTS `latest_step` VARCHAR(200) NULL
    COMMENT 'Current or last completed step name, e.g. [3/6] Checking escalations'
    AFTER `error_summary`;

-- ============================================================
-- 2. run_step_log  — per-step timing for every run
--    One row per step per run.
--    step_name examples:
--      Health Checks, Issue Tracking, Escalation Check,
--      Excel Generation, Email Notifications, Rerun Queue,
--      Tablespace Check (MMSDDB), RMAN Check (MMSDDB),
--      Schema Password (MMSDDB), Archive Mode (MMSDDB)
-- ============================================================
CREATE TABLE IF NOT EXISTS `run_step_log` (
  `id`           INT          NOT NULL AUTO_INCREMENT,
  `run_id`       INT          NOT NULL,
  `step_name`    VARCHAR(200) NOT NULL  COMMENT 'Human-readable step name',
  `step_order`   TINYINT      NOT NULL DEFAULT 0  COMMENT 'Order within the run',
  `status`       ENUM('RUNNING','COMPLETED','FAILED','SKIPPED') NOT NULL DEFAULT 'RUNNING',
  `started_at`   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completed_at` DATETIME(3)  NULL,
  `duration_ms`  INT          NULL  COMMENT 'Duration in milliseconds',
  `notes`        TEXT         NULL  COMMENT 'Failure reason or extra detail',
  PRIMARY KEY (`id`),
  KEY `idx_rsl_run` (`run_id`),
  CONSTRAINT `fk_rsl_run` FOREIGN KEY (`run_id`) REFERENCES `execution_runs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COMMENT 'Step-by-step timing for each execution run. Use for dashboards and audits.';

SELECT 'v6 alter complete: latest_step column + run_step_log table added.' AS status;
