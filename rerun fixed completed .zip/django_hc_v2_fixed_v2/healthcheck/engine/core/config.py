"""
core/config.py  (v8 - IST timezone + full system_config)
=========================================================
All runtime config loaded from database. Nothing hardcoded.
DB connection comes from env vars HC_DB_* only.
Timezone: Asia/Kolkata (IST) everywhere.
"""
import os
from dataclasses import dataclass, field
from typing import Dict, Optional

IST_TZ_NAME = "Asia/Kolkata"


def now_ist():
    """Return current datetime in IST (Asia/Kolkata)."""
    try:
        from zoneinfo import ZoneInfo
        from datetime import datetime, timezone
        return datetime.now(ZoneInfo(IST_TZ_NAME))
    except Exception:
        from datetime import datetime, timezone, timedelta
        IST_OFFSET = timedelta(hours=5, minutes=30)
        return datetime.now(timezone(IST_OFFSET))


def to_ist(dt):
    """Convert any datetime to IST. Returns naive IST datetime."""
    if dt is None:
        return None
    try:
        from zoneinfo import ZoneInfo
        from datetime import timezone
        ist = ZoneInfo(IST_TZ_NAME)
        if dt.tzinfo is None:
            # Assume UTC if naive
            from datetime import timezone as _tz
            dt = dt.replace(tzinfo=_tz.utc)
        return dt.astimezone(ist).replace(tzinfo=None)
    except Exception:
        from datetime import timedelta
        IST_OFFSET = timedelta(hours=5, minutes=30)
        if dt.tzinfo is None:
            dt = dt + IST_OFFSET
        return dt.replace(tzinfo=None)


@dataclass
class DBConfig:
    """MySQL connection from environment variables."""
    host:     str = field(default_factory=lambda: os.getenv("HC_DB_HOST", "localhost"))
    port:     int = field(default_factory=lambda: int(os.getenv("HC_DB_PORT", "3306")))
    name:     str = field(default_factory=lambda: os.getenv("HC_DB_NAME", "hc_v5"))
    user:     str = field(default_factory=lambda: os.getenv("HC_DB_USER", "hc_user"))
    password: str = field(default_factory=lambda: os.getenv("HC_DB_PASSWORD", ""))


@dataclass
class MailConfig:
    """SMTP settings from mail_config table."""
    smtp_host:     str           = ""
    smtp_port:     int           = 587
    use_tls:       bool          = True
    smtp_user:     str           = ""
    smtp_password: str           = ""
    from_address:  str           = ""
    reply_to:      Optional[str] = None


@dataclass
class AppConfig:
    """All runtime settings. Loaded once from DB at startup."""
    excel_output_path:         str   = "C:\\cloudFTP\\Health-Check-OUT\\Excel"
    log_output_path:           str   = "C:\\cloudFTP\\Health-Check-OUT\\Log"
    oracle_dll_path:           str   = ""
    excel_title_prefix:        str   = "Health Check Report"
    conn_retry_attempts:       int   = 3
    conn_retry_delay_sec:      int   = 10
    disk_free_threshold_gb:    float = 10.0
    tablespace_free_pct:       float = 25.0
    rerun_interval_hours:      float = 24.0
    rerun_max_attempts:        int   = 3
    log_retention_days:        int   = 90
    stuck_run_timeout_minutes: int   = 90
    timezone:                  str   = IST_TZ_NAME
    mail: MailConfig = field(default_factory=MailConfig)
    templates: Dict[str, Dict[str, str]] = field(default_factory=dict)


class ConfigLoader:
    """Loads AppConfig once and caches. Call load(db) at startup.
    Call reload(db) to force re-read from DB (e.g. after system_config change)."""
    _cfg: Optional[AppConfig] = None

    @classmethod
    def _build(cls, db) -> AppConfig:
        """Internal: read DB and build AppConfig. Always hits DB."""
        rows = db.fetch_all("SELECT config_key, config_value FROM system_config")
        raw  = {r["config_key"]: r["config_value"] for r in rows}

        def s(k, d=""): return raw.get(k, d)
        def i(k, d=0):
            try: return int(raw.get(k, d))
            except: return d
        def f(k, d=0.0):
            try: return float(raw.get(k, d))
            except: return d

        mail_cfg = MailConfig()
        try:
            row = db.fetch_one(
                "SELECT * FROM mail_config WHERE is_active=1 ORDER BY id LIMIT 1")
            if row:
                mail_cfg = MailConfig(
                    smtp_host=row["smtp_host"], smtp_port=int(row["smtp_port"]),
                    use_tls=bool(row["use_tls"]),
                    smtp_user=row["smtp_user"], smtp_password=row["smtp_password"],
                    from_address=row["from_address"], reply_to=row.get("reply_to"))
        except Exception:
            pass

        templates: Dict[str, Dict[str, str]] = {}
        try:
            for tr in db.fetch_all(
                "SELECT template_key,subject_template,body_html "
                "FROM mail_templates WHERE is_active=1"):
                templates[tr["template_key"]] = {
                    "subject": tr["subject_template"], "body_html": tr["body_html"]}
        except Exception:
            pass

        return AppConfig(
            excel_output_path    =s("excel_output_path",
                                    "C:\\cloudFTP\\Health-Check-OUT\\Excel"),
            log_output_path      =s("log_output_path",
                                    "C:\\cloudFTP\\Health-Check-OUT\\Log"),
            oracle_dll_path      =s("oracle_dll_path",       ""),
            excel_title_prefix   =s("excel_title_prefix",    "Health Check Report"),
            conn_retry_attempts  =i("conn_retry_attempts",   3),
            conn_retry_delay_sec =i("conn_retry_delay_sec",  10),
            disk_free_threshold_gb =f("disk_free_threshold_gb", 10.0),
            tablespace_free_pct  =f("tablespace_free_pct",   25.0),
            # rerun_interval_hours stored as FLOAT so 0.083 (~5 min) works
            rerun_interval_hours =f("rerun_interval_hours",  24.0),
            rerun_max_attempts   =i("rerun_max_attempts",    3),
            log_retention_days   =i("log_retention_days",    90),
            stuck_run_timeout_minutes=i("stuck_run_timeout_minutes", 90),
            timezone             =s("timezone",              IST_TZ_NAME),
            mail=mail_cfg, templates=templates,
        )

    @classmethod
    def load(cls, db) -> AppConfig:
        if cls._cfg is not None:
            return cls._cfg
        cls._cfg = cls._build(db)
        return cls._cfg

    @classmethod
    def reload(cls, db) -> AppConfig:
        """Force re-read from DB. Use after updating system_config."""
        cls._cfg = cls._build(db)
        return cls._cfg

    @classmethod
    def get(cls) -> AppConfig:
        if cls._cfg is None:
            raise RuntimeError(
                "ConfigLoader.load(db) must be called at startup first.")
        return cls._cfg

    @classmethod
    def reset(cls):
        cls._cfg = None


DB_CONFIG = DBConfig()
