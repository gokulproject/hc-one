"""
core/logger.py  (v5)
====================
Three-output logger: file (DEBUG) + console (INFO) + DB (all levels).

Log messages are CLEAN text — no [file|func()] prefix in the message.
File/function/line are stored as separate DB columns automatically.

Console output (for users):  HH:MM:SS [LEVEL] message
File output (for devs):       timestamp [LEVEL] [file::func():Lnn] message
DB output:                    clean message + py_file, py_function, py_line columns
"""
import logging
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import List, Optional


class _DBHandler(logging.Handler):
    """Batch-insert log rows to execution_logs table."""
    BATCH = 25

    def __init__(self, db, run_id, customer_id=None, env_type=None):
        super().__init__()
        self._db         = db
        self.run_id      = run_id
        self.customer_id = customer_id
        self.env_type    = env_type
        self.server_id   = None
        self.db_id       = None
        self._buf: List[tuple] = []
        self._lock = threading.Lock()

    def emit(self, record: logging.LogRecord):
        try:
            row = (
                self.run_id, self.customer_id, self.env_type,
                self.server_id, self.db_id,
                record.levelname,
                record.filename, record.module, record.funcName, record.lineno,
                self.format(record),
            )
            with self._lock:
                self._buf.append(row)
                if len(self._buf) >= self.BATCH:
                    self._flush_locked()
        except Exception:
            pass

    def flush(self):
        with self._lock:
            self._flush_locked()

    def _flush_locked(self):
        if not self._buf:
            return
        rows = list(self._buf)
        self._buf.clear()
        try:
            self._db.execute_many(
                """INSERT INTO execution_logs
                   (run_id,customer_id,env_type,server_id,db_id,
                    log_level,py_file,py_module,py_function,py_line,
                    message,logged_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW(3))""",
                rows)
        except Exception:
            pass


class RunLogger:
    """
    Per-run logger with three outputs.

    Usage:
        logger = RunLogger(run_id=5, log_dir="/logs", db=db, customer_id=1)
        logger.info("Connected to server")
        logger.step(2, 7, "Running Oracle checks")   # [2/7] (28%) ...
        logger.section("Environment: PRD")
        logger.close()
    """

    def __init__(self, run_id: int, log_dir: str, db=None,
                 customer_id: Optional[int] = None,
                 env_type: Optional[str] = None):
        self.run_id = run_id
        self._db_handler: Optional[_DBHandler] = None

        name = f"hc_run_{run_id}"
        self._log = logging.getLogger(name)
        self._log.setLevel(logging.DEBUG)
        self._log.handlers.clear()
        self._log.propagate = False

        # File handler (dev level)
        log_dir_path = Path(log_dir)
        log_dir_path.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.log_file = str(log_dir_path / f"run_{run_id}_{ts}.log")
        fh = logging.FileHandler(self.log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)-8s] [%(filename)s::%(funcName)s():L%(lineno)d] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"))
        self._log.addHandler(fh)

        # Console handler (user level)
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)-8s] %(message)s", datefmt="%H:%M:%S"))
        self._log.addHandler(ch)

        # DB handler
        if db is not None:
            self._db_handler = _DBHandler(db, run_id, customer_id, env_type)
            self._db_handler.setFormatter(logging.Formatter("%(message)s"))
            self._log.addHandler(self._db_handler)

    def set_context(self, customer_id=None, env_type=None, server_id=None, db_id=None):
        if not self._db_handler:
            return
        if customer_id is not None: self._db_handler.customer_id = customer_id
        if env_type    is not None: self._db_handler.env_type    = env_type
        if server_id   is not None: self._db_handler.server_id   = server_id
        if db_id       is not None: self._db_handler.db_id       = db_id

    def reset_server_context(self):
        if self._db_handler:
            self._db_handler.server_id = None
            self._db_handler.db_id = None

    def reset_db_context(self):
        if self._db_handler:
            self._db_handler.db_id = None

    def step(self, current: int, total: int, description: str):
        """Log numbered step progress: [2/7] (28% done, 5 remaining) Description"""
        pct = int(100 * current / total) if total else 0
        remaining = total - current
        msg = f"[{current}/{total}] ({pct}% done, {remaining} remaining) {description}"
        self._log.info(msg, stacklevel=2)

    def section(self, title: str):
        """Log a section divider."""
        self._log.info("─" * 60, stacklevel=2)
        self._log.info(f"  {title}", stacklevel=2)
        self._log.info("─" * 60, stacklevel=2)

    def debug(self, msg, *a, **kw):     self._log.debug(msg,    *a, stacklevel=2, **kw)
    def info(self, msg, *a, **kw):      self._log.info(msg,     *a, stacklevel=2, **kw)
    def warning(self, msg, *a, **kw):   self._log.warning(msg,  *a, stacklevel=2, **kw)
    def error(self, msg, *a, **kw):     self._log.error(msg,    *a, stacklevel=2, **kw)
    def critical(self, msg, *a, **kw):  self._log.critical(msg, *a, stacklevel=2, **kw)
    def exception(self, msg, *a, **kw): self._log.exception(msg,*a, stacklevel=2, **kw)

    def flush(self):
        if self._db_handler:
            self._db_handler.flush()

    def close(self):
        if self._db_handler:
            self._db_handler.flush()
        for h in list(self._log.handlers):
            try: h.flush(); h.close()
            except: pass
            self._log.removeHandler(h)


class SilentLogger:
    """No-op logger for background tasks."""
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warning(self, *a, **k): pass
    def error(self, *a, **k): pass
    def critical(self, *a, **k): pass
    def exception(self, *a, **k): pass
    def step(self, *a, **k): pass
    def section(self, *a, **k): pass
    def flush(self): pass
    def close(self): pass
    def set_context(self, **k): pass
    def reset_server_context(self): pass
    def reset_db_context(self): pass
