-- ============================================================
-- Health Check v9 — Bug-Fix Alter Script
-- Run ONCE on top of the v8 schema.
--
--   mysql -u admin -p hc_v5 < alter_v9_fixes.sql
--
-- Fixes:
--   1. rerun_queue — ensure all needed columns exist
--   2. rerun_queue — correct any stuck IN_PROGRESS rows to FAILED
--   3. schedules   — ensure next_run_at allows NULL (for reschedule reset)
--   4. Verification query at end
-- ============================================================

USE `hc_v5`;

-- ============================================================
-- 1. rerun_queue: ensure started_at / completed_at columns exist
--    (they may be missing in older schema versions)
-- ============================================================
ALTER TABLE `rerun_queue`
  ADD COLUMN IF NOT EXISTS `started_at`   DATETIME NULL
    COMMENT 'When this rerun attempt actually started executing'
    AFTER `scheduled_at`,
  ADD COLUMN IF NOT EXISTS `completed_at` DATETIME NULL
    COMMENT 'When this rerun attempt completed (success, failure, or exhausted)'
    AFTER `started_at`;

-- ============================================================
-- 2. rerun_queue: fix stuck IN_PROGRESS rows
--    Any IN_PROGRESS row that has been running for > 2 hours
--    is likely from a crashed process — mark it FAILED so the
--    scheduler can pick up the next attempt.
-- ============================================================
UPDATE `rerun_queue`
SET status = 'FAILED',
    completed_at = NOW(),
    last_error = 'Recovered: was stuck IN_PROGRESS after process restart'
WHERE status = 'IN_PROGRESS'
  AND started_at < DATE_SUB(NOW(), INTERVAL 2 HOUR);

-- ============================================================
-- 3. schedules: ensure next_run_at / start_at / last_run_at
--    are nullable (required for reschedule reset logic)
-- ============================================================
ALTER TABLE `schedules`
  MODIFY COLUMN `start_at`    DATETIME NULL
    COMMENT 'When this schedule should start firing (IST entered, UTC stored). NULL = next cron tick.',
  MODIFY COLUMN `last_run_at` DATETIME NULL
    COMMENT 'Last execution time (UTC). NULL = never run.',
  MODIFY COLUMN `next_run_at` DATETIME NULL
    COMMENT 'Next scheduled execution time (UTC). NULL = not yet scheduled.';

-- ============================================================
-- 4. execution_runs: ensure rerun_attempt column default is 0
--    (in case older schema has it as NOT NULL without default)
-- ============================================================
ALTER TABLE `execution_runs`
  MODIFY COLUMN `rerun_attempt` SMALLINT NOT NULL DEFAULT 0
    COMMENT '0 = original run, 1..N = rerun attempt number';

-- ============================================================
-- 5. system_config: ensure rerun_max_attempts and rerun_interval_hours
--    entries exist (views.py reads config_value column)
-- ============================================================
INSERT IGNORE INTO `system_config` (config_key, config_value, config_group, description)
VALUES
  ('rerun_max_attempts',   '3',  'rerun', 'Maximum number of automatic rerun attempts after a failed run'),
  ('rerun_interval_hours', '24', 'rerun', 'Hours to wait between automatic rerun attempts');

-- ============================================================
-- 6. Verification
-- ============================================================
SELECT
  'rerun_queue columns'  AS check_name,
  GROUP_CONCAT(COLUMN_NAME ORDER BY ORDINAL_POSITION) AS columns
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'rerun_queue'

UNION ALL

SELECT
  'system_config rerun rows',
  GROUP_CONCAT(CONCAT(config_key,'=',config_value) ORDER BY config_key)
FROM system_config
WHERE config_key IN ('rerun_max_attempts','rerun_interval_hours');

SELECT 'v9 fix alter complete.' AS status;
