"""
checks/oracle_manager.py
========================
Oracle database connections and health check queries.

ALL SQL queries come from the oracle_queries table in the DB.
No SQL is hardcoded in this file.

The exact queries seeded in schema.sql match the original
Process_Variables rows (8-15) from the legacy system.

Passwords are decrypted from AES-256-CBC before use.
"""
import time
from typing import List, Optional, Tuple

import oracledb

from core.config import ConfigLoader
from utils.crypto import decrypt_password


class OracleManager:
    """
    Manages a single Oracle DB connection and runs health check queries.

    Args:
        host:               Server host/IP
        port:               Oracle listener port (default 1521)
        service_name:       Oracle service name / SID
        username:           Oracle DB username
        encrypted_password: AES-encrypted password from oracle_databases table
        db_type:            'Argus' or 'FMW'
        logger:             RunLogger instance
    """

    def __init__(
        self,
        host:               str,
        port:               int,
        service_name:       str,
        username:           str,
        encrypted_password: str,
        db_type:            str,
        logger,
    ):
        self._cfg         = ConfigLoader.get()
        self.host         = host
        self.port         = port
        self.service_name = service_name
        self.username     = username
        self.db_type      = db_type
        self.logger       = logger
        self._conn        = None
        self._oracle_initialized = False  # instance flag

        # Decrypt password
        try:
            self.password = decrypt_password(encrypted_password)
        except Exception as exc:
            logger.error(
                f"[oracle_manager.py | OracleManager.__init__()] "
                f"Password decryption failed for DB '{service_name}': {exc}. "
                f"Ensure the password was stored via insert_oracle_database()."
            )
            self.password = encrypted_password  # fallback

    # ------------------------------------------------------------------ #
    # Connection
    # ------------------------------------------------------------------ #

    _class_oracle_initialized = False  # class-level: init once per process
    _class_oracle_lock = None

    def _init_oracle_client(self):
        """Initialize Oracle Instant Client (once per process, thread-safe)."""
        import threading
        if OracleManager._class_oracle_lock is None:
            OracleManager._class_oracle_lock = threading.Lock()
        with OracleManager._class_oracle_lock:
            if OracleManager._class_oracle_initialized:
                self._oracle_initialized = True
                return
            if self._cfg.oracle_dll_path:
                try:
                    oracledb.init_oracle_client(lib_dir=self._cfg.oracle_dll_path)
                    self.logger.debug(
                        f"[oracle_manager.py | _init_oracle_client()] "
                        f"Oracle client initialized from: {self._cfg.oracle_dll_path}"
                    )
                except Exception as exc:
                    # May already be initialized - safe to ignore
                    self.logger.debug(
                        f"[oracle_manager.py | _init_oracle_client()] "
                        f"Oracle client init note (may be already initialized): {exc}"
                    )
            OracleManager._class_oracle_initialized = True
            self._oracle_initialized = True

    def connect(self) -> bool:
        """
        Connect to Oracle with configured retries.
        Returns True on success, False after all attempts fail.
        """
        self._init_oracle_client()

        attempts = self._cfg.conn_retry_attempts
        delay    = self._cfg.conn_retry_delay_sec

        self.logger.info(
            f"[oracle_manager.py | connect()] "
            f"Connecting to Oracle {self.service_name}@{self.host}:{self.port} "
            f"as '{self.username}' (max {attempts} attempts)"
        )

        for attempt in range(1, attempts + 1):
            try:
                self._conn = oracledb.connect(
                    host=self.host,
                    port=self.port,
                    service_name=self.service_name,
                    user=self.username,
                    password=self.password,
                )
                self.logger.info(
                    f"[oracle_manager.py | connect()] "
                    f"Connected to {self.service_name} on attempt {attempt}/{attempts}"
                )
                return True
            except Exception as exc:
                self.logger.warning(
                    f"[oracle_manager.py | connect()] "
                    f"Attempt {attempt}/{attempts} failed for {self.service_name}: {exc}"
                )
                if attempt < attempts:
                    time.sleep(delay)

        self.logger.error(
            f"[oracle_manager.py | connect()] "
            f"All {attempts} connection attempts failed for {self.service_name}@{self.host}"
        )
        return False

    def disconnect(self):
        """Close Oracle connection."""
        try:
            if self._conn:
                self._conn.close()
                self.logger.debug(
                    f"[oracle_manager.py | disconnect()] "
                    f"Disconnected from {self.service_name}"
                )
        except Exception as exc:
            self.logger.warning(
                f"[oracle_manager.py | disconnect()] "
                f"Error closing Oracle connection for {self.service_name}: {exc}"
            )
        finally:
            self._conn = None

    # ------------------------------------------------------------------ #
    # Raw query execution
    # ------------------------------------------------------------------ #

    def query(self, sql: str, params: Optional[tuple] = None) -> List[tuple]:
        """
        Execute a SELECT query, return list of tuples.
        Raises exception on Oracle error (caller must handle).
        """
        if not self._conn:
            self.logger.error(
                f"[oracle_manager.py | query()] "
                f"No active connection to {self.service_name} - query aborted."
            )
            return []
        try:
            cur = self._conn.cursor()
            cur.execute(sql, params or ())
            rows = cur.fetchall()
            self.logger.debug(
                f"[oracle_manager.py | query()] "
                f"{self.service_name}: query returned {len(rows)} rows. "
                f"SQL preview: {sql[:120].strip()}"
            )
            return rows
        except Exception as exc:
            self.logger.error(
                f"[oracle_manager.py | query()] "
                f"Query failed on {self.service_name}: {exc}. "
                f"SQL: {sql[:200].strip()}"
            )
            raise

    # ------------------------------------------------------------------ #
    # Named health check methods (SQL injected from oracle_queries table)
    # ------------------------------------------------------------------ #

    def check_tablespace(
        self, low_sql: str, all_sql: str
    ) -> Tuple[bool, List[tuple]]:
        """
        Check tablespace usage.

        Args:
            low_sql: SQL that returns rows for tablespaces >= threshold (from oracle_queries)
            all_sql: SQL that returns all tablespace metrics (from oracle_queries)

        Returns:
            (has_low_space, all_rows)
            has_low_space: True if any tablespace exceeds the usage threshold
            all_rows: raw rows from all_sql for storage in tablespace_usage table
        """
        self.logger.debug(
            f"[oracle_manager.py | check_tablespace()] "
            f"Running tablespace checks on {self.service_name}"
        )
        low_rows = self.query(low_sql)
        all_rows = self.query(all_sql)
        has_low = len(low_rows) > 0
        self.logger.info(
            f"[oracle_manager.py | check_tablespace()] "
            f"{self.service_name}: {len(all_rows)} tablespaces total, "
            f"{len(low_rows)} below free threshold. Action needed: {has_low}"
        )
        return has_low, all_rows

    def get_latest_usernames(self, sql: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Run the latest_usernames query to find current WHODD* and MEDDRA* usernames.
        Returns (whodd_username, meddra_username). Either can be None if not found.
        """
        self.logger.debug(
            f"[oracle_manager.py | get_latest_usernames()] "
            f"Fetching latest WHODD/MEDDRA usernames from {self.service_name}"
        )
        rows = self.query(sql)
        names = [r[0] for r in rows if r[0]]
        item1 = next((n for n in names if n.upper().startswith("WHODD")),  None)
        item2 = next((n for n in names if n.upper().startswith("MEDDRA")), None)
        self.logger.debug(
            f"[oracle_manager.py | get_latest_usernames()] "
            f"Found WHODD='{item1}', MEDDRA='{item2}'"
        )
        return item1, item2

    def check_schema_password(self, sql: str) -> Tuple[bool, str]:
        """
        Run a schema expiry query.

        Returns:
            (has_expiry, detail_string)
            has_expiry: True if any row has a non-null EXPIRY_DATE
            detail_string: human-readable list of (username, status, expiry)
        """
        self.logger.debug(
            f"[oracle_manager.py | check_schema_password()] "
            f"Running schema expiry check on {self.service_name}"
        )
        rows = self.query(sql)
        has_expiry = any(r[2] not in (None, "None", "") for r in rows)
        parts = []
        for r in rows:
            expiry = str(r[2]) if r[2] not in (None, "None", "") else "No expiry"
            parts.append(f"({r[0]}, {r[1]}, {expiry})")
        detail = "; ".join(parts) if parts else "No schema rows returned"
        self.logger.info(
            f"[oracle_manager.py | check_schema_password()] "
            f"{self.service_name}: {len(rows)} schemas checked, "
            f"has_expiry={has_expiry}"
        )
        return has_expiry, detail

    def check_archive_mode(self, sql: str) -> Tuple[bool, str]:
        """
        Check if Oracle is in ARCHIVELOG mode.

        Returns:
            (is_archivelog, mode_string)
        """
        self.logger.debug(
            f"[oracle_manager.py | check_archive_mode()] "
            f"Checking archive log mode on {self.service_name}"
        )
        rows = self.query(sql)
        mode = str(rows[0][0]) if rows else "UNKNOWN"
        is_archivelog = mode.upper() == "ARCHIVELOG"
        self.logger.info(
            f"[oracle_manager.py | check_archive_mode()] "
            f"{self.service_name}: LOG_MODE={mode}, is_archivelog={is_archivelog}"
        )
        return is_archivelog, mode

    def check_archive_path(self, sql: str) -> Tuple[bool, str]:
        """
        Check archive log destinations - should NOT be on C: drive.

        Returns:
            (path_ok, detail_string)
            path_ok: True if NO destinations start with C:
        """
        self.logger.debug(
            f"[oracle_manager.py | check_archive_path()] "
            f"Checking archive destinations on {self.service_name}"
        )
        rows = self.query(sql)
        paths   = [str(r[0]) for r in rows if r[0]]
        on_c    = [p for p in paths if p.upper().startswith("C:")]
        path_ok = len(on_c) == 0
        detail  = "; ".join(paths) if paths else "No valid archive destinations found"
        self.logger.info(
            f"[oracle_manager.py | check_archive_path()] "
            f"{self.service_name}: {len(paths)} destinations, "
            f"on_C_drive={on_c}, path_ok={path_ok}"
        )
        return path_ok, detail

    def check_archive_logs_8days(self, sql: str) -> Tuple[bool, str]:
        """
        Check archive logs for the last 8 days.
        Action required if any log shows DELETED='YES'.

        Returns:
            (all_present, detail_string)
            all_present: True if no logs are marked as DELETED
        """
        self.logger.debug(
            f"[oracle_manager.py | check_archive_logs_8days()] "
            f"Checking last-8-day archive logs on {self.service_name}"
        )
        rows = self.query(sql)
        deleted = [r for r in rows if str(r[4]).upper() == "YES"]  # DELETED column
        all_present = len(deleted) == 0
        detail = (
            f"{len(rows)} archive log records found in last 8 days. "
            f"{len(deleted)} deleted."
        )
        self.logger.info(
            f"[oracle_manager.py | check_archive_logs_8days()] "
            f"{self.service_name}: {detail}"
        )
        return all_present, detail

    def check_rman(self, sql: str) -> Tuple[bool, List[tuple]]:
        """
        Check RMAN backup job status for today.

        Returns:
            (backup_ok, rows)
            backup_ok: True if rows exist AND all DISK+DB INCR backups completed
            rows: raw rows to store in rman_backup_details table
        """
        self.logger.debug(
            f"[oracle_manager.py | check_rman()] "
            f"Checking RMAN backups on {self.service_name}"
        )
        rows = self.query(sql)

        if not rows:
            self.logger.warning(
                f"[oracle_manager.py | check_rman()] "
                f"{self.service_name}: No RMAN backup rows found for today"
            )
            return False, rows

        backup_ok = all(
            str(r[2]).upper() == "DISK"
            and "COMPLETED" in str(r[5]).upper()
            for r in rows
            if r[2] is not None  # skip DELETE operation rows
        )
        self.logger.info(
            f"[oracle_manager.py | check_rman()] "
            f"{self.service_name}: {len(rows)} RMAN job rows, backup_ok={backup_ok}"
        )
        return backup_ok, rows
