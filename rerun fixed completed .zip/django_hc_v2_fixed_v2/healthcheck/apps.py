import os
import logging
from django.apps import AppConfig

logger = logging.getLogger("hc.scheduler")


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """
        Called once when Django starts. Start the background APScheduler.

        Guard against double-start:
        - Django's dev runserver spawns a *reloader* parent and a *worker* child.
          The child sets RUN_MAIN=true; we only start in the child.
        - In production (gunicorn/uwsgi) RUN_MAIN is absent, so we start always.
        - manage.py commands (migrate, shell, etc.) set DJANGO_MANAGEMENT_COMMAND=1
          via a custom wrapper — skip scheduler there.
        """
        # Skip in management commands (migrate, collectstatic, shell, …)
        if os.environ.get("DJANGO_MANAGEMENT_COMMAND") == "1":
            return

        run_main = os.environ.get("RUN_MAIN")
        # dev reloader parent process: RUN_MAIN is unset → skip
        # dev worker child:            RUN_MAIN == 'true' → start
        # production (no reloader):    RUN_MAIN is unset, but we ARE the main → start
        # We detect production by checking if runserver is NOT in the command.
        import sys
        is_runserver = "runserver" in " ".join(sys.argv)
        if is_runserver and run_main != "true":
            # Reloader parent — do NOT start scheduler here
            return

        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
            logger.info("Scheduler started via AppConfig.ready()")
        except Exception as e:
            logger.warning(f"Could not start scheduler on startup: {e}")
