"""
healthcheck/management/commands/encrypt_password.py
Usage: python manage.py encrypt_password
"""
from django.core.management.base import BaseCommand
import getpass
import sys
import os


class Command(BaseCommand):
    help = "Encrypt a plain-text password for storage in HC database"

    def handle(self, *args, **options):
        engine_path = os.path.join(
            os.path.dirname(__file__), "..", "..", "engine")
        if engine_path not in sys.path:
            sys.path.insert(0, engine_path)

        from engine.utils.crypto import encrypt_password, decrypt_password

        self.stdout.write("\nHealth Check v6 — Password Encryption")
        self.stdout.write("=" * 50)
        plain = getpass.getpass("Enter plain-text password: ")
        if not plain:
            self.stderr.write("ERROR: Password cannot be empty.")
            return

        enc = encrypt_password(plain)
        self.stdout.write(f"\nEncrypted value (paste into DB):\n  {enc}")

        try:
            if decrypt_password(enc) == plain:
                self.stdout.write(self.style.SUCCESS("\n[OK] Round-trip verification passed."))
            else:
                self.stdout.write(self.style.WARNING("\n[WARNING] Round-trip mismatch."))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"\n[ERROR] {e}"))
