# Health Check v7 — Complete Guide

## What Changed from v6 → v7

| Area | Change |
|------|--------|
| **Scheduling** | Fixed dual-run on `runserver` restart; APScheduler fires only in the main process worker |
| **Scheduling** | `last_run_at` and `next_run_at` now updated immediately after every fire |
| **Scheduling** | New `start_at` column on schedules — delay first fire to a future datetime |
| **Scheduling** | New `scheduler_tracker` table — full audit log of every firing event |
| **Escalation** | Fixed `last_escalated_at` → `last_escalation_at` (DB column + all Python references) |
| **Escalation UI** | Added customer/status/env filter bar and **View Report** button per issue row |
| **Oracle** | `OracleManager` now uses a class-level init lock — no double DPI-1047 errors |
| **WMI/COM** | `ServerManager.disconnect()` calls `del` on WMI objects; each scheduler thread runs `CoInitialize`/`CoUninitialize` |
| **UI** | Sidebar removed → top navbar (Bootstrap, static position, white body background) |
| **UI** | Color scheme: `#003A5F` for headings/card headers |
| **UI** | Logo placeholder in navbar (replace with your PNG) |
| **UI** | All URLs prefixed with `/healthcheck/` |
| **Dashboard** | Shows skeleton view + warning banner when HC database is unreachable |
| **Admin** | New **Scheduler Tracker** page (admin-only) with filter, re-queue, deactivate actions |

---

## Setup & Configuration

### 1. Run the Database Migration

Connect to your MySQL `hc_v5` database and run:

```sql
-- doc/migrations_v7.sql
```

**Do this BEFORE deploying the new code.**

### 2. Environment Variables (`.env`)

Copy `.env.example` to `.env` and fill in:

```
DJANGO_SECRET_KEY=your-long-random-secret
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=yourdomain.com,localhost

HC_DB_NAME=hc_v5
HC_DB_USER=your_mysql_user
HC_DB_PASSWORD=your_mysql_password
HC_DB_HOST=your_rds_or_mysql_host
HC_DB_PORT=3306

HC_ENC_KEY=your-32-byte-aes-key-change-me!!
```

### 3. Install Python Dependencies

```bash
pip install -r requirements.txt
# Key packages: django, apscheduler, pymysql, croniter
# Optional (Windows WMI): pywin32, pythoncom
# Optional (Oracle): oracledb
```

### 4. Django Setup

```bash
python manage.py migrate          # sets up Django auth/session tables (SQLite)
python manage.py createsuperuser  # create your admin user
python manage.py collectstatic    # (production only)
```

### 5. Start the Server

```bash
# Development
python manage.py runserver 0.0.0.0:8000

# Production (gunicorn)
gunicorn django_hc.wsgi:application --bind 0.0.0.0:8000 --workers 2
```

The APScheduler starts automatically via `HealthcheckConfig.ready()`.

---

## Scheduling

### How It Works

1. On startup, APScheduler reads all active schedules from the `schedules` table.
2. Each schedule fires at its cron expression in a background thread.
3. After each fire: `last_run_at` = now, `next_run_at` = next cron tick.
4. Every fire is logged in `scheduler_tracker`.

### `start_at` Column

- **Blank / NULL** → fires at next cron tick (immediately on restart if cron matches).
- **Future datetime** → scheduler will skip all ticks until `start_at` is reached.
- **Past datetime** → treated same as NULL (fires immediately at next tick).

Set via Django Admin → Schedules → Edit.

### Preventing Dual Runs

`apps.py` guards against the Django `runserver` reloader spawning two processes:
- Parent process (reloader): **no** scheduler start.
- Child process (worker, `RUN_MAIN=true`): scheduler starts.
- Production (gunicorn): scheduler starts normally.

---

## Scheduler Tracker Table

Access at `/healthcheck/scheduler/tracker/` (admin only).

| Column | Description |
|--------|-------------|
| `schedule_id` | FK to `schedules` |
| `customer_id` | FK to `customers` |
| `status` | PENDING / RUNNING / COMPLETED / FAILED / FAILED_QUEUE / SKIPPED |
| `scheduled_fire_at` | UTC datetime the cron was supposed to fire |
| `actual_start_at` | When the run actually started |
| `completed_at` | When it finished |
| `last_run_at` | Copied from schedule at fire time |
| `next_run_at` | Next predicted fire time |
| `run_id` | FK to `execution_runs` |
| `error_message` | Failure detail |
| `is_active` | Admin can deactivate entries |

### Admin Actions

- **Re-queue**: sets a FAILED entry back to PENDING (scheduler will pick it up next tick).
- **Deactivate**: marks entry `is_active=0` — removes from queue.

---

## Escalation

### Fix Applied

The column `last_escalated_at` was renamed to `last_escalation_at` throughout:
- `healthcheck/models.py`
- `engine/notifications/email_service.py`
- `engine/core/issue_tracker.py`
- `doc/migrations_v7.sql` (ALTER TABLE)

### Escalation Page Filters

Filter by Customer, Status (OPEN / ESCALATED / RESOLVED), and Environment.
Each issue row has a **View** button linking to the last failed run's report.

---

## Oracle Client (DPI-1047)

The error `DPI-1047: Cannot locate a 64-bit Oracle Client library` means the Oracle Instant Client is not installed or not on PATH.

**Fix options:**

1. Install Oracle Instant Client 64-bit and set `oracle_dll_path` in `system_config`:
   ```sql
   UPDATE system_config SET config_value='/opt/oracle/instantclient_21_9'
   WHERE config_key='oracle_dll_path';
   ```

2. Or use **python-oracledb in thin mode** (no client needed) by removing `lib_dir`:
   In `oracle_manager.py`, the client init is now skipped gracefully when `oracle_dll_path` is empty.

The `OracleManager` now uses a class-level lock so `init_oracle_client()` is called only once per process regardless of how many instances are created.

---

## WMI / CoInitialize Error

**Error**: `x_wmi: Unexpected COM Error (-2147221008, 'CoInitialize has not been called.')`

**Fix**: Each scheduler background thread now calls `pythoncom.CoInitialize()` before WMI and `pythoncom.CoUninitialize()` after. Requires `pywin32` on Windows:

```bash
pip install pywin32
```

On Linux (where WMI doesn't apply), these calls are safely ignored.

---

## UI Customization

### Logo

Replace the `LOGO` placeholder in `base.html`:

```html
<!-- Find this in base.html -->
<span class="logo-placeholder">LOGO</span>

<!-- Replace with your image -->
<img src="{% static 'healthcheck/logo.png' %}" height="34" alt="Logo">
```

Place your PNG at `static/healthcheck/logo.png` and run `collectstatic`.

### Colors

The primary color is `#003A5F` (deep navy). To change it, edit `base.html`:

```css
:root {
  --hc-primary:  #003A5F;  /* ← change this */
  --hc-accent:   #0072B2;
}
```

---

## File Change Summary (v6 → v7)

| File | Change |
|------|--------|
| `healthcheck/models.py` | `last_escalated_at` → `last_escalation_at`; `start_at` on Schedule; new `SchedulerTracker` model |
| `healthcheck/apps.py` | Fixed dual-start guard for `runserver` reloader |
| `healthcheck/scheduler_service.py` | Full rewrite: CoInit/CoUninit, start_at support, tracker writes, proper next_run_at update |
| `healthcheck/urls.py` | Added `scheduler/tracker/` URL; `app_name="healthcheck"` namespace |
| `django_hc/urls.py` | All HC URLs now under `/healthcheck/` prefix |
| `healthcheck/views.py` | Skeleton dashboard; scheduler_tracker view; escalation filter + View button |
| `healthcheck/engine/checks/oracle_manager.py` | Class-level init lock |
| `healthcheck/engine/checks/server_manager.py` | Proper COM resource release in `disconnect()` |
| `healthcheck/engine/notifications/email_service.py` | Column rename |
| `healthcheck/engine/core/issue_tracker.py` | Column rename |
| `templates/healthcheck/base.html` | Navbar replaces sidebar; white bg; #003A5F theme |
| `templates/healthcheck/escalation.html` | Filter bar + View Report button |
| `templates/healthcheck/scheduler.html` | start_at column; tracker link |
| `templates/healthcheck/scheduler_tracker.html` | New admin tracker page |
| `templates/healthcheck/dashboard.html` | Skeleton warning banner |
| `doc/migrations_v7.sql` | ALTER TABLE + CREATE TABLE statements |
| `doc/GUIDE_v7.md` | This guide |

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Scheduler fires twice | Confirm `RUN_MAIN` env fix in `apps.py` (already applied) |
| `last_escalation_at` column error | Run `migrations_v7.sql` on the HC database |
| `scheduler_tracker` table missing | Run `migrations_v7.sql` |
| DPI-1047 Oracle error | Set `oracle_dll_path` in `system_config` or use thin mode |
| CoInitialize WMI error | Install `pywin32`; each thread now auto-initialises COM |
| 404 on `/dashboard/` | URLs now live at `/healthcheck/` — use `/healthcheck/` or click nav |
| DB down — crash | Dashboard now shows skeleton view with warning; no crash |

---

## DB Connection Resilience (v7.1)

### What Happens When MySQL Goes Down

| Layer | Behaviour |
|-------|-----------|
| **Middleware** (`DBConnectionMiddleware`) | Catches any `OperationalError` / `ConnectionError` from any view. Returns a 503 maintenance page with 30-second auto-refresh instead of crashing |
| **`@_db_safe_view` decorator** | Applied to every view function — catches DB errors inside the view body (eager queryset evaluation, filter loops, etc.) and returns `db_error.html` |
| **Dashboard** | Already has `try/except` — shows skeleton + inline warning banner |
| **`DBManager._ensure_connected()`** | Detects dropped connections via `ping()`, automatically reconnects with exponential backoff (2s → 4s → 8s … capped at 30s) |
| **Scheduler fire** | If DB is unreachable when a job fires, the fire is **skipped gracefully** (logged as error). The scheduler process itself keeps running and retries at the next cron tick |
| **APScheduler process** | Completely independent of DB — keeps running even with no DB |
| **Live navbar banner** | JavaScript pings `/healthcheck/api/db-health/` every 20 seconds. A red bottom banner appears if DB is down; disappears automatically when DB comes back |

### DB Health Check Endpoint

```
GET /healthcheck/api/db-health/
```

Returns:
```json
{"ok": true,  "error": null,             "latency_ms": 3.2}   # 200 OK
{"ok": false, "error": "Can't connect…", "latency_ms": null}  # 503
```

No login required — safe to poll from load balancers, Nagios, AWS health checks, etc.

### Recovery Flow

1. DB goes down → users see `db_error.html` with auto-retry countdown
2. Scheduler skips fires silently (no crash)
3. DB comes back up → `_ensure_connected()` succeeds on next call
4. Views return to normal automatically (no restart needed)
5. Scheduler picks up at next cron tick normally
6. Navbar banner disappears within 20 seconds of DB recovery

### Connection Retry Policy

`DBManager.connect()` uses exponential backoff:

| Attempt | Wait before retry |
|---------|-------------------|
| 1 | immediate |
| 2 | 2 seconds |
| 3 | 4 seconds |
| 4 | 8 seconds |
| 5 | 16 seconds |

After 5 failures, raises `DBConnectionError` which propagates to middleware → 503 page.

### SQL Migration Required

No additional SQL needed for this feature.
