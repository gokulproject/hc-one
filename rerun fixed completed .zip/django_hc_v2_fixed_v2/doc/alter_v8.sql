-- ============================================================
-- Health Check v8 — Database ALTER Script
-- Run on your hc_v5 MySQL database BEFORE deploying v8 code.
-- Server stores DATETIME in UTC. App displays in IST.
-- ============================================================

-- ── 1. schedules table: add start_at column ─────────────────────────
ALTER TABLE schedules
  ADD COLUMN IF NOT EXISTS start_at DATETIME NULL
  COMMENT 'Admin-set first execution time (stored as UTC, displayed as IST). 
           NULL = fire at next cron tick after scheduler start.
           RULE: scheduler fires ONLY at/after this time, NEVER at creation time.'
  AFTER is_active;

-- ── 2. escalation_config: add resolved mail + env mail switch ────────
ALTER TABLE escalation_config
  ADD COLUMN IF NOT EXISTS send_resolved_mail TINYINT(1) NOT NULL DEFAULT 0
  COMMENT 'Send email when all issues for this customer/env are RESOLVED. 0=off, 1=on'
  AFTER notify_rerun_fail;

ALTER TABLE escalation_config
  ADD COLUMN IF NOT EXISTS env_mail_enabled TINYINT(1) NOT NULL DEFAULT 1
  COMMENT 'Master switch: 0 disables ALL escalation emails for this customer/env'
  AFTER send_resolved_mail;

-- ── 3. rerun_queue: add last_error column ────────────────────────────
ALTER TABLE rerun_queue
  ADD COLUMN IF NOT EXISTS last_error TEXT NULL
  COMMENT 'Reason the run failed and was queued for retry'
  AFTER max_attempts;

ALTER TABLE rerun_queue
  ADD COLUMN IF NOT EXISTS started_at DATETIME NULL
  COMMENT 'When this rerun attempt actually started (UTC)'
  AFTER scheduled_at;

-- ── 4. execution_runs: add error_summary ─────────────────────────────
ALTER TABLE execution_runs
  ADD COLUMN IF NOT EXISTS error_summary TEXT NULL
  COMMENT 'Error captured when run fails/crashes/is killed'
  AFTER completed_at;

ALTER TABLE execution_runs
  ADD COLUMN IF NOT EXISTS rerun_attempt INT NOT NULL DEFAULT 0
  COMMENT 'Which retry attempt this is (0=original, 1=first retry, etc.)'
  AFTER rerun_of_run_id;

-- ── 5. scheduler_tracker: create if not exists ───────────────────────
CREATE TABLE IF NOT EXISTS scheduler_tracker (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  schedule_id         INT UNSIGNED NULL,
  customer_id         INT UNSIGNED NOT NULL,
  env_types           VARCHAR(50) NOT NULL,
  schedule_name       VARCHAR(200) NOT NULL DEFAULT '',
  cron_expression     VARCHAR(100) NOT NULL DEFAULT '',
  run_id              BIGINT UNSIGNED NULL,
  status              ENUM('PENDING','RUNNING','COMPLETED','FAILED','FAILED_QUEUE','SKIPPED')
                      NOT NULL DEFAULT 'PENDING',
  scheduled_fire_at   DATETIME NOT NULL
                      COMMENT 'UTC datetime this fired',
  actual_start_at     DATETIME NULL,
  completed_at        DATETIME NULL,
  last_run_at         DATETIME NULL,
  next_run_at         DATETIME NULL,
  error_message       TEXT NULL,
  is_active           TINYINT(1) NOT NULL DEFAULT 1,
  triggered_by        VARCHAR(100) NOT NULL DEFAULT 'scheduler',
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_st_customer  (customer_id),
  KEY idx_st_schedule  (schedule_id),
  KEY idx_st_status    (status),
  KEY idx_st_fire_at   (scheduled_fire_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Tracks every scheduler firing. All datetimes UTC, UI shows IST.';

-- ── 6. system_config: add new keys ───────────────────────────────────
INSERT IGNORE INTO system_config (config_key, config_value, config_group, description)
VALUES
  ('timezone',                  'Asia/Kolkata', 'operational',
   'Application timezone. All UI displays in this timezone. DB stores UTC.'),
  ('stuck_run_timeout_minutes', '90',           'operational',
   'Minutes after which an IN_PROGRESS run is considered stuck and marked FAILED'),
  ('disk_free_threshold_pct',   '15',           'operational',
   'Optional: disk free % threshold (in addition to GB check)');

-- ── 7. Verify current state ──────────────────────────────────────────
-- Uncomment to check:
-- SELECT config_key, config_value FROM system_config ORDER BY config_group, config_key;
-- SHOW COLUMNS FROM schedules;
-- SHOW COLUMNS FROM escalation_config;
-- SHOW COLUMNS FROM rerun_queue;
-- SHOW COLUMNS FROM execution_runs;
-- SHOW TABLES LIKE 'scheduler_tracker';

-- ── 8. IMPORTANT: IST vs UTC note ────────────────────────────────────
-- MySQL server stores all DATETIME as UTC.
-- When admin sets "Start At = 4:43 PM" in Django Admin, Django converts
-- this IST input → UTC before saving to DB.
-- Example: Admin enters 4:43 PM IST → DB stores 11:13 AM UTC (IST - 5:30)
-- The HC app always displays DB datetimes as IST 12-hour format.
-- DO NOT manually insert IST times directly into DB — use UTC.
-- Quick UTC conversion: IST - 5:30 = UTC
--   4:43 PM IST = 11:13 AM UTC
--   8:00 AM IST = 2:30 AM UTC

-- ============================================================
-- END alter_v8.sql
-- ============================================================
