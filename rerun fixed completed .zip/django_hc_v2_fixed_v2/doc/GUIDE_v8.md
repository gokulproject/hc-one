# Health Check v8 — Complete Setup & Fix Guide

## What's New in v8

### Scheduler (IST Timezone + Start At Fix)
- All times displayed in **IST (Asia/Kolkata) 12-hour format** across UI, admin, emails, logs
- MySQL stores **UTC** — the app converts UTC↔IST automatically
- **Start At** is now strictly the first execution time (admin-set in IST)
- **Creation time never triggers execution**
- Minute preserved exactly: cron `43 */1 * * *` always fires at :43 (not shifted)
- Scheduler page auto-refreshes every 30s (no other pages affected)
- No popup when scheduler is stopped — clean info banner only
- `last_run_at` and `next_run_at` shown in IST 12h in scheduler page

### Escalation
- RESOLVED rows now visible (filter by Status = Resolved)
- Resolved escalation mail checkbox in EscalationConfig
- Customer environment mail enable/disable checkbox
- All filters working: Customer, Status (Open/Escalated/Resolved), Env
- Last mail column shows both TO and CC properly

### Rerun Queue
- Better UI with Queue ID, Retry Count, Failure Reason, View Logs
- EXHAUSTED status correctly written to DB
- Manual kill → stuck-run watcher queues rerun automatically
- All timestamps in IST 12-hour format

---

## IST/UTC Strategy

```
Admin enters: 4:43 PM IST
Django Admin converts: → 11:13 AM UTC → stores in DB

DB stores: 2026-04-27 11:13:00 (UTC, naive datetime)

App reads DB: 2026-04-27 11:13:00 UTC
App displays: 27-Apr-2026 04:43 PM IST ← user sees this

Scheduler APScheduler: runs in Asia/Kolkata timezone
  → cron "43 */1 * * *" fires at 4:43 PM, 5:43 PM, 6:43 PM etc (IST)
```

## Start At Logic — Example

```
Admin creates schedule at: 2:15 PM IST  (created_at)
Admin sets Start At:       4:43 PM IST  (start_at)
Cron expression:           43 */1 * * * (every hour at :43)

Timeline:
  2:15 PM — schedule created (NO execution)
  3:43 PM — cron ticks but start_at NOT reached → SKIP
  4:43 PM — start_at reached → FIRST EXECUTION ✓
  5:43 PM — next cron tick → EXECUTE ✓
  6:43 PM — next cron tick → EXECUTE ✓

DB stores:
  created_at = 2026-04-27 08:45:00 UTC  (2:15 PM IST)
  start_at   = 2026-04-27 11:13:00 UTC  (4:43 PM IST)
  last_run_at = 2026-04-27 11:13:00 UTC (updated after each run)
  next_run_at = 2026-04-27 12:13:00 UTC (5:43 PM IST)

UI shows:
  Start At:  27-Apr-2026 04:43 PM IST
  Last Run:  27-Apr-2026 04:43 PM IST
  Next Run:  27-Apr-2026 05:43 PM IST
```

---

## Step-by-Step Setup

### 1. Run DB Alterations
```sql
-- Connect to your hc_v5 MySQL database and run:
source doc/alter_v8.sql
```

### 2. Configure .env
```
HC_DB_HOST=your-rds-hostname
HC_DB_PORT=3306
HC_DB_NAME=hc_v5
HC_DB_USER=your_user
HC_DB_PASSWORD=your_password
HC_ENC_KEY=your-32-char-key-here!!!!!!!
DJANGO_SECRET_KEY=your-secret-key
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=yourdomain.com,localhost
```

### 3. Install Requirements
```bash
pip install -r requirements.txt
# Adds: zoneinfo (Python 3.9+), apscheduler, croniter
```

### 4. Django Setup
```bash
python manage.py migrate
python manage.py createsuperuser
python manage.py collectstatic
```

### 5. Start
```bash
python manage.py runserver 0.0.0.0:8000
# OR production:
gunicorn django_hc.wsgi:application --bind 0.0.0.0:8000 --workers 2
```

---

## How to Add a Schedule (Admin Panel)

1. Go to `/admin/healthcheck/schedule/`
2. Click **Add Schedule**
3. Fill fields:
   - **Customer**: select customer
   - **Env Types**: PROD, DEV, etc.
   - **Schedule Name**: "ABC Pharma Daily Check"
   - **Cron Expression**: `43 16 * * *` (4:43 PM every day)
   - **Start At**: Enter in IST — this is when FIRST run fires
     - Example: `2026-04-27 16:43:00` → means 4:43 PM IST
     - Leave blank → fires at very next cron tick
   - **Is Active**: ✓
4. Save
5. Go to `/healthcheck/scheduler/` → click **Restart & Reload**
6. Watch logs: `[Scheduler] ✓ [1] ABC Pharma Daily Check | cron=43 16 * * * | start_at=27-Apr-2026 04:43 PM IST`

---

## Cron Examples (IST)

| Cron | Meaning |
|------|---------|
| `43 16 * * *` | Every day at 4:43 PM IST |
| `43 */1 * * *` | Every hour at :43 (4:43, 5:43, 6:43...) |
| `0 8 * * 1-5` | Weekdays at 8:00 AM IST |
| `30 9 * * *` | Every day at 9:30 AM IST |
| `0 */4 * * *` | Every 4 hours at :00 |

**Rule**: Minute in cron is ALWAYS preserved after start_at.

---

## Escalation Config

### New Checkboxes
| Field | Default | Meaning |
|-------|---------|---------|
| `send_resolved_mail` | OFF | Send email when all issues resolved |
| `env_mail_enabled` | ON | Master switch for all escalation emails |

### Status Filter on Escalation Page
- Default view: Open + Escalated
- Click "Resolved: X" badge → shows resolved issues
- Use Status dropdown → filter by Open/Escalated/Resolved

---

## Rerun Queue

### View Logs Button
Each rerun row has **View Logs** → opens run logs showing:
- Exact failure reason
- Step-by-step execution log
- Error detail and stack trace

### Manual Kill Recovery
If a run is killed (server restart, OOM, etc.):
- Stuck-run watcher detects it after 90 minutes (configurable in `system_config.stuck_run_timeout_minutes`)
- Marks run as FAILED with reason
- Creates rerun_queue entry automatically
- Sends failure email

---

## File Change Summary (v7 → v8)

| File | Change |
|------|--------|
| `healthcheck/ist_utils.py` | **NEW** — IST/UTC conversion utilities |
| `healthcheck/templatetags/ist_filters.py` | **NEW** — `\|ist` template filter |
| `healthcheck/scheduler_service.py` | Full rewrite — IST/UTC separation, start_at gate |
| `healthcheck/engine/core/config.py` | Added timezone, stuck_run_timeout_minutes |
| `healthcheck/engine/core/issue_tracker.py` | Resolved tracking for mail |
| `healthcheck/engine/scheduling/run_launcher.py` | Resolved mail integration |
| `healthcheck/engine/notifications/email_service.py` | send_resolved() added |
| `healthcheck/engine/checks/server_manager.py` | WMI COM cleanup fix |
| `healthcheck/models.py` | EscalationConfig: send_resolved_mail, env_mail_enabled |
| `healthcheck/admin.py` | ScheduleAdmin shows IST times |
| `healthcheck/views.py` | escalation_view RESOLVED rows; scheduler_view IST |
| `templates/scheduler.html` | No popup, IST times, 30s refresh only here |
| `templates/escalation.html` | RESOLVED rows, all filters, resolved mail info |
| `templates/rerun.html` | View Logs button, IST times, better UI |
| `doc/alter_v8.sql` | **NEW** — DB alter script |
| `doc/GUIDE_v8.md` | **NEW** — This guide |
