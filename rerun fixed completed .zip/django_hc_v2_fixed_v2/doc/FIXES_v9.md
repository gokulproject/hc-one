# Health Check Scheduler — Bug-Fix Release v9

## Summary of Fixes Applied

---

## Fix 1 — `from healthcheck.ist_utils import utc_to_ist, _next_cron_utc, now_utc` → ImportError

**File:** `healthcheck/ist_utils.py`

**Root cause:** `_next_cron_utc` function was missing from `ist_utils.py`, causing an `ImportError` every time `scheduler_view` was loaded.

**Fix:** Added `_next_cron_utc(cron_expression, after_utc)` to `ist_utils.py`. It computes the next UTC datetime from a cron expression anchored in IST.

---

## Fix 2 — Updating `start_at` on an existing schedule has no effect

**Files:** `healthcheck/admin.py`, `healthcheck/scheduler_service.py`

**Root cause:** The APScheduler DateTrigger chain was already running with `last_run_at` and `next_run_at` set from the old `start_at`. Saving a new `start_at` in DB did nothing because the chain continued from its existing `next_run_at`.

**Fix:**
- Added `reschedule_after_start_at_update(schedule_id)` in `scheduler_service.py`. It:
  1. Reads the new `start_at`
  2. Computes the next correct fire time (advancing by intervals if `start_at` is in the past)
  3. Resets `last_run_at = NULL` and `next_run_at = new_fire_utc` in the DB
  4. Replaces the existing APScheduler job with a fresh `DateTrigger`
- Added `save_model()` hook in `ScheduleAdmin` that calls `reschedule_after_start_at_update` whenever `start_at` or `cron_expression` changes on save.

---

## Fix 3 — Missed / skipped runs fire immediately instead of computing next valid time

**File:** `healthcheck/scheduler_service.py` → `_register_jobs()`

**Root cause:** Case C (missed run detected on restart) fired at `now + 5s`, causing an unintended immediate execution without respecting the `start_at` offset anchor.

**Fix:** Case C now advances from `start_at` by the cron interval until it finds a future time:
```python
candidate = start_at_raw
while candidate <= now_utc:
    candidate += interval
fire_utc = candidate
```
This preserves the exact minute-offset from `start_at` and avoids unwanted duplicate runs.

---

## Fix 4 — All input fields selectable when scheduling a custom env (forms)

**File:** `healthcheck/forms.py` → `ScheduleForm`

**Root cause:** `env_types` was a plain `TextInput` (no dropdown), `start_at` was not in the form at all, and `cron_expression` had no preset picker.

**Fix:** `ScheduleForm` now has:
- `env_types` → `ChoiceField` (dropdown: PRD, VAL, DEV, PRD+VAL, PRD+VAL+DEV)
- `cron_preset` → preset picker (updates `cron_expression` via `onchange` JS)
- `start_at` → `DateTimeField` with `datetime-local` input (IST → UTC on clean)
- `clean_start_at()` converts IST naive input → UTC for DB storage

---

## Fix 5 — Rerun `status` stuck at PENDING / not updating after execution

**Files:**
- `healthcheck/engine/scheduling/scheduler.py` → `_process_reruns()`
- `healthcheck/views.py` → `trigger_rerun()`

**Root causes:**
1. `_process_reruns` always wrote `status='COMPLETED'` regardless of run outcome — so failed reruns showed as COMPLETED, and the next attempt was inserted but status never showed correctly.
2. Manual `trigger_rerun` left `rerun_queue.status = 'IN_PROGRESS'` forever because `_execute_run` ran in a thread with no status-update callback.

**Fixes:**
- `_process_reruns` now correctly sets:
  - `COMPLETED` only when run succeeds
  - `FAILED` when run fails but more attempts remain (and schedules next)
  - `EXHAUSTED` when all attempts are used up
- `trigger_rerun` now uses `_run_and_update_rerun_status()` wrapper thread that calls `_execute_run` then updates `rerun_queue.status` to `COMPLETED` or `FAILED` after the run finishes.

---

## Fix 6 — Rerun shows EXHAUSTED when retries not yet expired

**File:** `healthcheck/views.py` → `trigger_rerun()`

**Root cause:** The check `if nxt_att > max_att` was wrong — it blocked attempt 3 when max was 3 (treating attempt 3 as over the limit).

**Fix:** Changed to `if cur_att >= max_att` — correctly allows attempt `max_att` and blocks only when all are used.

---

## Fix 7 — `Unknown column 'rerun_max_attempts'` on manual rerun trigger

**File:** `healthcheck/views.py` → `trigger_rerun()`

**Root cause:** Query used `SELECT rerun_max_attempts FROM system_config WHERE config_key='rerun_max_attempts'` — but the column is `config_value`, not `rerun_max_attempts`.

**Fix:** Changed to:
```python
cfg_row = db.fetch_one(
    "SELECT config_value FROM system_config WHERE config_key='rerun_max_attempts'")
max_att = int(cfg_row["config_value"]) if cfg_row else 3
```

---

## Fix 8 — Wrong email import in `scheduler.py` `_process_reruns`

**File:** `healthcheck/engine/scheduling/scheduler.py`

**Root cause:** `from notifications.email_service import EmailService` — missing `healthcheck.engine.` prefix, causing `ModuleNotFoundError` when exhausted rerun email was sent.

**Fix:** Changed to `from healthcheck.engine.notifications.email_service import EmailService`.

---

## Fix 9 — `nxt_sched` using `datetime.now()` (local time) instead of UTC

**File:** `healthcheck/engine/scheduling/scheduler.py` → `_process_reruns()`

**Root cause:** `nxt_sched = datetime.now() + timedelta(hours=cfg.rerun_interval_hours)` used local server time, not UTC. Since DB stores UTC, the next rerun scheduled_at could be 5:30h wrong in IST environments.

**Fix:** Changed to `datetime.utcnow() + timedelta(hours=cfg.rerun_interval_hours)`.

---

## Database Migration

Run `alter_v9_fixes.sql` once on the `hc_v5` database:

```bash
mysql -u admin -p hc_v5 < healthcheck/engine/alter_v9_fixes.sql
```

**What it does:**
1. Adds `started_at` / `completed_at` columns to `rerun_queue` if missing
2. Recovers stuck `IN_PROGRESS` rows (from crashed processes) → sets to `FAILED`
3. Ensures `schedules.start_at`, `last_run_at`, `next_run_at` are nullable
4. Ensures `execution_runs.rerun_attempt` has `DEFAULT 0`
5. Inserts `rerun_max_attempts` and `rerun_interval_hours` into `system_config` if missing

---

## Files Changed

| File | Change |
|------|--------|
| `healthcheck/ist_utils.py` | Added `_next_cron_utc()` function |
| `healthcheck/forms.py` | `ScheduleForm` with dropdown inputs, `start_at`, cron presets |
| `healthcheck/admin.py` | `ScheduleAdmin.save_model()` triggers reschedule on `start_at`/cron change |
| `healthcheck/views.py` | Fixed import, `trigger_rerun` column name bug, rerun status update |
| `healthcheck/scheduler_service.py` | Fixed Case C missed-run logic; added `reschedule_after_start_at_update()` |
| `healthcheck/engine/scheduling/scheduler.py` | Fixed `_process_reruns`: status, exhausted, email import, UTC time |
| `healthcheck/engine/alter_v9_fixes.sql` | *(new)* DB migration script |
| `doc/FIXES_v9.md` | *(this file)* |
