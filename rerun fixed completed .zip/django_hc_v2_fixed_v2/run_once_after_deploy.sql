-- =============================================================================
--  Django Health Check v2 — Post-Deploy SQL  (v5 release)
--  Run this ONCE after deploying sceduler_fixed_v5_rerun_fixed.zip
--  Safe to run multiple times (all statements are idempotent / guarded).
-- =============================================================================

-- ── STEP 1: Reset stuck IN_PROGRESS rows from the old buggy code ──────────
-- Rows that were left IN_PROGRESS by the duplicate-execution bug (v4 and
-- earlier) will never be picked up again.  Reset them to FAILED so the
-- poller can create clean retry entries on the next cycle.

UPDATE rerun_queue
SET    status       = 'FAILED',
       last_error   = 'Reset by v5 deploy cleanup — was stuck IN_PROGRESS',
       completed_at = NOW()
WHERE  status      = 'IN_PROGRESS'
  AND  started_at  < NOW() - INTERVAL 2 HOUR;

SELECT CONCAT('Stuck rows reset: ', ROW_COUNT()) AS step1_result;


-- ── STEP 2: Remove duplicate rerun_queue rows ─────────────────────────────
-- Keep the row with the lowest id for each (original_run_id, attempt_number)
-- pair.  Duplicate rows were created when both _fire_rerun_entry and
-- run_launcher._queue_rerun each inserted the next attempt (fixed in v5).

DELETE rq
FROM   rerun_queue rq
JOIN (
    SELECT MIN(id) AS keep_id,
           original_run_id,
           attempt_number
    FROM   rerun_queue
    GROUP  BY original_run_id, attempt_number
    HAVING COUNT(*) > 1
) dup
  ON  rq.original_run_id = dup.original_run_id
  AND rq.attempt_number  = dup.attempt_number
  AND rq.id             <> dup.keep_id;

SELECT CONCAT('Duplicate rows removed: ', ROW_COUNT()) AS step2_result;


-- ── STEP 3: Add unique constraint to prevent future duplicates ────────────
-- Only runs if the constraint does not already exist.
-- This makes the DB itself enforce the invariant: one row per
-- (original_run_id, attempt_number) pair.

SET @con_exists = (
    SELECT COUNT(*)
    FROM   information_schema.TABLE_CONSTRAINTS
    WHERE  TABLE_SCHEMA    = DATABASE()
      AND  TABLE_NAME      = 'rerun_queue'
      AND  CONSTRAINT_NAME = 'uq_rerun_original_attempt'
);

SET @sql = IF(
    @con_exists = 0,
    'ALTER TABLE rerun_queue ADD CONSTRAINT uq_rerun_original_attempt UNIQUE (original_run_id, attempt_number)',
    'SELECT ''Constraint uq_rerun_original_attempt already exists — skipped'' AS step3_result'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;


-- ── STEP 4: Verify — confirm no duplicates remain ─────────────────────────

SELECT
    CASE
        WHEN COUNT(*) = 0 THEN 'OK — no duplicate (original_run_id, attempt_number) pairs'
        ELSE CONCAT('WARNING — ', COUNT(*), ' duplicate groups still exist')
    END AS step4_duplicate_check
FROM (
    SELECT original_run_id, attempt_number
    FROM   rerun_queue
    GROUP  BY original_run_id, attempt_number
    HAVING COUNT(*) > 1
) dups;


-- ── STEP 5: Summary of current rerun_queue status ─────────────────────────

SELECT
    status,
    COUNT(*) AS row_count,
    MIN(scheduled_at) AS earliest,
    MAX(scheduled_at) AS latest
FROM   rerun_queue
GROUP  BY status
ORDER  BY FIELD(status, 'PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'EXHAUSTED');

-- =============================================================================
--  END OF SCRIPT
-- =============================================================================
