from django.contrib import admin
from django.urls import path, include

admin.site.site_header = "Health Check Administration"
admin.site.site_title  = "HC Admin"
admin.site.index_title = "Health Check v6"

urlpatterns = [
    path("admin/", admin.site.urls),
    # All HC pages live under /healthcheck/
    path("healthcheck/", include("healthcheck.urls")),
    # Legacy root redirect → dashboard
    path("", include("healthcheck.urls")),
]
