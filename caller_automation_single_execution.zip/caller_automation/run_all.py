"""
SINGLE EXECUTION ENTRY POINT
======================================================================
Runs the entire process end to end, in one execution:

  PIPELINE 1 - 8x8
    Step 1  : Login to 8x8, download CDR Excel for Advagen MICC and
              Validus MICC (intilial_process_1.py logic, unchanged)
    Step 2  : Extract answered Call IDs from those Excel files
              (excel_extration_callids.py logic, unchanged)
    Step 3  : Open 8x8 Recordings admin page, capture size/duration
              per Call ID (call_info_ui.py logic, unchanged)
    Step 4  : Cross-check UI info against local recording files and
              build the final validation report
              (validation_report.py logic, unchanged)

  PIPELINE 2 - CLINEVO   (starts its OWN Chrome session, as requested)
    Step 1  : Login to Clinevo per enterprise (Advagen, Validus), edit
              the report SQL date range, download line listing Excel
              (intilial_process_2.py logic, unchanged)
    Step 2  : Check each Clinevo case against local recording folders
              and build the case-file-check report
              (extract_clinivo_excel_check.py logic, unchanged)

No automation logic (selectors, waits, matching rules) was changed in
any step - only how the 6 original scripts are wired together and
where their shared settings live (config.py).

USAGE:
    python run_all.py

Requires Chrome already reachable (or launchable) via CDP, same as
the original standalone scripts.
======================================================================
"""

import asyncio
import sys

from utils.logger_setup import get_logger

logger = get_logger(__name__)


async def run_pipeline_8x8():
    """
    Steps 1-4 of Pipeline 1 (8x8), run in sequence, in-process.
    Step 1 and Step 3 drive the browser (same Chrome/CDP session).
    Step 2 and Step 4 are pure Excel/data processing steps.
    """

    logger.info("#" * 100)
    logger.info("PIPELINE 1 (8x8) - STARTING")
    logger.info("#" * 100)

    from pipeline_8x8 import step1_download_cdr
    from pipeline_8x8 import step2_extract_call_ids
    from pipeline_8x8 import step3_capture_ui_info
    from pipeline_8x8 import step4_validation_report

    logger.info("PIPELINE 1 - STEP 1 : Login + Download CDR Excel")
    await step1_download_cdr.run_step1()

    logger.info("PIPELINE 1 - STEP 2 : Extract Call IDs From Excel")
    step2_extract_call_ids.run_step2()

    logger.info("PIPELINE 1 - STEP 3 : Capture UI Info From Recordings Page")
    await step3_capture_ui_info.run_step3()

    logger.info("PIPELINE 1 - STEP 4 : Build Validation Report")
    step4_validation_report.run_step4()

    logger.info("#" * 100)
    logger.info("PIPELINE 1 (8x8) - COMPLETED")
    logger.info("#" * 100)


async def run_pipeline_clinevo():
    """
    Steps 1-2 of Pipeline 2 (Clinevo). Step 1 opens/continues its own
    Chrome session (same CDP port, independent connection) and drives
    the Clinevo site. Step 2 is pure Excel/data processing.
    """

    logger.info("#" * 100)
    logger.info("PIPELINE 2 (CLINEVO) - STARTING")
    logger.info("#" * 100)

    from pipeline_clinevo import step1_download_line_listing
    from pipeline_clinevo import step2_case_file_check

    logger.info("PIPELINE 2 - STEP 1 : Login + Download Line Listing Excel")
    await step1_download_line_listing.run_step1_clinevo()

    logger.info("PIPELINE 2 - STEP 2 : Check Cases Against Local Files")
    step2_case_file_check.run_step2_clinevo()

    logger.info("#" * 100)
    logger.info("PIPELINE 2 (CLINEVO) - COMPLETED")
    logger.info("#" * 100)


async def main():

    logger.info("=" * 100)
    logger.info("SINGLE EXECUTION AUTOMATION STARTED")
    logger.info("=" * 100)

    try:
        # ------------------------------------------------------------
        # PIPELINE 1 first: download 8x8 CDR excel, extract call ids,
        # capture UI info, build the validation report.
        # ------------------------------------------------------------
        await run_pipeline_8x8()

        # ------------------------------------------------------------
        # PIPELINE 2 continues after Pipeline 1's excel/report work is
        # fully done - with its own Chrome session, exactly as
        # requested.
        # ------------------------------------------------------------
        await run_pipeline_clinevo()

        logger.info("=" * 100)
        logger.info("SINGLE EXECUTION AUTOMATION COMPLETED SUCCESSFULLY")
        logger.info("=" * 100)

    except Exception as e:
        logger.error(f"SINGLE EXECUTION AUTOMATION FAILED : {e}")
        raise


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.warning("Automation interrupted by user")
        sys.exit(1)
    except Exception:
        sys.exit(1)
