"""
CENTRAL CONFIGURATION
======================================================================
Every path, credential, site name, filter text, tolerance, and timing
value that used to be hardcoded separately inside the 6 original
scripts now lives here, in ONE place.

IMPORTANT: No automation logic (selectors, click order, wait
conditions, matching rules) was changed anywhere in this project.
This file only centralizes the VALUES that were previously duplicated
or scattered, and ALIGNS every Excel/report/screenshot folder under
one common root so the whole thing runs as a single execution.

Folder layout produced under BASE_DIR (see ALIGNED FOLDER LAYOUT
below) mirrors the original project's folder relationships 1:1 -
nothing was renamed in a way that changes what goes where, it was
only pulled out of scattered scripts into one aligned tree.
======================================================================
"""

import os

# ======================================================================
# BASE PATHS
# ======================================================================
# Everything is relative to the project folder so the project runs
# correctly no matter where it is copied/extracted on disk (Windows,
# same machine, another machine, etc). If you want to keep using the
# exact original D:\ location, set CALLER_AUTOMATION_ROOT env var to
# that path and this will use it automatically.

BASE_DIR = os.environ.get(
    "CALLER_AUTOMATION_ROOT",
    os.path.dirname(os.path.abspath(__file__))
)

DATA_DIR = os.path.join(BASE_DIR, "data")

# ======================================================================
# CHROME / CDP (shared by both pipelines)
# ======================================================================
# Pipeline 1 (8x8) and Pipeline 2 (Clinevo) each connect to Chrome via
# CDP independently, exactly like the original two scripts did.
# Pipeline 2 is expected to open/continue its OWN Chrome session after
# Pipeline 1 finishes and closes its Analytics popup - unchanged.

CHROME_DEBUG_URL = "http://127.0.0.1:9222"
CHROME_EXE_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_USER_DATA_DIR = r"C:\temp\chrome-debug"

# ======================================================================
# ALIGNED FOLDER LAYOUT
# ======================================================================
#
# data/
#   pipeline_8x8/
#     advagen_micc_excel/         <- CDR export for Advagen MICC
#     validus_micc_excel/         <- CDR export for Validus MICC
#     screenshots/                <- step1 failure screenshots
#     process2_screenshots/       <- step3 (UI capture) failure screenshots
#     process3_report/            <- step4 final validation report
#     call_ids.json                <- step1->step2 handoff file
#     ui_capture.json              <- step2->step3 handoff file
#   pipeline_clinevo/
#     advagen_excel/              <- Clinevo line listing for Advagen
#     validus_excel/              <- Clinevo line listing for Validus
#     screenshots/                <- step1 failure screenshots
#     case_check_report/          <- step2 final case-check report
#   documents/
#     advagen_micc/call_recordings/
#     validus_micc/call_recordings/

PIPELINE_8X8_DIR = os.path.join(DATA_DIR, "pipeline_8x8")
PIPELINE_CLINEVO_DIR = os.path.join(DATA_DIR, "pipeline_clinevo")
DOCUMENTS_DIR = os.path.join(DATA_DIR, "documents")

# ---- Pipeline 1 (8x8) folders -----------------------------------------
SITE_FILTER_1_DOWNLOAD_FOLDER = os.path.join(PIPELINE_8X8_DIR, "advagen_micc_excel")
SITE_FILTER_2_DOWNLOAD_FOLDER = os.path.join(PIPELINE_8X8_DIR, "validus_micc_excel")
PIPELINE_8X8_SCREENSHOT_FOLDER = os.path.join(PIPELINE_8X8_DIR, "screenshots")
PROCESS2_SCREENSHOT_FOLDER = os.path.join(PIPELINE_8X8_DIR, "process2_screenshots")
PROCESS3_REPORT_FOLDER = os.path.join(PIPELINE_8X8_DIR, "process3_report")

CALL_IDS_JSON = os.path.join(PIPELINE_8X8_DIR, "call_ids.json")
UI_CAPTURE_JSON = os.path.join(PIPELINE_8X8_DIR, "ui_capture.json")
VALIDATION_REPORT_FILE = os.path.join(PROCESS3_REPORT_FOLDER, "Recording_Validation_Report.xlsx")

# ---- Pipeline 2 (Clinevo) folders -------------------------------------
CLINEVO_ENTERPRISE_1_EXCEL = os.path.join(PIPELINE_CLINEVO_DIR, "advagen_excel")
CLINEVO_ENTERPRISE_2_EXCEL = os.path.join(PIPELINE_CLINEVO_DIR, "validus_excel")
PIPELINE_CLINEVO_SCREENSHOT_FOLDER = os.path.join(PIPELINE_CLINEVO_DIR, "screenshots")
CASE_CHECK_REPORT_FOLDER = os.path.join(PIPELINE_CLINEVO_DIR, "case_check_report")
CASE_CHECK_REPORT_FILE = os.path.join(CASE_CHECK_REPORT_FOLDER, "Clinivo_Case_File_Check_Report.xlsx")

# ---- Shared local recordings (read by step4 + clinevo step2) ----------
ADVAGEN_RECORDING_PATH = os.path.join(DOCUMENTS_DIR, "advagen_micc", "call_recordings")
VALIDUS_RECORDING_PATH = os.path.join(DOCUMENTS_DIR, "validus_micc", "call_recordings")

SITE_PATHS = {
    "Advagen MICC": ADVAGEN_RECORDING_PATH,
    "Validus MICC": VALIDUS_RECORDING_PATH
}

SITE_CONFIG_CLINEVO = {
    "Advagen MICC": {
        "excel_folder": CLINEVO_ENTERPRISE_1_EXCEL,
        "local_base_folder": ADVAGEN_RECORDING_PATH
    },
    "Validus MICC": {
        "excel_folder": CLINEVO_ENTERPRISE_2_EXCEL,
        "local_base_folder": VALIDUS_RECORDING_PATH
    }
}

# ======================================================================
# PIPELINE 1 - 8x8 (Analytics / CDR / Recordings / Validation)
# ======================================================================

# ---- Step 1 : login + CDR download ------------------------------------
EIGHTX8_USERNAME = "udhayaprakash.gajendhiran"
EIGHTX8_PASSWORD = "@Udhayag"

# DATE_RANGE = "Last 7 days"
DATE_RANGE = "Yesterday"

TIME_ZONE = "America/New_York"
SITE_FILTER_1 = "Advagen MICC"
SITE_FILTER_2 = "Validus MICC"

ANALYTICS_URL = "https://apps.8x8.com/"

# ---- Step 3 : UI capture (8x8 recordings admin) ------------------------
APP_URL = "https://apps.8x8.com/"
RECORDINGS_URL = "https://admin.8x8.com/recordings"

SITE_ORDER = [
    "Advagen MICC",
    "Validus MICC"
]

FILTER_ADD_BUTTON = '[data-test-id="FILTER_LIST_ADD_NEW_FILTER_BUTTON"]'
FILTER_NAME_SEARCH_INPUT = '[data-test-id="FILTER_LIST_ADD_NEW_FILTER_SEARCH_INPUT_FIELD"]'
FILTER_VALUE_SEARCH_INPUT = '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_VALUES_SELECTION_INPUT_FIELD"]'
FILTER_VALUE_CHECKBOX = '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_VALUES_CHECKBOX"]'
FILTER_APPLY_BUTTON = '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_BOTTOM_ACTIONS_APPLY_FILTER"]'
FILTER_DROPDOWN_CONTAINER = '[data-test-id="FILTER_LIST_FILTER_DROPDOWN_CONTENT_CONTAINER"]'
PLAYER_DURATION_LOCATOR = '[data-test-id="PLAYER_TIMELINE_MFE_SEEK_SLIDER_DURATION"]'

# ---- Step 4 : validation tolerances ------------------------------------
AUDIO_EXTENSIONS = (".wav", ".mp3", ".m4a", ".wma", ".aac", ".ogg", ".flac")

# Strict size tolerance. 0.02 means 2%.
# Example: UI Size = 1000 KB, Local Size = 1018 KB -> 1.8% diff -> match
SIZE_TOLERANCE = 0.02

# ======================================================================
# PIPELINE 2 - CLINEVO (Line Listing / Case File Check)
# ======================================================================

CLINEVO_LOGIN_URL = "https://octp.clinevotech.com/clinevo/#/login"

CLINEVO_USERNAME = "UDHAYAPRAKASHG"
CLINEVO_PASSWORD = "@NaHHHH123"

CLINEVO_ENTERPRISE_1 = "Advagen"
CLINEVO_ENTERPRISE_2 = "Validus"

REPORT_FROM_DATE = "03-JUL-2026"
REPORT_TO_DATE = "09-JUL-2026"

SUPPORTED_LOCAL_FILE_EXTENSIONS = (
    ".pdf", ".doc", ".docx", ".xlsx", ".xls", ".csv", ".txt", ".msg", ".eml",
    ".wav", ".mp3", ".m4a", ".wma", ".aac", ".ogg", ".flac"
)

# ======================================================================
# ENSURE ALL FOLDERS EXIST
# ======================================================================


def ensure_all_folders():
    for folder in (
        SITE_FILTER_1_DOWNLOAD_FOLDER,
        SITE_FILTER_2_DOWNLOAD_FOLDER,
        PIPELINE_8X8_SCREENSHOT_FOLDER,
        PROCESS2_SCREENSHOT_FOLDER,
        PROCESS3_REPORT_FOLDER,
        CLINEVO_ENTERPRISE_1_EXCEL,
        CLINEVO_ENTERPRISE_2_EXCEL,
        PIPELINE_CLINEVO_SCREENSHOT_FOLDER,
        CASE_CHECK_REPORT_FOLDER,
        ADVAGEN_RECORDING_PATH,
        VALIDUS_RECORDING_PATH,
    ):
        os.makedirs(folder, exist_ok=True)


ensure_all_folders()
