import os
import re
import glob
import logging
from datetime import datetime

import pandas as pd

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# ==========================================================
# CONFIGURATION (centralized in config.py - values unchanged)
# ==========================================================

from config import (
    SITE_CONFIG_CLINEVO as SITE_CONFIG,
    CASE_CHECK_REPORT_FOLDER as REPORT_FOLDER,
    CASE_CHECK_REPORT_FILE as REPORT_FILE,
    SUPPORTED_LOCAL_FILE_EXTENSIONS,
)


# ==========================================================
# LOGGING (centralized in utils/logger_setup.py)
# ==========================================================

from utils.logger_setup import get_logger

logger = get_logger(__name__)


# ==========================================================
# COMMON HELPERS
# ==========================================================

def safe_string(value):
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    try:
        if hasattr(value, "strftime"):
            return value.strftime("%d-%b-%Y").upper()
    except Exception:
        pass

    return str(value).strip()


def normalize_column_name(value):
    text = safe_string(value)
    text = text.replace("\n", " ")
    text = text.replace("\r", " ")
    text = text.replace("\xa0", " ")
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "", text)
    return text


def normalize_case_number(value):
    text = safe_string(value)
    text = text.strip()
    text = text.upper()
    text = re.sub(r"\s+", "", text)
    return text


def normalize_file_match_text(value):
    text = safe_string(value)
    text = text.upper()
    text = text.strip()
    return text


def latest_excel_files(folder_path):
    if not os.path.exists(folder_path):
        logger.warning(f"Clinivo Excel folder does not exist: {folder_path}")
        return []

    files = glob.glob(
        os.path.join(folder_path, "*.xlsx")
    )

    files = [
        file for file in files
        if not os.path.basename(file).startswith("~$")
    ]

    files.sort(
        key=lambda path: os.path.getmtime(path),
        reverse=True
    )

    return files


# ==========================================================
# DATE HELPERS
# ==========================================================

def parse_case_received_date(value):
    """
    Supports:
    - 06-JUL-2026
    - 6-JUL-2026
    - 06 JUL 2026
    - 07/06/2026
    - 2026-07-06
    - pandas Timestamp / datetime
    """

    if value is None:
        return None

    try:
        if pd.isna(value):
            return None
    except Exception:
        pass

    try:
        if hasattr(value, "strftime"):
            return value
    except Exception:
        pass

    text = str(value).strip()

    if not text:
        return None

    text_upper = text.upper()
    text_upper = text_upper.replace(".", "-")
    text_upper = re.sub(r"\s+", " ", text_upper)

    date_formats = [
        "%d-%b-%Y",
        "%d-%B-%Y",
        "%d %b %Y",
        "%d %B %Y",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M:%S"
    ]

    for fmt in date_formats:
        try:
            return datetime.strptime(text_upper, fmt)
        except Exception:
            pass

    match = re.search(
        r"\d{1,2}[-\s][A-Z]{3,9}[-\s]\d{4}",
        text_upper
    )

    if match:
        candidate = match.group(0).replace(" ", "-")

        for fmt in ["%d-%b-%Y", "%d-%B-%Y"]:
            try:
                return datetime.strptime(candidate, fmt)
            except Exception:
                pass

    return None


def format_case_received_date(value):
    dt = parse_case_received_date(value)

    if not dt:
        return safe_string(value)

    return dt.strftime("%d-%b-%Y").upper()


def build_expected_date_folder_parts(case_received_date):
    dt = parse_case_received_date(case_received_date)

    if not dt:
        return None

    year_folder = dt.strftime("%Y")
    month_folder = dt.strftime("%b %Y").upper()

    date_folder_no_leading_zero = f"{dt.day} {dt.strftime('%b %Y').upper()}"
    date_folder_with_leading_zero = f"{dt.day:02d} {dt.strftime('%b %Y').upper()}"

    return {
        "year_folder": year_folder,
        "month_folder": month_folder,
        "date_folder_no_leading_zero": date_folder_no_leading_zero,
        "date_folder_with_leading_zero": date_folder_with_leading_zero
    }


def get_possible_date_folders(local_base_folder, case_received_date):
    parts = build_expected_date_folder_parts(case_received_date)

    if not parts:
        return []

    possible_folders = [
        os.path.join(
            local_base_folder,
            parts["year_folder"],
            parts["month_folder"],
            parts["date_folder_no_leading_zero"]
        ),
        os.path.join(
            local_base_folder,
            parts["year_folder"],
            parts["month_folder"],
            parts["date_folder_with_leading_zero"]
        )
    ]

    unique_folders = []

    for folder in possible_folders:
        if folder not in unique_folders:
            unique_folders.append(folder)

    return unique_folders


def find_existing_date_folder(local_base_folder, case_received_date):
    possible_folders = get_possible_date_folders(
        local_base_folder,
        case_received_date
    )

    for folder in possible_folders:
        if os.path.exists(folder):
            return folder

    return ""


# ==========================================================
# CLINIVO EXCEL READING
# ==========================================================

def find_header_row(excel_file):
    preview_df = pd.read_excel(
        excel_file,
        header=None,
        dtype=str,
        engine="openpyxl"
    )

    max_rows_to_scan = min(
        30,
        len(preview_df)
    )

    for row_index in range(max_rows_to_scan):
        row_values = []

        for value in preview_df.iloc[row_index].tolist():
            normalized_value = normalize_column_name(value)

            if normalized_value:
                row_values.append(normalized_value)

        has_case_number = any(
            item in [
                "casenumber",
                "caseno",
                "caseid",
                "case"
            ]
            for item in row_values
        )

        has_received_date = any(
            item in [
                "casereceiveddate",
                "receiveddate",
                "casecreateddate",
                "createddate"
            ]
            for item in row_values
        )

        if has_case_number and has_received_date:
            return row_index

    return None


def find_columns(df):
    case_number_column = None
    case_classification_column = None
    case_received_date_column = None

    for col in df.columns:
        normalized_col = normalize_column_name(col)

        if normalized_col in [
            "casenumber",
            "caseno",
            "caseid",
            "case"
        ]:
            case_number_column = col

        elif normalized_col in [
            "caseclassification",
            "classification",
            "casetype",
            "casecategory"
        ]:
            case_classification_column = col

        elif normalized_col in [
            "casereceiveddate",
            "receiveddate",
            "casecreateddate",
            "createddate"
        ]:
            case_received_date_column = col

    return {
        "case_number_column": case_number_column,
        "case_classification_column": case_classification_column,
        "case_received_date_column": case_received_date_column
    }


def extract_clinivo_cases_from_excel(excel_file, site_name):
    logger.info("-" * 100)
    logger.info(f"Reading Clinivo Excel: {excel_file}")

    header_row = find_header_row(excel_file)

    if header_row is None:
        logger.warning(
            f"Header row not found. Required columns: Case Number and Case Received Date. File: {excel_file}"
        )
        return []

    df = pd.read_excel(
        excel_file,
        header=header_row,
        engine="openpyxl"
    )

    df.columns = [
        safe_string(col)
        for col in df.columns
    ]

    columns = find_columns(df)

    case_number_column = columns["case_number_column"]
    case_classification_column = columns["case_classification_column"]
    case_received_date_column = columns["case_received_date_column"]

    if not case_number_column:
        logger.warning(f"Case Number column not found in file: {excel_file}")
        return []

    if not case_received_date_column:
        logger.warning(f"Case Received Date column not found in file: {excel_file}")
        return []

    logger.info(f"Case Number column: {case_number_column}")
    logger.info(f"Case Classification column: {case_classification_column}")
    logger.info(f"Case Received Date column: {case_received_date_column}")

    cases = []

    for index, row in df.iterrows():
        case_number = normalize_case_number(
            row.get(case_number_column, "")
        )

        if not case_number:
            continue

        case_classification = ""

        if case_classification_column:
            case_classification = safe_string(
                row.get(case_classification_column, "")
            )

        case_received_date_raw = row.get(
            case_received_date_column,
            ""
        )

        case_received_date = format_case_received_date(
            case_received_date_raw
        )

        cases.append(
            {
                "source_site": site_name,
                "source_excel_file": excel_file,
                "excel_row_sequence": index + header_row + 2,
                "case_number": case_number,
                "case_classification": case_classification,
                "case_received_date": case_received_date
            }
        )

    logger.info(f"Cases extracted from file: {len(cases)}")

    return cases


def extract_all_clinivo_cases():
    all_cases = []

    for site_name, config in SITE_CONFIG.items():
        excel_folder = config["excel_folder"]

        excel_files = latest_excel_files(excel_folder)

        logger.info("=" * 100)
        logger.info(f"Clinivo extraction started for site: {site_name}")
        logger.info(f"Excel folder: {excel_folder}")
        logger.info(f"Excel files found: {len(excel_files)}")

        if not excel_files:
            all_cases.append(
                {
                    "source_site": site_name,
                    "source_excel_file": "",
                    "excel_row_sequence": "",
                    "case_number": "",
                    "case_classification": "",
                    "case_received_date": "",
                    "extract_status": "EXCEL FILE NOT FOUND",
                    "extract_remarks": f"No .xlsx file found in folder: {excel_folder}"
                }
            )
            continue

        for excel_file in excel_files:
            cases = extract_clinivo_cases_from_excel(
                excel_file,
                site_name
            )

            all_cases.extend(cases)

    logger.info(f"Total Clinivo cases extracted: {len(all_cases)}")

    return all_cases


# ==========================================================
# LOCAL FILE CHECK
# ==========================================================

def list_local_files(date_folder):
    if not date_folder:
        return []

    if not os.path.exists(date_folder):
        return []

    local_files = []

    for root, dirs, files in os.walk(date_folder):
        for file_name in files:
            if file_name.lower().endswith(SUPPORTED_LOCAL_FILE_EXTENSIONS):
                local_files.append(
                    {
                        "file_name": file_name,
                        "file_path": os.path.join(root, file_name)
                    }
                )

    return local_files


def find_case_file_match(local_files, case_number):
    case_number_norm = normalize_file_match_text(case_number)

    for item in local_files:
        file_name = item.get("file_name", "")
        file_name_norm = normalize_file_match_text(file_name)

        if file_name_norm.startswith(case_number_norm):
            return item

    return None


def check_case_against_local_folder(case_item):
    site_name = case_item.get("source_site", "")
    case_number = case_item.get("case_number", "")
    case_received_date = case_item.get("case_received_date", "")

    config = SITE_CONFIG.get(site_name, {})
    local_base_folder = config.get("local_base_folder", "")

    if case_item.get("extract_status") == "EXCEL FILE NOT FOUND":
        return {
            **case_item,
            "expected_date_folder": "",
            "date_folder_available": "NO",
            "file_available": "NO",
            "matched_file_name": "",
            "matched_file_path": "",
            "status": "EXCEL FILE NOT FOUND",
            "remarks": case_item.get("extract_remarks", "")
        }

    if not local_base_folder:
        return {
            **case_item,
            "expected_date_folder": "",
            "date_folder_available": "NO",
            "file_available": "NO",
            "matched_file_name": "",
            "matched_file_path": "",
            "status": "UNKNOWN SITE",
            "remarks": f"Unknown source site: {site_name}"
        }

    if not case_received_date:
        return {
            **case_item,
            "expected_date_folder": "",
            "date_folder_available": "NO",
            "file_available": "NO",
            "matched_file_name": "",
            "matched_file_path": "",
            "status": "INVALID CASE RECEIVED DATE",
            "remarks": "Case Received Date is empty. Cannot build local date folder path."
        }

    date_folder = find_existing_date_folder(
        local_base_folder,
        case_received_date
    )

    possible_folders = get_possible_date_folders(
        local_base_folder,
        case_received_date
    )

    expected_folder_display = possible_folders[0] if possible_folders else ""

    if not date_folder:
        return {
            **case_item,
            "expected_date_folder": expected_folder_display,
            "date_folder_available": "NO",
            "file_available": "NO",
            "matched_file_name": "",
            "matched_file_path": "",
            "status": "DATE FOLDER NOT FOUND",
            "remarks": (
                "Local date folder not found for Case Received Date. "
                f"Expected folder: {expected_folder_display}"
            )
        }

    local_files = list_local_files(date_folder)

    if not local_files:
        return {
            **case_item,
            "expected_date_folder": date_folder,
            "date_folder_available": "YES",
            "file_available": "NO",
            "matched_file_name": "",
            "matched_file_path": "",
            "status": "FILE NOT FOUND",
            "remarks": "Date folder exists, but no supported local files were found inside the folder."
        }

    matched_file = find_case_file_match(
        local_files,
        case_number
    )

    if matched_file:
        return {
            **case_item,
            "expected_date_folder": date_folder,
            "date_folder_available": "YES",
            "file_available": "YES",
            "matched_file_name": matched_file.get("file_name", ""),
            "matched_file_path": matched_file.get("file_path", ""),
            "status": "MATCHED",
            "remarks": "Local file found. File name starts with Case Number."
        }

    return {
        **case_item,
        "expected_date_folder": date_folder,
        "date_folder_available": "YES",
        "file_available": "NO",
        "matched_file_name": "",
        "matched_file_path": "",
        "status": "NOT MATCHED",
        "remarks": "Date folder exists, but no local file name starts with Case Number."
    }


# ==========================================================
# REPORT
# ==========================================================

def write_report(report_rows):
    os.makedirs(
        REPORT_FOLDER,
        exist_ok=True
    )

    columns = [
        "Source Site",
        "Case Number",
        "Case Classification",
        "Case Received Date",
        "Date Folder Available",
        "File Available",
        "Status",
        "Matched File Name",
        "Expected Date Folder",
        "Matched File Path",
        "Source Excel File",
        "Excel Row Sequence",
        "Remarks"
    ]

    output_rows = []

    for item in report_rows:
        output_rows.append(
            {
                "Source Site": item.get("source_site", ""),
                "Case Number": item.get("case_number", ""),
                "Case Classification": item.get("case_classification", ""),
                "Case Received Date": item.get("case_received_date", ""),
                "Date Folder Available": item.get("date_folder_available", ""),
                "File Available": item.get("file_available", ""),
                "Status": item.get("status", ""),
                "Matched File Name": item.get("matched_file_name", ""),
                "Expected Date Folder": item.get("expected_date_folder", ""),
                "Matched File Path": item.get("matched_file_path", ""),
                "Source Excel File": item.get("source_excel_file", ""),
                "Excel Row Sequence": item.get("excel_row_sequence", ""),
                "Remarks": item.get("remarks", "")
            }
        )

    with pd.ExcelWriter(
        REPORT_FILE,
        engine="openpyxl"
    ) as writer:
        full_df = pd.DataFrame(
            output_rows,
            columns=columns
        )

        full_df.to_excel(
            writer,
            sheet_name="All Cases",
            index=False
        )

        for site in SITE_CONFIG.keys():
            site_df = full_df[
                full_df["Source Site"] == site
            ]

            site_df.to_excel(
                writer,
                sheet_name=site[:31],
                index=False
            )

    style_report(REPORT_FILE)

    logger.info(f"Report generated: {os.path.abspath(REPORT_FILE)}")


def style_report(file_path):
    workbook = load_workbook(file_path)

    header_fill = PatternFill(
        start_color="1F4E78",
        end_color="1F4E78",
        fill_type="solid"
    )

    header_font = Font(
        color="FFFFFF",
        bold=True
    )

    status_colors = {
        "MATCHED": "C6EFCE",
        "NOT MATCHED": "FFC7CE",
        "FILE NOT FOUND": "FCE4D6",
        "DATE FOLDER NOT FOUND": "FCE4D6",
        "INVALID CASE RECEIVED DATE": "FCE4D6",
        "UNKNOWN SITE": "FCE4D6",
        "EXCEL FILE NOT FOUND": "FCE4D6"
    }

    for sheet in workbook.worksheets:
        sheet.freeze_panes = "A2"

        if sheet.max_row >= 1 and sheet.max_column >= 1:
            sheet.auto_filter.ref = sheet.dimensions

        status_col = None

        for col_num in range(1, sheet.max_column + 1):
            cell = sheet.cell(
                row=1,
                column=col_num
            )

            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True
            )

            if cell.value == "Status":
                status_col = col_num

        if status_col:
            for row_num in range(2, sheet.max_row + 1):
                status_cell = sheet.cell(
                    row=row_num,
                    column=status_col
                )

                if status_cell.value in status_colors:
                    status_cell.fill = PatternFill(
                        start_color=status_colors[status_cell.value],
                        end_color=status_colors[status_cell.value],
                        fill_type="solid"
                    )

        for col_num in range(1, sheet.max_column + 1):
            max_length = 0

            for row_num in range(1, sheet.max_row + 1):
                value = sheet.cell(
                    row=row_num,
                    column=col_num
                ).value

                if value is not None:
                    max_length = max(
                        max_length,
                        len(str(value))
                    )

            sheet.column_dimensions[
                get_column_letter(col_num)
            ].width = min(
                max_length + 3,
                70
            )

        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(
                    vertical="center",
                    wrap_text=True
                )

    workbook.save(file_path)


# ==========================================================
# MAIN
# ==========================================================

def process_clinivo_case_check():
    logger.info("=" * 100)
    logger.info("PROCESS STARTED | EXTRACT CLINIVO EXCEL AND CHECK LOCAL FILES")
    logger.info("=" * 100)

    cases = extract_all_clinivo_cases()

    final_rows = []

    for index, case_item in enumerate(cases, start=1):
        logger.info("-" * 100)
        logger.info(
            f"Processing case {index}/{len(cases)} | "
            f"Site: {case_item.get('source_site', '')} | "
            f"Case Number: {case_item.get('case_number', '')} | "
            f"Received Date: {case_item.get('case_received_date', '')}"
        )

        final_rows.append(
            check_case_against_local_folder(case_item)
        )

    write_report(final_rows)

    logger.info("=" * 100)
    logger.info("PROCESS COMPLETED | CLINIVO CASE FILE CHECK")
    logger.info(f"Total cases processed: {len(final_rows)}")
    logger.info(f"Report file: {os.path.abspath(REPORT_FILE)}")
    logger.info("=" * 100)


# ==========================================================
# ENTRY POINT USED BY run_all.py
# ==========================================================

run_step2_clinevo = process_clinivo_case_check


if __name__ == "__main__":
    process_clinivo_case_check()