# Caller Automation - Single Execution (Phase 1: no database)

This is your original 6-script project (process 1 + process 2), merged into
one importable, single-execution project. **No automation logic was
changed** - every selector, wait, click order, filter rule, matching
tolerance, and flow is byte-for-byte identical to your original scripts.
Only two things changed:

1. All settings that used to be duplicated/hardcoded across the 6 scripts
   now live in one place: `config.py`.
2. The 6 scripts are wired together behind one entry point: `run_all.py`.

## What changed vs. your original files (nothing else)

| Original file | New location | What changed |
|---|---|---|
| `process 1/intilial_process_1.py` | `pipeline_8x8/step1_download_cdr.py` | config/logging block only |
| `process 1/.../excel_extration_callids.py` | `pipeline_8x8/step2_extract_call_ids.py` | config/logging block only |
| `process 1/.../call_info_ui.py` | `pipeline_8x8/step3_capture_ui_info.py` | config/logging block only |
| `process 1/.../validation_report.py` | `pipeline_8x8/step4_validation_report.py` | config/logging block only |
| `process 2/intilial_process_2.py` | `pipeline_clinevo/step1_download_line_listing.py` | config/logging block only |
| `process 2/.../extract_clinivo_excel_check.py` | `pipeline_clinevo/step2_case_file_check.py` | config/logging block only |

Every function, selector, and line of logic below the config block in each
file is unchanged - verified with a line-by-line diff against your
originals.

## Folder structure

```
caller_automation/
├── config.py                        # all settings, in one place
├── run_all.py                       # SINGLE EXECUTION entry point
├── requirements.txt
├── utils/
│   └── logger_setup.py              # shared logging setup
├── pipeline_8x8/
│   ├── step1_download_cdr.py        # was intilial_process_1.py
│   ├── step2_extract_call_ids.py    # was excel_extration_callids.py
│   ├── step3_capture_ui_info.py     # was call_info_ui.py
│   └── step4_validation_report.py   # was validation_report.py
├── pipeline_clinevo/
│   ├── step1_download_line_listing.py  # was intilial_process_2.py
│   └── step2_case_file_check.py        # was extract_clinivo_excel_check.py
└── data/                            # ALL excel/report/screenshot output
    ├── pipeline_8x8/
    │   ├── advagen_micc_excel/
    │   ├── validus_micc_excel/
    │   ├── screenshots/
    │   ├── process2_screenshots/
    │   ├── process3_report/
    │   ├── call_ids.json
    │   └── ui_capture.json
    ├── pipeline_clinevo/
    │   ├── advagen_excel/
    │   ├── validus_excel/
    │   ├── screenshots/
    │   └── case_check_report/
    └── documents/
        ├── advagen_micc/call_recordings/     <- put your local recordings here
        └── validus_micc/call_recordings/     <- put your local recordings here
```

All Excel/screenshot/report folders from both pipelines are now aligned
under `data/`, instead of scattered under separate `process 1/` and
`process 2/` folders on `D:\...`. This is a folder-location change only -
no download/matching/validation logic changed.

**Important:** copy your existing recordings from
`Documents\MICC\Advagen MICC\Call recordings` and
`Documents\MICC\Validus MICC\Call recordings` into
`data/documents/advagen_micc/call_recordings/` and
`data/documents/validus_micc/call_recordings/` respectively (or point
`CALLER_AUTOMATION_ROOT` env var at your existing `D:\...\TESTING` folder -
see below).

## How to run (single execution)

```bash
pip install -r requirements.txt
playwright install chromium
python run_all.py
```

This runs, in order, in one process:

1. **Pipeline 1 (8x8)** - Step 1 → Step 2 → Step 3 → Step 4 (own Chrome/CDP session)
2. **Pipeline 2 (Clinevo)** - Step 1 → Step 2, starting/continuing its **own**
   Chrome session only after Pipeline 1's Excel work and report are fully
   done - exactly as you asked.

Each step still writes the same logs, screenshots-on-failure, and output
files as before; nothing about *how* a step behaves was touched, only the
order they're called in and where they read their settings from.

## Keeping your original D:\ paths instead of the new `data/` folder

If you'd rather keep everything exactly where it already is on
`D:\UI AUTOMATIONS PROJECTS\1- CALLER UI AUTOMATION\TESTING`, set an
environment variable before running and `config.py` will use it as the
base folder instead of the project's own `data/` directory:

```bash
set CALLER_AUTOMATION_ROOT=D:\UI AUTOMATIONS PROJECTS\1- CALLER UI AUTOMATION\TESTING
python run_all.py
```

## Running a single step on its own (unchanged capability)

Every step is still independently runnable, exactly like before:

```bash
python -m pipeline_8x8.step1_download_cdr
python -m pipeline_8x8.step2_extract_call_ids
python -m pipeline_8x8.step3_capture_ui_info
python -m pipeline_8x8.step4_validation_report
python -m pipeline_clinevo.step1_download_line_listing
python -m pipeline_clinevo.step2_case_file_check
```

## Next phase (not in this delivery, per your instruction)

Once you've confirmed this single-execution run works cleanly end to end,
the next step is adding the MySQL layer (`db/config.py` + a `pymysql`
connection manager + SELECT/INSERT/UPDATE/DELETE + table schema for the
call/case records) - to be built on top of this same structure without
touching the automation logic again.
