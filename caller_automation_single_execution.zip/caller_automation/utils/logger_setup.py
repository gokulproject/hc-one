"""
Shared logging configuration.

Every original script called logging.basicConfig(...) separately with
the identical format string. Centralized here so it is configured
exactly once for the whole single-execution run, and every module
just asks for its own named logger.
"""

import logging

_CONFIGURED = False


def _configure_once():
    global _CONFIGURED
    if _CONFIGURED:
        return

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s"
    )

    _CONFIGURED = True


def get_logger(name):
    _configure_once()
    return logging.getLogger(name)
