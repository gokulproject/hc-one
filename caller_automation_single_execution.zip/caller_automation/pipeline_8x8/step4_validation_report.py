import os
import re
import json
import wave
import math
import logging
from datetime import datetime

import pandas as pd

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

try:
    from mutagen import File as AudioFile
    from mutagen.mp3 import MP3
except Exception:
    AudioFile = None
    MP3 = None

try:
    from tinytag import TinyTag
except Exception:
    TinyTag = None


# ==========================================================
# CONFIGURATION (centralized in config.py - values unchanged)
# ==========================================================

from config import (
    UI_CAPTURE_JSON,
    PROCESS3_REPORT_FOLDER as REPORT_FOLDER,
    VALIDATION_REPORT_FILE as REPORT_FILE,
    ADVAGEN_RECORDING_PATH,
    VALIDUS_RECORDING_PATH,
    SITE_PATHS,
    AUDIO_EXTENSIONS,
    SIZE_TOLERANCE,
)


# ==========================================================
# LOGGING (centralized in utils/logger_setup.py)
# ==========================================================

from utils.logger_setup import get_logger

logger = get_logger(__name__)


# ==========================================================
# CACHE
# ==========================================================

AUDIO_SCAN_CACHE = {}
USED_AUDIO_FILES_BY_FOLDER = {}


# ==========================================================
# NORMALIZE HELPERS
# ==========================================================

def normalize_size_text(size_text):
    if not size_text:
        return ""

    text = str(size_text).replace("\n", " ").replace(",", "").strip()

    match = re.search(
        r"(\d+(?:\.\d+)?)\s*(KB|MB|GB)",
        text,
        re.IGNORECASE
    )

    if not match:
        return text

    number = match.group(1)
    unit = match.group(2).upper()

    return f"{number} {unit}"


def normalize_duration_text(duration_text):
    """
    Converts duration to HH:MM:SS.

    Supports:
    00:02:03
    00.02.03
    2:03
    02.03
    """

    if not duration_text:
        return ""

    text = str(duration_text).strip()
    text = text.replace(".", ":")

    match_hms = re.search(
        r"\b\d{1,2}:\d{1,2}:\d{1,2}\b",
        text
    )

    if match_hms:
        h, m, s = match_hms.group(0).split(":")
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d}"

    match_ms = re.search(
        r"\b\d{1,2}:\d{1,2}\b",
        text
    )

    if match_ms:
        m, s = match_ms.group(0).split(":")
        return f"00:{int(m):02d}:{int(s):02d}"

    return text


def is_zero_ui_duration(ui_duration):
    return normalize_duration_text(ui_duration) == "00:00:00"


def seconds_to_hms(total_seconds, mode="floor"):
    if total_seconds is None:
        return ""

    if mode == "ceil":
        total_seconds = int(math.ceil(total_seconds))
    elif mode == "round":
        total_seconds = int(round(total_seconds))
    else:
        total_seconds = int(total_seconds)

    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def duration_to_seconds(duration_text):
    duration_text = normalize_duration_text(duration_text)

    if not duration_text:
        return None

    parts = duration_text.split(":")

    if len(parts) != 3:
        return None

    try:
        hours = int(parts[0])
        minutes = int(parts[1])
        seconds = int(parts[2])

        return hours * 3600 + minutes * 60 + seconds

    except Exception:
        return None


def parse_size_to_kb(size_text):
    size_text = normalize_size_text(size_text)

    match = re.search(
        r"(\d+(?:\.\d+)?)\s*(KB|MB|GB)",
        size_text,
        re.IGNORECASE
    )

    if not match:
        return None

    value = float(match.group(1))
    unit = match.group(2).upper()

    if unit == "KB":
        return value

    if unit == "MB":
        return value * 1024

    if unit == "GB":
        return value * 1024 * 1024

    return None


def normalize_for_match(value):
    if not value:
        return ""

    return re.sub(
        r"[^A-Z0-9]",
        "",
        str(value).upper()
    )


def is_call_id_in_audio_file(call_id, audio_file_name):
    call_id_norm = normalize_for_match(call_id)
    file_name_norm = normalize_for_match(audio_file_name)

    if not call_id_norm or not file_name_norm:
        return False

    return call_id_norm in file_name_norm


# ==========================================================
# DATE HELPERS
# ==========================================================

def parse_excel_date_value(excel_date):
    if not excel_date:
        return None

    if isinstance(excel_date, datetime):
        return excel_date

    text = str(excel_date).strip()

    match = re.search(
        r"\d{1,2}/\d{1,2}/\d{4}",
        text
    )

    if match:
        return datetime.strptime(
            match.group(0),
            "%m/%d/%Y"
        )

    date_formats = [
        "%m/%d/%Y",
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%d/%m/%Y"
    ]

    for fmt in date_formats:
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            pass

    return None


def convert_excel_date_to_folder_parts(excel_date):
    """
    Example:
    07/10/2026 -> 2026 / JUL 2026 / 10 JUL 2026
    """

    dt = parse_excel_date_value(excel_date)

    if not dt:
        raise ValueError(f"Invalid Excel date: {excel_date}")

    year_folder = dt.strftime("%Y")
    month_folder = dt.strftime("%b %Y").upper()
    date_folder = f"{dt.day} {dt.strftime('%b %Y').upper()}"

    return year_folder, month_folder, date_folder


def build_local_folder_path(site, excel_date):
    base_path = SITE_PATHS.get(site)

    if not base_path:
        return ""

    year_folder, month_folder, date_folder = convert_excel_date_to_folder_parts(
        excel_date
    )

    return os.path.join(
        base_path,
        year_folder,
        month_folder,
        date_folder
    )


# ==========================================================
# SIZE HELPERS
# ==========================================================

def format_audio_size_like_ui(size_bytes):
    gb = size_bytes / (1024 * 1024 * 1024)
    mb = size_bytes / (1024 * 1024)
    kb = size_bytes / 1024

    if gb >= 1:
        return f"{round(gb, 1)} GB"

    if mb >= 1:
        return f"{round(mb, 1)} MB"

    return f"{round(kb, 1)} KB"


def get_audio_size_info(audio_file):
    try:
        size_bytes = os.path.getsize(audio_file)
        size_kb = size_bytes / 1024
        size_display = normalize_size_text(
            format_audio_size_like_ui(size_bytes)
        )

        return size_display, size_kb

    except Exception as e:
        logger.warning(f"Unable to read audio size for {audio_file}: {e}")
        return "", None


def get_size_difference_ratio(ui_size, local_size_kb):
    ui_kb = parse_size_to_kb(ui_size)

    if ui_kb is None or local_size_kb is None:
        return None

    if ui_kb == 0:
        return None

    return abs(ui_kb - local_size_kb) / ui_kb


def get_size_difference_percent(ui_size, local_size_kb):
    ratio = get_size_difference_ratio(ui_size, local_size_kb)

    if ratio is None:
        return None

    return ratio * 100


def is_size_match(ui_size, local_size_kb):
    ratio = get_size_difference_ratio(ui_size, local_size_kb)

    if ratio is None:
        return False

    return ratio <= SIZE_TOLERANCE


def get_size_matched_records(records, ui_size):
    matched = []

    for item in records:
        local_size_kb = item.get("local_size_kb")
        ratio = get_size_difference_ratio(ui_size, local_size_kb)

        if ratio is not None and ratio <= SIZE_TOLERANCE:
            item_copy = dict(item)
            item_copy["size_difference_ratio"] = ratio
            item_copy["size_difference_percent"] = ratio * 100
            matched.append(item_copy)

    matched.sort(
        key=lambda x: x.get("size_difference_ratio", 999999)
    )

    return matched


# ==========================================================
# DURATION HELPERS
# ==========================================================

def get_duration_difference_seconds(ui_duration, local_seconds):
    ui_seconds = duration_to_seconds(ui_duration)

    if ui_seconds is None or local_seconds is None:
        return None

    return abs(ui_seconds - int(local_seconds))


def is_duration_match(ui_duration, local_audio_seconds):
    """
    UI duration and local metadata length are compared in same UI format.

    Example:
    UI:
    00:02:03

    Local metadata:
    123.789 seconds

    floor -> 123 seconds
    123 -> 00:02:03
    """

    if not ui_duration:
        return False

    if local_audio_seconds is None:
        return False

    ui_duration_norm = normalize_duration_text(ui_duration)

    local_duration_ui = seconds_to_hms(
        local_audio_seconds,
        mode="floor"
    )

    return ui_duration_norm == local_duration_ui


# ==========================================================
# AUDIO DURATION READERS
# ==========================================================

def get_audio_duration_seconds_with_wave(audio_file):
    try:
        if not audio_file.lower().endswith(".wav"):
            return None

        with wave.open(audio_file, "rb") as wav_file:
            frames = wav_file.getnframes()
            rate = wav_file.getframerate()

            if rate > 0:
                return frames / float(rate)

    except Exception as e:
        logger.warning(f"WAV duration failed for {audio_file}: {e}")

    return None


def get_audio_duration_seconds_with_mutagen_generic(audio_file):
    try:
        if AudioFile is None:
            return None

        audio = AudioFile(audio_file)

        if audio and audio.info and hasattr(audio.info, "length"):
            length = audio.info.length

            if length and length > 0:
                return float(length)

    except Exception as e:
        logger.warning(f"Mutagen generic duration failed for {audio_file}: {e}")

    return None


def get_audio_duration_seconds_with_mutagen_mp3(audio_file):
    try:
        if MP3 is None:
            return None

        if not audio_file.lower().endswith(".mp3"):
            return None

        audio = MP3(audio_file)

        if audio and audio.info and hasattr(audio.info, "length"):
            length = audio.info.length

            if length and length > 0:
                return float(length)

    except Exception as e:
        logger.warning(f"Mutagen MP3 duration failed for {audio_file}: {e}")

    return None


def get_audio_duration_seconds_with_tinytag(audio_file):
    try:
        if TinyTag is None:
            return None

        tag = TinyTag.get(audio_file)

        if tag and tag.duration and tag.duration > 0:
            return float(tag.duration)

    except Exception as e:
        logger.warning(f"TinyTag duration failed for {audio_file}: {e}")

    return None


def get_audio_duration_seconds(audio_file):
    methods = [
        ("wave", get_audio_duration_seconds_with_wave),
        ("mutagen_generic", get_audio_duration_seconds_with_mutagen_generic),
        ("mutagen_mp3", get_audio_duration_seconds_with_mutagen_mp3),
        ("tinytag", get_audio_duration_seconds_with_tinytag)
    ]

    for method_name, method in methods:
        seconds = method(audio_file)

        if seconds is not None:
            logger.info(
                f"Duration captured using {method_name}: "
                f"{seconds:.3f} seconds | {os.path.basename(audio_file)}"
            )
            return seconds

    logger.warning(f"Unable to capture duration for audio file: {audio_file}")
    return None


# ==========================================================
# AUDIO SCANNING
# ==========================================================

def find_audio_files(folder_path):
    audio_files = []

    if not os.path.exists(folder_path):
        return audio_files

    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.lower().endswith(AUDIO_EXTENSIONS):
                audio_files.append(
                    os.path.join(root, file_name)
                )

    return audio_files


def scan_audio_metadata(folder_path):
    if folder_path in AUDIO_SCAN_CACHE:
        return AUDIO_SCAN_CACHE[folder_path]

    audio_records = []

    audio_files = find_audio_files(folder_path)

    logger.info(f"Audio files found in folder: {len(audio_files)}")

    for audio_file in audio_files:
        local_size_display, local_size_kb = get_audio_size_info(audio_file)

        exact_seconds = get_audio_duration_seconds(audio_file)

        if exact_seconds is not None:
            local_duration = seconds_to_hms(
                exact_seconds,
                mode="floor"
            )

            local_seconds_display = round(exact_seconds, 3)

        else:
            local_duration = ""
            local_seconds_display = ""

        record = {
            "audio_file_path": audio_file,
            "audio_file_name": os.path.basename(audio_file),
            "local_size": local_size_display,
            "local_size_kb": local_size_kb,
            "local_duration": normalize_duration_text(local_duration),
            "local_duration_seconds": exact_seconds,
            "local_duration_seconds_display": local_seconds_display
        }

        logger.info(
            "AUDIO METADATA | "
            f"File: {record['audio_file_name']} | "
            f"Size: {record['local_size']} | "
            f"Duration: {record['local_duration']} | "
            f"Seconds: {record['local_duration_seconds_display']}"
        )

        audio_records.append(record)

    AUDIO_SCAN_CACHE[folder_path] = audio_records

    return audio_records


# ==========================================================
# USED FILE TRACKING
# ==========================================================

def get_unused_audio_records(folder_path, audio_records):
    used_files = USED_AUDIO_FILES_BY_FOLDER.get(folder_path, set())

    return [
        item for item in audio_records
        if item.get("audio_file_path") not in used_files
    ]


def mark_audio_as_used(folder_path, audio_file_path):
    if not audio_file_path:
        return

    if folder_path not in USED_AUDIO_FILES_BY_FOLDER:
        USED_AUDIO_FILES_BY_FOLDER[folder_path] = set()

    USED_AUDIO_FILES_BY_FOLDER[folder_path].add(audio_file_path)


# ==========================================================
# MATCH RESPONSE
# ==========================================================

def build_selected_file_response(
    folder_path,
    item,
    ui_size,
    ui_duration,
    match_source,
    force_status=None,
    mark_used=True
):
    ui_duration_norm = normalize_duration_text(ui_duration)
    ui_size_norm = normalize_size_text(ui_size)

    local_duration_seconds = item.get("local_duration_seconds")
    local_duration = item.get("local_duration", "")
    local_size = item.get("local_size", "")
    local_size_kb = item.get("local_size_kb")

    duration_match = is_duration_match(
        ui_duration_norm,
        local_duration_seconds
    )

    size_match = is_size_match(
        ui_size_norm,
        local_size_kb
    )

    duration_diff = get_duration_difference_seconds(
        ui_duration_norm,
        local_duration_seconds
    )

    size_diff_percent = get_size_difference_percent(
        ui_size_norm,
        local_size_kb
    )

    if mark_used:
        mark_audio_as_used(
            folder_path,
            item.get("audio_file_path")
        )

    if force_status:
        status = force_status
    elif duration_match and size_match:
        status = "MATCHED"
    elif duration_match and not size_match:
        status = "SIZE MISMATCH"
    elif not duration_match and size_match:
        status = "DURATION MISMATCH"
    else:
        status = "DURATION AND SIZE MISMATCH"

    if status == "MATCHED":
        remarks = (
            f"{match_source}. Duration matched first by comparing UI duration with "
            "local audio metadata length converted to HH:MM:SS using floor. "
            f"Size also matched within {SIZE_TOLERANCE * 100}% tolerance."
        )

    elif status == "MATCHED USING SIZE":
        remarks = (
            f"{match_source}. UI duration was unavailable or displayed as 00:00:00. "
            f"Audio was identified using strict size comparison within {SIZE_TOLERANCE * 100}% tolerance. "
            f"UI Size: {ui_size_norm}, Local Size: {local_size}. "
            f"Size difference: {round(size_diff_percent, 2) if size_diff_percent is not None else 'N/A'}%."
        )

    elif status == "SIZE MISMATCH":
        remarks = (
            f"{match_source}. Duration matched, but size mismatch. "
            f"UI Size: {ui_size_norm}, Local Size: {local_size}. "
            f"Size difference: {round(size_diff_percent, 2) if size_diff_percent is not None else 'N/A'}%. "
            f"Allowed tolerance: {SIZE_TOLERANCE * 100}%."
        )

    elif status == "DURATION MISMATCH":
        remarks = (
            f"{match_source}. Size matched within {SIZE_TOLERANCE * 100}% tolerance, "
            "but duration did not match. Duration is primary validation. "
            f"UI Duration: {ui_duration_norm}, Local Duration: {local_duration}. "
            f"Duration difference: {duration_diff if duration_diff is not None else 'N/A'} seconds."
        )

    else:
        remarks = (
            f"{match_source}. File was identified, but both duration and size mismatched. "
            f"UI Duration: {ui_duration_norm}, Local Duration: {local_duration}. "
            f"UI Size: {ui_size_norm}, Local Size: {local_size}."
        )

    return {
        "file_available": "YES",
        "audio_file_name": item.get("audio_file_name", ""),
        "local_size": local_size,
        "local_duration": local_duration,
        "status": status,
        "remarks": remarks
    }


# ==========================================================
# AUDIO MATCHING LOGIC
# ==========================================================

def find_best_audio_match(folder_path, ui_size, ui_duration, call_id):
    """
    Final matching strategy:

    1. Check Call ID in filename first.
    2. If Call ID file is found, validate that file only.
    3. If UI duration is 00:00:00, skip duration and use size fallback.
    4. If UI duration is valid:
       - duration match first
       - if one duration match, select it
       - if multiple duration matches, use size to select
    5. If no duration match, use size fallback with strict tolerance.
    6. If multiple size matches, do not select randomly.
    """

    ui_size_norm = normalize_size_text(ui_size)
    ui_duration_norm = normalize_duration_text(ui_duration)

    audio_records = scan_audio_metadata(folder_path)

    if not audio_records:
        return {
            "file_available": "NO",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "FILE NOT FOUND",
            "remarks": "No audio files found in expected local date folder."
        }

    unused_audio_records = get_unused_audio_records(
        folder_path,
        audio_records
    )

    if not unused_audio_records:
        return {
            "file_available": "NO",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "FILE NOT FOUND",
            "remarks": "All audio files in this folder are already assigned to previous Call IDs."
        }

    logger.info(
        "MATCH INPUT | "
        f"Call ID: {call_id} | "
        f"UI Duration: {ui_duration_norm} | "
        f"UI Size: {ui_size_norm} | "
        f"Unused Files: {len(unused_audio_records)}"
    )

    # ======================================================
    # STEP 1: CALL ID MATCH IN FILE NAME
    # ======================================================

    call_id_matches = [
        item for item in unused_audio_records
        if is_call_id_in_audio_file(
            call_id,
            item.get("audio_file_name", "")
        )
    ]

    logger.info(f"Call ID filename matches found: {len(call_id_matches)}")

    if len(call_id_matches) == 1:
        item = call_id_matches[0]

        if is_zero_ui_duration(ui_duration_norm):
            return build_selected_file_response(
                folder_path=folder_path,
                item=item,
                ui_size=ui_size_norm,
                ui_duration=ui_duration_norm,
                match_source="Audio file selected by Call ID match in filename",
                force_status="MATCHED USING SIZE",
                mark_used=True
            )

        return build_selected_file_response(
            folder_path=folder_path,
            item=item,
            ui_size=ui_size_norm,
            ui_duration=ui_duration_norm,
            match_source="Audio file selected by Call ID match in filename",
            mark_used=True
        )

    if len(call_id_matches) > 1:
        if is_zero_ui_duration(ui_duration_norm):
            size_matches = get_size_matched_records(
                call_id_matches,
                ui_size_norm
            )

            if len(size_matches) == 1:
                return build_selected_file_response(
                    folder_path=folder_path,
                    item=size_matches[0],
                    ui_size=ui_size_norm,
                    ui_duration=ui_duration_norm,
                    match_source=(
                        "Multiple files contained Call ID. UI duration was 00:00:00. "
                        "Size selected the correct file"
                    ),
                    force_status="MATCHED USING SIZE",
                    mark_used=True
                )

            return {
                "file_available": "YES",
                "audio_file_name": "",
                "local_size": "",
                "local_duration": "",
                "status": "MULTIPLE CALL ID FILES FOUND",
                "remarks": (
                    "Multiple local audio files contain the same Call ID. UI duration is 00:00:00. "
                    "Size could not identify a unique file. Manual review required."
                )
            }

        duration_matches = [
            item for item in call_id_matches
            if is_duration_match(
                ui_duration_norm,
                item.get("local_duration_seconds")
            )
        ]

        if len(duration_matches) == 1:
            return build_selected_file_response(
                folder_path=folder_path,
                item=duration_matches[0],
                ui_size=ui_size_norm,
                ui_duration=ui_duration_norm,
                match_source=(
                    "Multiple files contained Call ID. Duration selected the correct file"
                ),
                mark_used=True
            )

        if len(duration_matches) > 1:
            size_matches = get_size_matched_records(
                duration_matches,
                ui_size_norm
            )

            if len(size_matches) == 1:
                return build_selected_file_response(
                    folder_path=folder_path,
                    item=size_matches[0],
                    ui_size=ui_size_norm,
                    ui_duration=ui_duration_norm,
                    match_source=(
                        "Multiple files contained Call ID and matched duration. "
                        "Size selected the correct file"
                    ),
                    mark_used=True
                )

            return {
                "file_available": "YES",
                "audio_file_name": "",
                "local_size": "",
                "local_duration": "",
                "status": "MULTIPLE DURATION MATCHES",
                "remarks": (
                    "Multiple files contained Call ID and matched duration. "
                    "Size did not identify a unique file. Manual review required."
                )
            }

        return {
            "file_available": "YES",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "MULTIPLE CALL ID FILES FOUND",
            "remarks": (
                "Multiple local audio files contain the same Call ID, but none matched UI duration. "
                "Unique file could not be confirmed. Manual review required."
            )
        }

    # ======================================================
    # STEP 2: UI DURATION 00:00:00 - SIZE FALLBACK
    # ======================================================

    if is_zero_ui_duration(ui_duration_norm):
        logger.info(
            "UI duration is 00:00:00. Skipping duration validation and using size fallback."
        )

        size_matches = get_size_matched_records(
            unused_audio_records,
            ui_size_norm
        )

        if len(size_matches) == 1:
            return build_selected_file_response(
                folder_path=folder_path,
                item=size_matches[0],
                ui_size=ui_size_norm,
                ui_duration=ui_duration_norm,
                match_source=(
                    "UI duration displayed as 00:00:00. "
                    "Audio identified using size fallback"
                ),
                force_status="MATCHED USING SIZE",
                mark_used=True
            )

        if len(size_matches) > 1:
            return {
                "file_available": "YES",
                "audio_file_name": "",
                "local_size": "",
                "local_duration": "",
                "status": "MULTIPLE SIZE MATCHES",
                "remarks": (
                    "UI duration displayed as 00:00:00. Multiple unused audio files matched "
                    f"size tolerance of {SIZE_TOLERANCE * 100}%. No file selected automatically. "
                    "Manual review required."
                )
            }

        return {
            "file_available": "NO",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "FILE NOT FOUND",
            "remarks": (
                "UI duration displayed as 00:00:00, but no local audio file matched "
                f"UI size within {SIZE_TOLERANCE * 100}% tolerance."
            )
        }

    # ======================================================
    # STEP 3: DURATION MATCH FIRST
    # ======================================================

    readable_records = [
        item for item in unused_audio_records
        if item.get("local_duration_seconds") is not None
    ]

    duration_matches = [
        item for item in readable_records
        if is_duration_match(
            ui_duration_norm,
            item.get("local_duration_seconds")
        )
    ]

    logger.info(f"Duration matches found: {len(duration_matches)}")

    if len(duration_matches) == 1:
        return build_selected_file_response(
            folder_path=folder_path,
            item=duration_matches[0],
            ui_size=ui_size_norm,
            ui_duration=ui_duration_norm,
            match_source="Unique audio file selected by duration match",
            mark_used=True
        )

    if len(duration_matches) > 1:
        logger.info(
            "Multiple duration matches found. Checking size only within duration-matched files."
        )

        size_matches = get_size_matched_records(
            duration_matches,
            ui_size_norm
        )

        if len(size_matches) == 1:
            return build_selected_file_response(
                folder_path=folder_path,
                item=size_matches[0],
                ui_size=ui_size_norm,
                ui_duration=ui_duration_norm,
                match_source=(
                    "Multiple audio files matched duration. "
                    "Size selected the correct file"
                ),
                mark_used=True
            )

        if len(size_matches) > 1:
            return {
                "file_available": "YES",
                "audio_file_name": "",
                "local_size": "",
                "local_duration": "",
                "status": "MULTIPLE POSSIBLE MATCHES",
                "remarks": (
                    "Multiple audio files matched duration and size tolerance. "
                    "No file selected automatically. Manual review required."
                )
            }

        return {
            "file_available": "YES",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "MULTIPLE DURATION MATCHES",
            "remarks": (
                "Multiple audio files matched UI duration, but none matched UI size "
                f"within {SIZE_TOLERANCE * 100}% tolerance. Manual review required."
            )
        }

    # ======================================================
    # STEP 4: NO DURATION MATCH - SIZE FALLBACK
    # ======================================================

    logger.info(
        "No duration match found. Proceeding with size fallback using strict tolerance."
    )

    size_matches = get_size_matched_records(
        unused_audio_records,
        ui_size_norm
    )

    logger.info(f"Size fallback matches found: {len(size_matches)}")

    if len(size_matches) == 1:
        return build_selected_file_response(
            folder_path=folder_path,
            item=size_matches[0],
            ui_size=ui_size_norm,
            ui_duration=ui_duration_norm,
            match_source=(
                "No audio file matched UI duration. "
                "One audio file matched by size fallback"
            ),
            force_status="DURATION MISMATCH",
            mark_used=True
        )

    if len(size_matches) > 1:
        return {
            "file_available": "YES",
            "audio_file_name": "",
            "local_size": "",
            "local_duration": "",
            "status": "MULTIPLE SIZE MATCHES",
            "remarks": (
                "No audio file matched UI duration. Multiple audio files matched "
                f"size tolerance of {SIZE_TOLERANCE * 100}%. No file selected automatically "
                "because size-only matching is not reliable when multiple recordings exist. "
                "Manual review required."
            )
        }

    return {
        "file_available": "NO",
        "audio_file_name": "",
        "local_size": "",
        "local_duration": "",
        "status": "FILE NOT FOUND",
        "remarks": (
            "No local audio file matched Call ID, UI duration, or UI size fallback. "
            "Expected recording could not be confirmed."
        )
    }


# ==========================================================
# REPORT HELPERS
# ==========================================================

def append_site_audit_remark(source_excel_site, ui_site, remarks):
    source_excel_site = str(source_excel_site or "").strip()
    ui_site = str(ui_site or "").strip()

    if source_excel_site and ui_site and source_excel_site != ui_site:
        audit_text = (
            f"Audit: Source Excel Site is '{source_excel_site}' but UI Site is '{ui_site}'. "
            "Report sheet placement is based only on Source Excel Site."
        )

        if remarks:
            return f"{remarks} | {audit_text}"

        return audit_text

    return remarks


def build_report_row(
    call_id,
    source_excel_site,
    excel_date_time,
    answered,
    ui_site,
    ui_audio_duration,
    local_audio_duration,
    ui_audio_size,
    local_audio_size,
    folder_available,
    file_available,
    status,
    audio_file_name,
    remarks
):
    return {
        "Call ID": call_id,
        "Source Excel Site": source_excel_site,
        "Excel Date Time": excel_date_time,
        "Answered": answered,
        "UI Site": ui_site,
        "UI Audio Duration": normalize_duration_text(ui_audio_duration),
        "Local Audio Duration": normalize_duration_text(local_audio_duration),
        "UI Audio Size": normalize_size_text(ui_audio_size),
        "Local Audio Size": normalize_size_text(local_audio_size),
        "Folder Available": folder_available,
        "File Available": file_available,
        "Status": status,
        "Audio File Name": audio_file_name,
        "Remarks": remarks
    }


# ==========================================================
# REPORT STYLING
# ==========================================================

def style_report(file_path):
    try:
        workbook = load_workbook(file_path)

        header_fill = PatternFill(
            start_color="1F4E78",
            end_color="1F4E78",
            fill_type="solid"
        )

        header_font = Font(
            color="FFFFFF",
            bold=True
        )

        status_colors = {
            "MATCHED": "C6EFCE",
            "MATCHED USING SIZE": "D9EAD3",
            "SIZE MISMATCH": "FFC7CE",
            "DURATION MISMATCH": "FFC7CE",
            "DURATION AND SIZE MISMATCH": "FFC7CE",
            "MULTIPLE CALL ID FILES FOUND": "FFF2CC",
            "MULTIPLE POSSIBLE MATCHES": "FFF2CC",
            "MULTIPLE DURATION MATCHES": "FFF2CC",
            "MULTIPLE SIZE MATCHES": "FFF2CC",
            "FILE NOT FOUND": "FCE4D6",
            "DATE FOLDER NOT FOUND": "FCE4D6",
            "NO RECORD FOUND IN UI": "FCE4D6",
            "CALL ID FILTER FAILED": "FCE4D6",
            "UI CAPTURE FAILED": "FCE4D6",
            "AUDIO INFO NOT OPENED": "FCE4D6",
            "NO AUDIO INFO FOUND": "FCE4D6",
            "INVALID EXCEL DATE": "FCE4D6",
            "UNKNOWN SITE": "FCE4D6",
            "EXCEL FILE NOT FOUND": "FCE4D6",
            "NO ANSWERED CALL IDS": "FCE4D6"
        }

        for sheet in workbook.worksheets:
            sheet.freeze_panes = "A2"

            if sheet.max_row >= 1 and sheet.max_column >= 1:
                sheet.auto_filter.ref = sheet.dimensions

            status_col = None

            for col_num in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=1, column=col_num)

                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(
                    horizontal="center",
                    vertical="center",
                    wrap_text=True
                )

                if cell.value == "Status":
                    status_col = col_num

            if status_col:
                for row_num in range(2, sheet.max_row + 1):
                    status_cell = sheet.cell(
                        row=row_num,
                        column=status_col
                    )

                    if status_cell.value in status_colors:
                        color = status_colors[status_cell.value]

                        status_cell.fill = PatternFill(
                            start_color=color,
                            end_color=color,
                            fill_type="solid"
                        )

            for col_num in range(1, sheet.max_column + 1):
                max_length = 0

                for row_num in range(1, sheet.max_row + 1):
                    value = sheet.cell(
                        row=row_num,
                        column=col_num
                    ).value

                    if value is not None:
                        max_length = max(
                            max_length,
                            len(str(value))
                        )

                sheet.column_dimensions[
                    get_column_letter(col_num)
                ].width = min(max_length + 3, 60)

            for row in sheet.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(
                        vertical="center",
                        wrap_text=True
                    )

        workbook.save(file_path)

        logger.info("Excel report styling completed")

    except Exception as e:
        logger.warning(f"Report styling skipped: {e}")


# ==========================================================
# PROCESS 3 MAIN
# ==========================================================

def process3():
    logger.info("=" * 100)
    logger.info("PROCESS 3 STARTED | AUDIO VALIDATION AND FINAL REPORT")
    logger.info("=" * 100)

    if not os.path.exists(UI_CAPTURE_JSON):
        raise FileNotFoundError(
            f"{UI_CAPTURE_JSON} not found. Run Process 2 first."
        )

    with open(UI_CAPTURE_JSON, "r", encoding="utf-8") as file:
        ui_records = json.load(file)

    logger.info(f"UI capture records loaded: {len(ui_records)}")

    report_rows = []

    ui_failure_statuses = [
        "EXCEL FILE NOT FOUND",
        "NO ANSWERED CALL IDS",
        "NO RECORD FOUND IN UI",
        "CALL ID FILTER FAILED",
        "UI CAPTURE FAILED",
        "AUDIO INFO NOT OPENED",
        "NO AUDIO INFO FOUND"
    ]

    for index, item in enumerate(ui_records, start=1):
        logger.info("-" * 100)
        logger.info(f"Processing record {index}/{len(ui_records)}")

        call_id = item.get("call_id", "")
        source_excel_site = item.get("source_excel_site", "")
        excel_date_time = item.get("excel_date_time", "")
        excel_date = item.get("excel_date", "")
        answered = item.get("answered", "")

        ui_site = item.get("ui_site", "")
        ui_size = item.get("ui_size", "")
        ui_duration = item.get("ui_duration", "")

        ui_status = item.get("status", "")
        ui_remarks = item.get("remarks", "")

        logger.info(f"Call ID: {call_id}")
        logger.info(f"Source Excel Site: {source_excel_site}")
        logger.info(f"Excel Date Time: {excel_date_time}")
        logger.info(f"Excel Date: {excel_date}")
        logger.info(f"Answered: {answered}")
        logger.info(f"UI Site: {ui_site}")
        logger.info(f"UI Size: {ui_size}")
        logger.info(f"UI Duration: {ui_duration}")
        logger.info(f"UI Status: {ui_status}")

        if ui_status in ui_failure_statuses:
            final_remarks = append_site_audit_remark(
                source_excel_site,
                ui_site,
                ui_remarks
            )

            report_rows.append(
                build_report_row(
                    call_id=call_id,
                    source_excel_site=source_excel_site,
                    excel_date_time=excel_date_time,
                    answered=answered,
                    ui_site=ui_site,
                    ui_audio_duration=ui_duration,
                    local_audio_duration="",
                    ui_audio_size=ui_size,
                    local_audio_size="",
                    folder_available="NO",
                    file_available="NO",
                    status=ui_status,
                    audio_file_name="",
                    remarks=final_remarks
                )
            )
            continue

        if not excel_date:
            remarks = "Excel date is empty. Cannot build local folder path."

            remarks = append_site_audit_remark(
                source_excel_site,
                ui_site,
                remarks
            )

            report_rows.append(
                build_report_row(
                    call_id=call_id,
                    source_excel_site=source_excel_site,
                    excel_date_time=excel_date_time,
                    answered=answered,
                    ui_site=ui_site,
                    ui_audio_duration=ui_duration,
                    local_audio_duration="",
                    ui_audio_size=ui_size,
                    local_audio_size="",
                    folder_available="NO",
                    file_available="NO",
                    status="INVALID EXCEL DATE",
                    audio_file_name="",
                    remarks=remarks
                )
            )
            continue

        folder_site = source_excel_site

        if folder_site not in SITE_PATHS:
            remarks = (
                f"Unknown Source Excel Site '{folder_site}'. "
                "Cannot identify local recording base folder."
            )

            remarks = append_site_audit_remark(
                source_excel_site,
                ui_site,
                remarks
            )

            report_rows.append(
                build_report_row(
                    call_id=call_id,
                    source_excel_site=source_excel_site,
                    excel_date_time=excel_date_time,
                    answered=answered,
                    ui_site=ui_site,
                    ui_audio_duration=ui_duration,
                    local_audio_duration="",
                    ui_audio_size=ui_size,
                    local_audio_size="",
                    folder_available="NO",
                    file_available="NO",
                    status="UNKNOWN SITE",
                    audio_file_name="",
                    remarks=remarks
                )
            )
            continue

        try:
            local_folder = build_local_folder_path(
                folder_site,
                excel_date
            )

        except Exception as e:
            remarks = (
                f"Invalid Excel date '{excel_date}'. "
                f"Unable to build local folder. Error: {e}"
            )

            remarks = append_site_audit_remark(
                source_excel_site,
                ui_site,
                remarks
            )

            report_rows.append(
                build_report_row(
                    call_id=call_id,
                    source_excel_site=source_excel_site,
                    excel_date_time=excel_date_time,
                    answered=answered,
                    ui_site=ui_site,
                    ui_audio_duration=ui_duration,
                    local_audio_duration="",
                    ui_audio_size=ui_size,
                    local_audio_size="",
                    folder_available="NO",
                    file_available="NO",
                    status="INVALID EXCEL DATE",
                    audio_file_name="",
                    remarks=remarks
                )
            )
            continue

        logger.info(f"Expected local folder: {local_folder}")

        folder_available = "YES" if os.path.exists(local_folder) else "NO"

        if folder_available == "NO":
            remarks = (
                "Local date folder not found using Source Excel Site and Excel date. "
                f"Expected folder: {local_folder}"
            )

            remarks = append_site_audit_remark(
                source_excel_site,
                ui_site,
                remarks
            )

            report_rows.append(
                build_report_row(
                    call_id=call_id,
                    source_excel_site=source_excel_site,
                    excel_date_time=excel_date_time,
                    answered=answered,
                    ui_site=ui_site,
                    ui_audio_duration=ui_duration,
                    local_audio_duration="",
                    ui_audio_size=ui_size,
                    local_audio_size="",
                    folder_available="NO",
                    file_available="NO",
                    status="DATE FOLDER NOT FOUND",
                    audio_file_name="",
                    remarks=remarks
                )
            )
            continue

        match_result = find_best_audio_match(
            local_folder,
            ui_size,
            ui_duration,
            call_id
        )

        final_remarks = append_site_audit_remark(
            source_excel_site,
            ui_site,
            match_result.get("remarks", "")
        )

        report_rows.append(
            build_report_row(
                call_id=call_id,
                source_excel_site=source_excel_site,
                excel_date_time=excel_date_time,
                answered=answered,
                ui_site=ui_site,
                ui_audio_duration=ui_duration,
                local_audio_duration=match_result.get("local_duration", ""),
                ui_audio_size=ui_size,
                local_audio_size=match_result.get("local_size", ""),
                folder_available=folder_available,
                file_available=match_result.get("file_available", "NO"),
                status=match_result.get("status", ""),
                audio_file_name=match_result.get("audio_file_name", ""),
                remarks=final_remarks
            )
        )

    os.makedirs(REPORT_FOLDER, exist_ok=True)

    columns = [
        "Call ID",
        "Source Excel Site",
        "Excel Date Time",
        "Answered",
        "UI Site",
        "UI Audio Duration",
        "Local Audio Duration",
        "UI Audio Size",
        "Local Audio Size",
        "Folder Available",
        "File Available",
        "Status",
        "Audio File Name",
        "Remarks"
    ]

    advagen_rows = [
        row for row in report_rows
        if row.get("Source Excel Site") == "Advagen MICC"
    ]

    validus_rows = [
        row for row in report_rows
        if row.get("Source Excel Site") == "Validus MICC"
    ]

    unknown_rows = [
        row for row in report_rows
        if row.get("Source Excel Site") not in [
            "Advagen MICC",
            "Validus MICC"
        ]
    ]

    logger.info(f"Writing report to: {REPORT_FILE}")
    logger.info(f"Advagen rows: {len(advagen_rows)}")
    logger.info(f"Validus rows: {len(validus_rows)}")
    logger.info(f"Unknown rows: {len(unknown_rows)}")

    with pd.ExcelWriter(REPORT_FILE, engine="openpyxl") as writer:
        pd.DataFrame(
            advagen_rows,
            columns=columns
        ).to_excel(
            writer,
            sheet_name="Advagen MICC",
            index=False
        )

        pd.DataFrame(
            validus_rows,
            columns=columns
        ).to_excel(
            writer,
            sheet_name="Validus MICC",
            index=False
        )

        if unknown_rows:
            pd.DataFrame(
                unknown_rows,
                columns=columns
            ).to_excel(
                writer,
                sheet_name="Unknown",
                index=False
            )

    style_report(REPORT_FILE)

    logger.info("=" * 100)
    logger.info("PROCESS 3 COMPLETED")
    logger.info(f"Final report generated: {os.path.abspath(REPORT_FILE)}")
    logger.info(f"Advagen rows: {len(advagen_rows)}")
    logger.info(f"Validus rows: {len(validus_rows)}")
    logger.info(f"Unknown rows: {len(unknown_rows)}")
    logger.info("=" * 100)


# ==========================================================
# ENTRY POINT USED BY run_all.py
# ==========================================================

run_step4 = process3


if __name__ == "__main__":
    process3()