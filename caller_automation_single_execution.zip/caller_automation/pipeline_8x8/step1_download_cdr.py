
import asyncio
import subprocess
import os
import logging
from datetime import datetime
import re

from playwright.async_api import (
    async_playwright,
    expect,
    Page,
    Browser,
    TimeoutError as PlaywrightTimeoutError
)

# =====================================================
# CONFIGURATION (centralized in config.py - values unchanged)
# =====================================================

from config import (
    EIGHTX8_USERNAME as USERNAME,
    EIGHTX8_PASSWORD as PASSWORD,
    DATE_RANGE,
    TIME_ZONE,
    SITE_FILTER_1,
    SITE_FILTER_2,
    SITE_FILTER_1_DOWNLOAD_FOLDER,
    SITE_FILTER_2_DOWNLOAD_FOLDER,
    ANALYTICS_URL,
    CHROME_DEBUG_URL,
    CHROME_EXE_PATH,
    CHROME_USER_DATA_DIR,
    PIPELINE_8X8_SCREENSHOT_FOLDER as SCREENSHOT_FOLDER,
)

# =====================================================
# LOGGING (centralized in utils/logger_setup.py)
# =====================================================

from utils.logger_setup import get_logger

logger = get_logger(__name__)

# =====================================================
# SCREENSHOT
# =====================================================

# async def take_screenshot(page, name):

    # try:

        # file_name = (
            # f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        # )

        # await page.screenshot(
            # path=file_name,
            # full_page=True
        # )

        # logger.info(f"Screenshot Saved : {file_name}")

    # except Exception as e:

        # logger.error(f"Screenshot Failed : {e}")

# =====================================================
# START CHROME
# =====================================================

async def start_chrome():

    try:

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            await browser.close()

            logger.info("Chrome already running")

            return True

    except Exception:

        logger.info("Starting Chrome")

        subprocess.Popen([
            CHROME_EXE_PATH,
            "--remote-debugging-port=9222",
            f"--user-data-dir={CHROME_USER_DATA_DIR}",
            "--start-maximized",
            "--no-first-run"
        ])

        for i in range(20):

            await asyncio.sleep(1)

            try:

                async with async_playwright() as p:

                    browser = await p.chromium.connect_over_cdp(
                        CHROME_DEBUG_URL
                    )

                    await browser.close()

                    logger.info("Chrome Started")

                    return True

            except Exception:

                logger.info(
                    f"Waiting Chrome Startup {i+1}/20"
                )

        return False

# =====================================================
# LOGIN
# =====================================================

async def login(page: Page):

    try:

        logger.info("Opening Login Page")

        await page.goto(
            "https://sso.8x8.com/v2/login",
            wait_until="domcontentloaded",
            timeout=60000
        )

        username_box = page.get_by_role(
            "textbox",
            name="Username / Email"
        )

        await expect(
            username_box
        ).to_be_visible()

        await username_box.fill(USERNAME)

        logger.info("Username Entered")

        continue_btn = page.get_by_role(
            "button",
            name="Continue"
        )

        await continue_btn.click()

        password_box = page.locator(
            'input[type="password"]'
        )

        await expect(
            password_box
        ).to_be_visible()

        await password_box.fill(PASSWORD)

        logger.info("Password Entered")

        login_btn = page.get_by_role(
            "button",
            name="Login"
        )

        await login_btn.click()

        logger.info("Login Clicked")

        await page.wait_for_timeout(5000)

        if "/mfa" in page.url:

            logger.error(
                "MFA Authentication Required"
            )

            await take_screenshot(
                page,
                "mfa_authentication"
            )

            raise Exception(
                "MFA Required"
            )

        logger.info("Login Completed")

    except Exception as e:

        logger.error(f"Login Failed : {e}")

        await take_screenshot(
            page,
            "login_error"
        )

        raise

# =====================================================
# ENSURE LOGIN
# =====================================================

async def ensure_login(page):

    try:

        logger.info("Checking Login Status")

        await page.goto(
            ANALYTICS_URL,
            wait_until="domcontentloaded",
            timeout=60000
        )

        await page.wait_for_timeout(5000)

        try:

            await expect(
                page.get_by_text(
                    "My Applications",
                    exact=False
                )
            ).to_be_visible(
                timeout=10000
            )

            logger.info(
                "Already Logged In"
            )

            return

        except Exception:

            logger.info(
                "Login Required"
            )

        await login(page)

        await page.goto(
            ANALYTICS_URL,
            wait_until="domcontentloaded"
        )

        await expect(
            page.get_by_text(
                "My Applications",
                exact=False
            )
        ).to_be_visible()

        logger.info("Login Successful")

    except Exception as e:

        logger.error(
            f"Ensure Login Failed : {e}"
        )

        raise

# =====================================================
# OPEN ANALYTICS
# =====================================================

async def open_analytics(page):

    try:

        logger.info(
            "Opening Analytics For 8x8 Work"
        )

        async with page.expect_popup(
            timeout=120000
        ) as popup:

            await page.get_by_role(
                "link",
                name="Analytics for 8x8 Work"
            ).click()

        analytics_page = await popup.value

        await analytics_page.wait_for_load_state(
            "domcontentloaded"
        )

        await expect(
            analytics_page.locator(
                'iframe[title="Company Summary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        logger.info(
            "Analytics Page Opened"
        )

        return analytics_page

    except Exception as e:

        logger.error(
            f"Analytics Opening Failed : {e}"
        )

        raise
        
# ======================================================
# caputure the date range after date range clicked 
# =====================================================
async def capture_selected_date_range(frame):

    try:

        logger.info(
            "Capturing selected From and To date"
        )

        header = frame.locator(
            '[data-test-id="voaheader.CompanySummary"]'
        )

        await expect(
            header
        ).to_be_visible(
            timeout=30000
        )

        # Wait for UI to update after DATE_RANGE click
        await asyncio.sleep(1)

        header_text = await header.inner_text()

        cleaned_text = (
            header_text
            .replace("\n", "")
            .replace(" ", "")
        )

        logger.info(
            f"Company Summary Date Text : {cleaned_text}"
        )

        # Capture all dates from header text
        # Example text:
        # Company Summary07/08/202607/08/202600:0024:00America/New_Yorknavitasinc
        date_values = re.findall(
            r"\d{2}/\d{2}/\d{4}",
            cleaned_text
        )

        logger.info(
            f"Date Values Found : {date_values}"
        )

        if len(date_values) >= 2:

            from_date_raw = date_values[0]
            to_date_raw = date_values[1]

            # Convert MM/DD/YYYY to DD-MON-YYYY
            from_date = datetime.strptime(
                from_date_raw,
                "%m/%d/%Y"
            ).strftime(
                "%d-%b-%Y"
            ).upper()

            to_date = datetime.strptime(
                to_date_raw,
                "%m/%d/%Y"
            ).strftime(
                "%d-%b-%Y"
            ).upper()

            logger.info(
                f"Captured Date Period | From : {from_date} | To : {to_date}"
            )

            return from_date, to_date

        logger.warning(
            "Unable to find From and To dates in Company Summary header"
        )

        return None, None

    except Exception as e:

        logger.error(
            f"Capture Selected Date Range Failed : {e}"
        )

        raise

       
# =====================================================
# COMPANY SUMMARY
# =====================================================
async def select_date_range(page):

    try:

        frame = page.frame_locator(
            'iframe[title="Company Summary"]'
        )

        await expect(
            page.locator(
                'iframe[title="Company Summary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        await expect(
            frame.locator(
                '[data-test-id="voaheader.CompanySummary"]'
            )
        ).to_be_visible(
            timeout=120000
        )

        # ============================================
        # Verify / Change Timezone
        # ============================================

        timezone = frame.locator(
            '[data-test-id="timezone-select.toggle"]'
        )

        await expect(
            timezone
        ).to_be_visible(
            timeout=30000
        )

        timezone_text = await timezone.text_content()

        logger.info(
            f"Current Timezone : {timezone_text}"
        )

        if timezone_text is None or TIME_ZONE not in timezone_text:

            logger.info(
                f"Timezone mismatch. Expected : {TIME_ZONE}, Actual : {timezone_text}"
            )

            await timezone.click()

            logger.info(
                "Timezone dropdown clicked"
            )

            search_box = frame.get_by_role(
                "textbox",
                name="Search"
            )

            await expect(
                search_box
            ).to_be_visible(
                timeout=30000
            )

            await search_box.click()

            await search_box.fill(
                TIME_ZONE
            )

            logger.info(
                f"Timezone search filled : {TIME_ZONE}"
            )

            timezone_option = frame.locator(
                f'[data-test-id="menu-item.{TIME_ZONE}"]'
            ).get_by_text(
                TIME_ZONE
            )

            await expect(
                timezone_option
            ).to_be_visible(
                timeout=30000
            )

            await timezone_option.click()

            logger.info(
                f"Timezone selected : {TIME_ZONE}"
            )

            await expect(
                timezone
            ).to_contain_text(
                TIME_ZONE,
                timeout=30000
            )

            logger.info(
                f"Timezone Verified After Selection : {TIME_ZONE}"
            )

        else:

            logger.info(
                f"Timezone Already Correct : {TIME_ZONE}"
            )

        # ============================================
        # Date Selector
        # ============================================

        date_button = frame.locator(
            '[data-test-id="voaheader.CompanySummary"] [data-test-id="BUTTON"]'
        )

        await expect(
            date_button
        ).to_be_visible(
            timeout=120000
        )

        logger.info(
            "Date Selector Visible"
        )

        await date_button.click()

        logger.info(
            "Date Selector Clicked"
        )

        available_dates = [
            "Today",
            "Yesterday",
            "Last 7 days",
            "Last 30 days",
            "This week",
            "Last week",
            "This month",
            "Last month"
        ]

        for item in available_dates:

            await expect(
                frame.get_by_role(
                    "button",
                    name=item
                )
            ).to_be_visible(
                timeout=30000
            )

            logger.info(
                f"Verified Date Option : {item}"
            )

        # ============================================
        # Click Date Range
        # ============================================

        await frame.get_by_role(
            "button",
            name=DATE_RANGE
        ).click()

        logger.info(
            f"Selected Date Range Clicked : {DATE_RANGE}"
        )

        # ============================================
        # Capture From and To Date After Date Click
        # ============================================

        from_date, to_date = await capture_selected_date_range(
            frame
        )

        logger.info(
            f"Final Date Filter Period | Range : {DATE_RANGE} | From : {from_date} | To : {to_date}"
        )

    except Exception as e:

        logger.error(
            f"Date Range Failed : {e}"
        )

        await take_screenshot(
            page,
            "date_range_error"
        )

        raise
# =====================================================
# SIDEBAR
# =====================================================

async def open_sidebar(page):

    try:

        await page.locator(
            "#navbar"
        ).click()

        logger.info(
            "Navbar Clicked"
        )

        toggle = page.get_by_role(
            "button",
            name="Toggle sidebar"
        )

        if await toggle.count() > 0:

            await toggle.click()

            logger.info(
                "Sidebar Toggled"
            )

    except Exception as e:

        logger.error(
            f"Sidebar Failed : {e}"
        )

        raise
# =====================================================
# CDR PAGE
# =====================================================

async def open_call_detail_records(page):

    try:

        await page.locator("#navbar").click()

        logger.info(
            "Navbar Clicked"
        )

        await page.locator(
            "#CallReportMenu"
        ).click()

        logger.info(
            "Call Report Opened"
        )

        cdr = page.locator(
            "#SideBarCDR"
        )

        await expect(
            cdr
        ).to_be_visible(
            timeout=30000
        )

        await cdr.click()

        logger.info(
            "Call Detail Records Clicked"
        )

    except Exception as e:

        logger.error(
            f"CDR Open Failed : {e}"
        )

        raise


# =====================================================
# FILTER
# =====================================================

# =====================================================
# FILTER
# =====================================================

async def apply_site_filter(page, site_filter):

    try:

        logger.info(
            f"Applying Site Filter : {site_filter}"
        )

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.locator(
                '[data-test-id="multiple-select.trigger"]'
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            "Filter dropdown visible"
        )

        await expect(
            frame.get_by_text(
                "Search or filter"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "Search or filter"
        ).click()

        logger.info(
            "Search Filter Opened"
        )

        await expect(
            frame.get_by_text(
                "Filter by Sites"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "Filter by Sites"
        ).click()

        logger.info(
            "Sites Filter Selected"
        )

        await expect(
            frame.get_by_text(
                "contains"
            )
        ).to_be_visible(
            timeout=30000
        )

        await frame.get_by_text(
            "contains Operator will match"
        ).click()

        logger.info(
            "Contains Operator Selected"
        )

        # ============================================
        # Select Site
        # If site is not found, skip this site only
        # ============================================

        site_option = (
            frame
            .locator(
                '[data-test-id="multiple-select.dropdown"] div'
            )
            .filter(
                has_text=site_filter
            )
            .nth(2)
        )

        try:

            await expect(
                site_option
            ).to_be_visible(
                timeout=30000
            )

        except Exception:

            logger.warning(
                f"Site Filter Not Found / Not Visible : {site_filter}. Skipping this site."
            )

            await take_screenshot(
                page,
                f"site_filter_not_found_{site_filter.replace(' ', '_')}"
            )

            try:

                await page.keyboard.press(
                    "Escape"
                )

                logger.info(
                    "Closed filter dropdown using Escape"
                )

            except Exception:

                logger.warning(
                    "Unable to close filter dropdown using Escape"
                )

            return False

        await site_option.click()

        logger.info(
            f"Site Selected : {site_filter}"
        )

        textbox = frame.get_by_role(
            "textbox"
        ).first

        await expect(
            textbox
        ).to_be_visible(
            timeout=30000
        )

        await expect(
            textbox
        ).to_have_value(
            site_filter,
            timeout=30000
        )

        logger.info(
            f"Textbox Validation Passed : {site_filter}"
        )

        finish_btn = frame.get_by_role(
            "button",
            name="Finish"
        )

        await expect(
            finish_btn
        ).to_be_visible(
            timeout=30000
        )

        await finish_btn.click()

        logger.info(
            "Finish Button Clicked"
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Filter Applied Successfully : {site_filter}"
        )

        return True

    except Exception as e:

        logger.error(
            f"Filter Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"filter_error_{site_filter.replace(' ', '_')}"
        )

        raise
# ======================================
# reset the filter 
# =======================================        
        
async def reset_site_filter(page, site_filter):

    try:

        logger.info(
            f"Resetting Site Filter : {site_filter}"
        )

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Existing Filter Found : Sites contains {site_filter}"
        )

        
        
        reject_btn = frame.locator(
            '[data-test-id="reject"]'
        ).first

        await expect(
            reject_btn
        ).to_be_visible(
            timeout=30000
        )


        await reject_btn.click()

        logger.info(
            f"Reject Button Clicked For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).not_to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Filter Reset Completed : {site_filter}"
        )

    except Exception as e:

        logger.error(
            f"Reset Filter Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"reset_filter_error_{site_filter.replace(' ', '_')}"
        )

        raise
# =====================================================
# SEARCH
# =====================================================
async def execute_search(page, site_filter):

    try:

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        await expect(
            frame.get_by_text(
                f"Sites contains {site_filter}"
            )
        ).to_be_visible(
            timeout=30000
        )

        logger.info(
            f"Verified Applied Filter : Sites contains {site_filter}"
        )

        search_btn = frame.locator(
            '[data-test-id="voaReports.cdr.search"]'
        )

        await expect(
            search_btn
        ).to_be_visible(
            timeout=30000
        )

        await search_btn.click()

        logger.info(
            f"Search Button Clicked For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                "Call Records"
            )
        ).to_be_visible(
            timeout=60000
        )

        logger.info(
            f"Search Completed For : {site_filter}"
        )

    except Exception as e:

        logger.error(
            f"Search Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"search_error_{site_filter.replace(' ', '_')}"
        )

        raise

# =====================================================
# DOWNLOAD
# =====================================================
async def download_excel(page, site_filter, download_folder):

    try:

        frame = page.frame_locator(
            'iframe[title="Call Detail Records"]'
        )

        download_btn = frame.locator(
            '[data-test-id="download"]'
        )

        await expect(
            download_btn
        ).to_be_visible(
            timeout=30000
        )

        await download_btn.click()

        logger.info(
            f"Download Menu Opened For : {site_filter}"
        )

        await expect(
            frame.get_by_text(
                "XLSX"
            )
        ).to_be_visible(
            timeout=30000
        )

        async with page.expect_download(
            timeout=120000
        ) as download_info:

            await frame.get_by_text(
                "XLSX",
                exact=True
            ).click()

        download = await download_info.value

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        safe_site_name = site_filter.replace(
            " ",
            "_"
        )

        file_path = os.path.join(
            download_folder,
            f"{safe_site_name}_Customer_Call_Details_{timestamp}.xlsx"
        )

        await download.save_as(
            file_path
        )

        logger.info(
            f"Excel Saved For {site_filter} : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Download Failed For {site_filter} : {e}"
        )

        await take_screenshot(
            page,
            f"download_error_{site_filter.replace(' ', '_')}"
        )

        raise

# ===========================================
# clear the old excel 
# =============================================
async def clear_old_excel_files(folder_path, folder_name):

    try:

        logger.info(
            f"Clearing old Excel files from : {folder_name}"
        )

        if not os.path.exists(folder_path):

            os.makedirs(
                folder_path,
                exist_ok=True
            )

            logger.info(
                f"Folder created : {folder_path}"
            )

            return

        excel_extensions = (
            ".xlsx",
            ".xls"
        )

        deleted_count = 0
        skipped_count = 0

        for file_name in os.listdir(folder_path):

            file_path = os.path.join(
                folder_path,
                file_name
            )

            if os.path.isfile(file_path) and file_name.lower().endswith(
                excel_extensions
            ):

                try:

                    os.remove(
                        file_path
                    )

                    deleted_count += 1

                    logger.info(
                        f"Deleted Old Excel File : {file_name}"
                    )

                except PermissionError:

                    skipped_count += 1

                    logger.warning(
                        f"Skipped Locked Excel File : {file_name}. Please close it if you want to delete."
                    )

                except OSError as e:

                    skipped_count += 1

                    logger.warning(
                        f"Skipped Excel File : {file_name}. Reason : {e}"
                    )

        logger.info(
            f"Old Excel Clear Completed For {folder_name}. Deleted : {deleted_count}, Skipped : {skipped_count}"
        )

    except Exception as e:

        logger.error(
            f"Failed To Clear Old Excel Files From {folder_name} : {e}"
        )

        raise


# =====================================================
# ANALYTICS FLOW
# =====================================================
async def analytics_flow(page):

    try:

        # ============================================
        # Clear Old Excel Files Before Current Run
        # ============================================

        await clear_old_excel_files(
            SITE_FILTER_1_DOWNLOAD_FOLDER,
            SITE_FILTER_1
        )

        await clear_old_excel_files(
            SITE_FILTER_2_DOWNLOAD_FOLDER,
            SITE_FILTER_2
        )

        logger.info(
            "Old Excel Files Cleared From Both Site Folders"
        )

        # ============================================
        # Open Analytics Page
        # ============================================

        analytics_page = await open_analytics(
            page
        )

        await select_date_range(
            analytics_page
        )

        await open_sidebar(
            analytics_page
        )

        await open_call_detail_records(
            analytics_page
        )

        file_path_1 = None
        file_path_2 = None

        # ============================================
        # First Site - Advagen MICC
        # ============================================

        site_1_applied = await apply_site_filter(
            analytics_page,
            SITE_FILTER_1
        )

        if site_1_applied:

            await execute_search(
                analytics_page,
                SITE_FILTER_1
            )

            file_path_1 = await download_excel(
                analytics_page,
                SITE_FILTER_1,
                SITE_FILTER_1_DOWNLOAD_FOLDER
            )

            logger.info(
                f"First Site Excel Download Completed : {file_path_1}"
            )

            await reset_site_filter(
                analytics_page,
                SITE_FILTER_1
            )

        else:

            logger.warning(
                f"Skipping Search and Download For : {SITE_FILTER_1}"
            )

        # ============================================
        # Second Site - Validus MICC
        # ============================================

        site_2_applied = await apply_site_filter(
            analytics_page,
            SITE_FILTER_2
        )

        if site_2_applied:

            await execute_search(
                analytics_page,
                SITE_FILTER_2
            )

            file_path_2 = await download_excel(
                analytics_page,
                SITE_FILTER_2,
                SITE_FILTER_2_DOWNLOAD_FOLDER
            )

            logger.info(
                f"Second Site Excel Download Completed : {file_path_2}"
            )

        else:

            logger.warning(
                f"Skipping Search and Download For : {SITE_FILTER_2}"
            )

        logger.info(
            "Analytics Flow Completed"
        )

        # ============================================
        # Close Analytics Page
        # ============================================

        await analytics_page.close()

        logger.info(
            "Analytics Page Closed"
        )

        logger.info(
            f"Current URL : {page.url}"
        )

        await page.bring_to_front()

        logger.info(
            "Returned To Main Apps Page"
        )

        return file_path_1, file_path_2

    except Exception as e:

        logger.error(
            f"Analytics Flow Failed : {e}"
        )

        raise
# =====================================================
# SCREENSHOT UTILITY
# =====================================================

async def take_screenshot(page, step_name="screenshot"):

    try:

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        file_path = os.path.join(
            SCREENSHOT_FOLDER,
            f"{step_name}_{timestamp}.png"
        )

        await page.screenshot(
            path=file_path,
            full_page=True
        )

        logger.info(
            f"Screenshot Saved : {file_path}"
        )

        return file_path

    except Exception as e:

        logger.error(
            f"Screenshot Failed : {e}"
        )

        return None
# =====================================================
# MAIN
# =====================================================

async def main():

    browser = None

    try:

        logger.info("AUTOMATION STARTED")

        if not await start_chrome():

            logger.error(
                "Chrome Startup Failed"
            )

            return

        async with async_playwright() as p:

            browser = await p.chromium.connect_over_cdp(
                CHROME_DEBUG_URL
            )

            if browser.contexts:
                context = browser.contexts[0]
            else:
                context = await browser.new_context(
                # -----------
                
                # viewport={
                        # "width": 1920,
                        # "height": 1080
                    # },
                    # record_video_dir="videos",
                    # record_video_size={
                        # "width": 1920,
                        # "height": 1080
                    # }

                # -----------
                )

            if context.pages:
                page = context.pages[0]
            else:
                page = await context.new_page()

            await ensure_login(page)

            downloaded_files = await analytics_flow(
                page
            )

            logger.info(
                f"SUCCESS : {downloaded_files}"
            )

    except PlaywrightTimeoutError as e:

        logger.error(
            f"Timeout Error : {e}"
        )

    except Exception as e:

        logger.error(
            f"Automation Failed : {e}"
        )

    finally:

        logger.info(
            "Automation Finished"
        )

# =====================================================
# ENTRY POINT USED BY run_all.py
# =====================================================

run_step1 = main

# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    asyncio.run(main())