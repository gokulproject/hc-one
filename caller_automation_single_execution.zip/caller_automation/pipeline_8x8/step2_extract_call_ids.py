import os
import re
import json
import glob
import logging

import pandas as pd


# ==========================================================
# CONFIGURATION (centralized in config.py - values unchanged)
# ==========================================================

from config import (
    SITE_FILTER_1_DOWNLOAD_FOLDER as ADVAGEN_EXCEL_FOLDER,
    SITE_FILTER_2_DOWNLOAD_FOLDER as VALIDUS_EXCEL_FOLDER,
    CALL_IDS_JSON,
)


# ==========================================================
# LOGGING (centralized in utils/logger_setup.py)
# ==========================================================

from utils.logger_setup import get_logger

logger = get_logger(__name__)


# ==========================================================
# COMMON HELPERS
# ==========================================================

def latest_excel_files(folder_path):
    """
    Finds all .xlsx files in folder.
    Skips temporary Excel files starting with ~$.
    This is read-only and does not modify Excel.
    """

    if not os.path.exists(folder_path):
        logger.warning(f"Excel folder does not exist: {folder_path}")
        return []

    files = glob.glob(
        os.path.join(folder_path, "*.xlsx")
    )

    files = [
        file for file in files
        if not os.path.basename(file).startswith("~$")
    ]

    return files


def safe_string(value):
    """
    Converts any Excel value to a safe JSON string.
    """

    if value is None:
        return ""

    if pd.isna(value):
        return ""

    return str(value).strip()


def normalize_call_id(value):
    """
    Normalizes Call ID safely.

    Examples:
    1776316267935
    1776316267935.0
    """

    if value is None:
        return ""

    if pd.isna(value):
        return ""

    text = str(value).strip()

    if text.endswith(".0"):
        text = text[:-2]

    text = re.sub(r"\D", "", text)

    return text


def normalize_column_name(value):
    """
    Normalizes column name only for matching.

    Examples:
    Call ID        -> callid
    Answered Time -> answeredtime
    Start Time    -> starttime
    """

    if value is None:
        return ""

    text = str(value)
    text = text.replace("\n", " ")
    text = text.replace("\r", " ")
    text = text.replace("\xa0", " ")
    text = text.strip()
    text = text.lower()
    text = text.replace(" ", "")
    text = text.replace("_", "")
    text = text.replace("-", "")

    return text


def extract_date_only(value):
    """
    Extracts date only from date-time text.

    Example:
    07/10/2026 15:14:22 -> 07/10/2026
    """

    text = safe_string(value)

    match = re.search(
        r"\d{1,2}/\d{1,2}/\d{4}",
        text
    )

    if match:
        return match.group(0)

    return ""


# ==========================================================
# HEADER DETECTION
# ==========================================================

def find_header_row(excel_file):
    """
    Finds header row by scanning first 30 rows.

    Main required column:
    - Call ID

    Answered column is used for ui_needed_call_items if available.
    """

    preview_df = pd.read_excel(
        excel_file,
        header=None,
        dtype=str,
        engine="openpyxl"
    )

    max_rows_to_scan = min(
        30,
        len(preview_df)
    )

    for row_index in range(max_rows_to_scan):

        row_values = []

        for value in preview_df.iloc[row_index].tolist():

            if pd.isna(value):
                continue

            normalized_value = normalize_column_name(value)

            if normalized_value:
                row_values.append(normalized_value)

        if "callid" in row_values:
            return row_index

    return None


def find_columns(df):
    """
    Finds known columns if available.

    Required for audit grouping:
    - Call ID

    Required for ui_needed_call_items:
    - Answered

    Date source:
    - Answered Time preferred
    - Start Time fallback
    """

    call_id_column = None
    answered_column = None
    answered_time_column = None
    start_time_column = None

    for col in df.columns:

        normalized_col = normalize_column_name(col)

        if normalized_col == "callid":
            call_id_column = col

        elif normalized_col == "answered":
            answered_column = col

        elif normalized_col == "answeredtime":
            answered_time_column = col

        elif normalized_col == "starttime":
            start_time_column = col

    date_column = answered_time_column or start_time_column

    return {
        "call_id_column": call_id_column,
        "answered_column": answered_column,
        "date_column": date_column
    }


def build_excel_row_data(row):
    """
    Stores all Excel columns and values for audit purpose.
    If new columns are added in Excel, they are automatically stored here.
    """

    row_data = {}

    for col_name, value in row.items():

        clean_col_name = safe_string(col_name)

        row_data[clean_col_name] = safe_string(value)

    return row_data


# ==========================================================
# CORE EXTRACTION
# ==========================================================

def extract_site_excel_data(folder_path, site_name):
    """
    Reads Excel files for one site.

    Creates:

    1. audit_call_items
       All Excel rows with all Excel columns.
       No Answered filter.

    2. audit_by_call_id
       Grouped audit rows by Call ID.

    3. ui_needed_call_items
       Only rows where Answered == Answered.
       One item per unique Call ID.

    4. call_ids
       Unique Call IDs from ui_needed_call_items for Process 2.
    """

    logger.info("=" * 100)
    logger.info(f"PROCESS 1 | SITE STARTED: {site_name}")
    logger.info(f"Excel folder: {folder_path}")
    logger.info("READ ONLY MODE: Excel will NOT be modified")
    logger.info("Audit: extract all Excel rows and all Excel columns")
    logger.info("UI Needed: filter Answered == Answered")

    result = {
        "site": site_name,
        "excel_found": False,
        "excel_files": [],
        "call_ids": [],
        "ui_needed_call_items": [],
        "audit_call_items": [],
        "audit_by_call_id": {},
        "all_call_id_occurrences": [],
        "total_excel_row_count": 0,
        "audit_row_count": 0,
        "answered_row_count": 0,
        "unique_call_id_count": 0,
        "duplicate_call_id_count": 0,
        "status": "",
        "remarks": ""
    }

    excel_files = latest_excel_files(folder_path)

    if not excel_files:
        result["status"] = "EXCEL FILE NOT FOUND"
        result["remarks"] = f"No .xlsx file found in folder: {folder_path}"

        logger.warning(result["remarks"])

        return result

    result["excel_found"] = True
    result["excel_files"] = excel_files

    audit_call_items = []
    audit_by_call_id = {}

    ui_needed_call_items_all_occurrences = []
    ui_needed_call_ids_all_occurrences = []

    global_excel_row_sequence = 0
    ui_row_sequence = 0

    for excel_file in excel_files:

        try:
            logger.info("-" * 80)
            logger.info(f"Reading Excel file: {excel_file}")

            header_row = find_header_row(excel_file)

            if header_row is None:
                logger.warning(
                    f"Header row containing Call ID not found: {excel_file}"
                )
                continue

            logger.info(f"Header row detected at index: {header_row}")

            df = pd.read_excel(
                excel_file,
                header=header_row,
                dtype=str,
                engine="openpyxl"
            )

            df.columns = [
                safe_string(col)
                for col in df.columns
            ]

            logger.info(f"Detected columns: {list(df.columns)}")

            columns = find_columns(df)

            call_id_column = columns["call_id_column"]
            answered_column = columns["answered_column"]
            date_column = columns["date_column"]

            if call_id_column is None:
                logger.warning(f"Call ID column not found in file: {excel_file}")
                continue

            if answered_column is None:
                logger.warning(
                    f"Answered column not found in file: {excel_file}. "
                    "Audit will be stored, but ui_needed_call_items cannot be filtered."
                )

            if date_column is None:
                logger.warning(
                    "Answered Time / Start Time column not found. "
                    "excel_date_time and excel_date will be blank."
                )

            logger.info(f"Call ID column found: {call_id_column}")
            logger.info(f"Answered column found: {answered_column}")
            logger.info(f"Excel date column used: {date_column}")

            result["total_excel_row_count"] += len(df)

            for _, row in df.iterrows():

                global_excel_row_sequence += 1

                call_id = normalize_call_id(
                    row.get(call_id_column, "")
                )

                excel_date_time = ""

                if date_column:
                    excel_date_time = safe_string(
                        row.get(date_column, "")
                    )

                excel_date = extract_date_only(
                    excel_date_time
                )

                answered_value = ""

                if answered_column:
                    answered_value = safe_string(
                        row.get(answered_column, "")
                    )

                excel_row_data = build_excel_row_data(row)

                audit_item = {
                    "call_id": call_id,
                    "source_excel_site": site_name,
                    "excel_date_time": excel_date_time,
                    "excel_date": excel_date,
                    "answered": answered_value,
                    "excel_row_sequence": global_excel_row_sequence,
                    "source_excel_file": excel_file,
                    "excel_row_data": excel_row_data
                }

                # Store every row for audit purpose
                audit_call_items.append(audit_item)

                # Group audit by Call ID if Call ID exists
                if call_id:
                    if call_id not in audit_by_call_id:
                        audit_by_call_id[call_id] = []

                    audit_by_call_id[call_id].append(audit_item)

                # ui_needed_call_items only for Answered == Answered
                if (
                    call_id
                    and answered_value.strip().lower() == "answered"
                ):
                    ui_row_sequence += 1

                    ui_needed_item = {
                        "call_id": call_id,
                        "source_excel_site": site_name,
                        "excel_date_time": excel_date_time,
                        "excel_date": excel_date,
                        "answered": answered_value,
                        "excel_row_sequence": ui_row_sequence
                    }

                    ui_needed_call_items_all_occurrences.append(
                        ui_needed_item
                    )

                    ui_needed_call_ids_all_occurrences.append(
                        call_id
                    )

            logger.info(
                f"Audit rows extracted so far: {len(audit_call_items)}"
            )

            logger.info(
                f"UI needed answered rows extracted so far: "
                f"{len(ui_needed_call_items_all_occurrences)}"
            )

        except Exception as e:
            logger.error(
                f"Failed reading Excel file {excel_file}: {e}"
            )

    unique_call_ids = list(
        dict.fromkeys(ui_needed_call_ids_all_occurrences)
    )

    # Keep one ui_needed_call_item per unique Call ID for Process 2
    unique_ui_needed_call_items = []

    seen_call_ids = set()

    for item in ui_needed_call_items_all_occurrences:

        call_id = item["call_id"]

        if call_id not in seen_call_ids:

            unique_ui_needed_call_items.append(item)

            seen_call_ids.add(call_id)

    result["call_ids"] = unique_call_ids
    result["ui_needed_call_items"] = unique_ui_needed_call_items
    result["audit_call_items"] = audit_call_items
    result["audit_by_call_id"] = audit_by_call_id
    result["all_call_id_occurrences"] = ui_needed_call_ids_all_occurrences
    result["audit_row_count"] = len(audit_call_items)
    result["answered_row_count"] = len(ui_needed_call_ids_all_occurrences)
    result["unique_call_id_count"] = len(unique_call_ids)
    result["duplicate_call_id_count"] = (
        len(ui_needed_call_ids_all_occurrences) - len(unique_call_ids)
    )

    if unique_call_ids:
        result["status"] = "CALL IDS EXTRACTED"
        result["remarks"] = (
            f"Total Excel audit rows: {len(audit_call_items)} | "
            f"Answered rows with valid Call ID: {len(ui_needed_call_ids_all_occurrences)} | "
            f"Unique Call IDs for UI filter: {len(unique_call_ids)} | "
            f"Duplicate answered occurrences: "
            f"{len(ui_needed_call_ids_all_occurrences) - len(unique_call_ids)}"
        )
    else:
        result["status"] = "NO ANSWERED CALL IDS"
        result["remarks"] = (
            f"Total Excel audit rows: {len(audit_call_items)} | "
            "No rows found where Answered == Answered with valid Call ID"
        )

    logger.info(f"{site_name} extraction status: {result['status']}")
    logger.info(result["remarks"])

    return result


# ==========================================================
# PROCESS 1 MAIN
# ==========================================================

def process1():
    logger.info("=" * 100)
    logger.info("PROCESS 1 STARTED | EXTRACT EXCEL AUDIT + UI NEEDED DATA")
    logger.info("=" * 100)

    output = {
        "Advagen MICC": extract_site_excel_data(
            ADVAGEN_EXCEL_FOLDER,
            "Advagen MICC"
        ),
        "Validus MICC": extract_site_excel_data(
            VALIDUS_EXCEL_FOLDER,
            "Validus MICC"
        )
    }

    with open(
        CALL_IDS_JSON,
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(
            output,
            file,
            indent=4
        )

    logger.info("-" * 100)
    logger.info(f"Output JSON saved to: {os.path.abspath(CALL_IDS_JSON)}")

    logger.info(
        "Advagen MICC audit row count: "
        f"{output['Advagen MICC'].get('audit_row_count', 0)}"
    )

    logger.info(
        "Advagen MICC unique UI Call ID count: "
        f"{output['Advagen MICC'].get('unique_call_id_count', 0)}"
    )

    logger.info(
        "Validus MICC audit row count: "
        f"{output['Validus MICC'].get('audit_row_count', 0)}"
    )

    logger.info(
        "Validus MICC unique UI Call ID count: "
        f"{output['Validus MICC'].get('unique_call_id_count', 0)}"
    )

    logger.info("PROCESS 1 COMPLETED")

    return output


# ==========================================================
# ENTRY POINT USED BY run_all.py
# ==========================================================

run_step2 = process1

# ==========================================================
# RUN
# ==========================================================

if __name__ == "__main__":
    process1()