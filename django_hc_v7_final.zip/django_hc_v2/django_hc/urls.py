from django.contrib import admin
from django.urls import path, include

admin.site.site_header = "Health Check Administration"
admin.site.site_title  = "HC Admin"
admin.site.index_title = "Health Check v7"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("",        include("healthcheck.urls")),
]
