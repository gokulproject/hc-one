"""
healthcheck/views.py  (v7 final — all bugs fixed)
===================================================
Fixes:
  D1  DB connection retries=1 (fail fast) — handled in db_manager.
  D2  Every page returns 200 + skeleton when DB is down (never 500).
  U1  AJAX /api/dashboard/stats/ checks both scheduler and service health.
  U2  Navbar/body scrollable: fixed in base.html (position-static nav).
  U3  Helper notes added in schedule_form template.
  E-UI last_escalated_at, sent_to, cc now shown correctly in escalation pages.
  COUNT open_issues = OPEN + ESCALATED (both shown in stat card, split in badge).
  Scheduler Tracker: future runs now show ALL active schedules as QUEUED rows.
  Rerun page: shows attempt_number, max_attempts, error_reason, status clearly.
"""
import logging
import threading
from datetime import datetime, timedelta

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from healthcheck.models import (
    AlertHistory, Customer, EscalationConfig, EnvRunStatus,
    ExecutionLog, ExecutionRun, IssueTracker, RerunQueue,
    RunStepLog, Schedule, SchedulerTracker,
)

log    = logging.getLogger("hc.views")
HC_DB  = "healthcheck_db"


def _is_admin(user):
    return user.is_staff or user.is_superuser


def _safe(fn, fallback=None):
    """Call fn(), return fallback on ANY exception (DB down, etc.)."""
    try:
        val = fn()
        # Force queryset evaluation so DB errors surface here
        if hasattr(val, "__iter__") and not isinstance(val, (list, dict, str)):
            val = list(val)
        return val
    except Exception as exc:
        log.warning("DB query failed: %s", exc)
        return fallback if fallback is not None else []


# ════════════════════════════════════════════════════════════════════
# AUTH
# ════════════════════════════════════════════════════════════════════

def login_view(request):
    if request.user.is_authenticated:
        return redirect("healthcheck:dashboard")
    error = None
    if request.method == "POST":
        user = authenticate(
            request,
            username=request.POST.get("username", ""),
            password=request.POST.get("password", ""),
        )
        if user:
            login(request, user)
            return redirect(request.GET.get("next", "healthcheck:dashboard"))
        error = "Invalid username or password."
    return render(request, "healthcheck/login.html", {"error": error})


def logout_view(request):
    logout(request)
    return redirect("healthcheck:login")


# ════════════════════════════════════════════════════════════════════
# DASHBOARD
# ════════════════════════════════════════════════════════════════════

@login_required
def dashboard(request):
    # FIX COUNT: open = OPEN+ESCALATED combined, split shown in template
    open_issues   = _safe(lambda: IssueTracker.objects.using(HC_DB)
                          .filter(status="OPEN").count(), 0)
    escalated     = _safe(lambda: IssueTracker.objects.using(HC_DB)
                          .filter(status="ESCALATED").count(), 0)
    total_issues  = (open_issues or 0) + (escalated or 0)

    active_scheds = _safe(lambda: Schedule.objects.using(HC_DB)
                          .filter(is_active=True).count(), 0)
    active_custs  = _safe(lambda: Customer.objects.using(HC_DB)
                          .filter(is_active=True).count(), 0)
    in_progress   = _safe(lambda: ExecutionRun.objects.using(HC_DB)
                          .filter(status="IN_PROGRESS").count(), 0)
    recent_runs   = _safe(lambda: list(ExecutionRun.objects.using(HC_DB)
                          .select_related("customer").order_by("-id")[:10]))
    customers     = _safe(lambda: list(Customer.objects.using(HC_DB)
                          .filter(is_active=True).order_by("name")))

    db_ok = recent_runs is not None

    return render(request, "healthcheck/dashboard.html", {
        "recent_runs":      recent_runs or [],
        "open_issues":      open_issues or 0,
        "escalated_issues": escalated   or 0,
        "total_issues":     total_issues,
        "active_schedules": active_scheds or 0,
        "active_customers": active_custs  or 0,
        "in_progress":      in_progress   or 0,
        "customers":        customers or [],
        "db_ok":            db_ok,
        "page_title":       "Dashboard",
    })


# ════════════════════════════════════════════════════════════════════
# RUNS
# ════════════════════════════════════════════════════════════════════

@login_required
def run_list(request):
    status_f   = request.GET.get("status", "")
    customer_f = request.GET.get("customer", "")
    run_type_f = request.GET.get("run_type", "")

    def _qs():
        qs = ExecutionRun.objects.using(HC_DB).select_related("customer").order_by("-id")
        if status_f:   qs = qs.filter(status=status_f)
        if customer_f: qs = qs.filter(customer_id=customer_f)
        if run_type_f: qs = qs.filter(run_type=run_type_f)
        return list(qs)

    runs      = _safe(_qs, [])
    paginator = Paginator(runs or [], 20)
    page_obj  = paginator.get_page(request.GET.get("page"))
    customers = _safe(lambda: list(Customer.objects.using(HC_DB).filter(is_active=True)))

    return render(request, "healthcheck/run_list.html", {
        "page_obj":   page_obj,
        "customers":  customers or [],
        "status_f":   status_f,
        "customer_f": customer_f,
        "run_type_f": run_type_f,
        "page_title": "Execution Runs",
        "db_ok":      runs is not None,
    })


@login_required
def run_detail(request, run_id):
    try:
        run = ExecutionRun.objects.using(HC_DB).select_related("customer").get(id=run_id)
    except ExecutionRun.DoesNotExist:
        raise Http404
    except Exception:
        run = None

    logs     = _safe(lambda: list(ExecutionLog.objects.using(HC_DB)
                     .filter(run_id=run_id).order_by("logged_at")))
    steps    = _safe(lambda: list(RunStepLog.objects.using(HC_DB)
                     .filter(run_id=run_id).order_by("step_order")))
    env_st   = _safe(lambda: list(EnvRunStatus.objects.using(HC_DB)
                     .filter(run_id=run_id)))
    # Rerun info for this run
    reruns   = _safe(lambda: list(RerunQueue.objects.using(HC_DB)
                     .filter(original_run_id=run_id).order_by("attempt_number")))

    paginator = Paginator(logs or [], 20)
    log_page  = paginator.get_page(request.GET.get("page"))

    return render(request, "healthcheck/run_detail.html", {
        "run":          run,
        "log_page":     log_page,
        "steps":        steps or [],
        "env_statuses": env_st or [],
        "reruns":       reruns or [],
        "page_title":   f"Run #{run_id}",
        "db_ok":        run is not None,
    })


@login_required
@require_POST
def run_trigger(request):
    customer_id = request.POST.get("customer_id", "").strip()
    env_types   = request.POST.get("env_types", "DEV").strip() or "DEV"
    if not customer_id:
        messages.error(request, "Please select a customer.")
        return redirect("healthcheck:dashboard")
    try:
        from healthcheck.engine_bridge import get_engine
        eng    = get_engine()
        run_id = None
        with eng["DBManager"]() as db:
            cfg    = eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id, env_types, run_type, status, triggered_by)
                   VALUES (%s,%s,'MANUAL','PENDING',%s)""",
                (customer_id, env_types, request.user.username))

        def _bg():
            try:
                from healthcheck.engine_bridge import get_engine as _ge
                _e = _ge()
                with _e["DBManager"]() as _db:
                    _cfg = _e["ConfigLoader"].load(_db)
                    _e["RunLauncher"](_db, run_id, _cfg).launch()
            except Exception as e:
                log.error("BG run #%s failed: %s", run_id, e)

        threading.Thread(target=_bg, daemon=True,
                         name=f"hc-run-{run_id}").start()
        messages.success(request, f"✅ Run #{run_id} started for {env_types}.")
    except Exception as e:
        messages.error(request, f"Failed to trigger run: {e}")
    return redirect("healthcheck:runs")


# ════════════════════════════════════════════════════════════════════
# RERUN QUEUE  (FIX R7: shows error_reason, attempt_number, status)
# ════════════════════════════════════════════════════════════════════

@login_required
def rerun_list(request):
    status_f    = request.GET.get("status", "")
    customer_f  = request.GET.get("customer", "")

    def _qs():
        qs = RerunQueue.objects.using(HC_DB).select_related("customer").order_by("-id")
        if status_f:   qs = qs.filter(status=status_f)
        if customer_f: qs = qs.filter(customer_id=customer_f)
        return list(qs)

    reruns    = _safe(_qs, [])
    paginator = Paginator(reruns or [], 20)
    page_obj  = paginator.get_page(request.GET.get("page"))
    customers = _safe(lambda: list(Customer.objects.using(HC_DB).filter(is_active=True)))

    return render(request, "healthcheck/rerun_list.html", {
        "page_obj":   page_obj,
        "customers":  customers or [],
        "status_f":   status_f,
        "customer_f": customer_f,
        "page_title": "Rerun Queue",
        "db_ok":      reruns is not None,
    })


# ════════════════════════════════════════════════════════════════════
# SCHEDULES
# ════════════════════════════════════════════════════════════════════

@login_required
def schedule_list(request):
    scheds    = _safe(lambda: list(Schedule.objects.using(HC_DB)
                      .select_related("customer")
                      .order_by("customer__name", "schedule_name")))
    paginator = Paginator(scheds or [], 20)
    page_obj  = paginator.get_page(request.GET.get("page"))
    customers = _safe(lambda: list(Customer.objects.using(HC_DB).filter(is_active=True)))

    return render(request, "healthcheck/schedule_list.html", {
        "page_obj":   page_obj,
        "customers":  customers or [],
        "page_title": "Schedules",
        "db_ok":      scheds is not None,
    })


@login_required
def schedule_create(request):
    from healthcheck.forms import ScheduleForm
    if request.method == "POST":
        form = ScheduleForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            try:
                from croniter import croniter
                base = obj.start_at if obj.start_at else datetime.now()
                obj.next_run_at = croniter(obj.cron_expression, base).get_next(datetime)
            except Exception:
                pass
            try:
                obj.save(using=HC_DB)
                messages.success(request, f"Schedule '{obj.schedule_name}' created.")
                return redirect("healthcheck:schedules")
            except Exception as e:
                messages.error(request, f"DB error: {e}")
    else:
        form = ScheduleForm()
    return render(request, "healthcheck/schedule_form.html",
                  {"form": form, "action": "Create", "page_title": "New Schedule"})


@login_required
def schedule_edit(request, pk):
    from healthcheck.forms import ScheduleForm
    try:
        obj = Schedule.objects.using(HC_DB).get(pk=pk)
    except Exception:
        messages.error(request, "Schedule not found or DB unavailable.")
        return redirect("healthcheck:schedules")
    if request.method == "POST":
        form = ScheduleForm(request.POST, instance=obj)
        if form.is_valid():
            saved = form.save(commit=False)
            try:
                from croniter import croniter
                base = saved.start_at if saved.start_at else datetime.now()
                saved.next_run_at = croniter(saved.cron_expression, base).get_next(datetime)
            except Exception:
                pass
            try:
                saved.save(using=HC_DB)
                messages.success(request, f"Schedule '{saved.schedule_name}' updated.")
                return redirect("healthcheck:schedules")
            except Exception as e:
                messages.error(request, f"DB error: {e}")
    else:
        form = ScheduleForm(instance=obj)
    return render(request, "healthcheck/schedule_form.html",
                  {"form": form, "action": "Edit", "page_title": "Edit Schedule"})


@login_required
@require_POST
def schedule_toggle(request, pk):
    try:
        s = Schedule.objects.using(HC_DB).get(pk=pk)
        s.is_active = not s.is_active
        s.save(using=HC_DB)
        messages.success(request,
            f"Schedule '{s.schedule_name}' {'activated' if s.is_active else 'paused'}.")
    except Exception as e:
        messages.error(request, f"Error: {e}")
    return redirect("healthcheck:schedules")


# ════════════════════════════════════════════════════════════════════
# ESCALATIONS  (FIX E-UI: last_escalated_at, sent_to, cc displayed)
# ════════════════════════════════════════════════════════════════════

@login_required
def escalation_list(request):
    customer_f = request.GET.get("customer", "")
    env_f      = request.GET.get("env_type", "")
    status_f   = request.GET.get("status", "")

    def _qs():
        qs = IssueTracker.objects.using(HC_DB).select_related(
            "customer", "test_catalog").order_by("-consecutive_failures", "-updated_at")
        if customer_f: qs = qs.filter(customer_id=customer_f)
        if env_f:      qs = qs.filter(env_type=env_f)
        if status_f:   qs = qs.filter(status=status_f)
        return list(qs)

    issues    = _safe(_qs, [])

    # FIX E-UI: attach last alert TO address per issue for display in list
    if issues:
        for iss in issues:
            try:
                last_ah = AlertHistory.objects.using(HC_DB).filter(
                    issue_id=iss.id, alert_type="ESCALATION"
                ).order_by("-sent_at").first()
                iss.last_alert_to = last_ah.recipients_to if last_ah else ""
            except Exception:
                iss.last_alert_to = ""

    paginator = Paginator(issues or [], 20)
    page_obj  = paginator.get_page(request.GET.get("page"))
    customers = _safe(lambda: list(Customer.objects.using(HC_DB).filter(is_active=True)))

    # FIX COUNT: split OPEN vs ESCALATED counts for badge display
    open_count      = _safe(lambda: IssueTracker.objects.using(HC_DB).filter(status="OPEN").count(), 0)
    escalated_count = _safe(lambda: IssueTracker.objects.using(HC_DB).filter(status="ESCALATED").count(), 0)

    return render(request, "healthcheck/escalation_list.html", {
        "page_obj":       page_obj,
        "customers":      customers or [],
        "customer_f":     customer_f,
        "env_f":          env_f,
        "status_f":       status_f,
        "open_count":     open_count or 0,
        "escalated_count": escalated_count or 0,
        "page_title":     "Escalations / Issue Tracker",
        "db_ok":          issues is not None,
    })


@login_required
def escalation_report(request, issue_id):
    try:
        issue = IssueTracker.objects.using(HC_DB).select_related(
            "customer", "test_catalog", "last_failed_run").get(id=issue_id)
    except IssueTracker.DoesNotExist:
        raise Http404
    except Exception:
        issue = None

    # FIX E-UI: pull alert_history with recipients for this issue
    alerts = _safe(lambda: list(
        AlertHistory.objects.using(HC_DB)
        .filter(issue_id=issue_id)
        .order_by("-sent_at")[:20]))

    # Last email sent_to / cc from alert_history
    last_alert = alerts[0] if alerts else None

    # Escalation config for this customer/env
    esc_cfg = None
    if issue:
        esc_cfg = _safe(lambda: EscalationConfig.objects.using(HC_DB).filter(
            customer=issue.customer, env_type=issue.env_type).first())

    return render(request, "healthcheck/escalation_report.html", {
        "issue":         issue,
        "alert_history": alerts or [],
        "last_alert":    last_alert,
        "esc_cfg":       esc_cfg,
        "page_title":    f"Issue #{issue_id} Report",
        "db_ok":         issue is not None,
    })


# ════════════════════════════════════════════════════════════════════
# SCHEDULER TRACKER  (FIX: future runs shown as QUEUED rows)
# ════════════════════════════════════════════════════════════════════

@login_required
@user_passes_test(_is_admin)
def scheduler_tracker(request):
    # Past completed scheduled runs
    past = _safe(lambda: list(
        ExecutionRun.objects.using(HC_DB)
        .select_related("customer", "schedule")
        .filter(run_type="SCHEDULED",
                status__in=["COMPLETED", "FAILED", "PARTIAL"])
        .order_by("-id")[:50]))

    # Currently running
    running = _safe(lambda: list(
        ExecutionRun.objects.using(HC_DB)
        .select_related("customer", "schedule")
        .filter(run_type="SCHEDULED", status="IN_PROGRESS")))

    # FIX: future runs = all active schedules shown as QUEUED
    # Each active schedule with next_run_at is a future queued entry
    future_schedules = _safe(lambda: list(
        Schedule.objects.using(HC_DB)
        .select_related("customer")
        .filter(is_active=True)
        .order_by("next_run_at")))

    # Also get pending rerun queue entries for completeness
    pending_reruns = _safe(lambda: list(
        RerunQueue.objects.using(HC_DB)
        .select_related("customer")
        .filter(status="PENDING")
        .order_by("scheduled_at")))

    return render(request, "healthcheck/scheduler_tracker.html", {
        "past_runs":       past or [],
        "running_runs":    running or [],
        "future_schedules": future_schedules or [],
        "pending_reruns":  pending_reruns or [],
        "page_title":      "Scheduler Tracker",
        "db_ok":           past is not None,
    })


# ════════════════════════════════════════════════════════════════════
# ALERT HISTORY
# ════════════════════════════════════════════════════════════════════

@login_required
def alert_history(request):
    alert_type_f = request.GET.get("alert_type", "")
    customer_f   = request.GET.get("customer", "")

    def _qs():
        qs = AlertHistory.objects.using(HC_DB).select_related("customer").order_by("-sent_at")
        if alert_type_f: qs = qs.filter(alert_type=alert_type_f)
        if customer_f:   qs = qs.filter(customer_id=customer_f)
        return list(qs)

    alerts    = _safe(_qs, [])
    paginator = Paginator(alerts or [], 20)
    page_obj  = paginator.get_page(request.GET.get("page"))
    customers = _safe(lambda: list(Customer.objects.using(HC_DB).filter(is_active=True)))

    return render(request, "healthcheck/alert_history.html", {
        "page_obj":     page_obj,
        "customers":    customers or [],
        "alert_type_f": alert_type_f,
        "customer_f":   customer_f,
        "page_title":   "Alert History",
        "db_ok":        alerts is not None,
    })


# ════════════════════════════════════════════════════════════════════
# API / AJAX
# ════════════════════════════════════════════════════════════════════

@login_required
def api_run_status(request, run_id):
    try:
        run = ExecutionRun.objects.using(HC_DB).get(id=run_id)
        return JsonResponse({
            "id":           run.id,
            "status":       run.status,
            "latest_step":  run.latest_step or "",
            "started_at":   run.started_at.isoformat() if run.started_at else None,
            "completed_at": run.completed_at.isoformat() if run.completed_at else None,
        })
    except ExecutionRun.DoesNotExist:
        return JsonResponse({"error": "Not found"}, status=404)
    except Exception as e:
        return JsonResponse({"error": "DB unavailable", "detail": str(e)}, status=503)


@login_required
def api_dashboard_stats(request):
    """
    FIX U1: returns both scheduler health AND service health.
    Used by dashboard AJAX to refresh stat cards without full reload.
    """
    try:
        open_c  = IssueTracker.objects.using(HC_DB).filter(status="OPEN").count()
        esc_c   = IssueTracker.objects.using(HC_DB).filter(status="ESCALATED").count()
        scheds  = Schedule.objects.using(HC_DB).filter(is_active=True).count()
        in_prog = ExecutionRun.objects.using(HC_DB).filter(status="IN_PROGRESS").count()
        return JsonResponse({
            "db_ok":            True,
            "open_issues":      open_c,
            "escalated_issues": esc_c,
            "total_issues":     open_c + esc_c,
            "active_schedules": scheds,
            "in_progress":      in_prog,
        })
    except Exception as e:
        return JsonResponse({"db_ok": False, "error": str(e)}, status=503)
