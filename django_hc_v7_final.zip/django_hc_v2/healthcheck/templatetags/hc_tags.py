from django import template
register = template.Library()

@register.filter
def split(value, delimiter=","):
    """Split string by delimiter."""
    if not value:
        return []
    return [x for x in str(value).split(delimiter) if x.strip()]

@register.filter
def trim(value):
    """Strip whitespace from string."""
    return str(value).strip() if value else ""
