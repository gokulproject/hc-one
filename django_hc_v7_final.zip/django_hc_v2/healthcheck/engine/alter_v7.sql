-- =============================================================
-- Health Check v7 -- Incremental Alter Script
-- Run ONCE after alter_v6.sql
--
--   mysql -u root -p hc_v5 < alter_v7.sql
--
-- Safe: uses ADD COLUMN IF NOT EXISTS / CREATE TABLE IF NOT EXISTS
-- =============================================================

USE `hc_v5`;

-- 1. schedules: add start_at column
--    Scheduler will not fire before this datetime. NULL = fire immediately.
ALTER TABLE `schedules`
  ADD COLUMN IF NOT EXISTS `start_at` DATETIME NULL
    COMMENT 'Scheduler will not fire before this datetime. NULL = start immediately.'
    AFTER `next_run_at`;

-- 2. issue_tracker: add last_escalated_at (fixes "Unknown column" error)
ALTER TABLE `issue_tracker`
  ADD COLUMN IF NOT EXISTS `last_escalated_at` DATETIME NULL
    COMMENT 'When last escalation email was sent for this issue'
    AFTER `status`;

-- 3. issue_tracker: add escalation_send_count
ALTER TABLE `issue_tracker`
  ADD COLUMN IF NOT EXISTS `escalation_send_count` INT NOT NULL DEFAULT 0
    COMMENT 'Total escalation emails sent'
    AFTER `last_escalated_at`;

-- 4. scheduler_tracker: admin visibility of past/running/future runs
CREATE TABLE IF NOT EXISTS `scheduler_tracker` (
  `id`            INT          NOT NULL AUTO_INCREMENT,
  `schedule_id`   INT          NOT NULL,
  `customer_id`   INT          NOT NULL,
  `run_id`        INT          NULL,
  `env_types`     VARCHAR(50)  NOT NULL,
  `status`        ENUM('PENDING','IN_PROGRESS','COMPLETED','FAILED','PARTIAL')
                               NOT NULL DEFAULT 'PENDING',
  `scheduled_for` DATETIME     NOT NULL,
  `started_at`    DATETIME     NULL,
  `completed_at`  DATETIME     NULL,
  `error_detail`  TEXT         NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_st_schedule` (`schedule_id`),
  KEY `idx_st_customer` (`customer_id`),
  KEY `idx_st_status`   (`status`),
  CONSTRAINT `fk_st_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules`     (`id`),
  CONSTRAINT `fk_st_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`     (`id`),
  CONSTRAINT `fk_st_run`      FOREIGN KEY (`run_id`)      REFERENCES `execution_runs`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT 'Admin tracker: past, running, and future scheduled execution runs.';

-- Verify
SELECT 'alter_v7 complete' AS result,
       (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema='hc_v5' AND table_name='schedules'     AND column_name='start_at')           AS schedules_start_at,
       (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema='hc_v5' AND table_name='issue_tracker' AND column_name='last_escalated_at')  AS issue_last_escalated_at,
       (SELECT COUNT(*) FROM information_schema.tables
        WHERE table_schema='hc_v5' AND table_name='scheduler_tracker')                                   AS scheduler_tracker_table;

-- 5. rerun_queue: ensure last_error column exists (stores fail reason)
ALTER TABLE `rerun_queue`
  ADD COLUMN IF NOT EXISTS `last_error` TEXT NULL
    COMMENT 'Error detail from the failed run that triggered this rerun'
    AFTER `completed_at`;

-- 6. rerun_queue: ensure status has EXHAUSTED option
ALTER TABLE `rerun_queue`
  MODIFY COLUMN `status`
    ENUM('PENDING','IN_PROGRESS','COMPLETED','FAILED','EXHAUSTED')
    NOT NULL DEFAULT 'PENDING'
    COMMENT 'EXHAUSTED = all attempts used up';

SELECT 'alter_v7 complete (all columns added)' AS result;
