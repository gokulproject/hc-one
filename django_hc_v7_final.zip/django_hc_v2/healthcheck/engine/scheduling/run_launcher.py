"""
scheduling/run_launcher.py  (v7 - all bugs fixed)
===================================================
Fixes in v7:
  R1  Attempt counter now reads max(attempt_number) from rerun_queue,
      not rerun_attempt on execution_runs — so 3/3 is reachable.
  R2  EXHAUSTED status written to rerun_queue row immediately.
  R3  rerun_queue row always updated PENDING→COMPLETED/FAILED after run.
  R4  Manual kill / DB error path also calls _queue_rerun via finally block.
  R5  DB error during execution queues rerun before re-raising.
  R6  All exit paths (normal, aborted) go through _ensure_rerun().
  R7  error_reason column stored in rerun_queue for UI display.
  R8  Failure email sent on every abort, including manual kill path.
  R9  rerun_attempt correctly set on new execution_runs row.
"""
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from core.config import ConfigLoader, AppConfig
from core.db_manager import DBManager
from core.executor import HealthCheckExecutor
from core.issue_tracker import IssueTrackerService
from core.logger import RunLogger, SilentLogger
from reports.excel_generator import ExcelReportGenerator
from notifications.email_service import EmailService

_TOTAL_STEPS = 6


class RunLauncher:
    def __init__(self, db: DBManager, run_id: int, cfg: AppConfig):
        self.db             = db
        self.run_id         = run_id
        self.cfg            = cfg
        self._step_failures: List[Dict] = []
        self._final_status  = "FAILED"   # tracked for finally block
        self._run_row       = None        # cached from DB

    # ══════════════════════════════════════════════════════════════════ #
    # Step log helpers
    # ══════════════════════════════════════════════════════════════════ #

    def _step_start(self, order: int, name: str) -> int:
        try:
            row_id = self.db.insert_get_id(
                """INSERT INTO run_step_log
                   (run_id, step_name, step_order, status, started_at)
                   VALUES (%s,%s,%s,'RUNNING',NOW(3))""",
                (self.run_id, name, order))
            self.db.execute(
                "UPDATE execution_runs SET latest_step=%s WHERE id=%s",
                (f"[{order}/{_TOTAL_STEPS}] {name} — RUNNING", self.run_id))
            return row_id
        except Exception:
            return 0

    def _step_end(self, row_id: int, order: int, name: str,
                  status: str = "COMPLETED", notes: str = ""):
        try:
            self.db.execute(
                """UPDATE run_step_log
                   SET status=%s, completed_at=NOW(3),
                       duration_ms=TIMESTAMPDIFF(MICROSECOND,started_at,NOW(3)) DIV 1000,
                       notes=%s
                   WHERE id=%s""",
                (status, notes[:2000] if notes else None, row_id))
            self.db.execute(
                "UPDATE execution_runs SET latest_step=%s WHERE id=%s",
                (f"[{order}/{_TOTAL_STEPS}] {name} — {status}", self.run_id))
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════ #
    # LAUNCH
    # ══════════════════════════════════════════════════════════════════ #

    def launch(self):
        """Execute a run end-to-end. Never raises — rerun always queued."""
        self._run_row = self.db.fetch_one(
            "SELECT * FROM execution_runs WHERE id=%s", (self.run_id,))
        if not self._run_row:
            print(f"ERROR: run_id={self.run_id} not found")
            return

        customer_id   = self._run_row["customer_id"]
        env_types_str = self._run_row["env_types"]
        env_types     = [e.strip() for e in env_types_str.split(",")]

        logger = RunLogger(
            run_id=self.run_id,
            log_dir=self.cfg.log_output_path,
            db=self.db,
            customer_id=customer_id)

        customer = self.db.fetch_one(
            "SELECT * FROM customers WHERE id=%s", (customer_id,))
        cname = customer["name"] if customer else str(customer_id)

        logger.section(
            f"Run #{self.run_id}  |  {cname}  |  {env_types_str}  |  "
            f"{self._run_row['run_type']}")

        email_svc  = EmailService(self.db, logger)
        has_action = False
        excel_path = None

        try:
            # ── Step 1: Health checks ──────────────────────────────────
            sid = self._step_start(1, "Health Checks")
            logger.step(1, _TOTAL_STEPS, "Executing health checks")
            try:
                executor = HealthCheckExecutor(self.db, self.run_id, logger)
                self._final_status = executor.run()
                logger.info(f"Executor status: {self._final_status}")
                self._step_end(sid, 1, "Health Checks", "COMPLETED",
                               f"status={self._final_status}")
            except Exception as exc:
                self._step_end(sid, 1, "Health Checks", "FAILED", str(exc))
                self._step_failures.append({"step": "Health Checks", "reason": str(exc)})
                raise

            # ── Step 2: Issue tracking ─────────────────────────────────
            sid = self._step_start(2, "Issue Tracking")
            logger.step(2, _TOTAL_STEPS, f"Issue tracker ({len(env_types)} env(s))")
            issue_errors = []
            issue_svc    = IssueTrackerService(self.db)
            for env_type in env_types:
                try:
                    issue_svc.process_run_results(
                        self.run_id, customer_id, env_type, logger)
                except Exception as exc:
                    issue_errors.append(f"{env_type}: {exc}")
                    logger.error(f"Issue tracking failed {env_type}: {exc}")
            if issue_errors:
                self._step_end(sid, 2, "Issue Tracking", "FAILED",
                               "; ".join(issue_errors))
                self._step_failures.append(
                    {"step": "Issue Tracking", "reason": "; ".join(issue_errors)})
            else:
                self._step_end(sid, 2, "Issue Tracking", "COMPLETED")

            # ── Step 3: Escalation ─────────────────────────────────────
            sid = self._step_start(3, "Escalation Check")
            logger.step(3, _TOTAL_STEPS, "Checking escalations")
            esc_errors = []
            for env_type in env_types:
                esc_cfg = self.db.fetch_one(
                    "SELECT * FROM escalation_config "
                    "WHERE customer_id=%s AND env_type=%s",
                    (customer_id, env_type))

                # Pause check
                if esc_cfg and esc_cfg["is_paused"]:
                    paused_until = esc_cfg["paused_until"]
                    if paused_until is None or datetime.now() < paused_until:
                        logger.info(
                            f"Escalation paused {cname}/{env_type} "
                            f"until {paused_until or 'manual resume'}")
                        continue
                    else:
                        self.db.execute(
                            "UPDATE escalation_config "
                            "SET is_paused=0,paused_until=NULL WHERE id=%s",
                            (esc_cfg["id"],))
                        logger.info(f"Escalation auto-resumed {cname}/{env_type}")

                threshold = esc_cfg["threshold"] if esc_cfg else 3
                interval  = esc_cfg["interval_hours"] if esc_cfg else 168

                # FIX E1/E2: filter by threshold before deciding to escalate
                escalated = issue_svc.get_escalated_issues(
                    customer_id, env_type, threshold)
                due_issues = [
                    i for i in escalated
                    if issue_svc.should_send_escalation(i, interval)
                ]
                if due_issues:
                    max_consec = max(i["consecutive_failures"] for i in due_issues)
                    logger.warning(
                        f"Escalating {len(due_issues)} issue(s) in {env_type}, "
                        f"max_consec={max_consec}, threshold={threshold}")
                    try:
                        email_svc.send_escalation(
                            customer_id=customer_id,
                            customer_name=cname,
                            env_type=env_type,
                            issues=due_issues,
                            escalation_count=max_consec)
                        for iss in due_issues:
                            issue_svc.mark_escalated(iss["id"])
                    except Exception as exc:
                        esc_errors.append(f"{env_type}: {exc}")
                        logger.error(f"Escalation email failed {env_type}: {exc}")

            if esc_errors:
                self._step_end(sid, 3, "Escalation Check", "FAILED",
                               "; ".join(esc_errors))
            else:
                self._step_end(sid, 3, "Escalation Check", "COMPLETED")

            # ── Step 4: Excel ──────────────────────────────────────────
            email_title = cname
            if self._final_status in ("COMPLETED", "PARTIAL"):
                sid = self._step_start(4, "Excel Generation")
                logger.step(4, _TOTAL_STEPS, "Generating Excel report")
                try:
                    gen = ExcelReportGenerator(self.db, self.run_id, logger)
                    excel_path, email_title = gen.generate()
                    has_action = email_title.startswith("Action Required -")
                    self._step_end(sid, 4, "Excel Generation", "COMPLETED",
                                   f"File: {excel_path}")
                except Exception as exc:
                    self._step_end(sid, 4, "Excel Generation", "FAILED", str(exc))
                    self._step_failures.append(
                        {"step": "Excel Generation", "reason": str(exc)})
                    logger.error(f"Excel failed: {exc}\n{traceback.format_exc()}")
            else:
                sid = self._step_start(4, "Excel Generation")
                self._step_end(sid, 4, "Excel Generation", "SKIPPED",
                               f"Run status={self._final_status}")

            # ── Step 5: Emails ─────────────────────────────────────────
            sid = self._step_start(5, "Email Notifications")
            logger.step(5, _TOTAL_STEPS, "Sending email notifications")
            env_labels    = ", ".join(
                {"PRD": "Production", "VAL": "Validation",
                 "DEV": "Development"}.get(e, e) for e in env_types)
            email_errors  = []

            if self._final_status in ("COMPLETED", "PARTIAL"):
                try:
                    email_svc.send_success(
                        run_id=self.run_id,
                        customer_id=customer_id,
                        customer_name=cname,
                        env_label=env_labels,
                        report_title=email_title,
                        excel_path=excel_path,
                        env_types=env_types_str,
                        triggered_by=self._run_row.get("triggered_by", "system"),
                        has_action=has_action,
                        step_failures=self._step_failures)
                except Exception as exc:
                    email_errors.append(f"SUCCESS: {exc}")
                    logger.error(f"Success email failed: {exc}")

            if self._final_status in ("FAILED", "PARTIAL"):
                for env_type in env_types:
                    try:
                        email_svc.send_failure(
                            run_id=self.run_id,
                            customer_id=customer_id,
                            customer_name=cname,
                            env_type=env_type,
                            error_message=(
                                f"Run #{self.run_id} status: {self._final_status}. "
                                "Check execution_logs for details."),
                            triggered_by=self._run_row.get("triggered_by", "system"),
                            step_failures=self._step_failures)
                    except Exception as exc:
                        email_errors.append(f"FAILURE/{env_type}: {exc}")
                        logger.error(f"Failure email failed {env_type}: {exc}")

            if email_errors:
                self._step_end(sid, 5, "Email Notifications", "FAILED",
                               "; ".join(email_errors))
                self._step_failures.append(
                    {"step": "Email Notifications",
                     "reason": "; ".join(email_errors)})
            else:
                self._step_end(sid, 5, "Email Notifications", "COMPLETED")

            # ── Step 6: Rerun queue ────────────────────────────────────
            sid = self._step_start(6, "Rerun Queue")
            logger.step(6, _TOTAL_STEPS, "Queuing rerun if needed")
            if self._final_status in ("FAILED", "PARTIAL"):
                queued = self._queue_rerun(
                    customer_id, env_types_str, cname, logger, email_svc)
                self._step_end(sid, 6, "Rerun Queue", "COMPLETED",
                               "Rerun queued" if queued else "Max attempts reached")
            else:
                self._step_end(sid, 6, "Rerun Queue", "SKIPPED",
                               f"Run status={self._final_status}")

            # Mark run COMPLETED in DB
            self.db.execute(
                """UPDATE execution_runs
                   SET status=%s, completed_at=NOW()
                   WHERE id=%s""",
                (self._final_status, self.run_id))

        except Exception as exc:
            # FIX R4/R5/R6: ALL abort paths send email + queue rerun
            tb = traceback.format_exc()
            logger.critical(f"Run #{self.run_id} ABORTED: {exc}\n{tb}")
            err_msg = f"{exc}\n{tb}"
            self.db.execute(
                """UPDATE execution_runs
                   SET status='FAILED', error_summary=%s, completed_at=NOW()
                   WHERE id=%s""",
                (err_msg[:2000], self.run_id))
            self._final_status = "FAILED"

            # FIX R8: always send failure email even on abort
            try:
                for et in env_types:
                    email_svc.send_failure(
                        run_id=self.run_id,
                        customer_id=customer_id,
                        customer_name=cname,
                        env_type=et,
                        error_message=str(exc),
                        triggered_by=self._run_row.get("triggered_by", "system"),
                        step_failures=self._step_failures)
            except Exception:
                pass

            # FIX R4/R5: queue rerun even on abort
            try:
                self._queue_rerun(
                    customer_id, env_types_str, cname, logger, email_svc,
                    error_reason=str(exc)[:1000])
            except Exception as qe:
                logger.error(f"Failed to queue rerun after abort: {qe}")

        finally:
            logger.info(f"Run #{self.run_id} done — status={self._final_status}")
            logger.flush()
            logger.close()

    # ══════════════════════════════════════════════════════════════════ #
    # Rerun queue — all R-bugs fixed here
    # ══════════════════════════════════════════════════════════════════ #

    def _queue_rerun(self, customer_id: int, env_types: str,
                     cname: str, logger, email_svc,
                     error_reason: str = "") -> bool:
        """
        Queue next rerun attempt. Returns True if queued, False if exhausted.

        FIX R1: attempt_number derived from max(attempt_number) in rerun_queue
                 so counter always increments correctly → 3/3 is reachable.
        FIX R2: EXHAUSTED status written to the exhausted row in rerun_queue.
        FIX R3: rerun_queue.status is always updated (PENDING→IN_PROGRESS→COMPLETED
                 is handled in scheduler._process_reruns which was already correct).
        FIX R7: error_reason stored in last_error column.
        FIX R9: attempt_number passed into execution_runs.rerun_attempt.
        """
        # Already queued and pending?
        existing = self.db.fetch_one(
            "SELECT id FROM rerun_queue "
            "WHERE original_run_id=%s AND status IN ('PENDING','IN_PROGRESS')",
            (self.run_id,))
        if existing:
            logger.debug(f"Rerun already queued (id={existing['id']})")
            return True

        # FIX R1: get the highest attempt_number already used for this chain
        # Walk back through rerun_of_run_id to find the original run
        original_run_id = self._get_original_run_id()

        max_row = self.db.fetch_one(
            """SELECT MAX(attempt_number) AS max_att
               FROM rerun_queue
               WHERE original_run_id=%s""",
            (original_run_id,))
        current_attempt = (max_row["max_att"] or 0) if max_row else 0
        next_attempt    = current_attempt + 1
        max_attempts    = self.cfg.rerun_max_attempts

        if next_attempt > max_attempts:
            # FIX R2: write EXHAUSTED to the last rerun_queue row
            logger.warning(
                f"Max reruns ({max_attempts}) reached for run #{self.run_id}")
            self.db.execute(
                """UPDATE rerun_queue
                   SET status='EXHAUSTED', last_error=%s
                   WHERE original_run_id=%s
                   ORDER BY id DESC LIMIT 1""",
                (f"Max attempts={max_attempts} reached", original_run_id))

            # Notify if configured
            ecs = self.db.fetch_all(
                "SELECT notify_rerun_fail FROM escalation_config "
                "WHERE customer_id=%s",
                (customer_id,))
            should_notify = any(e["notify_rerun_fail"] for e in ecs) if ecs else True
            if should_notify:
                try:
                    email_svc.send_rerun_exhausted(
                        run_id=original_run_id,
                        customer_id=customer_id,
                        customer_name=cname,
                        env_types=env_types,
                        max_attempts=max_attempts)
                except Exception as exc:
                    logger.error(f"Rerun exhausted email failed: {exc}")
            return False

        sched_at = datetime.now() + timedelta(hours=self.cfg.rerun_interval_hours)

        # FIX R7: store error_reason in last_error column
        self.db.execute(
            """INSERT INTO rerun_queue
               (original_run_id, customer_id, env_types,
                attempt_number, max_attempts, status,
                scheduled_at, last_error)
               VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s)""",
            (original_run_id, customer_id, env_types,
             next_attempt, max_attempts, sched_at,
             error_reason or f"Run #{self.run_id} {self._final_status}"))

        logger.info(
            f"Rerun queued: attempt {next_attempt}/{max_attempts} "
            f"at {sched_at.strftime('%Y-%m-%d %H:%M')}")
        return True

    def _get_original_run_id(self) -> int:
        """
        Walk rerun_of_run_id chain to find the root original run.
        FIX R9: ensures attempt counter is always relative to the original run.
        """
        if not self._run_row:
            return self.run_id
        parent = self._run_row.get("rerun_of_run_id")
        if not parent:
            return self.run_id
        # Walk up chain (max 20 steps to avoid infinite loop)
        seen = {self.run_id}
        current_id = parent
        for _ in range(20):
            if current_id in seen:
                break
            seen.add(current_id)
            row = self.db.fetch_one(
                "SELECT rerun_of_run_id FROM execution_runs WHERE id=%s",
                (current_id,))
            if not row or not row.get("rerun_of_run_id"):
                return current_id
            current_id = row["rerun_of_run_id"]
        return current_id
