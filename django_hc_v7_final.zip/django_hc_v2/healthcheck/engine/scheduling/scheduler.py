"""
scheduling/scheduler.py  (v7)
==============================
v7 fixes:
  1. Dual-run prevention: DB lock check before firing.
  2. start_at column: schedule won't fire before this datetime.
  3. last_run_at/next_run_at: always updated after every run.
  4. Memory release: handled in RunLauncher (oracle close).
"""
import threading
import time
import traceback
from datetime import datetime, timedelta

from croniter import croniter

from core.config import ConfigLoader
from core.db_manager import DBManager
from core.logger import SilentLogger
from scheduling.run_launcher import RunLauncher

POLL_SECONDS = 60
_FIRE_LOCK   = threading.Lock()


class HealthCheckScheduler:

    def __init__(self):
        self._running = True
        self._tick    = 0

    def _log(self, msg: str):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[SCHEDULER] {ts} | {msg}", flush=True)

    def _db_log(self, db, run_id: int, level: str, msg: str):
        try:
            db.execute(
                """INSERT INTO execution_logs
                   (run_id, log_level, py_file, py_module, py_function,
                    py_line, message, logged_at)
                   VALUES (%s,%s,'scheduler.py','scheduler','_db_log',0,%s,NOW(3))""",
                (run_id, level.upper(), msg))
        except Exception:
            pass

    def start(self):
        self._log("Started. Press Ctrl+C to stop.")
        while self._running:
            try:
                self._tick += 1
                self._log(f"Tick #{self._tick}")
                self._do_tick()
            except Exception as exc:
                self._log(f"ERROR in tick: {exc}\n{traceback.format_exc()}")
            time.sleep(POLL_SECONDS)

    def stop(self):
        self._running = False

    def _do_tick(self):
        with DBManager() as db:
            cfg = ConfigLoader.load(db)
            self._fire_schedules(db, cfg)
            self._process_reruns(db, cfg)
            self._purge_logs(db, cfg)

    def _fire_schedules(self, db, cfg):
        schedules = db.fetch_all(
            """SELECT s.*, c.name AS cname, c.code AS ccode
               FROM schedules s JOIN customers c ON c.id=s.customer_id
               WHERE s.is_active=1 AND c.is_active=1""")
        now = datetime.now()

        for sched in schedules:
            try:
                # start_at check: skip if not yet time to start
                start_at = sched.get("start_at")
                if start_at and now < start_at:
                    self._log(
                        f"{sched['cname']}/{sched['env_types']} | "
                        f"Waiting for start_at={start_at.strftime('%Y-%m-%d %H:%M')}")
                    continue

                # Cron base: use start_at if given (so cron fires relative to it)
                cron_base = start_at if start_at else (now - timedelta(minutes=1))

                # Find the most recent due time <= now
                ci   = croniter(sched["cron_expression"], cron_base)
                due  = ci.get_next(datetime)
                if due > now:
                    # fall back: get_prev from now
                    ci2  = croniter(sched["cron_expression"], now)
                    due  = ci2.get_prev(datetime)

                last = sched.get("last_run_at")
                if not (now >= due and (last is None or last < due)):
                    continue

                # dual-run guard: prevent duplicate fires
                with _FIRE_LOCK:
                    in_prog = db.fetch_one(
                        """SELECT id FROM execution_runs
                           WHERE schedule_id=%s AND status IN ('IN_PROGRESS','PENDING')
                           LIMIT 1""",
                        (sched["id"],))
                    if in_prog:
                        self._log(
                            f"{sched['cname']}/{sched['env_types']} | "
                            f"Already running #{in_prog['id']}, skipping")
                        continue

                    run_id = db.insert_get_id(
                        """INSERT INTO execution_runs
                           (schedule_id, customer_id, env_types,
                            run_type, status, triggered_by, started_at)
                           VALUES (%s,%s,%s,'SCHEDULED','IN_PROGRESS','scheduler',NOW())""",
                        (sched["id"], sched["customer_id"], sched["env_types"]))

                self._log(
                    f"{sched['cname']}/{sched['env_types']} | "
                    f"{sched['schedule_name']} | Firing → Run #{run_id}")

                self._db_log(db, run_id, "INFO",
                             f"Scheduled run fired | schedule='{sched['schedule_name']}' "
                             f"cron='{sched['cron_expression']}' "
                             f"customer='{sched['cname']}' env='{sched['env_types']}'")

                t0 = time.time()
                try:
                    RunLauncher(db, run_id, cfg).launch()
                except Exception as exc:
                    self._log(f"RunLauncher error run #{run_id}: {exc}")
                    db.execute(
                        "UPDATE execution_runs SET status='FAILED',error_summary=%s WHERE id=%s",
                        (str(exc)[:2000], run_id))
                elapsed = int(time.time() - t0)

                final  = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
                status = final["status"] if final else "UNKNOWN"
                self._log(f"{sched['cname']}/{sched['env_types']} | Run #{run_id} {status} in {elapsed}s")
                self._db_log(db, run_id, "INFO",
                             f"Scheduled run {status} in {elapsed}s | schedule='{sched['schedule_name']}'")

                nxt = croniter(sched["cron_expression"], now).get_next(datetime)
                db.execute(
                    "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                    (now, nxt, sched["id"]))
                self._log(f"{sched['cname']}/{sched['env_types']} | Next: {nxt.strftime('%Y-%m-%d %H:%M')}")

            except Exception as exc:
                self._log(f"Error schedule id={sched['id']}: {exc}\n{traceback.format_exc()}")

    def _process_reruns(self, db, cfg):
        pending = db.fetch_all(
            """SELECT rq.*, c.name AS cname FROM rerun_queue rq
               JOIN customers c ON c.id=rq.customer_id
               WHERE rq.status='PENDING' AND rq.scheduled_at<=NOW()
               ORDER BY rq.scheduled_at""")
        if not pending:
            return
        self._log(f"Processing {len(pending)} pending rerun(s)")

        for entry in pending:
            try:
                db.execute(
                    "UPDATE rerun_queue SET status='IN_PROGRESS',started_at=NOW() WHERE id=%s",
                    (entry["id"],))
                run_id = db.insert_get_id(
                    """INSERT INTO execution_runs
                       (customer_id,env_types,run_type,status,triggered_by,
                        rerun_of_run_id,rerun_attempt)
                       VALUES (%s,%s,'RERUN','PENDING','scheduler_rerun',%s,%s)""",
                    (entry["customer_id"], entry["env_types"],
                     entry["original_run_id"], entry["attempt_number"]))

                self._db_log(db, run_id, "INFO",
                             f"Rerun {entry['attempt_number']}/{entry['max_attempts']} fired | "
                             f"original={entry['original_run_id']} customer='{entry['cname']}'")

                t0 = time.time()
                RunLauncher(db, run_id, cfg).launch()
                elapsed = int(time.time() - t0)

                final  = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
                status = final["status"] if final else "UNKNOWN"
                run_ok = status in ("COMPLETED", "PARTIAL")
                self._db_log(db, run_id, "INFO" if run_ok else "WARNING", f"Rerun {status} in {elapsed}s")

                db.execute("UPDATE rerun_queue SET status='COMPLETED',completed_at=NOW() WHERE id=%s", (entry["id"],))
                self._log(f"{entry['cname']}/{entry['env_types']} | Rerun #{run_id} {status} in {elapsed}s")

                if not run_ok and entry["attempt_number"] < entry["max_attempts"]:
                    nxt_sched = datetime.now() + timedelta(hours=cfg.rerun_interval_hours)
                    db.execute(
                        """INSERT INTO rerun_queue
                           (original_run_id,customer_id,env_types,attempt_number,
                            max_attempts,status,scheduled_at)
                           VALUES (%s,%s,%s,%s,%s,'PENDING',%s)""",
                        (entry["original_run_id"], entry["customer_id"], entry["env_types"],
                         entry["attempt_number"]+1, entry["max_attempts"], nxt_sched))
                elif not run_ok:
                    db.execute(
                        "UPDATE rerun_queue SET status='EXHAUSTED' WHERE original_run_id=%s AND status='COMPLETED'",
                        (entry["original_run_id"],))
                    from notifications.email_service import EmailService
                    cust = db.fetch_one("SELECT name FROM customers WHERE id=%s", (entry["customer_id"],))
                    EmailService(db, SilentLogger()).send_rerun_exhausted(
                        run_id=entry["original_run_id"], customer_id=entry["customer_id"],
                        customer_name=cust["name"] if cust else str(entry["customer_id"]),
                        env_types=entry["env_types"], max_attempts=entry["max_attempts"])

            except Exception as exc:
                self._log(f"Rerun entry id={entry['id']} error: {exc}")
                try:
                    db.execute("UPDATE rerun_queue SET last_error=%s WHERE id=%s", (str(exc)[:1000], entry["id"]))
                except Exception:
                    pass

    def _purge_logs(self, db, cfg):
        try:
            n = db.execute(
                "DELETE FROM execution_logs WHERE logged_at < DATE_SUB(NOW(), INTERVAL %s DAY)",
                (cfg.log_retention_days,))
            if n:
                self._log(f"Purged {n} old log rows (>{cfg.log_retention_days}d)")
        except Exception as exc:
            self._log(f"Log purge failed: {exc}")
