"""
core/db_manager.py  (v7 fix D1)
================================
FIX D1: connect() retries=1 by default — fail fast, don't hang the page.
"""
import time
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

import pymysql
import pymysql.cursors

from core.config import DB_CONFIG
from utils.crypto import encrypt_password


class DBManager:
    def __init__(self):
        self._conn: Optional[pymysql.Connection] = None

    # ── connection ─────────────────────────────────────────────────────

    def connect(self, retries: int = 1, delay: int = 2) -> bool:
        """
        FIX D1: default retries=1 (was 5). Fail fast so pages show skeleton
        instead of hanging for 10+ seconds.
        """
        last_exc = None
        for attempt in range(1, retries + 1):
            try:
                self._conn = pymysql.connect(
                    host=DB_CONFIG.host,
                    port=DB_CONFIG.port,
                    user=DB_CONFIG.user,
                    password=DB_CONFIG.password,
                    database=DB_CONFIG.name,
                    charset="utf8mb4",
                    cursorclass=pymysql.cursors.DictCursor,
                    connect_timeout=5,
                    read_timeout=30,
                    write_timeout=30,
                    autocommit=True,
                )
                return True
            except Exception as e:
                last_exc = e
                if attempt < retries:
                    time.sleep(delay)
        raise ConnectionError(
            f"DB connect failed after {retries} attempt(s): {last_exc}")

    def disconnect(self):
        try:
            if self._conn:
                self._conn.close()
        except Exception:
            pass
        finally:
            self._conn = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *_):
        self.disconnect()

    # ── query helpers ──────────────────────────────────────────────────

    def _cursor(self):
        try:
            self._conn.ping(reconnect=True)
        except Exception:
            self.connect()
        return self._conn.cursor()

    def fetch_one(self, sql: str, args=()) -> Optional[Dict]:
        with self._cursor() as cur:
            cur.execute(sql, args)
            return cur.fetchone()

    def fetch_all(self, sql: str, args=()) -> List[Dict]:
        with self._cursor() as cur:
            cur.execute(sql, args)
            return cur.fetchall()

    def execute(self, sql: str, args=()) -> int:
        with self._cursor() as cur:
            cur.execute(sql, args)
            return cur.rowcount

    def insert_get_id(self, sql: str, args=()) -> int:
        with self._cursor() as cur:
            cur.execute(sql, args)
            return cur.lastrowid

    def execute_many(self, sql: str, args_list) -> int:
        with self._cursor() as cur:
            cur.executemany(sql, args_list)
            return cur.rowcount

    # ── password insert helpers ─────────────────────────────────────────

    def insert_environment(self, customer_id, env_type, server_user,
                           server_pwd_plain, is_active=True, notes=""):
        enc = encrypt_password(server_pwd_plain)
        return self.insert_get_id(
            """INSERT INTO environments
               (customer_id,env_type,server_user,server_pwd,is_active,notes)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (customer_id, env_type, server_user, enc, is_active, notes))

    def insert_oracle_db(self, server_id, db_name, db_type, db_user,
                         db_pwd_plain, port=1521, is_active=True, notes=""):
        enc = encrypt_password(db_pwd_plain)
        return self.insert_get_id(
            """INSERT INTO oracle_databases
               (server_id,db_name,db_type,db_user,db_pwd,port,is_active,notes)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (server_id, db_name, db_type, db_user, enc,
             port, is_active, notes))

    def get_config(self, key: str, default=None):
        row = self.fetch_one(
            "SELECT config_value FROM system_config WHERE config_key=%s", (key,))
        return row["config_value"] if row else default

    def get_oracle_query(self, query_name: str) -> Optional[str]:
        row = self.fetch_one(
            "SELECT query_sql FROM oracle_queries WHERE query_name=%s",
            (query_name,))
        return row["query_sql"] if row else None
