"""
checks/server_manager.py
========================
Windows server health checks via WMI.

Checks performed:
  - WMI connection (with configurable retries)
  - Disk space on all drives
  - Windows Update service (wuauserv) status
  - Configurable scheduled task status
  - Configurable Windows service listeners

Retry count and delay come from AppConfig (system_config table).
Passwords are decrypted before use.
"""
import time
from typing import Dict, Optional, Tuple

from core.config import ConfigLoader
from utils.crypto import decrypt_password


class ServerManager:
    """
    Manages a WMI connection to one Windows server and runs health checks.

    Args:
        host:               IP address or hostname
        username:           Windows domain/local username (e.g. DOMAIN\\user)
        encrypted_password: AES-encrypted password string from DB
        logger:             RunLogger instance
    """

    # Mapping of WMI task state integer to string
    TASK_STATE_MAP = {
        1: "Disabled",
        2: "Unknown",
        3: "Ready",
        4: "Running",
        5: "Queued",
    }

    def __init__(
        self,
        host: str,
        username: str,
        encrypted_password: str,
        logger,
    ):
        self._cfg       = ConfigLoader.get()
        self.host       = host
        self.username   = username.replace("\\\\", "\\")
        self.logger     = logger
        self._wmi_conn  = None
        self._tasksch   = None

        # Decrypt the password from DB
        try:
            self.password = decrypt_password(encrypted_password)
        except Exception as exc:
            logger.error(
                f"[server_manager.py | ServerManager.__init__() | host={host}] "
                f"Password decryption failed: {exc}. "
                f"Ensure the password was encrypted with encrypt_password() before storing."
            )
            self.password = encrypted_password  # fallback (will likely fail to connect)

    # ------------------------------------------------------------------ #
    # Connection
    # ------------------------------------------------------------------ #

    def connect(self) -> bool:
        """
        Attempt WMI connection with configured retries.
        Returns True on success, False after all attempts fail.
        """
        import wmi  # Windows-only; imported here so module loads on all platforms

        attempts = self._cfg.conn_retry_attempts
        delay    = self._cfg.conn_retry_delay_sec

        self.logger.info(
            f"[server_manager.py | connect()] "
            f"Connecting to {self.host} as '{self.username}' "
            f"(max {attempts} attempts, {delay}s delay)"
        )

        for attempt in range(1, attempts + 1):
            try:
                self._wmi_conn = wmi.WMI(
                    computer=self.host,
                    user=self.username,
                    password=self.password,
                )
                self.logger.info(
                    f"[server_manager.py | connect()] "
                    f"WMI connected to {self.host} on attempt {attempt}/{attempts}"
                )

                # Task Scheduler namespace (best-effort; continue even if fails)
                try:
                    self._tasksch = wmi.WMI(
                        computer=self.host,
                        user=self.username,
                        password=self.password,
                        namespace=r"root\Microsoft\Windows\TaskScheduler",
                    )
                    self.logger.debug(
                        f"[server_manager.py | connect()] "
                        f"Task Scheduler namespace connected for {self.host}"
                    )
                except Exception as ts_exc:
                    self.logger.warning(
                        f"[server_manager.py | connect()] "
                        f"Task Scheduler namespace failed for {self.host}: {ts_exc}. "
                        f"Task scheduler checks will report 'Connection Failed'."
                    )
                    self._tasksch = None

                return True

            except Exception as exc:
                self.logger.warning(
                    f"[server_manager.py | connect()] "
                    f"Attempt {attempt}/{attempts} failed for {self.host}: {exc}"
                )
                if attempt < attempts:
                    self.logger.debug(
                        f"[server_manager.py | connect()] "
                        f"Retrying in {delay}s..."
                    )
                    time.sleep(delay)

        self.logger.error(
            f"[server_manager.py | connect()] "
            f"All {attempts} connection attempts failed for {self.host}"
        )
        return False

    def disconnect(self):
        self._wmi_conn = None
        self._tasksch  = None
        self.logger.debug(
            f"[server_manager.py | disconnect()] Disconnected from {self.host}"
        )

    # ------------------------------------------------------------------ #
    # Health checks
    # ------------------------------------------------------------------ #

    def get_disk_info(self) -> Dict[str, Dict]:
        """
        Get disk space for all logical drives.

        Returns dict keyed by drive letter:
            {'C:': {'free_gb': 45.2, 'used_gb': 54.8, 'total_gb': 100.0, 'free_pct': 45.2}}
        """
        result = {}
        self.logger.debug(
            f"[server_manager.py | get_disk_info()] "
            f"Querying Win32_LogicalDisk on {self.host}"
        )
        try:
            for disk in self._wmi_conn.Win32_LogicalDisk():
                if disk.Size is None:
                    result[disk.Caption] = {"error": "Drive reported no size"}
                    self.logger.warning(
                        f"[server_manager.py | get_disk_info()] "
                        f"Drive {disk.Caption} on {self.host} has no size info"
                    )
                    continue
                total_gb = float(disk.Size)      / (1024 ** 3)
                free_gb  = float(disk.FreeSpace) / (1024 ** 3)
                used_gb  = total_gb - free_gb
                free_pct = (free_gb / total_gb * 100) if total_gb > 0 else 0
                result[disk.Caption] = {
                    "free_gb":  round(free_gb,  2),
                    "used_gb":  round(used_gb,  2),
                    "total_gb": round(total_gb, 2),
                    "free_pct": round(free_pct, 2),
                }
                self.logger.debug(
                    f"[server_manager.py | get_disk_info()] "
                    f"{disk.Caption}: {free_gb:.2f}GB free / {total_gb:.2f}GB total"
                )
        except Exception as exc:
            self.logger.error(
                f"[server_manager.py | get_disk_info()] "
                f"Failed querying disk info on {self.host}: {exc}"
            )
        return result

    def check_service(self, service_name: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Query a Windows service status.

        Returns:
            (State, StartMode) e.g. ('Running', 'Auto') or (None, None) on error.
        """
        self.logger.debug(
            f"[server_manager.py | check_service()] "
            f"Checking service '{service_name}' on {self.host}"
        )
        try:
            for svc in self._wmi_conn.Win32_Service(Name=service_name):
                self.logger.debug(
                    f"[server_manager.py | check_service()] "
                    f"'{service_name}': State={svc.State}, StartMode={svc.StartMode}"
                )
                return svc.State, svc.StartMode
            # Service not found
            self.logger.warning(
                f"[server_manager.py | check_service()] "
                f"Service '{service_name}' not found on {self.host}"
            )
            return "NotFound", "Unknown"
        except Exception as exc:
            self.logger.error(
                f"[server_manager.py | check_service()] "
                f"Error checking '{service_name}' on {self.host}: {exc}"
            )
            return "Error", "Unknown"

    def check_task_scheduler(self, task_name: str) -> Tuple[str, Optional[str]]:
        """
        Query a Windows Task Scheduler task status.

        Returns:
            (task_name, status_string) e.g. ('MyTask', 'Ready') or ('MyTask', 'Connection Failed')
        """
        if self._tasksch is None:
            self.logger.warning(
                f"[server_manager.py | check_task_scheduler()] "
                f"Task Scheduler namespace unavailable for {self.host}; "
                f"task '{task_name}' status unknown"
            )
            return task_name, "Connection Failed"

        self.logger.debug(
            f"[server_manager.py | check_task_scheduler()] "
            f"Checking task '{task_name}' on {self.host}"
        )
        try:
            tasks = self._tasksch.query(
                f"SELECT * FROM MSFT_ScheduledTask WHERE TaskName = '{task_name}'"
            )
            for task in tasks:
                status = self.TASK_STATE_MAP.get(task.State, f"Unknown({task.State})")
                self.logger.debug(
                    f"[server_manager.py | check_task_scheduler()] "
                    f"Task '{task_name}': State={status}"
                )
                return task_name, status
            # Task not found
            self.logger.warning(
                f"[server_manager.py | check_task_scheduler()] "
                f"Task '{task_name}' not found on {self.host}"
            )
            return task_name, "Not Found"
        except Exception as exc:
            self.logger.error(
                f"[server_manager.py | check_task_scheduler()] "
                f"Error checking task '{task_name}' on {self.host}: {exc}"
            )
            return task_name, "Error"
