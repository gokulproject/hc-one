"""
management/commands/run_hc_tests.py
=====================================
Self-test command: tests all HC subsystems in parallel.
Run with:  python manage.py run_hc_tests

Tests (all run concurrently):
  1. DB connectivity (healthcheck_db MySQL)
  2. Engine bridge import chain
  3. Model import & field verification
  4. URL reverse resolution
  5. Template existence check
  6. Scheduler: croniter expression validation
  7. Crypto: encrypt/decrypt round-trip
  8. Email config presence check
  9. alter_v7.sql column presence (if DB available)
 10. Admin registry check
"""
import sys
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from django.core.management.base import BaseCommand


PASS = "\033[92m✓\033[0m"
FAIL = "\033[91m✗\033[0m"
WARN = "\033[93m⚠\033[0m"


def _result(name, ok, detail=""):
    icon = PASS if ok else FAIL
    line = f"  {icon} {name}"
    if detail:
        line += f"\n      {detail}"
    return ok, line


# ── Individual tests ─────────────────────────────────────────────────────────

def test_db_connection():
    try:
        from django.db import connections
        conn = connections["healthcheck_db"]
        conn.ensure_connection()
        return _result("DB Connection (healthcheck_db MySQL)", True,
                       f"host={conn.settings_dict['HOST']}")
    except Exception as e:
        return _result("DB Connection (healthcheck_db MySQL)", False, str(e))


def test_engine_bridge():
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        required = ["DBManager","ConfigLoader","RunLogger","RunLauncher",
                    "HealthCheckExecutor","IssueTrackerService","ExcelReportGenerator"]
        missing  = [k for k in required if k not in eng]
        if missing:
            return _result("Engine Bridge", False, f"Missing: {missing}")
        return _result("Engine Bridge", True, f"All {len(required)} keys present")
    except Exception as e:
        return _result("Engine Bridge", False, traceback.format_exc(limit=2))


def test_models():
    try:
        from healthcheck import models as m
        required = [
            "Customer","Environment","Server","OracleDatabase","Schedule",
            "ExecutionRun","EnvRunStatus","ExecutionLog","IssueTracker",
            "AlertHistory","RerunQueue","RunStepLog","SchedulerTracker",
            "EscalationConfig","MailConfig","MailRecipient","SystemConfig",
        ]
        missing = [n for n in required if not hasattr(m, n)]
        if missing:
            return _result("Models", False, f"Missing: {missing}")
        # Field checks
        sched = m.Schedule
        for f in ["start_at","last_run_at","next_run_at","cron_expression"]:
            sched._meta.get_field(f)  # raises if missing
        issue = m.IssueTracker
        for f in ["last_escalated_at","escalation_send_count","consecutive_failures"]:
            issue._meta.get_field(f)
        return _result("Models", True, f"All {len(required)} models + required fields OK")
    except Exception as e:
        return _result("Models", False, str(e))


def test_urls():
    try:
        from django.urls import reverse, NoReverseMatch
        names = [
            ("healthcheck:login",     {}),
            ("healthcheck:logout",    {}),
            ("healthcheck:dashboard", {}),
            ("healthcheck:runs",      {}),
            ("healthcheck:run_detail",{"run_id":1}),
            ("healthcheck:run_trigger",{}),
            ("healthcheck:schedules", {}),
            ("healthcheck:schedule_create",{}),
            ("healthcheck:schedule_edit",{"pk":1}),
            ("healthcheck:escalations",{}),
            ("healthcheck:escalation_report",{"issue_id":1}),
            ("healthcheck:scheduler_tracker",{}),
            ("healthcheck:alerts",    {}),
            ("healthcheck:api_run_status",{"run_id":1}),
        ]
        failed = []
        for name, kwargs in names:
            try:
                reverse(name, kwargs=kwargs)
            except NoReverseMatch as e:
                failed.append(f"{name}: {e}")
        if failed:
            return _result("URL Resolution", False, "\n      ".join(failed))
        return _result("URL Resolution", True, f"All {len(names)} URLs resolve OK")
    except Exception as e:
        return _result("URL Resolution", False, str(e))


def test_templates():
    try:
        from django.template.loader import get_template
        templates = [
            "healthcheck/base.html",
            "healthcheck/login.html",
            "healthcheck/dashboard.html",
            "healthcheck/run_list.html",
            "healthcheck/run_detail.html",
            "healthcheck/schedule_list.html",
            "healthcheck/schedule_form.html",
            "healthcheck/escalation_list.html",
            "healthcheck/escalation_report.html",
            "healthcheck/scheduler_tracker.html",
            "healthcheck/alert_history.html",
        ]
        failed = []
        for t in templates:
            try:
                get_template(t)
            except Exception as e:
                failed.append(f"{t}: {e}")
        if failed:
            return _result("Templates", False, "\n      ".join(failed))
        return _result("Templates", True, f"All {len(templates)} templates load OK")
    except Exception as e:
        return _result("Templates", False, str(e))


def test_croniter():
    try:
        from croniter import croniter
        from datetime import datetime
        test_exprs = [
            "0 1 * * 0",
            "*/5 * * * *",
            "0 6 * * 1-5",
            "30 8 1 * *",
        ]
        for expr in test_exprs:
            nxt = croniter(expr, datetime.now()).get_next(datetime)
            assert nxt > datetime.now(), f"{expr} produced past datetime"
        # Invalid expr should raise
        try:
            croniter("invalid expr", datetime.now())
            return _result("Croniter", False, "Invalid expr should have raised")
        except Exception:
            pass
        return _result("Croniter", True, f"All {len(test_exprs)} cron expressions valid")
    except Exception as e:
        return _result("Croniter", False, str(e))


def test_crypto():
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        enc = eng["encrypt_password"]
        dec = eng["decrypt_password"]
        for plain in ["TestPass123!", "P@ssw0rd", "MyS3cr3t", "abc", "x" * 100]:
            encrypted = enc(plain)
            assert isinstance(encrypted, str), "encrypt returned non-string"
            assert encrypted != plain, "encrypt returned plaintext unchanged"
            decrypted = dec(encrypted)
            assert decrypted == plain, f"decrypt mismatch: got {decrypted!r} expected {plain!r}"
        return _result("Crypto (encrypt/decrypt)", True, "5 passwords round-tripped OK")
    except Exception as e:
        return _result("Crypto (encrypt/decrypt)", False, str(e))


def test_email_config():
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        with eng["DBManager"]() as db:
            rows = db.fetch_all("SELECT config_name,smtp_host,from_address FROM mail_config WHERE is_active=1")
            if not rows:
                return _result("Email Config", False,
                               "No active mail_config rows found. Insert SMTP config.", )
            cfg  = rows[0]
            smtp = cfg["smtp_host"] or ""
            if not smtp:
                return _result("Email Config (smtp_host)", False, "smtp_host is empty")
            return _result("Email Config", True,
                           f"config='{cfg['config_name']}' smtp={smtp} from={cfg['from_address']}")
    except Exception as e:
        return _result("Email Config", False, f"DB unavailable or config missing: {e}")


def test_db_columns():
    """Check alter_v7 columns exist."""
    try:
        from healthcheck.engine_bridge import get_engine
        eng = get_engine()
        checks = [
            ("schedules",      "start_at"),
            ("schedules",      "last_run_at"),
            ("schedules",      "next_run_at"),
            ("issue_tracker",  "last_escalated_at"),
            ("issue_tracker",  "escalation_send_count"),
            ("execution_runs", "latest_step"),
        ]
        with eng["DBManager"]() as db:
            failed = []
            for table, col in checks:
                row = db.fetch_one(
                    "SELECT COUNT(*) AS c FROM information_schema.columns "
                    "WHERE table_schema=DATABASE() AND table_name=%s AND column_name=%s",
                    (table, col))
                if not row or row["c"] == 0:
                    failed.append(f"{table}.{col}")
            if failed:
                return _result("DB Columns (alter_v7)", False,
                               f"Missing columns (run alter_v7.sql): {failed}")
            return _result("DB Columns (alter_v7)", True,
                           f"All {len(checks)} required columns present")
    except Exception as e:
        return _result("DB Columns (alter_v7)", False, f"DB unavailable: {e}")


def test_admin_registry():
    try:
        from django.contrib.admin import site
        from healthcheck import models as m
        needed = [m.Schedule, m.ExecutionRun, m.IssueTracker,
                  m.Customer, m.EscalationConfig, m.MailConfig]
        missing = [cls.__name__ for cls in needed if cls not in site._registry]
        if missing:
            return _result("Admin Registry", False, f"Not registered: {missing}")
        return _result("Admin Registry", True,
                       f"{len(site._registry)} models in admin, required models present")
    except Exception as e:
        return _result("Admin Registry", False, str(e))


def test_scheduler_service():
    try:
        from healthcheck import scheduler_service
        import inspect
        src = inspect.getsource(scheduler_service)
        assert "start_scheduler" in src
        assert "HealthCheckScheduler" in src or "scheduling.scheduler" in src
        return _result("Scheduler Service", True, "start_scheduler found")
    except Exception as e:
        return _result("Scheduler Service", False, str(e))


# ── Command ──────────────────────────────────────────────────────────────────

class Command(BaseCommand):
    help = "Run all Health Check self-tests in parallel"

    def handle(self, *args, **options):
        self.stdout.write("\n\033[1m╔══ Health Check v7 — Self Tests ══╗\033[0m\n")

        all_tests = [
            test_db_connection,
            test_engine_bridge,
            test_models,
            test_urls,
            test_templates,
            test_croniter,
            test_crypto,
            test_email_config,
            test_db_columns,
            test_admin_registry,
            test_scheduler_service,
        ]

        t0      = time.time()
        results = {}

        # Run all tests concurrently
        with ThreadPoolExecutor(max_workers=len(all_tests)) as pool:
            futs = {pool.submit(t): t.__name__ for t in all_tests}
            for fut in as_completed(futs):
                name = futs[fut]
                try:
                    ok, line = fut.result()
                except Exception as e:
                    ok, line = False, f"  {FAIL} {name}: UNEXPECTED {e}"
                results[name] = (ok, line)

        # Print in original order
        passed = failed = 0
        for t in all_tests:
            ok, line = results[t.__name__]
            self.stdout.write(line)
            if ok: passed += 1
            else:  failed += 1

        elapsed = time.time() - t0
        self.stdout.write(
            f"\n\033[1m{'='*40}\033[0m\n"
            f"  Passed: \033[92m{passed}\033[0m / {passed+failed}  "
            f"  Failed: \033[91m{failed}\033[0m  "
            f"  Time: {elapsed:.2f}s\n"
        )
        if failed:
            self.stderr.write("\n\033[91mSome tests FAILED — see above.\033[0m\n")
            sys.exit(1)
        else:
            self.stdout.write("\033[92mAll tests PASSED — ready to deploy.\033[0m\n\n")
