"""
healthcheck/tests.py
=====================
Unit tests for Health Check v7.
Run with: python manage.py test healthcheck

Tests use SQLite (default DB) + mock objects for healthcheck_db.
All tests run without a real MySQL connection.
"""
import json
import threading
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch, PropertyMock
from django.test import TestCase, RequestFactory, Client, override_settings
from django.contrib.auth.models import User
from django.urls import reverse, resolve


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _make_mock_run(id=1, status="COMPLETED", customer_name="ACME",
                   env_types="PRD", run_type="SCHEDULED",
                   triggered_by="scheduler", started_at=None,
                   completed_at=None, latest_step="[6/6] Done"):
    run = MagicMock()
    run.id = id
    run.status = status
    run.env_types = env_types
    run.run_type = run_type
    run.triggered_by = triggered_by
    run.started_at = started_at or datetime(2024, 1, 15, 6, 0, 0)
    run.completed_at = completed_at or datetime(2024, 1, 15, 6, 5, 0)
    run.latest_step = latest_step
    run.error_summary = None
    run.customer = MagicMock()
    run.customer.name = customer_name
    run.duration_seconds = MagicMock(return_value=300)
    return run


def _make_mock_issue(id=1, status="ESCALATED", consecutive=5, total=10):
    issue = MagicMock()
    issue.id = id
    issue.status = status
    issue.consecutive_failures = consecutive
    issue.total_failures = total
    issue.env_type = "PRD"
    issue.last_escalated_at = datetime(2024, 1, 14, 6, 0, 0)
    issue.escalation_send_count = 3
    issue.last_error_detail = "Connection timed out"
    issue.first_failed_run_id = 10
    issue.last_failed_run_id = 20
    issue.created_at = datetime(2024, 1, 10)
    issue.customer = MagicMock(); issue.customer.name = "ACME"
    issue.test_catalog = MagicMock(); issue.test_catalog.test_name = "Oracle Connection"
    return issue


def _make_mock_schedule(id=1, name="Weekly PRD", cron="0 1 * * 0",
                         active=True, last_run=None, next_run=None, start_at=None):
    s = MagicMock()
    s.id = id; s.pk = id
    s.schedule_name = name
    s.cron_expression = cron
    s.is_active = active
    s.env_types = "PRD"
    s.last_run_at = last_run
    s.next_run_at = next_run or datetime(2024, 1, 21, 1, 0, 0)
    s.start_at = start_at
    s.customer = MagicMock(); s.customer.name = "ACME"
    return s


# ─────────────────────────────────────────────────────────────────────
# URL Resolution Tests
# ─────────────────────────────────────────────────────────────────────

class URLTests(TestCase):
    """Test all URLs resolve correctly."""

    def test_dashboard_url(self):
        url = reverse("healthcheck:dashboard")
        self.assertEqual(url, "/")

    def test_login_url(self):
        url = reverse("healthcheck:login")
        self.assertEqual(url, "/healthcheck/login/")

    def test_logout_url(self):
        url = reverse("healthcheck:logout")
        self.assertEqual(url, "/healthcheck/logout/")

    def test_runs_url(self):
        url = reverse("healthcheck:runs")
        self.assertEqual(url, "/healthcheck/runs/")

    def test_run_detail_url(self):
        url = reverse("healthcheck:run_detail", args=[42])
        self.assertEqual(url, "/healthcheck/runs/42/")

    def test_run_trigger_url(self):
        url = reverse("healthcheck:run_trigger")
        self.assertEqual(url, "/healthcheck/runs/trigger/")

    def test_schedules_url(self):
        url = reverse("healthcheck:schedules")
        self.assertEqual(url, "/healthcheck/schedules/")

    def test_schedule_create_url(self):
        url = reverse("healthcheck:schedule_create")
        self.assertEqual(url, "/healthcheck/schedules/create/")

    def test_schedule_edit_url(self):
        url = reverse("healthcheck:schedule_edit", args=[5])
        self.assertEqual(url, "/healthcheck/schedules/5/edit/")

    def test_schedule_toggle_url(self):
        url = reverse("healthcheck:schedule_toggle", args=[5])
        self.assertEqual(url, "/healthcheck/schedules/5/toggle/")

    def test_escalations_url(self):
        url = reverse("healthcheck:escalations")
        self.assertEqual(url, "/healthcheck/escalations/")

    def test_escalation_report_url(self):
        url = reverse("healthcheck:escalation_report", args=[7])
        self.assertEqual(url, "/healthcheck/escalations/7/report/")

    def test_scheduler_tracker_url(self):
        url = reverse("healthcheck:scheduler_tracker")
        self.assertEqual(url, "/healthcheck/scheduler-tracker/")

    def test_alerts_url(self):
        url = reverse("healthcheck:alerts")
        self.assertEqual(url, "/healthcheck/alerts/")

    def test_api_run_status_url(self):
        url = reverse("healthcheck:api_run_status", args=[99])
        self.assertEqual(url, "/healthcheck/api/run/99/status/")

    def test_api_dashboard_stats_url(self):
        url = reverse("healthcheck:api_dashboard_stats")
        self.assertEqual(url, "/healthcheck/api/dashboard/stats/")


# ─────────────────────────────────────────────────────────────────────
# Auth Tests
# ─────────────────────────────────────────────────────────────────────

class AuthTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")

    def test_login_page_get(self):
        r = self.client.get(reverse("healthcheck:login"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Sign In")

    def test_login_success(self):
        r = self.client.post(reverse("healthcheck:login"),
                             {"username": "tester", "password": "pass123"})
        self.assertRedirects(r, "/", fetch_redirect_response=False)

    def test_login_fail(self):
        r = self.client.post(reverse("healthcheck:login"),
                             {"username": "tester", "password": "wrong"})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Invalid username or password")

    def test_redirect_when_not_authenticated(self):
        for name, kwargs in [
            ("healthcheck:dashboard", {}),
            ("healthcheck:runs", {}),
            ("healthcheck:schedules", {}),
            ("healthcheck:escalations", {}),
            ("healthcheck:alerts", {}),
        ]:
            with self.subTest(url=name):
                r = self.client.get(reverse(name, kwargs=kwargs))
                self.assertEqual(r.status_code, 302)
                self.assertIn("/healthcheck/login/", r["Location"])

    def test_logout(self):
        self.client.login(username="tester", password="pass123")
        r = self.client.post(reverse("healthcheck:logout"))
        self.assertEqual(r.status_code, 302)
        # After logout, dashboard should redirect to login
        r2 = self.client.get("/")
        self.assertIn("/healthcheck/login/", r2["Location"])


# ─────────────────────────────────────────────────────────────────────
# Dashboard Tests
# ─────────────────────────────────────────────────────────────────────

class DashboardTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    @patch("healthcheck.views.ExecutionRun.objects")
    @patch("healthcheck.views.IssueTracker.objects")
    @patch("healthcheck.views.Schedule.objects")
    @patch("healthcheck.views.Customer.objects")
    def test_dashboard_renders_with_data(self, mock_cust, mock_sched, mock_issue, mock_run):
        # Set up mocks
        mock_run.using.return_value.select_related.return_value.order_by.return_value.__getitem__ = MagicMock(return_value=[_make_mock_run()])
        mock_run.using.return_value.filter.return_value.count.return_value = 0
        mock_issue.using.return_value.filter.return_value.count.return_value = 2
        mock_sched.using.return_value.filter.return_value.count.return_value = 3
        mock_cust.using.return_value.filter.return_value.count.return_value = 5
        mock_cust.using.return_value.filter.return_value.order_by.return_value = []

        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Dashboard")
        self.assertContains(r, "Trigger Manual Run")

    def test_dashboard_db_failure_shows_skeleton(self):
        """When DB is down, dashboard must return 200 with skeleton UI."""
        with patch("healthcheck.views.ExecutionRun.objects") as mock_run, \
             patch("healthcheck.views.IssueTracker.objects") as mock_issue, \
             patch("healthcheck.views.Schedule.objects") as mock_sched, \
             patch("healthcheck.views.Customer.objects") as mock_cust:

            # Simulate DB failure
            mock_run.using.side_effect = Exception("DB connection failed")
            mock_issue.using.side_effect = Exception("DB connection failed")
            mock_sched.using.side_effect = Exception("DB connection failed")
            mock_cust.using.side_effect = Exception("DB connection failed")

            r = self.client.get("/")
            # Must return 200, NOT 500
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "Database unavailable")

    def test_dashboard_stats_api(self):
        """Test AJAX stats endpoint."""
        with patch("healthcheck.views.IssueTracker.objects") as mi, \
             patch("healthcheck.views.Schedule.objects") as ms, \
             patch("healthcheck.views.ExecutionRun.objects") as mr:
            mi.using.return_value.filter.return_value.count.return_value = 3
            ms.using.return_value.filter.return_value.count.return_value = 4
            mr.using.return_value.filter.return_value.count.return_value = 1

            r = self.client.get(reverse("healthcheck:api_dashboard_stats"))
            self.assertEqual(r.status_code, 200)
            data = json.loads(r.content)
            self.assertTrue(data["db_ok"])

    def test_dashboard_stats_api_db_failure(self):
        """AJAX stats returns 503 if DB down."""
        with patch("healthcheck.views.IssueTracker.objects") as mi:
            mi.using.side_effect = Exception("DB down")
            r = self.client.get(reverse("healthcheck:api_dashboard_stats"))
            self.assertEqual(r.status_code, 503)
            data = json.loads(r.content)
            self.assertFalse(data["db_ok"])


# ─────────────────────────────────────────────────────────────────────
# Run Tests
# ─────────────────────────────────────────────────────────────────────

class RunViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    def test_run_list_db_failure_shows_skeleton(self):
        with patch("healthcheck.views.ExecutionRun.objects") as mo:
            mo.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:runs"))
            self.assertEqual(r.status_code, 200)

    def test_run_list_with_filters(self):
        with patch("healthcheck.views.ExecutionRun.objects") as mo, \
             patch("healthcheck.views.Customer.objects") as mc:
            qs = MagicMock()
            qs.filter.return_value = qs
            qs.__iter__ = MagicMock(return_value=iter([]))
            qs.__len__ = MagicMock(return_value=0)
            mo.using.return_value.select_related.return_value.order_by.return_value = qs
            mc.using.return_value.filter.return_value = []

            r = self.client.get(reverse("healthcheck:runs") + "?status=FAILED&run_type=SCHEDULED")
            self.assertEqual(r.status_code, 200)

    def test_run_detail_db_failure(self):
        with patch("healthcheck.views.ExecutionRun.objects") as mo:
            mo.using.return_value.select_related.return_value.get.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:run_detail", args=[999]))
            self.assertEqual(r.status_code, 200)

    def test_run_detail_api_not_found(self):
        with patch("healthcheck.views.ExecutionRun.objects") as mo:
            from healthcheck.models import ExecutionRun
            mo.using.return_value.get.side_effect = ExecutionRun.DoesNotExist()
            r = self.client.get(reverse("healthcheck:api_run_status", args=[9999]))
            self.assertEqual(r.status_code, 404)

    def test_run_detail_api_db_down(self):
        with patch("healthcheck.views.ExecutionRun.objects") as mo:
            mo.using.return_value.get.side_effect = Exception("DB down")
            r = self.client.get(reverse("healthcheck:api_run_status", args=[1]))
            self.assertEqual(r.status_code, 503)

    def test_run_detail_api_success(self):
        run = _make_mock_run(id=5, status="COMPLETED")
        with patch("healthcheck.views.ExecutionRun.objects") as mo:
            mo.using.return_value.get.return_value = run
            r = self.client.get(reverse("healthcheck:api_run_status", args=[5]))
            self.assertEqual(r.status_code, 200)
            data = json.loads(r.content)
            self.assertEqual(data["status"], "COMPLETED")
            self.assertEqual(data["id"], 5)

    def test_run_trigger_no_customer(self):
        r = self.client.post(reverse("healthcheck:run_trigger"), {"env_types": "DEV"})
        self.assertEqual(r.status_code, 302)
        # Should redirect to dashboard with error message
        self.assertRedirects(r, reverse("healthcheck:dashboard"), fetch_redirect_response=False)

    def test_run_trigger_engine_error(self):
        with patch("healthcheck.views.get_engine") as me:
            me.side_effect = Exception("Engine not available")
            r = self.client.post(reverse("healthcheck:run_trigger"),
                                 {"customer_id": "1", "env_types": "DEV"})
            self.assertEqual(r.status_code, 302)


# ─────────────────────────────────────────────────────────────────────
# Schedule Tests
# ─────────────────────────────────────────────────────────────────────

class ScheduleViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    def test_schedule_list_renders(self):
        with patch("healthcheck.views.Schedule.objects") as ms, \
             patch("healthcheck.views.Customer.objects") as mc:
            ms.using.return_value.select_related.return_value.order_by.return_value = []
            mc.using.return_value.filter.return_value = []
            r = self.client.get(reverse("healthcheck:schedules"))
            self.assertEqual(r.status_code, 200)

    def test_schedule_list_db_failure(self):
        with patch("healthcheck.views.Schedule.objects") as ms:
            ms.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:schedules"))
            self.assertEqual(r.status_code, 200)

    def test_schedule_create_get(self):
        with patch("healthcheck.views.Customer.objects") as mc:
            mc.using.return_value.filter.return_value = []
            r = self.client.get(reverse("healthcheck:schedule_create"))
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "Create Schedule")

    def test_schedule_toggle_db_failure(self):
        with patch("healthcheck.views.Schedule.objects") as ms:
            ms.using.return_value.get.side_effect = Exception("DB gone")
            r = self.client.post(reverse("healthcheck:schedule_toggle", args=[1]))
            self.assertEqual(r.status_code, 302)


# ─────────────────────────────────────────────────────────────────────
# Escalation Tests
# ─────────────────────────────────────────────────────────────────────

class EscalationViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    def test_escalation_list_renders(self):
        with patch("healthcheck.views.IssueTracker.objects") as mi, \
             patch("healthcheck.views.Customer.objects") as mc:
            mi.using.return_value.select_related.return_value.order_by.return_value = []
            mc.using.return_value.filter.return_value = []
            r = self.client.get(reverse("healthcheck:escalations"))
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "Escalations")

    def test_escalation_list_db_failure(self):
        with patch("healthcheck.views.IssueTracker.objects") as mi:
            mi.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:escalations"))
            self.assertEqual(r.status_code, 200)

    def test_escalation_report_db_failure(self):
        with patch("healthcheck.views.IssueTracker.objects") as mi, \
             patch("healthcheck.views.AlertHistory.objects") as ma:
            mi.using.return_value.select_related.return_value.get.side_effect = Exception("DB gone")
            ma.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:escalation_report", args=[1]))
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "unavailable")

    def test_escalation_filters(self):
        with patch("healthcheck.views.IssueTracker.objects") as mi, \
             patch("healthcheck.views.Customer.objects") as mc:
            qs = MagicMock()
            qs.select_related.return_value.order_by.return_value = qs
            qs.filter.return_value = qs
            qs.__iter__ = MagicMock(return_value=iter([]))
            qs.__len__ = MagicMock(return_value=0)
            mi.using.return_value = qs
            mc.using.return_value.filter.return_value = []

            r = self.client.get(reverse("healthcheck:escalations") + "?status=ESCALATED&env_type=PRD")
            self.assertEqual(r.status_code, 200)


# ─────────────────────────────────────────────────────────────────────
# Scheduler Tracker Tests (admin-only)
# ─────────────────────────────────────────────────────────────────────

class SchedulerTrackerTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user    = User.objects.create_user("regular", "r@r.com", "pass123")
        self.admin   = User.objects.create_superuser("admin", "a@a.com", "pass123")

    def test_non_admin_redirected(self):
        self.client.login(username="regular", password="pass123")
        r = self.client.get(reverse("healthcheck:scheduler_tracker"))
        self.assertEqual(r.status_code, 302)

    def test_admin_can_access(self):
        self.client.login(username="admin", password="pass123")
        with patch("healthcheck.views.ExecutionRun.objects") as mr, \
             patch("healthcheck.views.Schedule.objects") as ms:
            mr.using.return_value.select_related.return_value.filter.return_value.order_by.return_value.__getitem__ = MagicMock(return_value=[])
            mr.using.return_value.select_related.return_value.filter.return_value = []
            ms.using.return_value.select_related.return_value.filter.return_value.order_by.return_value = []
            r = self.client.get(reverse("healthcheck:scheduler_tracker"))
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "Scheduler Tracker")

    def test_tracker_db_failure(self):
        self.client.login(username="admin", password="pass123")
        with patch("healthcheck.views.ExecutionRun.objects") as mr:
            mr.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:scheduler_tracker"))
            self.assertEqual(r.status_code, 200)


# ─────────────────────────────────────────────────────────────────────
# Alert History Tests
# ─────────────────────────────────────────────────────────────────────

class AlertHistoryTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    def test_alert_history_renders(self):
        with patch("healthcheck.views.AlertHistory.objects") as ma, \
             patch("healthcheck.views.Customer.objects") as mc:
            qs = MagicMock()
            qs.select_related.return_value.order_by.return_value = qs
            qs.filter.return_value = qs
            qs.__iter__ = MagicMock(return_value=iter([]))
            qs.__len__ = MagicMock(return_value=0)
            ma.using.return_value = qs
            mc.using.return_value.filter.return_value = []
            r = self.client.get(reverse("healthcheck:alerts"))
            self.assertEqual(r.status_code, 200)
            self.assertContains(r, "Alert History")

    def test_alert_history_db_failure(self):
        with patch("healthcheck.views.AlertHistory.objects") as ma:
            ma.using.side_effect = Exception("DB gone")
            r = self.client.get(reverse("healthcheck:alerts"))
            self.assertEqual(r.status_code, 200)


# ─────────────────────────────────────────────────────────────────────
# Model Tests
# ─────────────────────────────────────────────────────────────────────

class ModelTests(TestCase):
    """Test model properties without real DB."""

    def test_execution_run_duration(self):
        from healthcheck.models import ExecutionRun
        run = ExecutionRun.__new__(ExecutionRun)
        run.started_at   = datetime(2024, 1, 1, 6, 0, 0)
        run.completed_at = datetime(2024, 1, 1, 6, 5, 30)
        self.assertEqual(run.duration_seconds(), 330)

    def test_execution_run_no_duration(self):
        from healthcheck.models import ExecutionRun
        run = ExecutionRun.__new__(ExecutionRun)
        run.started_at   = datetime(2024, 1, 1, 6, 0, 0)
        run.completed_at = None
        self.assertIsNone(run.duration_seconds())

    def test_schedule_model_fields(self):
        from healthcheck.models import Schedule
        # Just check all expected fields exist (managed=False, no real DB needed)
        for field_name in ["cron_expression", "start_at", "last_run_at",
                           "next_run_at", "is_active", "schedule_name", "env_types"]:
            self.assertTrue(
                Schedule._meta.get_field(field_name) is not None,
                f"Missing field: {field_name}")

    def test_scheduler_tracker_model_exists(self):
        from healthcheck.models import SchedulerTracker
        for field_name in ["schedule", "customer", "run", "status",
                           "scheduled_for", "is_active"]:
            self.assertTrue(
                SchedulerTracker._meta.get_field(field_name) is not None,
                f"Missing field: {field_name}")

    def test_issue_tracker_has_last_escalated_at(self):
        from healthcheck.models import IssueTracker
        self.assertTrue(IssueTracker._meta.get_field("last_escalated_at") is not None)

    def test_issue_tracker_has_escalation_count(self):
        from healthcheck.models import IssueTracker
        self.assertTrue(IssueTracker._meta.get_field("escalation_send_count") is not None)


# ─────────────────────────────────────────────────────────────────────
# Scheduler Logic Tests (no DB)
# ─────────────────────────────────────────────────────────────────────

class SchedulerLogicTests(TestCase):
    """Test scheduler cron logic independently of Django/DB."""

    def test_cron_next_run(self):
        """croniter must produce correct next run from given base."""
        try:
            from croniter import croniter
        except ImportError:
            self.skipTest("croniter not installed")

        base = datetime(2024, 1, 14, 0, 0, 0)  # Sunday midnight
        ci   = croniter("0 1 * * 0", base)      # Every Sunday 1AM
        nxt  = ci.get_next(datetime)
        self.assertEqual(nxt, datetime(2024, 1, 14, 1, 0, 0))  # Same Sunday 1AM

    def test_cron_prev_run(self):
        try:
            from croniter import croniter
        except ImportError:
            self.skipTest("croniter not installed")

        now  = datetime(2024, 1, 14, 10, 0, 0)  # Sunday 10AM
        ci   = croniter("0 1 * * 0", now)
        prev = ci.get_prev(datetime)
        self.assertEqual(prev, datetime(2024, 1, 14, 1, 0, 0))  # Earlier today 1AM

    def test_start_at_future_skips(self):
        """If start_at is in future, should_fire must be False."""
        now      = datetime(2024, 1, 14, 10, 0, 0)
        start_at = datetime(2024, 1, 21, 10, 0, 0)  # 1 week later
        should_fire = now >= start_at
        self.assertFalse(should_fire)

    def test_start_at_past_fires(self):
        now      = datetime(2024, 1, 14, 10, 0, 0)
        start_at = datetime(2024, 1, 7, 10, 0, 0)   # 1 week earlier
        should_fire = now >= start_at
        self.assertTrue(should_fire)

    def test_dual_run_prevention_logic(self):
        """Simulate the dual-run lock: if in_progress exists, skip."""
        in_prog = {"id": 99}   # simulates DB returning a running row
        should_fire = in_prog is None
        self.assertFalse(should_fire)


# ─────────────────────────────────────────────────────────────────────
# Engine Bridge Tests
# ─────────────────────────────────────────────────────────────────────

class EngineBridgeTests(TestCase):
    def test_bridge_sets_up_path(self):
        """engine_bridge must add engine dir to sys.path."""
        import sys
        from healthcheck.engine_bridge import _setup_engine_path
        _setup_engine_path()
        engine_paths = [p for p in sys.path if "engine" in p.lower()]
        self.assertTrue(len(engine_paths) > 0)

    def test_bridge_syncs_db_config(self):
        """_sync_db_config must read from Django settings."""
        import os
        from healthcheck.engine_bridge import _sync_db_config
        # Run without error
        _sync_db_config()
        # HC_DB_NAME should be set (from settings or env)
        # Not asserting value because it depends on env


# ─────────────────────────────────────────────────────────────────────
# Pagination Tests
# ─────────────────────────────────────────────────────────────────────

class PaginationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user("tester", "t@t.com", "pass123")
        self.client.login(username="tester", password="pass123")

    def test_runs_pagination_param(self):
        """Page param must be accepted without error."""
        with patch("healthcheck.views.ExecutionRun.objects") as mo, \
             patch("healthcheck.views.Customer.objects") as mc:
            qs = MagicMock()
            qs.filter.return_value = qs
            qs.__iter__ = MagicMock(return_value=iter([]))
            qs.__len__ = MagicMock(return_value=0)
            mo.using.return_value.select_related.return_value.order_by.return_value = qs
            mc.using.return_value.filter.return_value = []
            r = self.client.get(reverse("healthcheck:runs") + "?page=999")
            # Django paginates to last page on invalid, must not 500
            self.assertEqual(r.status_code, 200)


# ─────────────────────────────────────────────────────────────────────
# Template Tag Tests
# ─────────────────────────────────────────────────────────────────────

class TemplateTagTests(TestCase):
    def test_split_filter(self):
        from healthcheck.templatetags.hc_tags import split
        self.assertEqual(split("a,b,c"), ["a", "b", "c"])
        self.assertEqual(split("a|b", "|"), ["a", "b"])
        self.assertEqual(split("alone"), ["alone"])


# ─────────────────────────────────────────────────────────────────────
# Concurrent Safety Tests
# ─────────────────────────────────────────────────────────────────────

class ConcurrencyTests(TestCase):
    def test_safe_qs_thread_safety(self):
        """_safe_qs must not raise even when called from multiple threads."""
        from healthcheck.views import _safe_qs
        results = []
        errors  = []

        def _worker():
            try:
                r = _safe_qs(lambda: [1, 2, 3], [])
                results.append(r)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_worker) for _ in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()

        self.assertEqual(len(errors), 0)
        self.assertEqual(len(results), 20)

    def test_safe_qs_exception_handling(self):
        from healthcheck.views import _safe_qs
        result = _safe_qs(lambda: 1/0, "fallback")
        self.assertEqual(result, "fallback")
