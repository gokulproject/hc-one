"""
healthcheck/scheduler_service.py
Starts the background scheduler thread exactly once when Django boots.
Thread is daemon so it dies when the main process exits.
"""
import threading
import logging

_log     = logging.getLogger("hc.scheduler")
_started = False
_lock    = threading.Lock()


def start_scheduler():
    global _started
    with _lock:
        if _started:
            return
        _started = True

    try:
        from healthcheck.engine_bridge import get_engine   # sets sys.path
        get_engine()                                       # preload imports

        from scheduling.scheduler import HealthCheckScheduler
        sched = HealthCheckScheduler()
        t = threading.Thread(target=sched.start,
                             name="hc-scheduler",
                             daemon=True)
        t.start()
        _log.info("HC Scheduler started (background daemon thread).")
    except Exception as exc:
        _log.error(f"HC Scheduler failed to start: {exc}")
