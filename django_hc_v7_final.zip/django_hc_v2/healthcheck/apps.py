from django.apps import AppConfig
import os


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v7"

    def ready(self):
        """
        Start background scheduler thread when Django boots.
        Guards:
          - RUN_SCHEDULER env var must be "1" (default: yes)
          - Skips manage.py commands like migrate, shell, collectstatic
          - Skips Django dev-server reloader child process
        """
        import sys

        # Skip for management commands that are not the live server
        is_server = (
            len(sys.argv) == 0
            or (len(sys.argv) > 1 and sys.argv[1] == "runserver")
            or "gunicorn" in sys.argv[0]
            or "uwsgi" in sys.argv[0]
        )
        # RUN_SCHEDULER guard: set to "0" to disable auto-start
        if os.environ.get("RUN_SCHEDULER", "1") != "1":
            return
        if not is_server:
            return
        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
        except Exception as e:
            import logging
            logging.getLogger("hc.scheduler").warning(
                "Scheduler did not start: %s", e)
