from django.urls import path
from healthcheck import views

app_name = "healthcheck"

urlpatterns = [
    # Auth
    path("healthcheck/login/",  views.login_view,  name="login"),
    path("healthcheck/logout/", views.logout_view, name="logout"),
    # Dashboard
    path("", views.dashboard, name="dashboard"),
    # Runs
    path("healthcheck/runs/",              views.run_list,    name="runs"),
    path("healthcheck/runs/<int:run_id>/", views.run_detail,  name="run_detail"),
    path("healthcheck/runs/trigger/",      views.run_trigger, name="run_trigger"),
    # Rerun queue
    path("healthcheck/reruns/", views.rerun_list, name="reruns"),
    # Schedules
    path("healthcheck/schedules/",                 views.schedule_list,   name="schedules"),
    path("healthcheck/schedules/create/",          views.schedule_create, name="schedule_create"),
    path("healthcheck/schedules/<int:pk>/edit/",   views.schedule_edit,   name="schedule_edit"),
    path("healthcheck/schedules/<int:pk>/toggle/", views.schedule_toggle, name="schedule_toggle"),
    # Escalations
    path("healthcheck/escalations/",                       views.escalation_list,   name="escalations"),
    path("healthcheck/escalations/<int:issue_id>/report/", views.escalation_report, name="escalation_report"),
    # Scheduler Tracker (admin)
    path("healthcheck/scheduler-tracker/", views.scheduler_tracker, name="scheduler_tracker"),
    # Alert History
    path("healthcheck/alerts/", views.alert_history, name="alerts"),
    # API
    path("healthcheck/api/run/<int:run_id>/status/", views.api_run_status,     name="api_run_status"),
    path("healthcheck/api/dashboard/stats/",          views.api_dashboard_stats, name="api_dashboard_stats"),
]
