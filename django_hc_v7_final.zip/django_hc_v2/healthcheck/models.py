"""
healthcheck/models.py
All HC models - managed=False (table structure lives in MySQL hc_v5).
"""
from django.db import models

_DB = "healthcheck_db"


class Customer(models.Model):
    name        = models.CharField(max_length=255)
    code        = models.CharField(max_length=50, unique=True)
    tenant_type = models.CharField(max_length=10, default="Single")
    is_active   = models.BooleanField(default=True)
    notes       = models.CharField(max_length=500, null=True, blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "customers"
    def __str__(self): return self.name


class Environment(models.Model):
    customer   = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_type   = models.CharField(max_length=10)
    server_user= models.CharField(max_length=255)
    server_pwd = models.CharField(max_length=700)
    is_active  = models.BooleanField(default=True)
    notes      = models.CharField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "environments"
    def __str__(self): return f"{self.customer} / {self.env_type}"


class Server(models.Model):
    env                  = models.ForeignKey(Environment, on_delete=models.CASCADE)
    server_role          = models.CharField(max_length=10)
    server_name          = models.CharField(max_length=100)
    host                 = models.CharField(max_length=255)
    service_listeners    = models.TextField(null=True, blank=True)
    task_scheduler_names = models.TextField(null=True, blank=True)
    is_active            = models.BooleanField(default=True)
    notes                = models.CharField(max_length=500, null=True, blank=True)
    created_at           = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "servers"
    def __str__(self): return f"{self.server_name} ({self.server_role})"


class OracleDatabase(models.Model):
    server     = models.ForeignKey(Server, on_delete=models.CASCADE)
    db_name    = models.CharField(max_length=255)
    db_type    = models.CharField(max_length=10)
    db_user    = models.CharField(max_length=255)
    db_pwd     = models.CharField(max_length=700)
    port       = models.IntegerField(default=1521)
    is_active  = models.BooleanField(default=True)
    notes      = models.CharField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "oracle_databases"
    def __str__(self): return f"{self.db_name} ({self.db_type})"


class TestCatalog(models.Model):
    test_name     = models.CharField(max_length=500)
    category      = models.CharField(max_length=20)
    server_role   = models.CharField(max_length=10)
    db_type       = models.CharField(max_length=10)
    is_active     = models.BooleanField(default=True)
    display_order = models.IntegerField(default=0)
    class Meta:
        managed  = False
        db_table = "test_catalog"
    def __str__(self): return self.test_name


class TestOverride(models.Model):
    customer     = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_type     = models.CharField(max_length=10, null=True, blank=True)
    test_catalog = models.ForeignKey(TestCatalog, on_delete=models.CASCADE)
    is_active    = models.BooleanField(default=False)
    reason       = models.CharField(max_length=300, null=True, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "test_override"


class MailConfig(models.Model):
    config_name   = models.CharField(max_length=100, default="default")
    smtp_host     = models.CharField(max_length=255)
    smtp_port     = models.IntegerField(default=587)
    use_tls       = models.BooleanField(default=True)
    smtp_user     = models.CharField(max_length=255)
    smtp_password = models.CharField(max_length=500)
    from_address  = models.CharField(max_length=255)
    reply_to      = models.CharField(max_length=255, null=True, blank=True)
    is_active     = models.BooleanField(default=True)
    notes         = models.CharField(max_length=300, null=True, blank=True)
    updated_at    = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "mail_config"
    def __str__(self): return self.config_name


class MailRecipient(models.Model):
    alert_type  = models.CharField(max_length=20)
    customer    = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    to_addresses= models.TextField()
    cc_addresses= models.TextField(null=True, blank=True)
    is_active   = models.BooleanField(default=True)
    notes       = models.CharField(max_length=300, null=True, blank=True)
    updated_at  = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "mail_recipients"


class MailTemplate(models.Model):
    template_key     = models.CharField(max_length=100, unique=True)
    subject_template = models.CharField(max_length=500)
    body_html        = models.TextField()
    is_active        = models.BooleanField(default=True)
    notes            = models.CharField(max_length=300, null=True, blank=True)
    updated_at       = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "mail_templates"
    def __str__(self): return self.template_key


class SystemConfig(models.Model):
    config_key   = models.CharField(max_length=200, unique=True)
    config_value = models.TextField()
    config_group = models.CharField(max_length=50, default="general")
    description  = models.CharField(max_length=500, default="")
    updated_at   = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "system_config"
    def __str__(self): return self.config_key


class EscalationConfig(models.Model):
    customer          = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_type          = models.CharField(max_length=10)
    threshold         = models.IntegerField(default=3)
    interval_hours    = models.IntegerField(default=168)
    max_escalations   = models.IntegerField(default=0)
    is_paused         = models.BooleanField(default=False)
    paused_until      = models.DateTimeField(null=True, blank=True)
    pause_reason      = models.CharField(max_length=300, null=True, blank=True)
    notify_rerun_fail = models.BooleanField(default=True)
    updated_at        = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "escalation_config"
    def __str__(self): return f"{self.customer} / {self.env_type}"


class Schedule(models.Model):
    customer        = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_types       = models.CharField(max_length=50)
    schedule_name   = models.CharField(max_length=200)
    cron_expression = models.CharField(max_length=100)
    is_active       = models.BooleanField(default=True)
    last_run_at     = models.DateTimeField(null=True, blank=True)
    next_run_at     = models.DateTimeField(null=True, blank=True)
    start_at        = models.DateTimeField(null=True, blank=True)
    notes           = models.CharField(max_length=300, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "schedules"
    def __str__(self): return self.schedule_name


class ExecutionRun(models.Model):
    schedule        = models.ForeignKey(Schedule, on_delete=models.SET_NULL, null=True, blank=True)
    customer        = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_types       = models.CharField(max_length=50)
    run_type        = models.CharField(max_length=20, default="SCHEDULED")
    status          = models.CharField(max_length=20, default="PENDING")
    triggered_by    = models.CharField(max_length=100, default="system")
    started_at      = models.DateTimeField(null=True, blank=True)
    completed_at    = models.DateTimeField(null=True, blank=True)
    error_summary   = models.TextField(null=True, blank=True)
    latest_step     = models.CharField(max_length=200, null=True, blank=True)
    rerun_of_run_id = models.IntegerField(null=True, blank=True)
    rerun_attempt   = models.SmallIntegerField(default=0)
    created_at      = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "execution_runs"
    def __str__(self): return f"Run #{self.id} ({self.status})"
    def duration_seconds(self):
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds())
        return None


class EnvRunStatus(models.Model):
    run         = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE)
    customer    = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_type    = models.CharField(max_length=10)
    tenant      = models.CharField(max_length=50, default="")
    status      = models.CharField(max_length=20, default="PENDING")
    error_message = models.TextField(null=True, blank=True)
    started_at  = models.DateTimeField(null=True, blank=True)
    completed_at= models.DateTimeField(null=True, blank=True)
    class Meta:
        managed  = False
        db_table = "env_run_status"


class ExecutionLog(models.Model):
    run         = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE)
    customer    = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    env_type    = models.CharField(max_length=10, null=True, blank=True)
    server_id   = models.IntegerField(null=True, blank=True)
    db_id       = models.IntegerField(null=True, blank=True)
    log_level   = models.CharField(max_length=10, default="INFO")
    py_file     = models.CharField(max_length=200, default="")
    py_module   = models.CharField(max_length=200, default="")
    py_function = models.CharField(max_length=200, default="")
    py_line     = models.IntegerField(null=True, blank=True)
    message     = models.TextField()
    logged_at   = models.DateTimeField()
    class Meta:
        managed  = False
        db_table = "execution_logs"


class ServerCheckResult(models.Model):
    env_status             = models.ForeignKey(EnvRunStatus, on_delete=models.CASCADE)
    server                 = models.ForeignKey(Server, on_delete=models.CASCADE)
    connection_status      = models.CharField(max_length=200, default="")
    connection_ok          = models.BooleanField(default=False)
    win_update_status      = models.TextField(null=True, blank=True)
    win_update_action      = models.BooleanField(null=True, blank=True)
    task_scheduler_detail  = models.TextField(null=True, blank=True)
    task_scheduler_action  = models.BooleanField(null=True, blank=True)
    listeners_detail       = models.TextField(null=True, blank=True)
    listeners_action       = models.BooleanField(null=True, blank=True)
    disk_space_detail      = models.TextField(null=True, blank=True)
    disk_space_action      = models.BooleanField(null=True, blank=True)
    checked_at             = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "server_check_results"


class DBCheckResult(models.Model):
    env_status              = models.ForeignKey(EnvRunStatus, on_delete=models.CASCADE)
    server                  = models.ForeignKey(Server, on_delete=models.CASCADE)
    oracle_db               = models.ForeignKey(OracleDatabase, on_delete=models.CASCADE)
    connection_status       = models.CharField(max_length=200, default="")
    connection_ok           = models.BooleanField(default=False)
    schema_password_detail  = models.TextField(null=True, blank=True)
    schema_password_action  = models.BooleanField(null=True, blank=True)
    tablespace_detail       = models.TextField(null=True, blank=True)
    tablespace_action       = models.BooleanField(null=True, blank=True)
    archive_mode            = models.CharField(max_length=50, null=True, blank=True)
    archive_mode_action     = models.BooleanField(null=True, blank=True)
    archive_log_detail      = models.TextField(null=True, blank=True)
    archive_log_action      = models.BooleanField(null=True, blank=True)
    archive_path_detail     = models.TextField(null=True, blank=True)
    archive_path_action     = models.BooleanField(null=True, blank=True)
    rman_detail             = models.TextField(null=True, blank=True)
    rman_action             = models.BooleanField(null=True, blank=True)
    checked_at              = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "db_check_results"


class TablespaceUsage(models.Model):
    db_check        = models.ForeignKey(DBCheckResult, on_delete=models.CASCADE)
    tablespace_name = models.CharField(max_length=100)
    used_space_kb   = models.BigIntegerField(null=True, blank=True)
    total_space_kb  = models.BigIntegerField(null=True, blank=True)
    used_pct        = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    recorded_at     = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "tablespace_usage"


class RMANBackupDetail(models.Model):
    db_check            = models.ForeignKey(DBCheckResult, on_delete=models.CASCADE)
    start_time          = models.CharField(max_length=100, null=True, blank=True)
    end_time            = models.CharField(max_length=100, null=True, blank=True)
    output_device_type  = models.CharField(max_length=50, null=True, blank=True)
    backup_type         = models.CharField(max_length=50, null=True, blank=True)
    time_taken_display  = models.CharField(max_length=50, null=True, blank=True)
    status              = models.CharField(max_length=100, null=True, blank=True)
    recorded_at         = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "rman_backup_details"


class IssueTracker(models.Model):
    customer              = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_type              = models.CharField(max_length=10)
    server                = models.ForeignKey(Server, on_delete=models.SET_NULL, null=True, blank=True)
    oracle_db             = models.ForeignKey(OracleDatabase, on_delete=models.SET_NULL, null=True, blank=True)
    test_catalog          = models.ForeignKey(TestCatalog, on_delete=models.CASCADE)
    first_failed_run      = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE, related_name="first_issues")
    last_failed_run       = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE, related_name="last_issues")
    consecutive_failures  = models.IntegerField(default=1)
    total_failures        = models.IntegerField(default=1)
    last_error_detail     = models.TextField(null=True, blank=True)
    status                = models.CharField(max_length=20, default="OPEN")
    resolved_run          = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL, null=True, blank=True, related_name="resolved_issues")
    last_escalated_at     = models.DateTimeField(null=True, blank=True)
    escalation_send_count = models.IntegerField(default=0)
    created_at            = models.DateTimeField(auto_now_add=True)
    updated_at            = models.DateTimeField(auto_now=True)
    class Meta:
        managed  = False
        db_table = "issue_tracker"


class AlertHistory(models.Model):
    run                  = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL, null=True, blank=True)
    issue                = models.ForeignKey(IssueTracker, on_delete=models.SET_NULL, null=True, blank=True)
    alert_type           = models.CharField(max_length=20)
    customer             = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name        = models.CharField(max_length=255, null=True, blank=True)
    env_type             = models.CharField(max_length=10, null=True, blank=True)
    run_env_types        = models.CharField(max_length=50, null=True, blank=True)
    subject              = models.CharField(max_length=500)
    recipients_to        = models.TextField()
    recipients_cc        = models.TextField(null=True, blank=True)
    escalation_count     = models.IntegerField(default=0)
    escalation_ordinal   = models.CharField(max_length=50, null=True, blank=True)
    attachment_name      = models.CharField(max_length=500, null=True, blank=True)
    attachment_size_bytes= models.BigIntegerField(null=True, blank=True)
    triggered_by         = models.CharField(max_length=100, null=True, blank=True)
    send_status          = models.CharField(max_length=10, default="SENT")
    error_message        = models.TextField(null=True, blank=True)
    sent_at              = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "alert_history"


class RerunQueue(models.Model):
    original_run   = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE)
    customer       = models.ForeignKey(Customer, on_delete=models.CASCADE)
    env_types      = models.CharField(max_length=50)
    attempt_number = models.SmallIntegerField(default=1)
    max_attempts   = models.SmallIntegerField(default=3)
    status         = models.CharField(max_length=20, default="PENDING")
    scheduled_at   = models.DateTimeField()
    started_at     = models.DateTimeField(null=True, blank=True)
    completed_at   = models.DateTimeField(null=True, blank=True)
    last_error     = models.TextField(null=True, blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "rerun_queue"


class RunStepLog(models.Model):
    run          = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE)
    step_name    = models.CharField(max_length=200)
    step_order   = models.SmallIntegerField(default=0)
    status       = models.CharField(max_length=20, default="RUNNING")
    started_at   = models.DateTimeField()
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_ms  = models.IntegerField(null=True, blank=True)
    notes        = models.TextField(null=True, blank=True)
    class Meta:
        managed  = False
        db_table = "run_step_log"


class SchedulerTracker(models.Model):
    """New table: shows past/future/running scheduled processes for admin UI."""
    schedule      = models.ForeignKey(Schedule, on_delete=models.CASCADE)
    customer      = models.ForeignKey(Customer, on_delete=models.CASCADE)
    run           = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL, null=True, blank=True)
    env_types     = models.CharField(max_length=50)
    status        = models.CharField(max_length=20, default="PENDING")
    scheduled_for = models.DateTimeField()
    started_at    = models.DateTimeField(null=True, blank=True)
    completed_at  = models.DateTimeField(null=True, blank=True)
    error_detail  = models.TextField(null=True, blank=True)
    is_active     = models.BooleanField(default=True)
    created_at    = models.DateTimeField(auto_now_add=True)
    class Meta:
        managed  = False
        db_table = "scheduler_tracker"
    def __str__(self): return f"{self.customer} {self.env_types} @ {self.scheduled_for}"
