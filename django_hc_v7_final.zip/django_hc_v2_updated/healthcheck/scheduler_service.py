"""
healthcheck/scheduler_service.py  (v7 - fixed)
================================================
APScheduler wrapper. Fixes:
  - Dual-run prevention (only starts in main Django process)
  - last_run_at / next_run_at properly updated after each fire
  - start_at support: schedule won't fire before its start_at datetime
  - CoInitialize fix: each job thread calls CoInitialize/CoUninitialize
  - SchedulerTracker table updated on every fire/complete/fail
"""
import logging
import threading
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger("hc.scheduler")

# Import DB error type for graceful handling when DB is down
def _db_error_types():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError:
        pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError:
        pass
    return types

_scheduler = None
_scheduler_lock = threading.Lock()
_active_runs: dict = {}           # run_id -> label
_active_runs_lock = threading.Lock()


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────

def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


def _update_tracker(db, tracker_id: int, **kwargs):
    """Update a scheduler_tracker row safely."""
    try:
        if not kwargs:
            return
        sets = ", ".join(f"{k}=%s" for k in kwargs)
        vals = list(kwargs.values()) + [tracker_id]
        db.execute(f"UPDATE scheduler_tracker SET {sets}, updated_at=NOW() WHERE id=%s", vals)
    except Exception as exc:
        logger.warning(f"scheduler_tracker update failed: {exc}")


def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, scheduled_fire_at, triggered_by="apscheduler") -> int:
    """Insert a scheduler_tracker row and return its id."""
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id, customer_id, env_types, schedule_name, cron_expression,
                status, scheduled_fire_at, triggered_by, is_active, created_at, updated_at)
               VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, scheduled_fire_at, triggered_by))
    except Exception as exc:
        logger.warning(f"scheduler_tracker insert failed: {exc}")
        return 0


# ──────────────────────────────────────────────────────────────
# Job execution (runs in background thread)
# ──────────────────────────────────────────────────────────────

def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """Execute one HC run in a background thread with COM init/cleanup."""
    # CoInitialize for WMI in this thread (Windows only — safe to ignore on Linux)
    _coinit_done = False
    try:
        import pythoncom
        pythoncom.CoInitialize()
        _coinit_done = True
    except ImportError:
        pass  # Not on Windows / pythoncom not installed
    except Exception:
        pass

    eng = _get_engine()
    with _active_runs_lock:
        _active_runs[run_id] = label
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                status="RUNNING",
                                actual_start_at=datetime.now())
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

        final = _get_run_status(run_id)
        logger.info(f"[Scheduler] Run #{run_id} ({label}) → {final}")

        if tracker_id:
            with eng["DBManager"]() as db:
                status = "COMPLETED" if final in ("COMPLETED", "PARTIAL") else "FAILED"
                _update_tracker(db, tracker_id,
                                status=status,
                                completed_at=datetime.now(),
                                error_message=None if status == "COMPLETED" else final)
    except Exception as exc:
        logger.error(f"[Scheduler] Run #{run_id} error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    completed_at=datetime.now(),
                                    error_message=str(exc)[:1000])
            except Exception:
                pass
    finally:
        with _active_runs_lock:
            _active_runs.pop(run_id, None)
        # CoUninitialize — release COM resources for this thread
        if _coinit_done:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _get_run_status(run_id: int) -> str:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            row = db.fetch_one(
                "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return row["status"] if row else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


# ──────────────────────────────────────────────────────────────
# Schedule firing (called by APScheduler in worker thread)
# ──────────────────────────────────────────────────────────────

def _fire_schedule(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str, start_at=None):
    """Called by APScheduler in a worker thread for each scheduled fire."""
    eng = _get_engine()
    label = f"{customer_name}/{env_types}"
    now = datetime.utcnow()

    # Honour start_at: if this schedule shouldn't fire yet, skip
    if start_at and isinstance(start_at, datetime):
        if now < start_at:
            logger.info(
                f"[Scheduler] Skipping '{schedule_name}' — start_at={start_at} is in the future")
            return

    logger.info(f"[Scheduler] Firing '{schedule_name}' | {label}")

    tracker_id = 0
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)

            # Compute next fire for tracker
            from croniter import croniter
            nxt = croniter(cron_expression, now).get_next(datetime)

            # Create tracker entry
            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            # Update last_run_at and next_run_at immediately
            db.execute(
                "UPDATE schedules SET last_run_at=NOW(), next_run_at=%s WHERE id=%s",
                (nxt, schedule_id))

            # Link run to tracker
            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                next_run_at=nxt,
                                last_run_at=now)

        logger.info(f"[Scheduler] Run #{run_id} created for '{schedule_name}'")
        _execute_run(run_id, label, tracker_id)

    except Exception as exc:
        db_err_types = _db_error_types()
        if isinstance(exc, db_err_types):
            logger.error(
                f"[Scheduler] DB unavailable while firing '{schedule_name}'. "
                f"Skipping this fire. Error: {exc}")
            # Do NOT crash the scheduler — it will retry at next cron tick
            return
        logger.error(f"[Scheduler] Error firing '{schedule_name}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────
# Schedule loading / registration
# ──────────────────────────────────────────────────────────────

def _load_schedules() -> list:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


def _register_jobs(scheduler):
    """Remove all sched_* jobs and re-register from DB."""
    from apscheduler.triggers.cron import CronTrigger

    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try:
                job.remove()
            except Exception:
                pass

    schedules = _load_schedules()
    logger.info(f"[Scheduler] Registering {len(schedules)} schedule(s)")

    now = datetime.utcnow()
    for s in schedules:
        job_id = f"sched_{s['id']}"
        try:
            parts = s["cron_expression"].strip().split()
            trigger = CronTrigger(
                minute     =parts[0] if len(parts) > 0 else "*",
                hour       =parts[1] if len(parts) > 1 else "*",
                day        =parts[2] if len(parts) > 2 else "*",
                month      =parts[3] if len(parts) > 3 else "*",
                day_of_week=parts[4] if len(parts) > 4 else "*",
            )

            # If start_at is in the past (or None), allow firing immediately;
            # APScheduler will fire at next cron tick.
            # We pass start_at into the job function to let it decide.
            start_at = s.get("start_at")

            scheduler.add_job(
                _fire_schedule,
                trigger=trigger,
                id=job_id,
                name=s["schedule_name"],
                args=[s["id"], s["customer_id"], s["env_types"],
                      s["schedule_name"], s["customer_name"],
                      s["cron_expression"], start_at],
                max_instances=1,
                coalesce=True,
                replace_existing=True,
                misfire_grace_time=300,
            )
            logger.info(
                f"  ✓ [{s['id']}] {s['schedule_name']} "
                f"cron={s['cron_expression']} start_at={start_at or 'NOW'}")
        except Exception as exc:
            logger.error(f"  ✗ Failed schedule id={s['id']}: {exc}")


# ──────────────────────────────────────────────────────────────
# Lifecycle
# ──────────────────────────────────────────────────────────────

def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("Scheduler already running — skipping duplicate start")
            return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor

            _scheduler = BackgroundScheduler(
                executors={"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults={"coalesce": True, "max_instances": 1},
                timezone="UTC",
            )
            _register_jobs(_scheduler)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules",
                name="Refresh schedules from DB",
                replace_existing=True,
            )
            _scheduler.start()
            logger.info("APScheduler started (ThreadPool x20)")
            return _scheduler
        except ImportError:
            logger.error("APScheduler not installed: pip install apscheduler")
            return None
        except Exception as exc:
            logger.error(f"Failed to start scheduler: {exc}", exc_info=True)
            return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("APScheduler stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """Return full live status dict for dashboard/API."""
    if _scheduler is None or not _scheduler.running:
        return {"running": False, "job_count": 0, "jobs": [],
                "active_runs": [], "active_run_count": 0}

    schedule_jobs = []
    for job in _scheduler.get_jobs():
        if not job.id.startswith("sched_"):
            continue
        nxt = job.next_run_time
        schedule_jobs.append({
            "id":       job.id,
            "name":     job.name,
            "next_run": nxt.strftime("%Y-%m-%d %H:%M:%S UTC") if nxt else "—",
        })

    with _active_runs_lock:
        active = [{"run_id": rid, "label": lbl}
                  for rid, lbl in _active_runs.items()]

    return {
        "running":          True,
        "job_count":        len(schedule_jobs),
        "jobs":             schedule_jobs,
        "active_runs":      active,
        "active_run_count": len(active),
    }


# ──────────────────────────────────────────────────────────────
# Manual run helpers (called from views)
# ──────────────────────────────────────────────────────────────

def run_now_sync(schedule_id: int) -> Optional[int]:
    """Fire a specific schedule immediately. Returns new run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                """SELECT s.*,c.name AS cname FROM schedules s
                   JOIN customers c ON c.id=s.customer_id WHERE s.id=%s""",
                (schedule_id,))
            if not s:
                return None

            from croniter import croniter
            nxt = croniter(s["cron_expression"], datetime.utcnow()).get_next(datetime)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))

            db.execute(
                "UPDATE schedules SET last_run_at=NOW(), next_run_at=%s WHERE id=%s",
                (nxt, schedule_id))

            tracker_id = _create_tracker(
                db, schedule_id, s["customer_id"], s["env_types"],
                s["schedule_name"], s["cron_expression"],
                datetime.utcnow(), triggered_by="admin:run_now")

        label = f"{s['cname']}/{s['env_types']}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label, tracker_id),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync error: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """Fire a manual run for customer+env. Returns new run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        label = f"{cname}/{env_types}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label, 0),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_customer_now error: {exc}", exc_info=True)
        return None
