"""
healthcheck/scheduler_service.py  (v10 – self-scheduling DateTrigger chain)
============================================================================
ROOT CAUSE FIX:
  CronTrigger is clock-anchored. "*/10 * * * *" fires at :00, :10, :20...
  If start_at = 4:08, CronTrigger would fire at 4:10 (2 min late), then 4:20...
  This is WRONG. User wants: 4:08 → 4:18 → 4:28 (exact interval from start_at).

SOLUTION — Self-scheduling DateTrigger chain:
  1. Register ONE DateTrigger at exact start_at (0s delay).
  2. When that fires and run completes → schedule NEXT DateTrigger at (last_run + interval).
  3. Repeat forever. Interval derived from cron expression.

RESULT:
  start_at=4:08, cron=*/10  → 4:08, 4:18, 4:28, 4:38... (exact, no clock drift)
  start_at=4:43, cron=0 */1 → 4:43, 5:43, 6:43, 7:43... (exact, preserves :43)
  start_at=9:17, cron=*/5   → 9:17, 9:22, 9:27, 9:32... (exact 5min from 9:17)

TIMEZONE: All inputs IST → stored UTC → displayed IST 12-hour.
"""
import logging
import threading
from datetime import datetime, timedelta, timezone as _dtz
from typing import Optional

logger = logging.getLogger("hc.scheduler")

_scheduler       = None
_scheduler_lock  = threading.Lock()
_active_runs: dict = {}
_active_runs_lock  = threading.Lock()

IST_OFFSET = timedelta(hours=5, minutes=30)


# ── IST / UTC helpers ──────────────────────────────────────────────────────
def _now_utc() -> datetime:
    return datetime.utcnow()

def _now_ist() -> datetime:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
    except Exception:
        return datetime.utcnow() + IST_OFFSET

def _utc_to_ist(dt: datetime) -> datetime:
    if dt is None: return None
    try:
        from zoneinfo import ZoneInfo
        if hasattr(dt,'tzinfo') and dt.tzinfo:
            return dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
        return dt + IST_OFFSET
    except Exception:
        if hasattr(dt,'tzinfo') and dt.tzinfo:
            return dt.replace(tzinfo=None) + IST_OFFSET
        return dt + IST_OFFSET

def _ist_to_utc(dt: datetime) -> datetime:
    if dt is None: return None
    if hasattr(dt,'tzinfo') and dt.tzinfo:
        return dt.astimezone(_dtz.utc).replace(tzinfo=None)
    return dt - IST_OFFSET          # naive IST → subtract 5:30 → naive UTC

def _strip_tz(dt: datetime) -> Optional[datetime]:
    if dt is None: return None
    return dt.replace(tzinfo=None) if (hasattr(dt,'tzinfo') and dt.tzinfo) else dt

def _fmt(dt: datetime) -> str:
    if dt is None: return "Never"
    return _utc_to_ist(_strip_tz(dt)).strftime("%d-%b-%Y %I:%M %p IST")


# ── Interval extraction from cron expression ──────────────────────────────
def _cron_to_timedelta(cron_expr: str) -> timedelta:
    """
    Convert cron expression to a timedelta interval.
    Uses croniter to find the difference between first two ticks.

    Examples:
      "*/5 * * * *"   →  timedelta(minutes=5)
      "*/10 * * * *"  →  timedelta(minutes=10)
      "0 */1 * * *"   →  timedelta(hours=1)
      "0 0 * * *"     →  timedelta(hours=24)
      "0 0 * * 0"     →  timedelta(days=7)
      "30 9 * * *"    →  timedelta(hours=24)  ← daily at 9:30
    """
    try:
        from croniter import croniter
        base = datetime(2026, 1, 1, 0, 0, 0)
        ci = croniter(cron_expr, base)
        t1 = ci.get_next(datetime)
        t2 = ci.get_next(datetime)
        delta = t2 - t1
        if delta.total_seconds() < 60:
            logger.warning(f"Cron '{cron_expr}' interval < 60s — using 60s minimum")
            return timedelta(minutes=1)
        return delta
    except Exception as exc:
        logger.error(f"Cannot parse cron '{cron_expr}': {exc}. Defaulting to 1 hour.")
        return timedelta(hours=1)


# ── DB error types ─────────────────────────────────────────────────────────
def _db_err():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError: pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError: pass
    return types

def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


# ── Tracker helpers ─────────────────────────────────────────────────────────
def _update_tracker(db, tid: int, **kw):
    if not kw or not tid: return
    try:
        db.execute(
            "UPDATE scheduler_tracker SET " +
            ", ".join(f"{k}=%s" for k in kw) +
            ", updated_at=NOW() WHERE id=%s",
            list(kw.values()) + [tid])
    except Exception as e:
        logger.warning(f"tracker update: {e}")

def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, fire_utc,
                    triggered_by="apscheduler") -> int:
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id,customer_id,env_types,schedule_name,cron_expression,
                status,scheduled_fire_at,triggered_by,is_active,created_at,updated_at)
               VALUES(%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id,customer_id,env_types,schedule_name,
             cron_expr,fire_utc,triggered_by))
    except Exception as e:
        logger.warning(f"tracker insert: {e}"); return 0


# ── Core execution ─────────────────────────────────────────────────────────
def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """Execute a HC run in its own thread. COM-safe."""
    _ci = False
    try: import pythoncom; pythoncom.CoInitialize(); _ci = True
    except Exception: pass

    eng = _get_engine()
    with _active_runs_lock: _active_runs[run_id] = label
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            if tracker_id:
                _update_tracker(db, tracker_id, run_id=run_id,
                                status="RUNNING", actual_start_at=_now_utc())
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()
        final = _get_status(run_id)
        logger.info(f"[Sched] Run #{run_id} ({label}) → {final}")
        if tracker_id:
            with eng["DBManager"]() as db:
                st = "COMPLETED" if final in ("COMPLETED","PARTIAL") else "FAILED"
                _update_tracker(db, tracker_id, status=st,
                                completed_at=_now_utc(),
                                error_message=None if st=="COMPLETED" else final)
    except Exception as exc:
        logger.error(f"[Sched] Run #{run_id} error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    completed_at=_now_utc(), error_message=str(exc)[:1000])
            except Exception: pass
    finally:
        with _active_runs_lock: _active_runs.pop(run_id, None)
        if _ci:
            try: import pythoncom; pythoncom.CoUninitialize()
            except Exception: pass

def _get_status(run_id: int) -> str:
    try:
        with _get_engine()["DBManager"]() as db:
            r = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s",(run_id,))
            return r["status"] if r else "UNKNOWN"
    except Exception: return "UNKNOWN"


# ── RERUN QUEUE PROCESSOR ─────────────────────────────────────────────────
def _process_rerun_queue():
    """
    Poll rerun_queue for PENDING entries whose scheduled_at has passed,
    and execute each one in its own background thread.

    Scheduled as an APScheduler interval job (every 60 s) so reruns fire
    at the correct time without relying on the old blocking poll loop.
    """
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            pending = db.fetch_all(
                """SELECT rq.*, c.name AS cname
                   FROM rerun_queue rq
                   JOIN customers c ON c.id=rq.customer_id
                   WHERE rq.status='PENDING' AND rq.scheduled_at<=NOW()
                   ORDER BY rq.scheduled_at""")
    except Exception as exc:
        logger.error(f"[Rerun] Cannot fetch rerun_queue: {exc}")
        return

    if not pending:
        return

    logger.info(f"[Rerun] Processing {len(pending)} pending rerun(s)")

    for entry in pending:
        _fire_rerun_entry(entry)


def _fire_rerun_entry(entry: dict):
    """Execute one rerun_queue entry in a background thread."""
    entry_id    = entry["id"]
    cname       = entry.get("cname", str(entry["customer_id"]))
    env_types   = entry["env_types"]
    label       = f"{cname}/{env_types}"

    def _do_rerun():
        _ci = False
        try:
            try:
                import pythoncom
                pythoncom.CoInitialize()
                _ci = True
            except Exception:
                pass

            eng = _get_engine()
            run_id = 0
            try:
                with eng["DBManager"]() as db:
                    eng["ConfigLoader"].load(db)

                    # Claim the entry atomically
                    affected = db.execute(
                        "UPDATE rerun_queue SET status='IN_PROGRESS', started_at=NOW() "
                        "WHERE id=%s AND status='PENDING'",
                        (entry_id,))
                    if not affected:
                        # Another thread/process already claimed it
                        return

                    run_id = db.insert_get_id(
                        """INSERT INTO execution_runs
                           (customer_id, env_types, run_type, status,
                            triggered_by, rerun_of_run_id, rerun_attempt)
                           VALUES (%s,%s,'RERUN','PENDING','apscheduler_rerun',%s,%s)""",
                        (entry["customer_id"], env_types,
                         entry["original_run_id"], entry["attempt_number"]))

                logger.info(
                    f"[Rerun] {label} | attempt {entry['attempt_number']}/{entry['max_attempts']}"
                    f" → Run #{run_id}")

                # Execute the run
                _execute_run(run_id, label)

                # Read final status
                final_status = _get_status(run_id)
                run_ok = final_status in ("COMPLETED", "PARTIAL")

                with eng["DBManager"]() as db:
                    if run_ok:
                        db.execute(
                            "UPDATE rerun_queue SET status='COMPLETED', completed_at=NOW() "
                            "WHERE id=%s",
                            (entry_id,))
                        logger.info(
                            f"[Rerun] {label} | Run #{run_id} COMPLETED ✓")
                    elif entry["attempt_number"] < entry["max_attempts"]:
                        db.execute(
                            "UPDATE rerun_queue SET status='FAILED', completed_at=NOW() "
                            "WHERE id=%s",
                            (entry_id,))
                        # Read interval fresh from DB
                        try:
                            iv_row = db.fetch_one(
                                "SELECT config_value FROM system_config "
                                "WHERE config_key='rerun_interval_hours'")
                            interval_hours = float(iv_row["config_value"]) if iv_row else 1.0
                        except Exception:
                            interval_hours = 1.0
                        nxt_sched = _now_utc() + timedelta(hours=interval_hours)
                        db.insert_get_id(
                            """INSERT INTO rerun_queue
                               (original_run_id, customer_id, env_types,
                                attempt_number, max_attempts, status, scheduled_at)
                               VALUES (%s,%s,%s,%s,%s,'PENDING',%s)""",
                            (entry["original_run_id"], entry["customer_id"],
                             env_types,
                             entry["attempt_number"] + 1, entry["max_attempts"],
                             nxt_sched))
                        mins = round(interval_hours * 60, 1)
                        logger.info(
                            f"[Rerun] {label} | Run #{run_id} FAILED — "
                            f"next attempt at "
                            f"{_utc_to_ist(nxt_sched).strftime('%I:%M %p IST')} "
                            f"(+{mins}min)")
                    else:
                        db.execute(
                            "UPDATE rerun_queue SET status='EXHAUSTED', completed_at=NOW() "
                            "WHERE id=%s",
                            (entry_id,))
                        logger.warning(
                            f"[Rerun] {label} | All {entry['max_attempts']} attempts "
                            f"exhausted for original run #{entry['original_run_id']}")
                        # Send exhausted notification
                        try:
                            from healthcheck.engine.notifications.email_service import EmailService
                            from healthcheck.engine.core.logger import SilentLogger
                            with eng["DBManager"]() as db2:
                                EmailService(db2, SilentLogger()).send_rerun_exhausted(
                                    run_id=entry["original_run_id"],
                                    customer_id=entry["customer_id"],
                                    customer_name=cname,
                                    env_types=env_types,
                                    max_attempts=entry["max_attempts"])
                        except Exception as email_exc:
                            logger.warning(f"[Rerun] exhausted email failed: {email_exc}")

            except Exception as exc:
                logger.error(f"[Rerun] entry {entry_id} error: {exc}", exc_info=True)
                try:
                    with eng["DBManager"]() as db:
                        db.execute(
                            "UPDATE rerun_queue SET status='FAILED', "
                            "last_error=%s WHERE id=%s",
                            (str(exc)[:1000], entry_id))
                except Exception:
                    pass

        finally:
            if _ci:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    t = threading.Thread(
        target=_do_rerun,
        daemon=True,
        name=f"hc_rerun_{entry_id}")
    t.start()


# ── THE CHAIN RUNNER ───────────────────────────────────────────────────────
def _chain_run(schedule_id: int, customer_id: int, env_types: str,
               schedule_name: str, customer_name: str,
               cron_expression: str, run_number: int = 1):
    """
    Execute one run, then immediately schedule the NEXT DateTrigger.

    Chain: start_at DateTrigger → _chain_run(1)
              → executes run
              → schedules DateTrigger(last_run + interval) → _chain_run(2)
              → executes run
              → schedules DateTrigger(last_run + interval) → _chain_run(3)
              → ...

    This means the exact minute from start_at is preserved forever.
    """
    global _scheduler

    label   = f"{customer_name}/{env_types}"
    now_utc = _now_utc()
    now_ist = _utc_to_ist(now_utc)

    logger.info(
        f"[Sched] RUN #{run_number} '{schedule_name}' | {label} | "
        f"IST={now_ist.strftime('%d-%b-%Y %I:%M:%S %p')}")

    # ── Compute interval and next run time ────────────────────────────
    interval   = _cron_to_timedelta(cron_expression)
    next_ist   = now_ist + interval          # next = this run + interval (exact offset)
    next_utc   = _ist_to_utc(next_ist)

    eng = _get_engine()
    tracker_id = 0
    run_id     = 0

    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)

            # Check schedule still active
            sch = db.fetch_one(
                "SELECT is_active FROM schedules WHERE id=%s", (schedule_id,))
            if not sch or not sch["is_active"]:
                logger.info(
                    f"[Sched] '{schedule_name}' deactivated — stopping chain.")
                return

            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now_utc)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            # Update last_run (UTC now) and next_run (UTC) in schedules table
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                last_run_at=now_utc,
                                next_run_at=next_utc)

        logger.info(
            f"[Sched] Run #{run_id} created | "
            f"last={now_ist.strftime('%I:%M %p IST')} | "
            f"next={next_ist.strftime('%I:%M %p IST')} "
            f"(+{int(interval.total_seconds()//60)}min)")

        # ── Schedule NEXT run BEFORE executing this one ─────────────────
        # This ensures next run is queued even if this run crashes
        _schedule_next(schedule_id, customer_id, env_types,
                       schedule_name, customer_name,
                       cron_expression, next_utc, run_number + 1)

        # ── Execute this run ─────────────────────────────────────────────
        _execute_run(run_id, label, tracker_id)

    except Exception as exc:
        if isinstance(exc, _db_err()):
            logger.error(
                f"[Sched] DB down for '{schedule_name}'. "
                f"Rescheduling next in {int(interval.total_seconds()//60)}min.")
            # Still schedule next even when DB is down
            _schedule_next(schedule_id, customer_id, env_types,
                           schedule_name, customer_name,
                           cron_expression, next_utc, run_number + 1)
            return
        logger.error(f"[Sched] chain_run error '{schedule_name}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception: pass


def _schedule_next(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str, fire_at_utc: datetime,
                   run_number: int):
    """
    Register a DateTrigger for the next run.
    fire_at_utc is already computed as (last_run_utc + interval).
    """
    global _scheduler
    if _scheduler is None or not _scheduler.running:
        logger.warning(f"[Sched] Scheduler stopped — cannot schedule next for '{schedule_name}'")
        return

    from apscheduler.triggers.date import DateTrigger

    job_id   = f"sched_{schedule_id}"
    fire_ist = _utc_to_ist(fire_at_utc)

    try:
        # Convert UTC → aware datetime for APScheduler
        fire_aware = fire_at_utc.replace(tzinfo=_dtz.utc)
        trigger    = DateTrigger(run_date=fire_aware, timezone="Asia/Kolkata")

        _scheduler.add_job(
            _chain_run,
            trigger=trigger,
            id=job_id,
            name=schedule_name,
            args=[schedule_id, customer_id, env_types,
                  schedule_name, customer_name, cron_expression, run_number],
            max_instances=1,
            replace_existing=True)

        logger.info(
            f"[Sched] Next DateTrigger: run #{run_number} "
            f"'{schedule_name}' @ {fire_ist.strftime('%d-%b-%Y %I:%M %p IST')}")
    except Exception as exc:
        logger.error(f"[Sched] Failed to schedule next for '{schedule_name}': {exc}")


# ── Schedule loading ────────────────────────────────────────────────────────
def _load_schedules() -> list:
    try:
        with _get_engine()["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s
                   JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}"); return []


# ── Register all schedules (one DateTrigger each) ──────────────────────────
def _register_jobs(scheduler):
    """
    Register each active schedule as a single DateTrigger.

    Logic per schedule:
      A) Has start_at AND never run yet → DateTrigger at start_at
      B) Has next_run_at (resumed after restart) → DateTrigger at next_run_at
      C) No start_at, no next_run_at → DateTrigger at now+5s (fire immediately)

    After each run, _chain_run() schedules the NEXT DateTrigger automatically.
    """
    from apscheduler.triggers.date import DateTrigger

    # Remove all existing schedule jobs
    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try: job.remove()
            except Exception: pass

    schedules = _load_schedules()
    logger.info(
        f"[Sched] Registering {len(schedules)} schedule(s) | tz=Asia/Kolkata")

    now_utc = _now_utc()
    now_ist = _utc_to_ist(now_utc)

    for s in schedules:
        sid = s["id"]
        try:
            # Validate cron
            try:
                from croniter import croniter as _ci
                _ci(s["cron_expression"], datetime(2026,1,1))
            except Exception:
                logger.error(f"  ✗ [{sid}] Invalid cron: '{s['cron_expression']}'")
                continue

            start_at_raw  = _strip_tz(s.get("start_at"))
            last_run_raw  = _strip_tz(s.get("last_run_at"))
            next_run_raw  = _strip_tz(s.get("next_run_at"))
            already_ran   = last_run_raw is not None

            # ── Determine when to fire ────────────────────────────────
            if not already_ran and start_at_raw is not None:
                # Case A: First run — fire at exact start_at (or immediately if past)
                if start_at_raw >= now_utc:
                    fire_utc = start_at_raw
                    mode     = "start_at (FIRST)"
                else:
                    fire_utc = now_utc + timedelta(seconds=5)
                    mode     = "start_at PAST → immediate"
                run_num  = 1
            elif next_run_raw is not None and next_run_raw > now_utc:
                # Case B: Resume after restart — fire at scheduled next_run
                fire_utc = next_run_raw
                run_num  = 2
                mode     = "next_run (RESUME)"
            elif already_ran and next_run_raw is not None and next_run_raw <= now_utc:
                # Case C: Missed run — compute NEXT valid fire from start_at anchor + interval
                # instead of firing immediately (avoids unwanted duplicate runs)
                interval = _cron_to_timedelta(s["cron_expression"])
                if start_at_raw is not None:
                    # Anchor to start_at and advance by intervals until > now
                    anchor = start_at_raw
                    candidate = anchor
                    while candidate <= now_utc:
                        candidate = candidate + interval
                    fire_utc = candidate
                else:
                    # No anchor — use next cron tick from now
                    fire_utc = now_utc + interval
                run_num  = 2
                mode     = f"CATCHUP→next valid ({fire_utc})"
            else:
                # Case D: No start_at, no history — fire shortly
                fire_utc = now_utc + timedelta(seconds=5)
                run_num  = 1
                mode     = "immediate (no start_at)"

            fire_ist   = _utc_to_ist(fire_utc)
            fire_aware = fire_utc.replace(tzinfo=_dtz.utc)
            trigger    = DateTrigger(run_date=fire_aware, timezone="Asia/Kolkata")
            interval   = _cron_to_timedelta(s["cron_expression"])

            scheduler.add_job(
                _chain_run,
                trigger=trigger,
                id=f"sched_{sid}",
                name=s["schedule_name"],
                args=[sid, s["customer_id"], s["env_types"],
                      s["schedule_name"], s["customer_name"],
                      s["cron_expression"], run_num],
                max_instances=1,
                replace_existing=True)

            logger.info(
                f"  ✓ [{sid}] {s['schedule_name']} | "
                f"cron={s['cron_expression']} | "
                f"interval={int(interval.total_seconds()//60)}min | "
                f"{mode} | fire={fire_ist.strftime('%d-%b-%Y %I:%M:%S %p IST')}")

        except Exception as exc:
            logger.error(f"  ✗ [{sid}] {s.get('schedule_name','?')}: {exc}")


# ── Lifecycle ──────────────────────────────────────────────────────────────
def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("[Sched] Already running"); return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor
            _scheduler = BackgroundScheduler(
                executors={"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults={"coalesce": True, "max_instances": 1},
                timezone="Asia/Kolkata")
            _register_jobs(_scheduler)
            # Refresh from DB every 5 min (picks up newly added schedules)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules",
                name="DB refresh",
                replace_existing=True)
            # Poll rerun_queue every 60 s — fires automatic reruns exactly on schedule
            _scheduler.add_job(
                _process_rerun_queue,
                "interval", seconds=60,
                id="rerun_queue_poller",
                name="Rerun Queue Poller",
                replace_existing=True,
                max_instances=1,
                coalesce=True)
            _scheduler.start()
            logger.info(
                f"[Sched] Started | tz=Asia/Kolkata | "
                f"IST={_now_ist().strftime('%d-%b-%Y %I:%M:%S %p')}")
            return _scheduler
        except ImportError:
            logger.error("APScheduler not installed"); return None
        except Exception as exc:
            logger.error(f"Start failed: {exc}", exc_info=True); return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("[Sched] Stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler(); return start_scheduler()


def scheduler_status() -> dict:
    now_ist_str = _now_ist().strftime("%d-%b-%Y %I:%M:%S %p")
    if _scheduler is None or not _scheduler.running:
        return {"running": False, "job_count": 0, "jobs": [],
                "active_runs": [], "active_run_count": 0,
                "timezone": "Asia/Kolkata (IST)",
                "server_time_ist": now_ist_str}

    jobs = []
    for job in _scheduler.get_jobs():
        if job.id == "refresh_schedules": continue
        nxt = job.next_run_time
        nxt_str = (_utc_to_ist(nxt).strftime("%d-%b-%Y %I:%M:%S %p IST")
                   if nxt else "—")
        jobs.append({"id": job.id, "name": job.name, "next_run": nxt_str})

    with _active_runs_lock:
        active = [{"run_id": r, "label": l} for r, l in _active_runs.items()]

    return {"running": True, "job_count": len(jobs), "jobs": jobs,
            "active_runs": active, "active_run_count": len(active),
            "timezone": "Asia/Kolkata (IST)", "server_time_ist": now_ist_str}


# ── Manual run helpers ──────────────────────────────────────────────────────
def run_now_sync(schedule_id: int) -> Optional[int]:
    """Admin Run Now — fire immediately, chain continues from now."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
            if not s: return None

            now_utc  = _now_utc()
            now_ist  = _utc_to_ist(now_utc)
            interval = _cron_to_timedelta(s["cron_expression"])
            next_utc = _ist_to_utc(now_ist + interval)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

            tid = _create_tracker(db, schedule_id, s["customer_id"], s["env_types"],
                                   s["schedule_name"], s["cron_expression"],
                                   now_utc, "admin:run_now")

        label = f"{s['cname']}/{s['env_types']}"
        # Schedule next chain run
        _schedule_next(schedule_id, s["customer_id"], s["env_types"],
                       s["schedule_name"], s["cname"],
                       s["cron_expression"], next_utc, 2)

        t = threading.Thread(target=_execute_run, args=(run_id, label, tid),
                             daemon=True, name=f"hc_run_{run_id}")
        t.start()
        logger.info(
            f"[Sched] admin:run_now → Run #{run_id} | "
            f"next={_utc_to_ist(next_utc).strftime('%I:%M %p IST')}")
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync: {exc}", exc_info=True); return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust  = db.fetch_one("SELECT name FROM customers WHERE id=%s",(customer_id,))
            cname = cust["name"] if cust else str(customer_id)
        label = f"{cname}/{env_types}"
        t = threading.Thread(target=_execute_run, args=(run_id, label, 0),
                             daemon=True, name=f"hc_run_{run_id}")
        t.start(); return run_id
    except Exception as exc:
        logger.error(f"run_customer_now: {exc}", exc_info=True); return None


def reschedule_after_start_at_update(schedule_id: int) -> bool:
    """
    Called when admin changes start_at on an existing scheduled row.
    Resets last_run_at / next_run_at in DB so the chain restarts from the new
    start_at, then re-registers the APScheduler DateTrigger for that time.

    FIX v2: Split read and write into separate short connections to minimise
    lock-hold time.  The UPDATE is retried up to 3 times on MySQL 1205
    (Lock wait timeout) / 1213 (Deadlock) so admin saves never surface a
    DB error to the user even when _chain_run is concurrently updating the
    same schedules row.
    """
    import time as _time

    global _scheduler
    if _scheduler is None or not _scheduler.running:
        logger.warning("[Sched] reschedule_after_start_at_update: scheduler not running")
        return False

    eng = _get_engine()

    # ── Phase 1: READ only — short connection, no row-lock held ──────────
    try:
        with eng["DBManager"]() as db:
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
        if not s:
            logger.error(f"[Sched] reschedule: schedule {schedule_id} not found")
            return False
    except Exception as exc:
        logger.error(
            f"[Sched] reschedule_after_start_at_update read error: {exc}",
            exc_info=True)
        return False

    start_at_raw = _strip_tz(s.get("start_at"))
    now_utc_val  = _now_utc()

    if start_at_raw is None:
        fire_utc = now_utc_val + timedelta(seconds=5)
    elif start_at_raw > now_utc_val:
        fire_utc = start_at_raw
    else:
        interval  = _cron_to_timedelta(s["cron_expression"])
        candidate = start_at_raw
        while candidate <= now_utc_val:
            candidate += interval
        fire_utc = candidate

    # ── Phase 2: WRITE — new connection + retry on lock timeout ──────────
    MAX_RETRIES = 3
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with eng["DBManager"]() as db:
                db.execute(
                    "UPDATE schedules SET last_run_at=NULL, next_run_at=%s WHERE id=%s",
                    (fire_utc, schedule_id))
            break   # success — exit retry loop
        except Exception as exc:
            err_str = str(exc)
            is_lock = any(kw in err_str
                          for kw in ("1205", "1213", "Lock wait", "Deadlock"))
            if is_lock and attempt < MAX_RETRIES:
                wait = attempt * 2   # 2 s, then 4 s
                logger.warning(
                    f"[Sched] reschedule UPDATE lock conflict "
                    f"(attempt {attempt}/{MAX_RETRIES}), "
                    f"retrying in {wait}s — {exc}")
                _time.sleep(wait)
                continue
            logger.error(
                f"[Sched] reschedule_after_start_at_update error: {exc}",
                exc_info=True)
            return False

    fire_ist = _utc_to_ist(fire_utc)
    logger.info(
        f"[Sched] reschedule_after_start_at_update [{schedule_id}] "
        f"'{s['schedule_name']}' → fire @ {fire_ist.strftime('%d-%b-%Y %I:%M %p IST')}")

    # ── Phase 3: Re-register APScheduler DateTrigger ──────────────────────
    try:
        from apscheduler.triggers.date import DateTrigger
        fire_aware = fire_utc.replace(tzinfo=_dtz.utc)
        trigger    = DateTrigger(run_date=fire_aware, timezone="Asia/Kolkata")
        _scheduler.add_job(
            _chain_run,
            trigger=trigger,
            id=f"sched_{schedule_id}",
            name=s["schedule_name"],
            args=[schedule_id, s["customer_id"], s["env_types"],
                  s["schedule_name"], s["cname"],
                  s["cron_expression"], 1],
            max_instances=1,
            replace_existing=True)
        return True
    except Exception as exc:
        logger.error(
            f"[Sched] reschedule add_job error: {exc}", exc_info=True)
        return False
