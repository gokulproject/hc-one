"""
healthcheck/admin.py
Full Django admin for all HC tables.
Bootstrap-style admin via django-jazzmin or vanilla admin with custom CSS.
"""
from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse
from healthcheck.models import (
    Customer, Environment, Server, OracleDatabase,
    TestCatalog, TestOverride, MailConfig, MailRecipient,
    MailTemplate, SystemConfig, EscalationConfig, Schedule,
    ExecutionRun, EnvRunStatus, ExecutionLog, ServerCheckResult,
    DBCheckResult, TablespaceUsage, RMANBackupDetail,
    IssueTracker, AlertHistory, RerunQueue, RunStepLog,
)

_DB = "healthcheck_db"


class HCAdmin(admin.ModelAdmin):
    """Base admin that reads/writes to healthcheck_db."""

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)

    def save_model(self, request, obj, form, change):
        obj.save(using=_DB)

    def delete_model(self, request, obj):
        obj.delete(using=_DB)

    def delete_queryset(self, request, queryset):
        queryset.using(_DB).delete()


# ──────────────────────────────────────────────────────────────
# Customer & related
# ──────────────────────────────────────────────────────────────

class EnvironmentInline(admin.TabularInline):
    model   = Environment
    extra   = 1
    fields  = ["env_type", "server_user", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


class ServerInline(admin.TabularInline):
    model   = Server
    extra   = 1
    fields  = ["server_role", "server_name", "host", "is_active"]
    show_change_link = True

    def get_queryset(self, request):
        return super().get_queryset(request).using(_DB)


@admin.register(Customer)
class CustomerAdmin(HCAdmin):
    list_display    = ["name", "code", "tenant_type", "is_active", "created_at"]
    list_filter     = ["is_active", "tenant_type"]
    search_fields   = ["name", "code"]
    inlines         = [EnvironmentInline]
    list_editable   = ["is_active"]


@admin.register(Environment)
class EnvironmentAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "server_user", "is_active"]
    list_filter   = ["env_type", "is_active"]
    search_fields = ["customer__name", "server_user"]
    inlines       = [ServerInline]

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields["server_pwd"].help_text = (
            "AES-256 encrypted. Use 'python manage.py encrypt_password' "
            "to encrypt a plain password.")
        return form


@admin.register(Server)
class ServerAdmin(HCAdmin):
    list_display   = ["server_name", "server_role", "host", "is_active"]
    list_filter    = ["server_role", "is_active"]
    search_fields  = ["server_name", "host"]


@admin.register(OracleDatabase)
class OracleDatabaseAdmin(HCAdmin):
    list_display   = ["db_name", "db_type", "server", "port", "is_active"]
    list_filter    = ["db_type", "is_active"]
    search_fields  = ["db_name"]


# ──────────────────────────────────────────────────────────────
# Test catalog
# ──────────────────────────────────────────────────────────────

@admin.register(TestCatalog)
class TestCatalogAdmin(HCAdmin):
    list_display  = ["id", "test_name", "category", "server_role", "db_type", "is_active"]
    list_filter   = ["category", "server_role", "db_type", "is_active"]
    list_editable = ["is_active"]
    ordering      = ["display_order"]


@admin.register(TestOverride)
class TestOverrideAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "test_catalog", "is_active", "reason"]
    list_filter   = ["is_active", "env_type"]
    search_fields = ["customer__name", "test_catalog__test_name"]


# ──────────────────────────────────────────────────────────────
# Mail config
# ──────────────────────────────────────────────────────────────

@admin.register(MailConfig)
class MailConfigAdmin(HCAdmin):
    list_display  = ["config_name", "smtp_host", "smtp_port", "from_address", "is_active"]
    list_editable = ["is_active"]


@admin.register(MailRecipient)
class MailRecipientAdmin(HCAdmin):
    list_display  = ["alert_type", "customer", "to_addresses_short", "is_active"]
    list_filter   = ["alert_type", "is_active"]

    def to_addresses_short(self, obj):
        return obj.to_addresses[:60]
    to_addresses_short.short_description = "TO Addresses"


@admin.register(MailTemplate)
class MailTemplateAdmin(HCAdmin):
    list_display  = ["template_key", "subject_template", "is_active"]
    list_editable = ["is_active"]


# ──────────────────────────────────────────────────────────────
# System config
# ──────────────────────────────────────────────────────────────

@admin.register(SystemConfig)
class SystemConfigAdmin(HCAdmin):
    list_display  = ["config_key", "config_value_short", "config_group"]
    list_filter   = ["config_group"]
    search_fields = ["config_key"]

    def config_value_short(self, obj):
        return obj.config_value[:60]
    config_value_short.short_description = "Value"


# ──────────────────────────────────────────────────────────────
# Escalation
# ──────────────────────────────────────────────────────────────

@admin.register(EscalationConfig)
class EscalationConfigAdmin(HCAdmin):
    list_display  = ["customer", "env_type", "threshold", "interval_hours",
                     "is_paused", "paused_until"]
    list_filter   = ["is_paused", "env_type"]
    list_editable = ["is_paused"]


# ──────────────────────────────────────────────────────────────
# Schedules
# ──────────────────────────────────────────────────────────────

# ── IST-aware widget for start_at ────────────────────────────────────────
class ISTDateTimeWidget(forms.DateTimeInput):
    """Shows IST hint in placeholder. Admin enters IST → backend converts to UTC."""
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('format', '%Y-%m-%d %H:%M:%S')
        kwargs.setdefault('attrs', {})
        kwargs['attrs'].update({
            'placeholder': 'YYYY-MM-DD HH:MM:SS  (IST — e.g. 2026-05-01 16:43:00)',
            'style': 'width:280px',
            'title': 'Enter time in IST (Asia/Kolkata). System will convert to UTC.',
        })
        super().__init__(*args, **kwargs)


class ScheduleAdminForm(forms.ModelForm):
    start_at = forms.DateTimeField(
        required=False,
        widget=ISTDateTimeWidget(),
        help_text=(
            "<strong style='color:#1565C0'>Enter time in IST (Asia/Kolkata, 12h or 24h).</strong><br>"
            "Examples: <code>2026-05-01 16:43:00</code> = 4:43 PM IST&nbsp;|&nbsp;"
            "<code>2026-05-01 04:08:00</code> = 4:08 AM IST.<br>"
            "Leave blank → fires at very next cron tick after scheduler start."
        ),
        label="Start At (IST)",
    )

    class Meta:
        model  = Schedule
        fields = '__all__'

    def clean_start_at(self):
        """Accept IST input → convert to UTC for DB storage."""
        dt = self.cleaned_data.get('start_at')
        if dt is None:
            return None
        from datetime import timedelta, timezone as _tz
        IST_OFFSET = timedelta(hours=5, minutes=30)
        # Django may have already made it UTC-aware if USE_TZ=True
        if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
            return dt  # Already TZ-aware, Django stores as UTC
        # Naive input → treat as IST → subtract 5:30 → UTC naive
        # Then Django (USE_TZ=True) will treat it as UTC
        return dt - IST_OFFSET


@admin.register(Schedule)
class ScheduleAdmin(HCAdmin):
    form = ScheduleAdminForm
    list_display  = ["schedule_name", "customer", "env_types",
                     "cron_expression", "start_at_ist", "is_active",
                     "last_run_ist", "next_run_ist"]
    list_filter   = ["is_active"]
    list_editable = ["is_active"]
    search_fields = ["schedule_name", "customer__name"]
    readonly_fields = ["last_run_ist", "next_run_ist", "start_at_ist",
                       "created_at", "updated_at"]

    def _ist(self, dt):
        if dt is None: return "—"
        try:
            from zoneinfo import ZoneInfo
            from datetime import timedelta
            if hasattr(dt,'tzinfo') and dt.tzinfo:
                v = dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
            else:
                v = dt + timedelta(hours=5, minutes=30)
            return v.strftime("%d-%b-%Y %I:%M %p IST")
        except Exception:
            return str(dt)

    def start_at_ist(self, obj):
        return self._ist(obj.start_at)
    start_at_ist.short_description = "Start At (IST)"

    def last_run_ist(self, obj):
        return self._ist(obj.last_run_at)
    last_run_ist.short_description = "Last Run (IST)"

    def next_run_ist(self, obj):
        return self._ist(obj.next_run_at)
    next_run_ist.short_description = "Next Run (IST)"

    def save_model(self, request, obj, form, change):
        """
        When start_at changes on an existing schedule, reset the chain so
        the scheduler fires from the new start_at instead of the old one.
        """
        old_start_at = None
        if change and obj.pk:
            try:
                old_start_at = Schedule.objects.using("healthcheck_db").get(pk=obj.pk).start_at
            except Exception:
                pass

        super().save_model(request, obj, form, change)

        # If start_at was changed (or cron changed on existing schedule), reschedule
        start_at_changed = change and (old_start_at != obj.start_at)
        cron_changed = change and ("cron_expression" in form.changed_data)

        if start_at_changed or cron_changed:
            try:
                from healthcheck.scheduler_service import reschedule_after_start_at_update
                ok = reschedule_after_start_at_update(obj.pk)
                if ok:
                    self.message_user(
                        request,
                        f"Schedule '{obj.schedule_name}': timing updated and rescheduled. "
                        f"Next run recalculated from new start_at.",
                        level="success")
                else:
                    self.message_user(
                        request,
                        f"Saved, but scheduler not running — start/restart it for new timing to take effect.",
                        level="warning")
            except Exception as exc:
                import logging
                logging.getLogger("hc.admin").error(f"reschedule after save_model: {exc}")

    def get_fieldsets(self, request, obj=None):
        return [
            ("Schedule Info", {
                "fields": ["schedule_name", "customer", "env_types"],
            }),
            ("Timing", {
                "fields": ["cron_expression", "start_at"],
                "description": (
                    "<strong>Start At</strong>: Enter time in IST (Asia/Kolkata). "
                    "This is when the FIRST execution fires. Creation time is ignored. "
                    "Example cron: <code>43 */1 * * *</code> = every hour at :43. "
                    "If Start At = 4:43 PM, first fire = 4:43 PM, then 5:43, 6:43...<br>"
                    "<strong>Changing Start At on an existing schedule</strong> will "
                    "automatically reschedule the next run from the new time."
                ),
            }),
            ("Status", {
                "fields": ["is_active", "notes"],
            }),
            ("Timestamps (IST display)", {
                "fields": ["start_at_ist", "last_run_ist", "next_run_ist"],
                "classes": ["collapse"],
            }),
        ]


# ──────────────────────────────────────────────────────────────
# Execution runs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionRun)
class ExecutionRunAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "run_type", "status_badge",
                     "triggered_by", "started_at", "duration_display", "latest_step"]
    list_filter   = ["status", "run_type"]
    search_fields = ["customer__name"]
    readonly_fields = ["started_at", "completed_at", "error_summary", "latest_step"]
    ordering      = ["-id"]

    def status_badge(self, obj):
        colors = {
            "COMPLETED": "success", "FAILED": "danger",
            "PARTIAL": "warning", "IN_PROGRESS": "info",
            "PENDING": "secondary",
        }
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"

    def duration_display(self, obj):
        s = obj.duration_seconds()
        return f"{s}s" if s is not None else "—"
    duration_display.short_description = "Duration"


# ──────────────────────────────────────────────────────────────
# Logs
# ──────────────────────────────────────────────────────────────

@admin.register(ExecutionLog)
class ExecutionLogAdmin(HCAdmin):
    list_display   = ["logged_at", "run_id", "log_level", "py_file", "py_function", "message_short"]
    list_filter    = ["log_level"]
    search_fields  = ["message", "py_file", "py_function"]
    readonly_fields = ["run", "logged_at", "py_file", "py_module",
                       "py_function", "py_line", "message"]

    def message_short(self, obj):
        return obj.message[:80]
    message_short.short_description = "Message"


# ──────────────────────────────────────────────────────────────
# Check results
# ──────────────────────────────────────────────────────────────

@admin.register(ServerCheckResult)
class ServerCheckResultAdmin(HCAdmin):
    list_display   = ["id", "server", "connection_ok", "disk_space_action",
                      "win_update_action", "checked_at"]
    list_filter    = ["connection_ok"]
    readonly_fields = [f.name for f in ServerCheckResult._meta.fields]


@admin.register(DBCheckResult)
class DBCheckResultAdmin(HCAdmin):
    list_display   = ["id", "oracle_db", "connection_ok", "tablespace_action",
                      "rman_action", "checked_at"]
    list_filter    = ["connection_ok", "rman_action"]
    readonly_fields = [f.name for f in DBCheckResult._meta.fields]


@admin.register(TablespaceUsage)
class TablespaceUsageAdmin(HCAdmin):
    list_display  = ["tablespace_name", "used_pct", "used_space_kb", "total_space_kb"]
    list_filter   = []
    search_fields = ["tablespace_name"]


@admin.register(RMANBackupDetail)
class RMANBackupDetailAdmin(HCAdmin):
    list_display  = ["start_time", "end_time", "backup_type", "status"]


# ──────────────────────────────────────────────────────────────
# Issue tracker
# ──────────────────────────────────────────────────────────────

@admin.register(IssueTracker)
class IssueTrackerAdmin(HCAdmin):
    list_display   = ["customer", "env_type", "test_catalog", "consecutive_failures",
                      "total_failures", "status_badge", "last_escalation_at"]
    list_filter    = ["status", "env_type"]
    search_fields  = ["customer__name", "test_catalog__test_name"]

    def status_badge(self, obj):
        colors = {"OPEN": "warning", "ESCALATED": "danger", "RESOLVED": "success"}
        c = colors.get(obj.status, "secondary")
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.status)
    status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Alert history
# ──────────────────────────────────────────────────────────────

@admin.register(AlertHistory)
class AlertHistoryAdmin(HCAdmin):
    list_display   = ["sent_at", "alert_type", "customer_name", "env_type",
                      "subject_short", "send_status_badge"]
    list_filter    = ["alert_type", "send_status"]
    search_fields  = ["subject", "customer_name"]
    readonly_fields = [f.name for f in AlertHistory._meta.fields]

    def subject_short(self, obj):
        return obj.subject[:60]
    subject_short.short_description = "Subject"

    def send_status_badge(self, obj):
        c = "success" if obj.send_status == "SENT" else "danger"
        return format_html(
            '<span class="badge bg-{}">{}</span>', c, obj.send_status)
    send_status_badge.short_description = "Status"


# ──────────────────────────────────────────────────────────────
# Rerun queue
# ──────────────────────────────────────────────────────────────

@admin.register(RerunQueue)
class RerunQueueAdmin(HCAdmin):
    list_display  = ["id", "customer", "env_types", "attempt_number",
                     "max_attempts", "status", "scheduled_at"]
    list_filter   = ["status"]


# ──────────────────────────────────────────────────────────────
# Run step log
# ──────────────────────────────────────────────────────────────

@admin.register(RunStepLog)
class RunStepLogAdmin(HCAdmin):
    list_display   = ["run_id", "step_order", "step_name", "status",
                      "started_at", "completed_at", "duration_ms"]
    list_filter    = ["status"]
    readonly_fields = [f.name for f in RunStepLog._meta.fields]


@admin.register(EnvRunStatus)
class EnvRunStatusAdmin(HCAdmin):
    list_display   = ["run_id", "customer", "env_type", "status",
                      "started_at", "completed_at"]
    list_filter    = ["status", "env_type"]
    readonly_fields = [f.name for f in EnvRunStatus._meta.fields]


# ── SchedulerTracker ──
from healthcheck.models import SchedulerTracker

@admin.register(SchedulerTracker)
class SchedulerTrackerAdmin(admin.ModelAdmin):
    list_display  = ("id", "customer", "env_types", "schedule_name", "status",
                     "scheduled_fire_at", "last_run_at", "next_run_at",
                     "run_id", "is_active", "triggered_by")
    list_filter   = ("status", "is_active", "customer")
    search_fields = ("schedule_name", "customer__name", "env_types")
    readonly_fields = ("created_at", "updated_at")
    ordering      = ("-scheduled_fire_at",)
    using         = "healthcheck_db"

    def get_queryset(self, request):
        return super().get_queryset(request).using("healthcheck_db")

    def save_model(self, request, obj, form, change):
        obj.save(using="healthcheck_db")
