"""
healthcheck/models.py
All HC tables from hc_v5 as Django models (managed=False).
Django reads/writes these through healthcheck_db connection.
We set _hc_db=True so HCRouter routes them correctly.
"""
from django.db import models


class HCModel(models.Model):
    """Base class: routes to healthcheck_db, never migrated."""
    _hc_db = True

    class Meta:
        abstract = True
        app_label = "healthcheck"


# ──────────────────────────────────────────────────────────────
class Customer(HCModel):
    name         = models.CharField(max_length=255)
    code         = models.CharField(max_length=50, unique=True)
    tenant_type  = models.CharField(max_length=10, default="Single")
    is_active    = models.BooleanField(default=True)
    notes        = models.CharField(max_length=500, null=True, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table  = "customers"
        managed   = False
        ordering  = ["name"]

    def __str__(self): return f"{self.name} ({self.code})"


class Environment(HCModel):
    customer     = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_type     = models.CharField(max_length=5)
    server_user  = models.CharField(max_length=255)
    server_pwd   = models.CharField(max_length=700)
    is_active    = models.BooleanField(default=True)
    notes        = models.CharField(max_length=500, null=True, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "environments"
        managed  = False

    def __str__(self): return f"{self.customer.name} - {self.env_type}"


class Server(HCModel):
    env                   = models.ForeignKey(Environment, on_delete=models.CASCADE, db_column="env_id")
    server_role           = models.CharField(max_length=10)
    server_name           = models.CharField(max_length=100)
    host                  = models.CharField(max_length=255)
    service_listeners     = models.TextField(null=True, blank=True)
    task_scheduler_names  = models.TextField(null=True, blank=True)
    is_active             = models.BooleanField(default=True)
    notes                 = models.CharField(max_length=500, null=True, blank=True)
    created_at            = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "servers"
        managed  = False

    def __str__(self): return f"{self.server_name} ({self.host})"


class OracleDatabase(HCModel):
    server     = models.ForeignKey(Server, on_delete=models.CASCADE, db_column="server_id")
    db_name    = models.CharField(max_length=255)
    db_type    = models.CharField(max_length=10)
    db_user    = models.CharField(max_length=255)
    db_pwd     = models.CharField(max_length=700)
    port       = models.IntegerField(default=1521)
    is_active  = models.BooleanField(default=True)
    notes      = models.CharField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "oracle_databases"
        managed  = False

    def __str__(self): return f"{self.db_name} ({self.db_type})"


class TestCatalog(HCModel):
    id            = models.IntegerField(primary_key=True)
    test_name     = models.CharField(max_length=500)
    category      = models.CharField(max_length=20)
    server_role   = models.CharField(max_length=10)
    db_type       = models.CharField(max_length=10)
    is_active     = models.BooleanField(default=True)
    display_order = models.IntegerField(default=0)

    class Meta(HCModel.Meta):
        db_table = "test_catalog"
        managed  = False
        ordering = ["display_order"]

    def __str__(self): return self.test_name


class TestOverride(HCModel):
    customer      = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_type      = models.CharField(max_length=5, null=True, blank=True)
    test_catalog  = models.ForeignKey(TestCatalog, on_delete=models.CASCADE, db_column="test_catalog_id")
    is_active     = models.BooleanField(default=False)
    reason        = models.CharField(max_length=300, null=True, blank=True)
    created_at    = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table  = "test_override"
        managed   = False
        unique_together = [("customer", "env_type", "test_catalog")]

    def __str__(self):
        state = "ON" if self.is_active else "OFF"
        return f"{self.customer.name}/{self.env_type or 'ALL'} - {self.test_catalog.test_name} [{state}]"


class MailConfig(HCModel):
    config_name   = models.CharField(max_length=100, default="default")
    smtp_host     = models.CharField(max_length=255)
    smtp_port     = models.IntegerField(default=587)
    use_tls       = models.BooleanField(default=True)
    smtp_user     = models.CharField(max_length=255)
    smtp_password = models.CharField(max_length=500)
    from_address  = models.CharField(max_length=255)
    reply_to      = models.CharField(max_length=255, null=True, blank=True)
    is_active     = models.BooleanField(default=True)
    notes         = models.CharField(max_length=300, null=True, blank=True)
    updated_at    = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "mail_config"
        managed  = False

    def __str__(self): return f"{self.config_name} ({self.smtp_host})"


class MailRecipient(HCModel):
    alert_type   = models.CharField(max_length=20)
    customer     = models.ForeignKey(Customer, on_delete=models.CASCADE,
                                     db_column="customer_id", null=True, blank=True)
    to_addresses = models.TextField()
    cc_addresses = models.TextField(null=True, blank=True)
    is_active    = models.BooleanField(default=True)
    notes        = models.CharField(max_length=300, null=True, blank=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "mail_recipients"
        managed  = False

    def __str__(self):
        cname = self.customer.name if self.customer_id else "Global"
        return f"{self.alert_type} | {cname}"


class MailTemplate(HCModel):
    template_key     = models.CharField(max_length=100, unique=True)
    subject_template = models.CharField(max_length=500)
    body_html        = models.TextField()
    is_active        = models.BooleanField(default=True)
    notes            = models.CharField(max_length=300, null=True, blank=True)
    updated_at       = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "mail_templates"
        managed  = False

    def __str__(self): return self.template_key


class SystemConfig(HCModel):
    config_key   = models.CharField(max_length=200, unique=True)
    config_value = models.TextField()
    config_group = models.CharField(max_length=50, default="general")
    description  = models.CharField(max_length=500, default="")
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "system_config"
        managed  = False
        ordering = ["config_group", "config_key"]

    def __str__(self): return f"{self.config_key} = {self.config_value[:40]}"


class EscalationConfig(HCModel):
    customer          = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_type          = models.CharField(max_length=5)
    threshold         = models.IntegerField(default=3)
    interval_hours    = models.IntegerField(default=168)
    max_escalations   = models.IntegerField(default=0)
    is_paused         = models.BooleanField(default=False)
    paused_until      = models.DateTimeField(null=True, blank=True)
    pause_reason      = models.CharField(max_length=300, null=True, blank=True)
    notify_rerun_fail      = models.BooleanField(default=True)
    send_resolved_mail     = models.BooleanField(default=False,
                                 help_text="Send email when an escalated issue is resolved")
    customer_env_mail      = models.BooleanField(default=False,
                                 help_text="(Future) Send customer-facing env mail")
    updated_at             = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table       = "escalation_config"
        managed        = False
        unique_together = [("customer", "env_type")]

    def __str__(self): return f"{self.customer.name}/{self.env_type} (thr={self.threshold})"


class Schedule(HCModel):
    customer        = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_types       = models.CharField(max_length=50)
    schedule_name   = models.CharField(max_length=200)
    cron_expression = models.CharField(max_length=100)
    is_active       = models.BooleanField(default=True)
    start_at        = models.DateTimeField(null=True, blank=True,
                          help_text="When this schedule should start firing. Defaults to now. "
                                    "If in the past, fires immediately on next tick.")
    last_run_at     = models.DateTimeField(null=True, blank=True)
    next_run_at     = models.DateTimeField(null=True, blank=True)
    notes           = models.CharField(max_length=300, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "schedules"
        managed  = False
        ordering = ["customer__name", "env_types"]

    def __str__(self): return f"{self.schedule_name} [{self.cron_expression}]"


class ExecutionRun(HCModel):
    schedule    = models.ForeignKey(Schedule, on_delete=models.SET_NULL,
                                    null=True, blank=True, db_column="schedule_id")
    customer    = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_types   = models.CharField(max_length=50)
    run_type    = models.CharField(max_length=20, default="SCHEDULED")
    status      = models.CharField(max_length=20, default="PENDING")
    triggered_by = models.CharField(max_length=100, default="system")
    started_at  = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    error_summary = models.TextField(null=True, blank=True)
    latest_step  = models.CharField(max_length=200, null=True, blank=True)
    rerun_of_run = models.ForeignKey("self", on_delete=models.SET_NULL,
                                     null=True, blank=True, db_column="rerun_of_run_id")
    rerun_attempt = models.SmallIntegerField(default=0)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "execution_runs"
        managed  = False
        ordering = ["-id"]

    def __str__(self): return f"Run #{self.id} {self.customer.name}/{self.env_types} [{self.status}]"

    def duration_seconds(self):
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds())
        return None


class EnvRunStatus(HCModel):
    run         = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE, db_column="run_id")
    customer    = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_type    = models.CharField(max_length=10)
    tenant      = models.CharField(max_length=50, default="")
    status      = models.CharField(max_length=20, default="PENDING")
    error_message = models.TextField(null=True, blank=True)
    started_at  = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta(HCModel.Meta):
        db_table = "env_run_status"
        managed  = False

    def __str__(self): return f"Run#{self.run_id} {self.env_type} [{self.status}]"


class ExecutionLog(HCModel):
    run         = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE, db_column="run_id")
    customer    = models.ForeignKey(Customer, on_delete=models.SET_NULL,
                                    null=True, blank=True, db_column="customer_id")
    env_type    = models.CharField(max_length=10, null=True, blank=True)
    server_id   = models.IntegerField(null=True, blank=True)
    db_id       = models.IntegerField(null=True, blank=True)
    log_level   = models.CharField(max_length=10, default="INFO")
    py_file     = models.CharField(max_length=200, default="")
    py_module   = models.CharField(max_length=200, default="")
    py_function = models.CharField(max_length=200, default="")
    py_line     = models.IntegerField(null=True, blank=True)
    message     = models.TextField()
    logged_at   = models.DateTimeField()

    class Meta(HCModel.Meta):
        db_table = "execution_logs"
        managed  = False
        ordering = ["logged_at"]

    def __str__(self): return f"[{self.log_level}] {self.message[:60]}"


class ServerCheckResult(HCModel):
    env_status           = models.ForeignKey(EnvRunStatus, on_delete=models.CASCADE, db_column="env_status_id")
    server               = models.ForeignKey(Server, on_delete=models.CASCADE, db_column="server_id")
    connection_status    = models.CharField(max_length=200, default="")
    connection_ok        = models.BooleanField(default=False)
    win_update_status    = models.TextField(null=True, blank=True)
    win_update_action    = models.BooleanField(null=True, blank=True)
    task_scheduler_detail = models.TextField(null=True, blank=True)
    task_scheduler_action = models.BooleanField(null=True, blank=True)
    listeners_detail     = models.TextField(null=True, blank=True)
    listeners_action     = models.BooleanField(null=True, blank=True)
    disk_space_detail    = models.TextField(null=True, blank=True)
    disk_space_action    = models.BooleanField(null=True, blank=True)
    checked_at           = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "server_check_results"
        managed  = False

    def any_action(self):
        return any([
            not self.connection_ok,
            self.win_update_action,
            self.task_scheduler_action,
            self.listeners_action,
            self.disk_space_action,
        ])


class DBCheckResult(HCModel):
    env_status              = models.ForeignKey(EnvRunStatus, on_delete=models.CASCADE, db_column="env_status_id")
    server                  = models.ForeignKey(Server, on_delete=models.CASCADE, db_column="server_id")
    oracle_db               = models.ForeignKey(OracleDatabase, on_delete=models.CASCADE, db_column="oracle_db_id")
    connection_status       = models.CharField(max_length=200, default="")
    connection_ok           = models.BooleanField(default=False)
    schema_password_detail  = models.TextField(null=True, blank=True)
    schema_password_action  = models.BooleanField(null=True, blank=True)
    tablespace_detail       = models.TextField(null=True, blank=True)
    tablespace_action       = models.BooleanField(null=True, blank=True)
    archive_mode            = models.CharField(max_length=50, null=True, blank=True)
    archive_mode_action     = models.BooleanField(null=True, blank=True)
    archive_log_detail      = models.TextField(null=True, blank=True)
    archive_log_action      = models.BooleanField(null=True, blank=True)
    archive_path_detail     = models.TextField(null=True, blank=True)
    archive_path_action     = models.BooleanField(null=True, blank=True)
    rman_detail             = models.TextField(null=True, blank=True)
    rman_action             = models.BooleanField(null=True, blank=True)
    checked_at              = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "db_check_results"
        managed  = False

    def any_action(self):
        return any([
            not self.connection_ok,
            self.schema_password_action,
            self.tablespace_action,
            self.archive_mode_action,
            self.archive_log_action,
            self.archive_path_action,
            self.rman_action,
        ])


class TablespaceUsage(HCModel):
    db_check        = models.ForeignKey(DBCheckResult, on_delete=models.CASCADE, db_column="db_check_id")
    tablespace_name = models.CharField(max_length=100)
    used_space_kb   = models.BigIntegerField(null=True, blank=True)
    total_space_kb  = models.BigIntegerField(null=True, blank=True)
    used_pct        = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    recorded_at     = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "tablespace_usage"
        managed  = False
        ordering = ["-used_pct"]

    def __str__(self): return f"{self.tablespace_name} {self.used_pct}%"


class RMANBackupDetail(HCModel):
    db_check            = models.ForeignKey(DBCheckResult, on_delete=models.CASCADE, db_column="db_check_id")
    start_time          = models.CharField(max_length=100, null=True, blank=True)
    end_time            = models.CharField(max_length=100, null=True, blank=True)
    output_device_type  = models.CharField(max_length=50, null=True, blank=True)
    backup_type         = models.CharField(max_length=50, null=True, blank=True)
    time_taken_display  = models.CharField(max_length=50, null=True, blank=True)
    status              = models.CharField(max_length=100, null=True, blank=True)
    recorded_at         = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "rman_backup_details"
        managed  = False


class IssueTracker(HCModel):
    customer              = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_type              = models.CharField(max_length=10)
    server                = models.ForeignKey(Server, on_delete=models.SET_NULL,
                                              null=True, blank=True, db_column="server_id")
    oracle_db             = models.ForeignKey(OracleDatabase, on_delete=models.SET_NULL,
                                              null=True, blank=True, db_column="oracle_db_id")
    test_catalog          = models.ForeignKey(TestCatalog, on_delete=models.CASCADE, db_column="test_catalog_id")
    first_failed_run      = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE,
                                              related_name="+", db_column="first_failed_run_id")
    last_failed_run       = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE,
                                              related_name="+", db_column="last_failed_run_id")
    consecutive_failures  = models.IntegerField(default=1)
    total_failures        = models.IntegerField(default=1)
    last_error_detail     = models.TextField(null=True, blank=True)
    status                = models.CharField(max_length=20, default="OPEN")
    resolved_run          = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL,
                                              null=True, blank=True, related_name="+",
                                              db_column="resolved_run_id")
    last_escalation_at     = models.DateTimeField(null=True, blank=True)
    escalation_send_count = models.IntegerField(default=0)
    created_at            = models.DateTimeField(auto_now_add=True)
    updated_at            = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "issue_tracker"
        managed  = False
        ordering = ["-consecutive_failures"]

    def __str__(self):
        return f"{self.customer.name}/{self.env_type} {self.test_catalog.test_name} [{self.status}]"


class AlertHistory(HCModel):
    run               = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL,
                                          null=True, blank=True, db_column="run_id")
    issue_id          = models.IntegerField(null=True, blank=True)
    alert_type        = models.CharField(max_length=20)
    customer          = models.ForeignKey(Customer, on_delete=models.SET_NULL,
                                          null=True, blank=True, db_column="customer_id")
    customer_name     = models.CharField(max_length=255, null=True, blank=True)
    env_type          = models.CharField(max_length=10, null=True, blank=True)
    run_env_types     = models.CharField(max_length=50, null=True, blank=True)
    subject           = models.CharField(max_length=500)
    recipients_to     = models.TextField()
    recipients_cc     = models.TextField(null=True, blank=True)
    escalation_count  = models.IntegerField(default=0)
    escalation_ordinal = models.CharField(max_length=50, null=True, blank=True)
    attachment_name   = models.CharField(max_length=500, null=True, blank=True)
    attachment_size_bytes = models.BigIntegerField(null=True, blank=True)
    triggered_by      = models.CharField(max_length=100, null=True, blank=True)
    send_status       = models.CharField(max_length=10, default="SENT")
    error_message     = models.TextField(null=True, blank=True)
    sent_at           = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "alert_history"
        managed  = False
        ordering = ["-sent_at"]

    def __str__(self): return f"{self.alert_type} | {self.subject[:60]}"


class RerunQueue(HCModel):
    original_run  = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE,
                                      db_column="original_run_id")
    customer      = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_types     = models.CharField(max_length=50)
    attempt_number = models.SmallIntegerField(default=1)
    max_attempts  = models.SmallIntegerField(default=3)
    status        = models.CharField(max_length=20, default="PENDING")
    scheduled_at  = models.DateTimeField()
    started_at    = models.DateTimeField(null=True, blank=True)
    completed_at  = models.DateTimeField(null=True, blank=True)
    last_error    = models.TextField(null=True, blank=True)
    created_at    = models.DateTimeField(auto_now_add=True)

    class Meta(HCModel.Meta):
        db_table = "rerun_queue"
        managed  = False
        ordering = ["scheduled_at"]

    def __str__(self):
        return f"Rerun #{self.id} orig={self.original_run_id} [{self.status}]"


class RunStepLog(HCModel):
    run          = models.ForeignKey(ExecutionRun, on_delete=models.CASCADE, db_column="run_id")
    step_name    = models.CharField(max_length=200)
    step_order   = models.SmallIntegerField(default=0)
    status       = models.CharField(max_length=20, default="RUNNING")
    started_at   = models.DateTimeField()
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_ms  = models.IntegerField(null=True, blank=True)
    notes        = models.TextField(null=True, blank=True)

    class Meta(HCModel.Meta):
        db_table = "run_step_log"
        managed  = False
        ordering = ["step_order"]

    def __str__(self): return f"Run#{self.run_id} [{self.step_order}] {self.step_name} {self.status}"


class SchedulerTracker(HCModel):
    """
    Tracks every scheduler firing event: past, future, and currently running.
    Admin can view this table in the UI and manage failed queue entries.
    """
    STATUS_CHOICES = [
        ("PENDING",     "Pending"),
        ("RUNNING",     "Running"),
        ("COMPLETED",   "Completed"),
        ("FAILED",      "Failed"),
        ("FAILED_QUEUE","Failed Queue"),
        ("SKIPPED",     "Skipped"),
    ]

    schedule        = models.ForeignKey(Schedule, on_delete=models.SET_NULL,
                                        null=True, blank=True, db_column="schedule_id")
    customer        = models.ForeignKey(Customer, on_delete=models.CASCADE, db_column="customer_id")
    env_types       = models.CharField(max_length=50)
    schedule_name   = models.CharField(max_length=200, default="")
    cron_expression = models.CharField(max_length=100, default="")
    run             = models.ForeignKey(ExecutionRun, on_delete=models.SET_NULL,
                                        null=True, blank=True, db_column="run_id")
    status          = models.CharField(max_length=20, choices=STATUS_CHOICES, default="PENDING")
    scheduled_fire_at = models.DateTimeField(help_text="When this run was supposed to fire")
    actual_start_at = models.DateTimeField(null=True, blank=True)
    completed_at    = models.DateTimeField(null=True, blank=True)
    last_run_at     = models.DateTimeField(null=True, blank=True)
    next_run_at     = models.DateTimeField(null=True, blank=True)
    error_message   = models.TextField(null=True, blank=True)
    is_active       = models.BooleanField(default=True,
                          help_text="Admin can deactivate/re-queue failed entries")
    triggered_by    = models.CharField(max_length=100, default="scheduler")
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta(HCModel.Meta):
        db_table = "scheduler_tracker"
        managed  = False
        ordering = ["-scheduled_fire_at"]

    def __str__(self):
        return (f"Tracker #{self.id} {self.customer.name}/{self.env_types} "
                f"[{self.status}] fire={self.scheduled_fire_at}")
