"""
healthcheck/scheduler_service.py  (v8 - IST + start_at fixed)
================================================================
APScheduler wrapper.

KEY FIXES in v8:
  1. ALL times use Asia/Kolkata (IST) — scheduler, DB writes, logs, API output.
  2. Start At logic: first execution fires ONLY at admin-selected start_at time,
     NOT at creation time. Cron base is anchored to start_at minute/hour.
  3. last_run_at / next_run_at correctly updated after each fire (IST).
  4. Duplicate-run prevention (main process only).
  5. CoInitialize / CoUninitialize fix — Win32 IUnknown error resolved.
  6. Scheduler page auto-refresh every 30s (template).
  7. No popup when scheduler is stopped.
"""
import logging
import threading
from datetime import datetime, timedelta

import pytz

logger = logging.getLogger("hc.scheduler")

IST = pytz.timezone("Asia/Kolkata")


def _now_ist() -> datetime:
    """Return current time as timezone-aware datetime in IST."""
    return datetime.now(IST)


def _to_ist(dt) -> datetime:
    """Convert a naive or UTC datetime to IST-aware datetime."""
    if dt is None:
        return None
    if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
        return dt.astimezone(IST)
    return IST.localize(dt)


def _naive_ist(dt) -> datetime:
    """Return naive datetime that is the IST wall-clock time (for DB storage)."""
    if dt is None:
        return None
    ist_aware = _to_ist(dt)
    return ist_aware.replace(tzinfo=None)


def _db_error_types():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError:
        pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError:
        pass
    return types


_scheduler = None
_scheduler_lock = threading.Lock()
_active_runs: dict = {}
_active_runs_lock = threading.Lock()


def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


def _update_tracker(db, tracker_id: int, **kwargs):
    try:
        if not kwargs:
            return
        sets = ", ".join(f"{k}=%s" for k in kwargs)
        vals = list(kwargs.values()) + [tracker_id]
        db.execute(f"UPDATE scheduler_tracker SET {sets}, updated_at=NOW() WHERE id=%s", vals)
    except Exception as exc:
        logger.warning(f"scheduler_tracker update failed: {exc}")


def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, scheduled_fire_at,
                    triggered_by="apscheduler") -> int:
    try:
        fire_naive = _naive_ist(scheduled_fire_at)
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id, customer_id, env_types, schedule_name, cron_expression,
                status, scheduled_fire_at, triggered_by, is_active, created_at, updated_at)
               VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, fire_naive, triggered_by))
    except Exception as exc:
        logger.warning(f"scheduler_tracker insert failed: {exc}")
        return 0


def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """Execute one HC run in a background thread with COM init/cleanup."""
    _coinit_done = False
    try:
        import pythoncom
        pythoncom.CoInitialize()
        _coinit_done = True
    except ImportError:
        pass
    except Exception as exc:
        logger.debug(f"CoInitialize skipped: {exc}")

    eng = _get_engine()
    with _active_runs_lock:
        _active_runs[run_id] = label
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                status="RUNNING",
                                actual_start_at=_naive_ist(_now_ist()))
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

        final = _get_run_status(run_id)
        logger.info(f"[Scheduler] Run #{run_id} ({label}) completed: {final}")

        if tracker_id:
            with eng["DBManager"]() as db:
                status = "COMPLETED" if final in ("COMPLETED", "PARTIAL") else "FAILED"
                _update_tracker(db, tracker_id,
                                status=status,
                                completed_at=_naive_ist(_now_ist()),
                                error_message=None if status == "COMPLETED" else final)
    except Exception as exc:
        logger.error(f"[Scheduler] Run #{run_id} error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    completed_at=_naive_ist(_now_ist()),
                                    error_message=str(exc)[:1000])
            except Exception:
                pass
    finally:
        with _active_runs_lock:
            _active_runs.pop(run_id, None)
        # CRITICAL: always CoUninitialize to prevent Win32 IUnknown errors
        if _coinit_done:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _get_run_status(run_id: int) -> str:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            row = db.fetch_one(
                "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return row["status"] if row else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def _build_cron_anchored_to_start_at(cron_expression: str, start_at) -> str:
    """
    CRITICAL: When start_at is set, override minute/hour in cron to match
    the exact minute/hour from start_at.

    Example: start_at=4:43 PM, cron='0 8 * * *'
    Result: '43 16 * * *'  → fires at :43 on every matching hour/day.

    This ensures:
    - If admin sets start_at=4:43 PM, runs go at 4:43, 5:43, 6:43 etc.
    - NOT rounded to 4:00, 5:00 etc.
    """
    if start_at is None:
        return cron_expression
    try:
        start_ist = _to_ist(start_at)
        if start_ist is None:
            return cron_expression
        parts = cron_expression.strip().split()
        if len(parts) >= 2:
            parts[0] = str(start_ist.minute)
            parts[1] = str(start_ist.hour)
        return " ".join(parts)
    except Exception:
        return cron_expression


def _fire_schedule(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str, start_at=None):
    """
    Called by APScheduler for each scheduled fire.

    START AT LOGIC (CRITICAL):
    - Created time and Start At are DIFFERENT things.
    - Execution fires ONLY at/after start_at, never at creation time.
    - All times are stored and displayed in IST (Asia/Kolkata).
    """
    eng = _get_engine()
    label = f"{customer_name}/{env_types}"
    now_ist = _now_ist()

    # Honour start_at: skip all APScheduler ticks before start_at
    if start_at is not None:
        try:
            start_at_ist = _to_ist(start_at)
            if start_at_ist and now_ist < start_at_ist:
                logger.info(
                    f"[Scheduler] Skipping '{schedule_name}' — "
                    f"start_at={start_at_ist.strftime('%Y-%m-%d %H:%M IST')} "
                    f"is in the future (now={now_ist.strftime('%H:%M IST')})")
                return
        except Exception as exc:
            logger.warning(f"start_at comparison failed: {exc}")

    logger.info(
        f"[Scheduler] Firing '{schedule_name}' | {label} "
        f"| IST={now_ist.strftime('%Y-%m-%d %H:%M:%S')}")

    tracker_id = 0
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)

            from croniter import croniter
            now_naive = now_ist.replace(tzinfo=None)
            nxt_naive = croniter(cron_expression, now_naive).get_next(datetime)

            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now_ist)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            # Update last_run_at=now IST, next_run_at=next cron tick IST
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_naive, nxt_naive, schedule_id))

            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                next_run_at=nxt_naive,
                                last_run_at=now_naive)

        logger.info(
            f"[Scheduler] Run #{run_id} created | "
            f"next_run IST={nxt_naive.strftime('%Y-%m-%d %H:%M')}")
        _execute_run(run_id, label, tracker_id)

    except Exception as exc:
        db_err_types = _db_error_types()
        if isinstance(exc, db_err_types):
            logger.error(
                f"[Scheduler] DB unavailable while firing '{schedule_name}': {exc}")
            return
        logger.error(f"[Scheduler] Error firing '{schedule_name}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception:
                pass


def _load_schedules() -> list:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


def _register_jobs(scheduler):
    """Remove all sched_* jobs and re-register from DB using IST timezone."""
    from apscheduler.triggers.cron import CronTrigger

    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try:
                job.remove()
            except Exception:
                pass

    schedules = _load_schedules()
    logger.info(f"[Scheduler] Registering {len(schedules)} schedule(s) (IST)")

    for s in schedules:
        job_id = f"sched_{s['id']}"
        try:
            # Anchor cron minute/hour to start_at so exact minute is preserved
            effective_cron = _build_cron_anchored_to_start_at(
                s["cron_expression"], s.get("start_at"))
            parts = effective_cron.strip().split()

            trigger = CronTrigger(
                minute     =parts[0] if len(parts) > 0 else "*",
                hour       =parts[1] if len(parts) > 1 else "*",
                day        =parts[2] if len(parts) > 2 else "*",
                month      =parts[3] if len(parts) > 3 else "*",
                day_of_week=parts[4] if len(parts) > 4 else "*",
                timezone   =IST,   # CRITICAL: wall-clock IST
            )

            start_at = s.get("start_at")
            scheduler.add_job(
                _fire_schedule,
                trigger=trigger,
                id=job_id,
                name=s["schedule_name"],
                args=[s["id"], s["customer_id"], s["env_types"],
                      s["schedule_name"], s["customer_name"],
                      s["cron_expression"], start_at],
                max_instances=1,
                coalesce=True,
                replace_existing=True,
                misfire_grace_time=300,
            )
            start_at_str = (_to_ist(start_at).strftime("%Y-%m-%d %H:%M IST")
                            if start_at else "immediate")
            logger.info(
                f"  OK [{s['id']}] {s['schedule_name']} "
                f"effective_cron={effective_cron} start_at={start_at_str}")
        except Exception as exc:
            logger.error(f"  FAIL schedule id={s['id']}: {exc}")


def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("Scheduler already running — skipping duplicate start")
            return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor

            _scheduler = BackgroundScheduler(
                executors={"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults={"coalesce": True, "max_instances": 1},
                timezone=IST,
            )
            _register_jobs(_scheduler)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules",
                name="Refresh schedules from DB",
                replace_existing=True,
            )
            _scheduler.start()
            logger.info("APScheduler started (Asia/Kolkata, ThreadPool x20)")
            return _scheduler
        except ImportError:
            logger.error("APScheduler not installed: pip install apscheduler")
            return None
        except Exception as exc:
            logger.error(f"Failed to start scheduler: {exc}", exc_info=True)
            return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            try:
                _scheduler.shutdown(wait=False)
            except Exception as exc:
                logger.warning(f"Scheduler shutdown warning (safe to ignore): {exc}")
            logger.info("APScheduler stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """Return full live status dict for dashboard/API. All times in IST."""
    if _scheduler is None or not _scheduler.running:
        return {"running": False, "job_count": 0, "jobs": [],
                "active_runs": [], "active_run_count": 0}

    schedule_jobs = []
    for job in _scheduler.get_jobs():
        if not job.id.startswith("sched_"):
            continue
        nxt = job.next_run_time
        if nxt:
            nxt_ist = nxt.astimezone(IST)
            nxt_str = nxt_ist.strftime("%d-%b-%Y %H:%M IST")
        else:
            nxt_str = "—"
        schedule_jobs.append({
            "id":       job.id,
            "name":     job.name,
            "next_run": nxt_str,
        })

    with _active_runs_lock:
        active = [{"run_id": rid, "label": lbl}
                  for rid, lbl in _active_runs.items()]

    return {
        "running":          True,
        "job_count":        len(schedule_jobs),
        "jobs":             schedule_jobs,
        "active_runs":      active,
        "active_run_count": len(active),
    }


def run_now_sync(schedule_id: int):
    """Fire a specific schedule immediately. Returns new run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                """SELECT s.*,c.name AS cname FROM schedules s
                   JOIN customers c ON c.id=s.customer_id WHERE s.id=%s""",
                (schedule_id,))
            if not s:
                return None

            from croniter import croniter
            now_ist = _now_ist()
            now_naive = now_ist.replace(tzinfo=None)
            nxt_naive = croniter(s["cron_expression"], now_naive).get_next(datetime)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,
                    run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))

            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_naive, nxt_naive, schedule_id))

            tracker_id = _create_tracker(
                db, schedule_id, s["customer_id"], s["env_types"],
                s["schedule_name"], s["cron_expression"],
                now_ist, triggered_by="admin:run_now")

        label = f"{s['cname']}/{s['env_types']}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label, tracker_id),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync error: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str):
    """Fire a manual run for customer+env. Returns new run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        label = f"{cname}/{env_types}"
        t = threading.Thread(
            target=_execute_run, args=(run_id, label, 0),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_customer_now error: {exc}", exc_info=True)
        return None
