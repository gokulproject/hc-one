"""
notifications/email_service.py  (v6)
======================================
All email notifications.

v6 changes vs v5:
  1. send_success: accepts has_action (bool) and step_failures (list).
     - When has_action=True → subject gets "ACTION REQUIRED - " prefix.
     - When step_failures not empty → email body includes a failure
       table showing each failed step name and reason.
  2. send_failure: accepts step_failures (list) and includes a
     step-by-step failure breakdown table in the email body.
  3. No other behaviour changed.
"""
import os
import smtplib
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Dict, List, Optional

from core.config import ConfigLoader
from core.db_manager import DBManager

_ORDINALS = ["", "First", "Second", "Third", "Fourth", "Fifth",
             "Sixth", "Seventh", "Eighth", "Ninth", "Tenth"]


def _ordinal(n: int) -> str:
    return _ORDINALS[n] if 1 <= n <= len(_ORDINALS) - 1 else f"{n}th"


def _render(tmpl: str, ctx: Dict) -> str:
    """Replace {key} and legacy <key> placeholders."""
    out = tmpl
    for k, v in ctx.items():
        out = out.replace(f"{{{k}}}", str(v))
        out = out.replace(f"<{k}>", str(v))
    return out.replace("<>", "\n")


def _build_step_failure_html(step_failures: List[Dict]) -> str:
    """
    Build an HTML table showing each failed step and its reason.
    Used in both success (partial failures) and failure emails.
    """
    if not step_failures:
        return ""
    rows_html = "".join(
        f"<tr>"
        f"<td style='padding:6px 10px;border:1px solid #e0e0e0;"
        f"font-weight:bold;color:#C62828'>{f.get('step', '')}</td>"
        f"<td style='padding:6px 10px;border:1px solid #e0e0e0;"
        f"font-family:monospace;font-size:12px'>{f.get('reason', '')}</td>"
        f"</tr>"
        for f in step_failures
    )
    return (
        f"<br><p style='font-weight:bold;color:#C62828'>Step Failures:</p>"
        f"<table style='border-collapse:collapse;width:100%;margin-bottom:12px'>"
        f"<tr style='background:#FFEBEE'>"
        f"<th style='padding:6px 10px;border:1px solid #e0e0e0;text-align:left'>Step</th>"
        f"<th style='padding:6px 10px;border:1px solid #e0e0e0;text-align:left'>Reason</th>"
        f"</tr>"
        f"{rows_html}</table>"
    )


class EmailService:
    def __init__(self, db: DBManager, logger):
        self.db     = db
        self.logger = logger
        self.cfg    = ConfigLoader.get()

    # ------------------------------------------------------------------ #
    # Recipient and template helpers
    # ------------------------------------------------------------------ #

    def _recipients(self, alert_type: str, customer_id: Optional[int] = None):
        if customer_id:
            row = self.db.fetch_one(
                "SELECT to_addresses,cc_addresses FROM mail_recipients "
                "WHERE alert_type=%s AND customer_id=%s AND is_active=1 LIMIT 1",
                (alert_type, customer_id))
            if row:
                return row["to_addresses"] or "", row["cc_addresses"] or ""
        row = self.db.fetch_one(
            "SELECT to_addresses,cc_addresses FROM mail_recipients "
            "WHERE alert_type=%s AND customer_id IS NULL AND is_active=1 LIMIT 1",
            (alert_type,))
        if row:
            return row["to_addresses"] or "", row["cc_addresses"] or ""
        return "", ""

    def _tmpl(self, key: str) -> Dict[str, str]:
        return self.cfg.templates.get(key, {})

    # ================================================================== #
    # PUBLIC: send_success
    # ================================================================== #

    def send_success(self,
                     run_id:        int,
                     customer_id:   int,
                     customer_name: str,
                     env_label:     str,
                     report_title:  str,
                     excel_path:    Optional[str] = None,
                     env_types:     str = "",
                     triggered_by:  str = "system",
                     has_action:    bool = False,
                     step_failures: Optional[List[Dict]] = None):
        """
        Send success email.
        - has_action=True → subject prefixed with "ACTION REQUIRED - "
        - step_failures   → failure table appended to HTML body
        """
        sf = step_failures or []
        self.logger.info(
            f"Preparing SUCCESS email for run #{run_id} | "
            f"{customer_name} | {env_label} | action={has_action}")

        to_addr, cc_addr = self._recipients("SUCCESS", customer_id)
        if not to_addr:
            self.logger.warning(
                "SUCCESS recipients not configured in mail_recipients — email skipped")
            return

        attach_name = os.path.basename(excel_path) if excel_path else ""
        attach_size = (os.path.getsize(excel_path)
                       if excel_path and os.path.exists(excel_path) else 0)
        ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ctx = {"customer": customer_name, "env": env_label, "run_id": run_id,
               "date_time": ts, "report_title": report_title,
               "attachment": attach_name, "server_info": report_title}

        tmpl = self._tmpl("success")
        base_subject = _render(
            tmpl.get("subject",
                     f"Health Check Report - {customer_name} - {env_label}"), ctx)

        # Prefix subject with ACTION REQUIRED when any check requires action
        subject = f"ACTION REQUIRED - {base_subject}" if has_action else base_subject

        base_html = _render(
            tmpl.get("body_html",
                     "<p>Please find the attached {report_title}.</p>"), ctx)

        # Append failure table to HTML body if any step failed
        step_fail_html = _build_step_failure_html(sf)
        html_body = base_html.replace("</body></html>",
                                      f"{step_fail_html}</body></html>") \
                    if step_fail_html else base_html

        plain = (
            f"{'ACTION REQUIRED — ' if has_action else ''}"
            f"Health Check Report: {report_title}\n\n"
            f"Customer: {customer_name}\nEnvironment: {env_label}\n"
            f"Run ID: #{run_id}\nGenerated: {ts}\n"
            f"Attachment: {attach_name}\n"
        )
        if sf:
            plain += "\nStep Failures:\n" + "\n".join(
                f"  [{f['step']}] {f['reason']}" for f in sf)

        self._send(
            subject=subject, html=html_body, plain=plain,
            to_addr=to_addr, cc_addr=cc_addr,
            attachment=excel_path, alert_type="SUCCESS",
            run_id=run_id, customer_id=customer_id,
            customer_name=customer_name, env_type=env_label,
            run_env_types=env_types, triggered_by=triggered_by,
            attachment_name=attach_name, attachment_size=attach_size)

    # ================================================================== #
    # PUBLIC: send_failure
    # ================================================================== #

    def send_failure(self,
                     run_id:        int,
                     customer_id:   int,
                     customer_name: str,
                     env_type:      str,
                     error_message: str,
                     triggered_by:  str = "system",
                     step_failures: Optional[List[Dict]] = None):
        """
        Send failure alert.
        step_failures → step-by-step breakdown table in the email body.
        """
        sf = step_failures or []
        self.logger.info(
            f"Preparing FAILURE email for run #{run_id} | "
            f"{customer_name} | {env_type}")

        to_addr, cc_addr = self._recipients("FAILURE", customer_id)
        if not to_addr:
            self.logger.warning("FAILURE recipients not configured — email skipped")
            return

        ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ctx = {"customer": customer_name, "env": env_type, "run_id": run_id,
               "date_time": ts, "error": error_message, "message": error_message}

        tmpl = self._tmpl("failure")
        subject  = _render(
            tmpl.get("subject",
                     f"Job Failure Notification - Health Check - {customer_name} - {env_type}"),
            ctx)
        base_html = _render(
            tmpl.get("body_html", "<p>{error}</p>"), ctx)

        # Append step failure breakdown
        step_fail_html = _build_step_failure_html(sf)
        html_body = base_html.replace("</body></html>",
                                      f"{step_fail_html}</body></html>") \
                    if step_fail_html else base_html

        plain = (
            f"Failure — Customer: {customer_name} | Env: {env_type} | "
            f"Run #{run_id}\n\nError: {error_message}\n"
        )
        if sf:
            plain += "\nStep Failures:\n" + "\n".join(
                f"  [{f['step']}] {f['reason']}" for f in sf)

        self._send(
            subject=subject, html=html_body, plain=plain,
            to_addr=to_addr, cc_addr=cc_addr, alert_type="FAILURE",
            run_id=run_id, customer_id=customer_id,
            customer_name=customer_name, env_type=env_type,
            run_env_types=env_type, triggered_by=triggered_by)

    # ================================================================== #
    # PUBLIC: send_escalation
    # ================================================================== #

    def send_escalation(self,
                        customer_id:      int,
                        customer_name:    str,
                        env_type:         str,
                        issues:           List[Dict],
                        escalation_count: int):
        if not issues:
            return
        to_addr, cc_addr = self._recipients("ESCALATION", customer_id)
        if not to_addr:
            self.logger.warning("ESCALATION recipients not configured — skipped")
            return

        ordinal = _ordinal(escalation_count)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        issue_rows_html = "".join(
            f"<tr>"
            f"<td style='padding:6px;border:1px solid #ccc'>{i['test_name']}</td>"
            f"<td style='padding:6px;border:1px solid #ccc;color:#C62828;"
            f"text-align:center;font-weight:bold'>{i['consecutive_failures']}</td>"
            f"<td style='padding:6px;border:1px solid #ccc;text-align:center'>"
            f"{i['total_failures']}</td>"
            f"<td style='padding:6px;border:1px solid #ccc;font-size:12px'>"
            f"{i.get('last_error_detail', '')}</td>"
            f"</tr>"
            for i in issues
        )
        ctx = {"customer": customer_name, "env": env_type, "date_time": ts,
               "ordinal": f"{ordinal} Escalation",
               "issue_table": issue_rows_html,
               "escalation_count": escalation_count}

        tmpl = self._tmpl("escalation")
        subject  = _render(
            tmpl.get("subject",
                     f"ACTION REQUIRED - {ordinal} Escalation - {customer_name} - {env_type}"),
            ctx)
        html_body = _render(tmpl.get("body_html", ""), ctx)
        plain_issues = "\n".join(
            f"  - {i['test_name']} (Consecutive: {i['consecutive_failures']}, "
            f"Total: {i['total_failures']})"
            for i in issues)
        plain = (
            f"ACTION REQUIRED — {ordinal} Escalation\n"
            f"Customer: {customer_name}\nEnv: {env_type}\n\n"
            f"Failing tests:\n{plain_issues}\n\nPlease investigate.")

        self.logger.info(
            f"Sending {ordinal} Escalation | "
            f"{customer_name}/{env_type} | {len(issues)} issue(s)")
        self._send(
            subject=subject, html=html_body, plain=plain,
            to_addr=to_addr, cc_addr=cc_addr, alert_type="ESCALATION",
            customer_id=customer_id, customer_name=customer_name,
            env_type=env_type, escalation_count=escalation_count,
            escalation_ordinal=ordinal)

    # ================================================================== #
    # PUBLIC: send_rerun_exhausted
    # ================================================================== #

    def send_resolved(self,
                      run_id: int,
                      issue_id: int,
                      customer_id: int,
                      customer_name: str,
                      env_type: str,
                      test_name: str,
                      consecutive_failures: int = 0) -> None:
        """
        Send resolved notification email.
        Only called when EscalationConfig.send_resolved_mail = True.
        """
        try:
            to_addr, cc_addr = self._recipients("ESCALATION", customer_id)
            if not to_addr:
                self.logger.info(
                    f"No recipients for resolved mail cust={customer_id} env={env_type} — skip")
                return

            subject = (
                f"[RESOLVED] Health Check — {customer_name} / {env_type} — {test_name}")
            html_body = (
                f"<html><body style='font-family:Arial,sans-serif'>"
                f"<p>The following Health Check issue has been "
                f"<strong style='color:#28a745'>RESOLVED</strong>:</p>"
                f"<table border='1' cellpadding='6' cellspacing='0' "
                f"style='border-collapse:collapse;min-width:350px'>"
                f"<tr style='background:#f8f9fa'><th align='left'>Customer</th>"
                f"<td>{customer_name}</td></tr>"
                f"<tr><th align='left'>Environment</th><td>{env_type}</td></tr>"
                f"<tr style='background:#f8f9fa'><th align='left'>Test</th>"
                f"<td>{test_name}</td></tr>"
                f"<tr><th align='left'>Previous Failures</th>"
                f"<td>{consecutive_failures}</td></tr>"
                f"<tr style='background:#d4edda'><th align='left'>Status</th>"
                f"<td><b style='color:#155724'>RESOLVED</b></td></tr>"
                f"</table>"
                f"<p>All checks are now passing. No further action required.</p>"
                f"</body></html>")
            plain_body = (
                f"RESOLVED: {test_name} for {customer_name}/{env_type}. "
                f"All checks passing.")

            self._send(
                subject=subject, html=html_body, plain=plain_body,
                to_addr=to_addr, cc_addr=cc_addr,
                alert_type="RESOLVED",
                run_id=run_id, issue_id=issue_id,
                customer_id=customer_id, customer_name=customer_name,
                env_type=env_type, run_env_types=env_type,
                triggered_by="issue_tracker")
        except Exception as exc:
            self.logger.error(f"send_resolved error: {exc}")

    def send_rerun_exhausted(self,
                             run_id:       int,
                             customer_id:  int,
                             customer_name: str,
                             env_types:    str,
                             max_attempts: int,
                             triggered_by: str = "system"):
        self.logger.warning(
            f"Sending RERUN_FAILURE | run #{run_id} | "
            f"{customer_name} | {env_types}")
        to_addr, cc_addr = self._recipients("RERUN_FAILURE", customer_id)
        if not to_addr:
            return
        ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ctx = {"customer": customer_name, "env": env_types, "run_id": run_id,
               "max_attempts": max_attempts, "date_time": ts}
        tmpl = self._tmpl("rerun_failure")
        subject   = _render(
            tmpl.get("subject",
                     f"RERUN EXHAUSTED - Health Check - {customer_name} ({env_types})"),
            ctx)
        html_body = _render(
            tmpl.get("body_html", "<p>All rerun attempts exhausted.</p>"), ctx)
        plain = (
            f"All {max_attempts} rerun attempts exhausted.\n"
            f"Customer: {customer_name}\nEnvironment: {env_types}\n"
            f"Run ID: #{run_id}\nTime: {ts}")
        self._send(
            subject=subject, html=html_body, plain=plain,
            to_addr=to_addr, cc_addr=cc_addr, alert_type="RERUN_FAILURE",
            run_id=run_id, customer_id=customer_id,
            customer_name=customer_name, env_type=env_types,
            run_env_types=env_types, triggered_by=triggered_by)

    # ================================================================== #
    # CORE SEND
    # ================================================================== #

    def _send(self,
              subject:             str,
              html:                str,
              plain:               str,
              to_addr:             str,
              cc_addr:             str           = "",
              attachment:          Optional[str] = None,
              alert_type:          str           = "SUCCESS",
              run_id:              Optional[int] = None,
              issue_id:            Optional[int] = None,
              customer_id:         Optional[int] = None,
              customer_name:       Optional[str] = None,
              env_type:            Optional[str] = None,
              run_env_types:       Optional[str] = None,
              triggered_by:        Optional[str] = None,
              escalation_count:    int           = 0,
              escalation_ordinal:  Optional[str] = None,
              attachment_name:     Optional[str] = None,
              attachment_size:     Optional[int] = None):
        to_list = [a.strip() for a in to_addr.split(",") if a.strip()]
        cc_list = [a.strip() for a in cc_addr.split(",") if a.strip()] if cc_addr else []
        if not to_list:
            self.logger.warning(f"No TO addresses for {alert_type} — skipped")
            return

        mail = self.cfg.mail
        all_rcpt = to_list + cc_list
        self.logger.info(
            f"Sending {alert_type} | Subject: '{subject}' | "
            f"TO: {to_list} | CC: {cc_list}")

        send_status = "SENT"
        error_msg   = None
        try:
            alt = MIMEMultipart("alternative")
            alt.attach(MIMEText(plain, "plain", "utf-8"))
            alt.attach(MIMEText(html,  "html",  "utf-8"))

            if attachment and os.path.exists(attachment):
                outer = MIMEMultipart("mixed")
                outer["From"]    = mail.from_address
                outer["To"]      = ", ".join(to_list)
                outer["Subject"] = subject
                if cc_list:      outer["Cc"]       = ", ".join(cc_list)
                if mail.reply_to: outer["Reply-To"] = mail.reply_to
                outer.attach(alt)
                fname = os.path.basename(attachment).replace(" ", "_")
                self.logger.info(
                    f"Attaching: {fname} ({os.path.getsize(attachment):,} bytes)")
                with open(attachment, "rb") as f:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition",
                                f'attachment; filename="{fname}"')
                outer.attach(part)
                msg = outer
            else:
                alt["From"]    = mail.from_address
                alt["To"]      = ", ".join(to_list)
                alt["Subject"] = subject
                if cc_list:       alt["Cc"]       = ", ".join(cc_list)
                if mail.reply_to: alt["Reply-To"] = mail.reply_to
                msg = alt
                if attachment:
                    self.logger.warning(f"Attachment not found: {attachment}")

            self.logger.debug(
                f"SMTP connect to {mail.smtp_host}:{mail.smtp_port}")
            with smtplib.SMTP(mail.smtp_host, mail.smtp_port, timeout=30) as srv:
                srv.ehlo()
                if mail.use_tls:
                    srv.starttls(); srv.ehlo()
                srv.login(mail.smtp_user, mail.smtp_password)
                srv.sendmail(mail.from_address, all_rcpt, msg.as_string())
            self.logger.info(f"Email SENT: {alert_type} → {all_rcpt}")

        except smtplib.SMTPAuthenticationError as e:
            send_status = "FAILED"; error_msg = f"SMTP auth failed: {e}"
            self.logger.error(f"SMTP auth error for {alert_type}: {e}")
        except smtplib.SMTPException as e:
            send_status = "FAILED"; error_msg = f"SMTP error: {e}"
            self.logger.error(f"SMTP error for {alert_type}: {e}")
        except Exception as e:
            send_status = "FAILED"; error_msg = str(e)
            self.logger.error(f"Unexpected error sending {alert_type}: {e}")

        try:
            self.db.execute(
                """INSERT INTO alert_history
                   (run_id, issue_id, alert_type, customer_id, customer_name,
                    env_type, run_env_types, subject, recipients_to, recipients_cc,
                    escalation_count, escalation_ordinal,
                    attachment_name, attachment_size_bytes,
                    triggered_by, send_status, error_message)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (run_id, issue_id, alert_type, customer_id, customer_name,
                 env_type, run_env_types, subject[:500],
                 ", ".join(to_list), ", ".join(cc_list),
                 escalation_count, escalation_ordinal,
                 attachment_name, attachment_size,
                 triggered_by, send_status,
                 error_msg[:2000] if error_msg else None))
        except Exception as e:
            self.logger.error(f"Failed to write alert_history: {e}")
