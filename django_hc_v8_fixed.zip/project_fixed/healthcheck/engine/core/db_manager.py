"""
core/db_manager.py  (v7 - connection-resilient)
================================================
MySQL database connection and query execution.

Features:
  - DictCursor: all rows returned as dicts
  - Auto-reconnect with exponential backoff on lost connection
  - Raises DBConnectionError (a subclass of ConnectionError) on permanent failure
  - insert_environment / insert_oracle_db auto-encrypt passwords
  - transaction() context manager
"""
import logging
import time
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

import pymysql
import pymysql.cursors
from pymysql.err import OperationalError, InterfaceError

logger = logging.getLogger("hc.db")


# ─────────────────────────────────────────────────────────────
# Custom exception — import this to catch DB-down scenarios
# ─────────────────────────────────────────────────────────────
class DBConnectionError(ConnectionError):
    """Raised when MySQL cannot be reached after all retries."""


# ─────────────────────────────────────────────────────────────
# Internal lazy import for config (avoids circular imports)
# ─────────────────────────────────────────────────────────────
def _get_cfg():
    from healthcheck.engine.core.config import DB_CONFIG
    return DB_CONFIG


class DBManager:
    """
    Wraps a single pymysql connection.

    Usage (context manager - preferred):
        with DBManager() as db:
            rows = db.fetch_all("SELECT * FROM customers WHERE is_active=1")

    Usage (explicit):
        db = DBManager()
        db.connect()
        rows = db.fetch_all(...)
        db.disconnect()
    """

    # Reconnect policy
    _MAX_RETRIES   = 1
    _BASE_DELAY    = 2    # seconds
    _MAX_DELAY     = 30   # seconds cap
    _PING_TIMEOUT  = 5    # seconds for ping

    def __init__(self):
        self._conn: Optional[pymysql.Connection] = None
        self._cursor = None

    # ------------------------------------------------------------------ #
    # Connection management
    # ------------------------------------------------------------------ #

    def connect(self, retries: int = None, base_delay: int = None) -> bool:
        """
        Connect to MySQL with exponential backoff.
        Raises DBConnectionError after all attempts fail.
        """
        retries    = retries    if retries    is not None else self._MAX_RETRIES
        base_delay = base_delay if base_delay is not None else self._BASE_DELAY
        cfg = _get_cfg()
        last_exc = None

        for attempt in range(1, retries + 1):
            try:
                self._conn = pymysql.connect(
                    host            = cfg.host,
                    port            = cfg.port,
                    user            = cfg.user,
                    password        = cfg.password,
                    database        = cfg.name,
                    charset         = "utf8mb4",
                    cursorclass     = pymysql.cursors.DictCursor,
                    autocommit      = False,
                    connect_timeout = 10,
                    read_timeout    = 60,
                    write_timeout   = 60,
                )
                self._cursor = self._conn.cursor()
                logger.debug(f"[DBManager] Connected to {cfg.host}/{cfg.name}")
                return True
            except Exception as exc:
                last_exc = exc
                wait = min(base_delay * (2 ** (attempt - 1)), self._MAX_DELAY)
                logger.warning(
                    f"[DBManager] Connect attempt {attempt}/{retries} failed "
                    f"({type(exc).__name__}: {exc}). "
                    f"{'Retrying in ' + str(wait) + 's…' if attempt < retries else 'Giving up.'}"
                )
                if attempt < retries:
                    time.sleep(wait)

        raise DBConnectionError(
            f"Cannot connect to MySQL ({cfg.host}/{cfg.name}) "
            f"after {retries} attempts. Last error: {last_exc}"
        ) from last_exc

    def disconnect(self):
        """Close cursor and connection, silently ignoring errors."""
        for obj in (self._cursor, self._conn):
            try:
                if obj:
                    obj.close()
            except Exception:
                pass
        self._conn = None
        self._cursor = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    def _ensure_connected(self):
        """
        Verify the connection is alive; reconnect transparently if it dropped.
        Uses ping first (fast), falls back to full reconnect on failure.
        """
        if self._conn is None:
            self.connect()
            return

        try:
            self._conn.ping(reconnect=False)
        except (OperationalError, InterfaceError) as exc:
            logger.warning(
                f"[DBManager] Connection lost ({exc}). Attempting reconnect…")
            self.disconnect()
            self.connect()          # raises DBConnectionError if DB is truly down
        except Exception as exc:
            logger.warning(f"[DBManager] Ping unexpected error ({exc}). Reconnecting…")
            self.disconnect()
            self.connect()

    # ------------------------------------------------------------------ #
    # Query helpers
    # ------------------------------------------------------------------ #

    def fetch_all(self, sql: str, params: Optional[tuple] = None) -> List[Dict]:
        """Execute SELECT, return all rows as list of dicts."""
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        return self._cursor.fetchall()

    def fetch_one(self, sql: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """Execute SELECT, return first row as dict or None."""
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        return self._cursor.fetchone()

    def execute(self, sql: str, params: Optional[tuple] = None) -> int:
        """
        Execute INSERT / UPDATE / DELETE.
        Returns number of affected rows. Auto-commits.
        """
        self._ensure_connected()
        affected = self._cursor.execute(sql, params or ())
        self._conn.commit()
        return affected

    def execute_many(self, sql: str, data: List[tuple]) -> int:
        """Bulk INSERT/UPDATE using executemany. Auto-commits."""
        if not data:
            return 0
        self._ensure_connected()
        affected = self._cursor.executemany(sql, data)
        self._conn.commit()
        return affected

    def insert_get_id(self, sql: str, params: Optional[tuple] = None) -> int:
        """Execute INSERT and return the auto-generated primary key."""
        self._ensure_connected()
        self._cursor.execute(sql, params or ())
        self._conn.commit()
        return self._cursor.lastrowid

    @contextmanager
    def transaction(self):
        """
        Context manager for explicit multi-statement transactions.
        Commits on success, rolls back on exception.
        """
        try:
            yield self
            self._conn.commit()
        except Exception:
            try:
                self._conn.rollback()
            except Exception:
                pass
            raise

    # ------------------------------------------------------------------ #
    # Config / query helpers
    # ------------------------------------------------------------------ #

    def get_config(self, key: str, default: str = "") -> str:
        row = self.fetch_one(
            "SELECT config_value FROM system_config WHERE config_key=%s", (key,))
        return row["config_value"] if row else default

    def get_oracle_query(self, query_key: str) -> str:
        row = self.fetch_one(
            "SELECT query_sql FROM oracle_queries WHERE query_key=%s AND is_active=1",
            (query_key,))
        if not row:
            raise ValueError(
                f"Oracle query key '{query_key}' not found in oracle_queries. "
                f"Add it with the correct SQL, or check is_active=1.")
        return row["query_sql"]

    # ------------------------------------------------------------------ #
    # Password-encrypting insert helpers
    # ------------------------------------------------------------------ #

    def insert_environment(self, customer_id, env_type, server_user,
                            plain_password) -> int:
        from healthcheck.engine.utils.crypto import encrypt_password
        encrypted = encrypt_password(plain_password)
        return self.insert_get_id(
            "INSERT INTO environments (customer_id,env_type,server_user,server_pwd) "
            "VALUES (%s,%s,%s,%s)",
            (customer_id, env_type, server_user, encrypted))

    def insert_oracle_database(self, server_id, db_name, db_type,
                                db_user, plain_password, port=1521) -> int:
        from healthcheck.engine.utils.crypto import encrypt_password
        encrypted = encrypt_password(plain_password)
        return self.insert_get_id(
            "INSERT INTO oracle_databases "
            "(server_id,db_name,db_type,db_user,db_pwd,port) "
            "VALUES (%s,%s,%s,%s,%s,%s)",
            (server_id, db_name, db_type, db_user, encrypted, port))

    def update_environment_password(self, env_id: int, plain_password: str):
        from healthcheck.engine.utils.crypto import encrypt_password
        self.execute(
            "UPDATE environments SET server_pwd=%s WHERE id=%s",
            (encrypt_password(plain_password), env_id))

    def update_oracle_db_password(self, db_id: int, plain_password: str):
        from healthcheck.engine.utils.crypto import encrypt_password
        self.execute(
            "UPDATE oracle_databases SET db_pwd=%s WHERE id=%s",
            (encrypt_password(plain_password), db_id))


# ─────────────────────────────────────────────────────────────
# Health check utility — used by middleware + views
# ─────────────────────────────────────────────────────────────
def check_db_health() -> dict:
    """
    Quick non-blocking DB health check.
    Returns {"ok": True/False, "error": str|None, "latency_ms": float|None}
    """
    import time as _time
    t0 = _time.monotonic()
    try:
        with DBManager() as db:
            db.fetch_one("SELECT 1 AS ok")
        return {"ok": True,  "error": None,
                "latency_ms": round((_time.monotonic() - t0) * 1000, 1)}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "latency_ms": None}
