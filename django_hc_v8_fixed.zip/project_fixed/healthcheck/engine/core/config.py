"""
core/config.py  (v5)
====================
All runtime config loaded from database. Nothing hardcoded.
DB connection comes from env vars HC_DB_* only.
"""
import os
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class DBConfig:
    """MySQL connection from environment variables."""
    host:     str = field(default_factory=lambda: os.getenv("HC_DB_HOST", "localhost"))
    port:     int = field(default_factory=lambda: int(os.getenv("HC_DB_PORT", "3306")))
    name:     str = field(default_factory=lambda: os.getenv("HC_DB_NAME", "hc_v5"))
    user:     str = field(default_factory=lambda: os.getenv("HC_DB_USER", "admin"))
    password: str = field(default_factory=lambda: os.getenv("HC_DB_PASSWORD", ""))


@dataclass
class MailConfig:
    """SMTP settings from mail_config table."""
    smtp_host:     str           = ""
    smtp_port:     int           = 587
    use_tls:       bool          = True
    smtp_user:     str           = ""
    smtp_password: str           = ""
    from_address:  str           = ""
    reply_to:      Optional[str] = None


@dataclass
class AppConfig:
    """All runtime settings. Loaded once from DB at startup."""
    excel_output_path:    str   = "C:\\cloudFTP\\Health-Check-OUT\\Excel"
    log_output_path:      str   = "C:\\cloudFTP\\Health-Check-OUT\\Log"
    oracle_dll_path:      str   = ""
    excel_title_prefix:   str   = "Health Check Report"
    conn_retry_attempts:  int   = 3
    conn_retry_delay_sec: int   = 10
    disk_free_threshold_gb: float = 10.0
    tablespace_free_pct:  float = 25.0
    rerun_interval_hours:      int   = 24
    rerun_max_attempts:        int   = 3
    log_retention_days:        int   = 90
    stuck_run_timeout_minutes: int   = 90   # minutes before a run is marked stuck
    timezone:                  str   = "Asia/Kolkata"  # always IST
    mail: MailConfig = field(default_factory=MailConfig)
    templates: Dict[str, Dict[str, str]] = field(default_factory=dict)


class ConfigLoader:
    """Loads AppConfig once and caches. Call load(db) at startup."""
    _cfg: Optional[AppConfig] = None

    @classmethod
    def load(cls, db) -> AppConfig:
        if cls._cfg is not None:
            return cls._cfg
        rows = db.fetch_all("SELECT config_key, config_value FROM system_config")
        raw = {r["config_key"]: r["config_value"] for r in rows}

        def s(k, d=""): return raw.get(k, d)
        def i(k, d=0):
            try: return int(raw.get(k, d))
            except: return d
        def f(k, d=0.0):
            try: return float(raw.get(k, d))
            except: return d

        mail_cfg = MailConfig()
        try:
            row = db.fetch_one("SELECT * FROM mail_config WHERE is_active=1 ORDER BY id LIMIT 1")
            if row:
                mail_cfg = MailConfig(
                    smtp_host=row["smtp_host"], smtp_port=int(row["smtp_port"]),
                    use_tls=bool(row["use_tls"]),
                    smtp_user=row["smtp_user"], smtp_password=row["smtp_password"],
                    from_address=row["from_address"], reply_to=row.get("reply_to"))
        except Exception:
            pass

        templates: Dict[str, Dict[str, str]] = {}
        try:
            for tr in db.fetch_all(
                "SELECT template_key,subject_template,body_html FROM mail_templates WHERE is_active=1"
            ):
                templates[tr["template_key"]] = {
                    "subject": tr["subject_template"], "body_html": tr["body_html"]}
        except Exception:
            pass

        cls._cfg = AppConfig(
            excel_output_path    =s("excel_output_path",     "C:\\cloudFTP\\Health-Check-OUT\\Excel"),
            log_output_path      =s("log_output_path",       "C:\\cloudFTP\\Health-Check-OUT\\Log"),
            oracle_dll_path      =s("oracle_dll_path",       ""),
            excel_title_prefix   =s("excel_title_prefix",    "Health Check Report"),
            conn_retry_attempts  =i("conn_retry_attempts",   3),
            conn_retry_delay_sec =i("conn_retry_delay_sec",  10),
            disk_free_threshold_gb=f("disk_free_threshold_gb", 10.0),
            tablespace_free_pct  =f("tablespace_free_pct",   25.0),
            rerun_interval_hours      =i("rerun_interval_hours",         24),
            rerun_max_attempts        =i("rerun_max_attempts",           3),
            log_retention_days        =i("log_retention_days",           90),
            stuck_run_timeout_minutes =i("stuck_run_timeout_minutes",    90),
            timezone                  =s("timezone",                     "Asia/Kolkata"),
            mail=mail_cfg, templates=templates,
        )
        return cls._cfg

    @classmethod
    def get(cls) -> AppConfig:
        if cls._cfg is None:
            raise RuntimeError("ConfigLoader.load(db) must be called at startup first.")
        return cls._cfg

    @classmethod
    def reset(cls):
        cls._cfg = None


DB_CONFIG = DBConfig()
