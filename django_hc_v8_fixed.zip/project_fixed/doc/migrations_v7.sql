-- ============================================================
-- Health Check v7 — Database Migration Script
-- Run this on your hc_v5 MySQL database BEFORE deploying v7
-- ============================================================

-- 1. Rename last_escalated_at → last_escalation_at in issue_tracker
ALTER TABLE issue_tracker
  CHANGE COLUMN last_escalated_at last_escalation_at DATETIME NULL DEFAULT NULL;

-- 2. Add start_at column to schedules table
ALTER TABLE schedules
  ADD COLUMN start_at DATETIME NULL DEFAULT NULL
  COMMENT 'When this schedule should first fire. NULL = fire immediately at next cron tick.'
  AFTER is_active;

-- 3. Create scheduler_tracker table
CREATE TABLE IF NOT EXISTS scheduler_tracker (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  schedule_id         INT UNSIGNED NULL,
  customer_id         INT UNSIGNED NOT NULL,
  env_types           VARCHAR(50) NOT NULL,
  schedule_name       VARCHAR(200) NOT NULL DEFAULT '',
  cron_expression     VARCHAR(100) NOT NULL DEFAULT '',
  run_id              BIGINT UNSIGNED NULL,
  status              ENUM('PENDING','RUNNING','COMPLETED','FAILED','FAILED_QUEUE','SKIPPED')
                      NOT NULL DEFAULT 'PENDING',
  scheduled_fire_at   DATETIME NOT NULL
                      COMMENT 'UTC datetime this entry was supposed to fire',
  actual_start_at     DATETIME NULL,
  completed_at        DATETIME NULL,
  last_run_at         DATETIME NULL,
  next_run_at         DATETIME NULL,
  error_message       TEXT NULL,
  is_active           TINYINT(1) NOT NULL DEFAULT 1
                      COMMENT 'Admin can deactivate / re-queue entries',
  triggered_by        VARCHAR(100) NOT NULL DEFAULT 'scheduler',
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_st_customer  (customer_id),
  KEY idx_st_schedule  (schedule_id),
  KEY idx_st_status    (status),
  KEY idx_st_fire_at   (scheduled_fire_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Tracks every APScheduler firing event for audit and admin management.';

-- 4. Verify columns exist (run manually to double-check)
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
--   WHERE TABLE_SCHEMA='hc_v5' AND TABLE_NAME='issue_tracker'
--   AND COLUMN_NAME='last_escalation_at';
--
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
--   WHERE TABLE_SCHEMA='hc_v5' AND TABLE_NAME='schedules'
--   AND COLUMN_NAME='start_at';
--
-- SHOW TABLES LIKE 'scheduler_tracker';

-- ============================================================
-- END OF MIGRATION
-- ============================================================

-- ── v7.1 additions ──────────────────────────────────────────────────
-- Add last_error to rerun_queue for fail reason tracking
ALTER TABLE rerun_queue
  ADD COLUMN IF NOT EXISTS last_error TEXT NULL
  COMMENT 'Reason the run failed and was queued for retry';

-- Add error_summary to execution_runs for crashed/killed runs
ALTER TABLE execution_runs
  ADD COLUMN IF NOT EXISTS error_summary TEXT NULL
  COMMENT 'Error captured when run fails/crashes/is killed';

-- stuck_run_timeout_minutes config (default 90 min)
INSERT IGNORE INTO system_config (config_key, config_value, description)
VALUES ('stuck_run_timeout_minutes', '90',
        'Minutes before an IN_PROGRESS run is considered stuck and marked FAILED');

-- ============================================================
-- v8 MIGRATIONS (run after v7)
-- ============================================================

-- Add send_resolved_mail and customer_env_mail to escalation_config
ALTER TABLE escalation_config
    ADD COLUMN IF NOT EXISTS send_resolved_mail  TINYINT(1) NOT NULL DEFAULT 0
        COMMENT 'Send email when escalated issue resolves',
    ADD COLUMN IF NOT EXISTS customer_env_mail   TINYINT(1) NOT NULL DEFAULT 0
        COMMENT 'Future: send customer-facing env mail';

-- Ensure last_run_at / next_run_at exist on schedules (IST stored as DATETIME)
ALTER TABLE schedules
    MODIFY COLUMN IF EXISTS last_run_at  DATETIME NULL COMMENT 'IST wall-clock time of last run',
    MODIFY COLUMN IF EXISTS next_run_at  DATETIME NULL COMMENT 'IST wall-clock time of next run';
