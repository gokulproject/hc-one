-- ============================================================
-- dbconnection_checker Schema  (v8.1)
-- Oracle DB connection checker — NO WMI
--
-- Fresh install:
--   mysql -u root -p < schema.sql
--
-- Existing v8 install — run alter instead:
--   mysql -u root -p < schema_alter.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS dbconnection_checker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE dbconnection_checker;

-- ── Email config ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_config (
    id          INT           NOT NULL AUTO_INCREMENT,
    config_name VARCHAR(100)  NOT NULL DEFAULT 'default',
    smtp_host   VARCHAR(255)  NOT NULL,
    smtp_port   INT           NOT NULL DEFAULT 587,
    smtp_user   VARCHAR(255)  NOT NULL,
    smtp_pass   VARCHAR(255)  NOT NULL,
    use_tls     TINYINT(1)    NOT NULL DEFAULT 1,
    from_addr   VARCHAR(255)  NOT NULL,
    to_addr     TEXT          NOT NULL,
    cc_addr     TEXT          NULL,
    bcc_addr    TEXT          NULL,
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── App config ─────────────────────────────────────────────────
-- Keys: excel_path, log_path, oracle_dll_path,
--       config_customers, config_envs, config_dbtype, report_label
CREATE TABLE IF NOT EXISTS app_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value VARCHAR(500)  NOT NULL DEFAULT '',
    description  VARCHAR(500)  NULL,
    updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Process run — one row per execution ───────────────────────
CREATE TABLE IF NOT EXISTS process_run (
    id                  INT          NOT NULL AUTO_INCREMENT,
    status              VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',
                        -- RUNNING | COMPLETED | PARTIAL | FAILED | SKIPPED | NO_DATA
    db_type             VARCHAR(100) NULL,

    execution_start_at  DATETIME     NULL    COMMENT 'When the run started',
    execution_end_at    DATETIME     NULL    COMMENT 'When the run ended (success, fail, or manual stop)',

    total_envs          INT          NOT NULL DEFAULT 0   COMMENT 'Total Oracle DB rows processed',
    success_count       INT          NOT NULL DEFAULT 0   COMMENT 'DB CONNECTED',
    fail_count          INT          NOT NULL DEFAULT 0   COMMENT 'DB NOT CONNECTED',
    skipped_count       INT          NOT NULL DEFAULT 0   COMMENT 'SKIPPED',

    excel_path          VARCHAR(500) NULL    COMMENT 'Full path to generated Excel file',
    log_file            VARCHAR(500) NULL    COMMENT 'Full path to per-run log file',

    email_sent_status   VARCHAR(20)  NULL    COMMENT 'SENT | FAILED | SKIPPED',
    email_sent_error    TEXT         NULL    COMMENT 'Error detail if email failed',

    created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Oracle DB connection result — one row per Oracle DB ───────
CREATE TABLE IF NOT EXISTS process_db_connection_result (
    id                 INT           NOT NULL AUTO_INCREMENT,
    run_id             INT           NOT NULL,
    customer_id        INT           NOT NULL,
    customer_name      VARCHAR(255)  NOT NULL,
    env_type           VARCHAR(50)   NOT NULL,

    -- DB Server mapping (from health_check.Servers)
    server_id          INT           NOT NULL DEFAULT 0,
    server_name        VARCHAR(255)  NOT NULL DEFAULT '',
    server_host        VARCHAR(255)  NOT NULL DEFAULT '',

    -- Oracle DB (from health_check.OracleDatabase)
    db_name            VARCHAR(255)  NOT NULL DEFAULT '',
    db_type            VARCHAR(50)   NOT NULL DEFAULT '',
    db_host            VARCHAR(255)  NOT NULL DEFAULT '',
    db_port            INT           NOT NULL DEFAULT 1521,
    db_service         VARCHAR(255)  NOT NULL DEFAULT '',

    -- Result
    connection_status  VARCHAR(20)   NOT NULL DEFAULT 'FAILED',
                       -- COMPLETED | FAILED | SKIPPED
    error_message      TEXT          NULL,
    error_type         VARCHAR(30)   NOT NULL DEFAULT '',
                       -- TCP_TIMEOUT | PASSWORD | UNKNOWN | (empty if connected)

    duration_ms        INT           NOT NULL DEFAULT 0,
    checked_at         DATETIME      NOT NULL,

    PRIMARY KEY (id),
    KEY idx_run_id     (run_id),
    KEY idx_customer   (customer_id),
    KEY idx_env        (env_type),
    KEY idx_db_type    (db_type),
    KEY idx_db_status  (connection_status),
    KEY idx_error_type (error_type),
    KEY idx_checked_at (checked_at),
    CONSTRAINT fk_result_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Step audit log ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS process_run_log (
    id         INT          NOT NULL AUTO_INCREMENT,
    run_id     INT          NOT NULL,
    step_no    INT          NOT NULL DEFAULT 0,
    step_name  VARCHAR(100) NOT NULL,
    status     VARCHAR(20)  NOT NULL,
    message    TEXT         NULL,
    customer   VARCHAR(255) NULL,
    env_type   VARCHAR(50)  NULL,
    logged_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_run_id  (run_id),
    KEY idx_log_step_no (step_no),
    CONSTRAINT fk_log_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Default config ────────────────────────────────────────────
INSERT INTO app_config (config_key, config_value, description) VALUES
  ('excel_path',       'Excel',  'Folder where Excel reports are saved'),
  ('log_path',         'Logs',   'Folder where log files are written'),
  ('oracle_dll_path',  '',       'Oracle Instant Client folder (empty = thin mode, WARNING logged)'),
  ('config_customers', '',       'Comma-sep customer names; empty = ALL active'),
  ('config_envs',      '',       'Comma-sep envs (DEV,VAL,PRD); empty = ALL'),
  ('config_dbtype',    'FMW',    'DatabaseType to check (e.g. FMW or FMW,OAM)'),
  ('report_label',     'FMW',    'Display name in Excel/email — update with config_dbtype')
ON DUPLICATE KEY UPDATE description = VALUES(description);

INSERT INTO email_config
  (config_name, smtp_host, smtp_port, smtp_user, smtp_pass,
   use_tls, from_addr, to_addr, cc_addr, bcc_addr, is_active)
VALUES
  ('default', 'smtp.company.com', 587,
   'alerts@company.com', 'email_password', 1,
   'alerts@company.com', 'team@company.com', '', '', 1)
ON DUPLICATE KEY UPDATE smtp_host = VALUES(smtp_host);
