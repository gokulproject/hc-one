-- ============================================================
-- ALTER SCRIPT — dbconnection_checker (v8 -> v8.1)
-- Run this on your EXISTING dbconnection_checker schema.
-- (If creating fresh, just use schema.sql — it already has these.)
-- ============================================================

USE dbconnection_checker;

-- 1. Rename started_at -> execution_start_at
ALTER TABLE process_run
    CHANGE COLUMN started_at     execution_start_at  DATETIME NULL,
    CHANGE COLUMN completed_at   execution_end_at    DATETIME NULL;

-- 2. Add email columns if not already present (idempotent)
ALTER TABLE process_run
    ADD COLUMN IF NOT EXISTS email_sent_status VARCHAR(20) NULL
        COMMENT 'SENT | FAILED | SKIPPED'
        AFTER log_file,
    ADD COLUMN IF NOT EXISTS email_sent_error  TEXT        NULL
        COMMENT 'Error message if email failed'
        AFTER email_sent_status;

-- 3. Rename old email columns if they exist from v7/v8
-- (email_status -> email_sent_status, email_error -> email_sent_error)
-- Only run these if you have the old column names:
-- ALTER TABLE process_run
--     CHANGE COLUMN email_status email_sent_status VARCHAR(20) NULL,
--     CHANGE COLUMN email_error  email_sent_error  TEXT NULL;

-- 4. Confirm final structure
DESCRIBE process_run;
