"""
checker.py
==========
Database Connection Checker (generic — DB type is dynamic).

STRICT FLOW per requirement:
  FOR each Customer:
    Check customer exists -> if not, log + skip
    FOR each Environment (DEV/VAL/PRD or filtered):
      Check environment exists -> if not, log + skip
      Identify DB Server (host) from Servers table
      STEP A: DB Server connection check via WMI (WMI ONLY)
        Credentials: Environments.ServerUser + Environments.ServerPwd
        IF NOT connected -> log full error, mark NOT CONNECTED, skip Step B
        IF connected     -> proceed to Step B
      STEP B: Target DB connection check
        IF connected  -> status COMPLETED
        IF not        -> capture full error, status FAILED
      ONE ROW per environment written to process_db_connection_result

Reads from : health_check schema (READ ONLY)
Writes to  : dbconnection_checker schema (process_db_connection_result + process_run_log)

config_customers -> empty = ALL active, populated = only those names
config_envs      -> empty = ALL (DEV,VAL,PRD), populated = only those types
config_dbtype    -> DatabaseType(s) to check (e.g. ['FMW'] or ['FMW','OAM']).
                    DYNAMIC — change in app_config.config_dbtype, no code
                    change needed when the DB type changes in future.
"""
import logging
import os
import sys
import time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.crypto     import decrypt_password, is_encrypted
from Common.db_manager import DBManager
from config            import HC_DB, FMWCHECKS_DB

logger = logging.getLogger("checker.checker")

ALL_ENV_TYPES = ["DEV", "VAL", "PRD"]
IST_OFFSET    = timedelta(hours=5, minutes=30)


def _now_ist() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


class Checker:

    def __init__(self, run_id: int, app_cfg=None):
        self.run_id            = run_id
        self.cfg               = app_cfg
        # NOTE: oracle_timeout is read for backward-compat but is no
        # longer passed to oracledb.connect() — it caused crashes on
        # some driver versions (see _check_db_connection).
        self._oracle_timeout   = getattr(app_cfg, "oracle_timeout",   15) if app_cfg else 15
        self._oracle_dll_path  = getattr(app_cfg, "oracle_dll_path",  "") if app_cfg else ""
        self._config_customers = getattr(app_cfg, "config_customers", []) if app_cfg else []
        self._config_envs      = getattr(app_cfg, "config_envs",      []) if app_cfg else []

        # ── Dynamic DB type(s) to check — drives the DatabaseType filter
        #    and the report label. Change in app_config, not here.
        self.db_types  = getattr(app_cfg, "config_dbtype", ["FMW"]) if app_cfg else ["FMW"]
        self.db_label  = getattr(app_cfg, "report_label", "/".join(self.db_types)) \
            if app_cfg else "/".join(self.db_types)

        self._setup_oracle_client()

    # ── Oracle client init ────────────────────────────────────────────────────
    def _setup_oracle_client(self):
        try:
            import oracledb
            dll = self._oracle_dll_path
            if dll and os.path.isdir(dll) and os.listdir(dll):
                oracledb.init_oracle_client(lib_dir=dll)
                logger.info(f"[STEP-5] Oracle thick client initialised: {dll}")
            else:
                logger.info("[STEP-5] Oracle thin client mode (no DLL path configured)")
        except Exception as exc:
            logger.warning(f"[STEP-5] Oracle client init warning: {exc}")

    # ── STEP A: DB Server check via WMI (WMI ONLY — no socket fallback) ───────
    def _check_server_wmi(self, host: str,
                           username: str, password: str) -> tuple:
        """
        Connect to Windows server via WMI using server credentials.
        Credentials from health_check.Environments (ServerUser, ServerPwd).

        WMI-ONLY: if the wmi module is missing or the connection fails,
        the server is marked NOT CONNECTED (no socket fallback). This
        avoids false-positive "connected" results from a fallback check
        that doesn't actually verify the same thing as WMI.

        Returns (connected: bool, error: str|None, duration_ms: int)
        """
        logger.info(
            f"    [STEP-5A] WMI server check -> host={host} | user={username}")
        start = time.time()
        conn  = None
        try:
            import wmi

            # Handle domain\\user format (clean extra backslashes)
            clean_user = username.replace("\\\\", "\\") if username else username

            conn = wmi.WMI(
                computer = host,
                user     = clean_user,
                password = password
            )

            # Simple query to confirm WMI connection is live
            conn.Win32_OperatingSystem()

            ms = int((time.time() - start) * 1000)
            logger.info(
                f"    [STEP-5A] CONNECTED (WMI) | host={host} | {ms}ms")
            return True, None, ms

        except ImportError:
            ms  = int((time.time() - start) * 1000)
            err = ("WMI module not available on this host — "
                   "install with: pip install WMI pywin32 (Windows only). "
                   "Server connection check is WMI-ONLY, marking NOT CONNECTED.")
            logger.error(f"    [STEP-5A] NOT CONNECTED (WMI unavailable) | {host} | {err}")
            return False, err, ms

        except Exception as exc:
            ms  = int((time.time() - start) * 1000)
            err = str(exc)
            logger.error(
                f"    [STEP-5A] NOT CONNECTED (WMI) | "
                f"host={host} | user={username} | "
                f"Error: {err}")
            return False, err, ms

        finally:
            # Properly release the WMI connection object every time —
            # success or failure.
            if conn is not None:
                try:
                    del conn
                except Exception:
                    pass
                conn = None
            logger.debug(f"    [STEP-5A] WMI connection closed/released | host={host}")

    # ── STEP B: Target DB connection check ────────────────────────────────────
    def _check_db_connection(self, db_info: dict) -> tuple:
        """
        Connect to the target Oracle DB using oracledb, verify, and
        ALWAYS close the connection (success or failure path).

        Returns (connected: bool, error: str|None, duration_ms: int)
        """
        import oracledb

        host    = db_info.get("db_host",    "")
        port    = int(db_info.get("db_port", 1521))
        service = db_info.get("db_service", "")
        user    = db_info.get("db_user",    "")
        pwd_raw = db_info.get("db_password",  "")
        name    = db_info.get("db_name",    "?")
        db_type = db_info.get("db_type",    "")
        cname   = db_info.get("customer_name", "")
        env     = db_info.get("env_type",   "")

        # Decrypt target DB password
        try:
            password = decrypt_password(pwd_raw) if is_encrypted(pwd_raw) else pwd_raw
        except Exception as de:
            logger.warning(f"    [STEP-6B] Password decrypt warning: {de} — using raw")
            password = pwd_raw

        dsn = f"{host}:{port}/{service}"
        logger.info(
            f"    [STEP-6B] {db_type} DB check -> "
            f"{cname}/{env} | DB={name} | DSN={dsn} | user={user}")

        start = time.time()
        conn  = None
        connected = False
        error = None

        try:
            # NOTE: 'timeout' kwarg removed — on some oracledb/driver
            # combinations passing timeout to connect() raised an
            # unrelated error and crashed the whole run. Connection
            # attempts now rely on the driver's own default behaviour.
            conn = oracledb.connect(
                user     = user,
                password = password,
                dsn      = dsn
            )
            connected = True
            ms = int((time.time() - start) * 1000)
            logger.info(
                f"    [STEP-6B] CONNECTED ({db_type}) | "
                f"{cname}/{env} | DB={name} | {ms}ms")

        except Exception as exc:
            ms    = int((time.time() - start) * 1000)
            error = str(exc)   # FULL error captured, not truncated
            logger.error(
                f"    [STEP-6B] NOT CONNECTED ({db_type}) | "
                f"{cname}/{env} | DB={name} | Error: {error}")

        finally:
            # Always close the connection if it was opened — regardless
            # of whether the try block succeeded or raised afterwards.
            if conn is not None:
                try:
                    conn.close()
                    logger.debug(
                        f"    [STEP-6B] Connection closed | {cname}/{env} | DB={name}")
                except Exception as ce:
                    logger.warning(
                        f"    [STEP-6B] Error while closing connection | "
                        f"{cname}/{env} | DB={name} | {ce}")
                conn = None

        return connected, error, ms

    # ── HC schema queries (READ ONLY) ─────────────────────────────────────────
    def _load_customers(self, db) -> list:
        """Load customers from health_check.Customers"""
        if self._config_customers:
            ph   = ",".join(["%s"] * len(self._config_customers))
            rows = db.fetch_all(
                f"""SELECT CustomerID   AS customer_id,
                           CustomerName AS customer_name
                    FROM Customers
                    WHERE CustomerName IN ({ph}) AND Status=1
                    ORDER BY CustomerName""",
                tuple(self._config_customers))
            logger.info(
                f"[STEP-3] Filtered customers: "
                f"{self._config_customers} -> found {len(rows)}")
        else:
            rows = db.fetch_all(
                """SELECT CustomerID   AS customer_id,
                          CustomerName AS customer_name
                   FROM Customers
                   WHERE Status=1
                   ORDER BY CustomerName""")
            logger.info(f"[STEP-3] All active customers: {len(rows)} found")
        return rows

    def _load_envs(self, db, customer_id: int) -> list:
        """
        Load environments for a customer.
        Includes ServerUser + ServerPwd for WMI authentication.
        """
        scope = self._config_envs if self._config_envs else ALL_ENV_TYPES
        ph    = ",".join(["%s"] * len(scope))
        return db.fetch_all(
            f"""SELECT EnvID      AS env_id,
                       ServerType AS env_type,
                       ServerUser AS server_user,
                       ServerPwd  AS server_pwd
                FROM Environments
                WHERE CustomerID=%s
                  AND ServerType IN ({ph})
                  AND Status=1
                ORDER BY FIELD(ServerType,'DEV','VAL','PRD')""",
            tuple([customer_id] + scope))

    def _load_server(self, db, env_id: int) -> dict:
        """
        Load DB server details from health_check.Servers.
        Filtered to ServerName='DB Server' — the row representing the
        database host (as opposed to app/web servers in the same env).
        """
        return db.fetch_one(
            """SELECT ServerID   AS server_id,
                      ServerName AS server_name,
                      Host       AS host
               FROM Servers
               WHERE EnvID=%s
                 AND ServerName='DB Server'
                 AND Status=1
               LIMIT 1""",
            (env_id,))

    def load_db_types(self, db, server_id: int) -> list:
        """
        Load target databases from health_check.OracleDatabase whose
        DatabaseType is in the configured db_types list (app_config.config_dbtype).

        DYNAMIC: db_types comes from config — change app_config.config_dbtype
        (e.g. 'FMW' -> 'OAM' or 'FMW,OAM') without touching this code.
        """
        ph = ",".join(["%s"] * len(self.db_types))
        return db.fetch_all(
            f"""SELECT dbid     AS db_id,
                       OrdName  AS db_name,
                       OrdName  AS db_service,
                       Port     AS db_port,
                       User     AS db_user,
                       Password AS db_password,
                       DatabaseType AS db_type
                FROM OracleDatabase
                WHERE ServerID=%s
                  AND DatabaseType IN ({ph})
                  AND Status=1""",
            tuple([server_id] + self.db_types))

    # ── Save one result row (one per environment) ─────────────────────────────
    def _save_result(self, result: dict):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO process_db_connection_result
                       (run_id, customer_id, customer_name, env_type,
                        server_host, server_status, server_error,
                        db_name, db_type, db_host, db_port, db_service,
                        connection_status, error_message,
                        duration_ms, checked_at)
                       VALUES
                       (%s,%s,%s,%s, %s,%s,%s, %s,%s,%s,%s,%s, %s,%s, %s,%s)""",
                    (result["run_id"],
                     result["customer_id"],  result["customer_name"],
                     result["env_type"],
                     result["server_host"],  result["server_status"],
                     result["server_error"],
                     result["db_name"],      result["db_type"],
                     result["db_host"],
                     result["db_port"],      result["db_service"],
                     result["connection_status"], result["error_message"],
                     result["duration_ms"],  result["checked_at"]))
        except Exception as exc:
            logger.error(f"[STEP-7] Failed to save result: {exc}")

    # ── Log step ──────────────────────────────────────────────────────────────
    def _log_step(self, step_no: int, step_name: str, status: str,
                  message: str = "", customer: str = "", env_type: str = ""):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO process_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     message[:2000] if message else "",
                     customer[:255] if customer else "",
                     env_type[:50]  if env_type  else ""))
        except Exception as exc:
            logger.warning(f"Step log write failed: {exc}")

    # ── Build a result row for ANY case — normal check OR a "not
    #    found / skipped" case. Every row produced here is written to
    #    process_db_connection_result AND appears in the Excel report,
    #    so nothing is silently dropped. ──────────────────────────────────────
    def _make_result(self, cid, cname, env_type,
                      server_host="", server_status="NOT CONNECTED",
                      server_error=None,
                      db_name="", db_type=None, db_host="", db_port=0,
                      db_service="",
                      connection_status="SKIPPED", error_message="",
                      duration_ms=0) -> dict:
        return {
            "run_id":            self.run_id,
            "customer_id":       cid,
            "customer_name":     cname,
            "env_type":          env_type,
            "server_host":       server_host,
            "server_status":     server_status,
            "server_error":      server_error,
            "db_name":           db_name,
            "db_type":           db_type if db_type is not None else "/".join(self.db_types),
            "db_host":           db_host,
            "db_port":           db_port,
            "db_service":        db_service,
            "connection_status": connection_status,
            "error_message":     error_message,
            "duration_ms":       duration_ms,
            "checked_at":        datetime.utcnow(),
        }

    # ── MAIN LOOP ─────────────────────────────────────────────────────────────
    def run_all(self) -> list:
        """
        Full Customer -> Environment -> Server(WMI) -> DB check loop.
        Returns list of result dicts (one per environment/db processed).
        """
        results   = []
        env_scope = self._config_envs if self._config_envs else ALL_ENV_TYPES

        logger.info("")
        logger.info(
            f"[STEP-3] Loading customers | env_scope={env_scope} | "
            f"db_types={self.db_types} | {_now_ist()}")
        self._log_step(
            3, "IDENTIFY_CUSTOMERS", "STARTED",
            f"customer_filter={'ALL' if not self._config_customers else self._config_customers} | "
            f"env_filter={'ALL' if not self._config_envs else self._config_envs} | "
            f"db_type_filter={self.db_types}")

        # ── Step 3: Load customers ────────────────────────────────────────────
        try:
            with DBManager(cfg=HC_DB) as db:
                customers = self._load_customers(db)
        except Exception as exc:
            logger.error(
                f"[STEP-3] FATAL: Cannot load customers: {exc}", exc_info=True)
            self._log_step(3, "IDENTIFY_CUSTOMERS", "FAILED", str(exc))
            return []

        if not customers:
            logger.warning("[STEP-3] No active customers found — nothing to check")
            self._log_step(3, "IDENTIFY_CUSTOMERS", "SKIPPED",
                           "No active customers found")
            return []

        self._log_step(3, "IDENTIFY_CUSTOMERS", "COMPLETED",
                       f"{len(customers)} customer(s) found")

        # ── Customer loop ─────────────────────────────────────────────────────
        for cust in customers:
            cid   = cust["customer_id"]
            cname = cust["customer_name"]

            logger.info("")
            logger.info(f"{'─' * 60}")
            logger.info(f"[STEP-3] ▶ Customer: {cname} (ID={cid})")

            # ── Step 4: Load environments ─────────────────────────────────────
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "STARTED",
                           f"scope={env_scope}", cname)
            try:
                with DBManager(cfg=HC_DB) as db:
                    envs = self._load_envs(db, cid)
            except Exception as exc:
                logger.error(
                    f"[STEP-4] Cannot load environments for {cname}: {exc}")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "FAILED",
                               str(exc), cname)
                continue

            if not envs:
                env_label = ",".join(env_scope)
                warn = (f"No active environment found for customer "
                        f"(env filter={env_scope})")
                logger.warning(
                    f"[STEP-4] {warn} | '{cname}' — recording SKIPPED row")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "SKIPPED",
                               warn, cname)

                result = self._make_result(
                    cid, cname, env_label,
                    server_status="NOT FOUND",
                    server_error=warn,
                    connection_status="SKIPPED",
                    error_message=warn)
                self._save_result(result)
                results.append(result)
                self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                               "Environment=NOT FOUND | recorded in Excel",
                               cname, env_label)
                continue

            env_types_found = [e["env_type"] for e in envs]
            logger.info(
                f"[STEP-4] Environments for {cname}: {env_types_found}")
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "COMPLETED",
                           f"found: {env_types_found}", cname)

            # ── Environment loop ──────────────────────────────────────────────
            for env in envs:
                env_id      = env["env_id"]
                env_type    = env["env_type"]
                srv_user_raw = env.get("server_user", "") or ""
                srv_pwd_raw  = env.get("server_pwd",  "") or ""

                # Decrypt server password for WMI
                try:
                    srv_pwd = (decrypt_password(srv_pwd_raw)
                               if is_encrypted(srv_pwd_raw)
                               else srv_pwd_raw)
                except Exception:
                    srv_pwd = srv_pwd_raw

                logger.info("")
                logger.info(
                    f"[STEP-4] ── {cname} / {env_type} "
                    f"(EnvID={env_id}) ──────────")

                # ── Identify DB Server ────────────────────────────────────────
                try:
                    with DBManager(cfg=HC_DB) as db:
                        server = self._load_server(db, env_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-5] Cannot load server for "
                        f"{cname}/{env_type}: {exc}")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "FAILED",
                                   str(exc), cname, env_type)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_status="UNKNOWN",
                        server_error=f"DB lookup error: {exc}",
                        connection_status="SKIPPED",
                        error_message=f"Server lookup failed: {exc}")
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                                   "DB Server lookup error | recorded in Excel",
                                   cname, env_type)
                    continue

                if not server:
                    msg = "No active server record found in DB"
                    logger.warning(
                        f"[STEP-5] {msg} for "
                        f"{cname}/{env_type} — recording SKIPPED row")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "SKIPPED",
                                   msg, cname, env_type)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_status="NOT FOUND",
                        server_error=msg,
                        connection_status="SKIPPED",
                        error_message=msg)
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                                   "DB Server=NOT FOUND | recorded in Excel",
                                   cname, env_type)
                    continue

                server_host = server["host"]
                server_id   = server["server_id"]
                server_name = server.get("server_name", "")

                logger.info(
                    f"[STEP-5] DB Server: {server_name} "
                    f"| host={server_host} (ID={server_id}) "
                    f"| {cname}/{env_type}")
                self._log_step(5, "IDENTIFY_DB_SERVER", "COMPLETED",
                               f"server={server_name} host={server_host}",
                               cname, env_type)

                # ── STEP A: WMI Server Connection Check (WMI ONLY) ────────────
                logger.info(
                    f"[STEP-5A] WMI check: {cname}/{env_type} -> {server_host} "
                    f"| user={srv_user_raw}")
                self._log_step(5, "DB_SERVER_WMI_CHECK", "STARTED",
                               f"host={server_host} user={srv_user_raw}",
                               cname, env_type)

                srv_ok, srv_err, srv_ms = self._check_server_wmi(
                    host     = server_host,
                    username = srv_user_raw,
                    password = srv_pwd
                )

                if not srv_ok:
                    # Server unreachable — record row, skip DB check
                    logger.error(
                        f"[STEP-5A] NOT CONNECTED: "
                        f"{cname}/{env_type} | {server_host} | {srv_err}")
                    logger.warning(
                        f"[STEP-5A] Skipping DB check for "
                        f"{cname}/{env_type} — server unreachable")
                    self._log_step(5, "DB_SERVER_WMI_CHECK", "FAILED",
                                   f"NOT CONNECTED: {srv_err}",
                                   cname, env_type)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="NOT CONNECTED",
                        server_error=srv_err,
                        db_host=server_host,
                        connection_status="SKIPPED",
                        error_message=f"DB Server unreachable (WMI): {srv_err}",
                        duration_ms=srv_ms)
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                                   "Server=NOT CONNECTED | DB check skipped",
                                   cname, env_type)
                    logger.info(
                        f"[STEP-5A] -> Next environment "
                        f"(server down: {cname}/{env_type})")
                    continue

                # Server connected
                logger.info(
                    f"[STEP-5A] CONNECTED: "
                    f"{cname}/{env_type} | {server_host} | {srv_ms}ms")
                self._log_step(5, "DB_SERVER_WMI_CHECK", "COMPLETED",
                               f"CONNECTED | {srv_ms}ms",
                               cname, env_type)

                # ── Step 6: Load target DB(s) ─────────────────────────────────
                logger.info(
                    f"[STEP-6] Loading {self.db_types} DB(s): "
                    f"{cname}/{env_type} | server_id={server_id}")
                self._log_step(6, "LOAD_DB_TYPES", "STARTED",
                               f"server_id={server_id} db_types={self.db_types}",
                               cname, env_type)
                try:
                    with DBManager(cfg=HC_DB) as db:
                        target_dbs = self.load_db_types(db, server_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-6] Cannot load DBs for "
                        f"{cname}/{env_type}: {exc}")
                    self._log_step(6, "LOAD_DB_TYPES", "FAILED",
                                   str(exc), cname, env_type)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="CONNECTED",
                        db_host=server_host,
                        connection_status="SKIPPED",
                        error_message=f"DB type lookup error: {exc}",
                        duration_ms=srv_ms)
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                                   "DB type lookup error | recorded in Excel",
                                   cname, env_type)
                    continue

                if not target_dbs:
                    warn = (f"No active database found "
                            f"(DatabaseType IN {self.db_types}) for this server")
                    logger.warning(
                        f"[STEP-6] {warn} | {cname}/{env_type} — recording SKIPPED row")
                    self._log_step(6, "LOAD_DB_TYPES", "SKIPPED", warn,
                                   cname, env_type)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="CONNECTED",
                        db_host=server_host,
                        connection_status="SKIPPED",
                        error_message=warn,
                        duration_ms=srv_ms)
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "SKIPPED",
                                   "DB Type=NOT FOUND | recorded in Excel",
                                   cname, env_type)
                    continue

                logger.info(
                    f"[STEP-6] {len(target_dbs)} DB(s) found "
                    f"for {cname}/{env_type}")
                self._log_step(6, "LOAD_DB_TYPES", "COMPLETED",
                               f"{len(target_dbs)} DB(s) found",
                               cname, env_type)

                # ── STEP B: Check each target DB ──────────────────────────────
                for tdb in target_dbs:
                    db_info = {
                        "customer_id":   cid,
                        "customer_name": cname,
                        "env_type":      env_type,
                        "db_name":       tdb["db_name"],
                        "db_type":       tdb.get("db_type", ""),
                        "db_host":       server_host,
                        "db_port":       tdb.get("db_port", 1521),
                        "db_service":    tdb["db_service"],
                        "db_user":       tdb["db_user"],
                        "db_password":   tdb["db_password"],
                    }

                    self._log_step(6, "DB_CONNECTION_CHECK", "STARTED",
                                   f"DB={tdb['db_name']} type={tdb.get('db_type','')} "
                                   f"dsn={server_host}:{tdb.get('db_port',1521)}"
                                   f"/{tdb['db_service']}",
                                   cname, env_type)

                    db_ok, db_err, db_ms = self._check_db_connection(db_info)

                    status = "COMPLETED" if db_ok else "FAILED"

                    result = {
                        "run_id":            self.run_id,
                        "customer_id":       cid,
                        "customer_name":     cname,
                        "env_type":          env_type,
                        "server_host":       server_host,
                        "server_status":     "CONNECTED",
                        "server_error":      None,
                        "db_name":           tdb["db_name"],
                        "db_type":           tdb.get("db_type", ""),
                        "db_host":           server_host,
                        "db_port":           tdb.get("db_port", 1521),
                        "db_service":        tdb["db_service"],
                        "connection_status": status,
                        "error_message":     db_err or "",
                        "duration_ms":       db_ms,
                        "checked_at":        datetime.utcnow(),
                    }
                    self._save_result(result)
                    results.append(result)

                    self._log_step(
                        7, "CAPTURE_RESULT", status,
                        f"DB={tdb['db_name']} | "
                        f"{status} | {db_ms}ms"
                        + (f" | Error: {db_err}" if db_err else ""),
                        cname, env_type)

                    logger.info(
                        f"[STEP-7] Result: {cname}/{env_type} | "
                        f"DB={tdb['db_name']} | "
                        f"{status} | {db_ms}ms")

                # Mark env as complete
                env_results = [
                    r for r in results
                    if r["customer_name"] == cname
                    and r["env_type"] == env_type]
                env_ok = all(
                    r["connection_status"] == "COMPLETED" for r in env_results)
                self._log_step(
                    6, "DB_CONNECTION_CHECK",
                    "COMPLETED" if env_ok else "PARTIAL",
                    f"{cname}/{env_type} done",
                    cname, env_type)

                logger.info(
                    f"[STEP-6] -> Next environment after {cname}/{env_type}")

            logger.info(
                f"[STEP-4] All environments done for {cname} -> next customer")

        # ── Summary ───────────────────────────────────────────────────────────
        success = sum(1 for r in results if r["connection_status"] == "COMPLETED")
        failed  = sum(1 for r in results if r["connection_status"] == "FAILED")
        skipped = sum(1 for r in results if r["connection_status"] == "SKIPPED")
        logger.info("")
        logger.info(f"{'=' * 60}")
        logger.info(
            f"[STEP-7] All checks done | db_types={self.db_types} | "
            f"total_rows={len(results)} | "
            f"db_connected={success} | db_not_connected={failed} | "
            f"skipped={skipped}")
        logger.info(f"{'=' * 60}")
        return results
