"""
main.py
=======
DB Connection Checker — Entry Point

Run:
    py main.py
    python main.py

What it does:
  1. Reads connection details for all active target databases
     (DatabaseType driven by app_config.config_dbtype, default 'FMW')
     from the health_check MySQL schema (customers / environments / OracleDatabase).
  2. Checks the DB Server via WMI (WMI ONLY).
  3. If server reachable, attempts a connection to each target DB.
  4. Saves results (COMPLETED / FAILED + error) to dbconnection_checker MySQL schema.
  5. Generates an Excel report (.xlsx) with all results.
  6. Emails the report to configured recipients (TO / CC / BCC).

Config lives in dbconnection_checker DB:
  app_config   -> excel_path, log_path, oracle_timeout, oracle_dll_path,
                  config_customers, config_envs,
                  config_dbtype, report_label   (DYNAMIC — change here when
                  the target DatabaseType changes in future, no code edits)
  email_config -> smtp settings, TO, CC, BCC addresses

Only DB credentials live in config.py.

Logging:
  Initial startup log: ./Logs/checker_YYYYMMDD.log
  Once a run starts, logging switches to a per-run file:
    ./Logs/checker_run_<run_id>_YYYYMMDD.log
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.logger   import setup_logging
from process_manager import ProcessManager


def main():
    # Initial logging to ./Logs before DB config is loaded
    logger = setup_logging()
    logger.info("DB Connection Checker — Starting...")

    try:
        pm = ProcessManager()
        pm.execute()
    except KeyboardInterrupt:
        logger.info("Stopped by user.")
    except Exception as exc:
        logger.critical(f"Fatal error: {exc}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
