-- ============================================================
-- DBConnectionChecker Schema  (v4 — dynamic DB_TYPE, schema rename,
--                                  SKIPPED status, plain-text email)
-- Run ONCE before first execution:
--   mysql -u root -p < schema.sql
--
-- SCHEMA (DATABASE) RENAME:
--   fmwchecks  ->  dbconnection_checker
--
-- TABLE RENAMES (old -> new):
--   fmw_config              -> app_config
--   fmw_run                 -> process_run
--   fmw_connection_result   -> process_db_connection_result
--   fmw_run_log             -> process_run_log
--   fmw_email_config        -> email_config
--
-- MIGRATING FROM AN EXISTING "fmwchecks" DATABASE:
--   mysqldump fmwchecks | mysql dbconnection_checker   (after creating it)
--   -- or simply run this script against a fresh server and
--   -- reconfigure app_config / email_config.
-- ============================================================

CREATE DATABASE IF NOT EXISTS dbconnection_checker
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE dbconnection_checker;

-- ── Email config ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_config (
    id          INT           NOT NULL AUTO_INCREMENT,
    config_name VARCHAR(100)  NOT NULL DEFAULT 'default',
    smtp_host   VARCHAR(255)  NOT NULL,
    smtp_port   INT           NOT NULL DEFAULT 587,
    smtp_user   VARCHAR(255)  NOT NULL,
    smtp_pass   VARCHAR(255)  NOT NULL,
    use_tls     TINYINT(1)    NOT NULL DEFAULT 1,
    from_addr   VARCHAR(255)  NOT NULL,
    to_addr     TEXT          NOT NULL,   -- comma-separated
    cc_addr     TEXT          NULL,
    bcc_addr    TEXT          NULL,
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── General / path / dynamic DB_TYPE config ───────────────────
-- Keys: excel_path, log_path, oracle_timeout, oracle_dll_path
--       config_customers  (comma-sep customer names; empty = ALL)
--       config_envs       (comma-sep: DEV,VAL,PRD;  empty = ALL)
--       config_dbtype     (comma-sep DatabaseType values to check,
--                          e.g. 'FMW' or 'FMW,OAM'; drives the
--                          OracleDatabase.DatabaseType IN (...) filter)
--       report_label      (display name used in Excel title/filename
--                          and email subject — change this when
--                          config_dbtype changes, e.g. 'OAM')
CREATE TABLE IF NOT EXISTS app_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value VARCHAR(500)  NOT NULL DEFAULT '',
    description  VARCHAR(500)  NULL,
    updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Run table — one row per execution ─────────────────────────
CREATE TABLE IF NOT EXISTS process_run (
    id            INT          NOT NULL AUTO_INCREMENT,
    status        VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',
                  -- RUNNING | COMPLETED | PARTIAL | FAILED | SKIPPED | NO_DATA
    db_type       VARCHAR(100) NULL,                -- DatabaseType(s) checked this run
    started_at    DATETIME     NULL,
    completed_at  DATETIME     NULL,
    total_envs    INT          NOT NULL DEFAULT 0,   -- total environments processed
    success_count INT          NOT NULL DEFAULT 0,   -- DB CONNECTED
    fail_count    INT          NOT NULL DEFAULT 0,   -- DB NOT CONNECTED
    skipped_count INT          NOT NULL DEFAULT 0,   -- SKIPPED (no active env/server/db_type)
    excel_path    VARCHAR(500) NULL,
    log_file      VARCHAR(500) NULL,                 -- per-run log file path
    email_status  VARCHAR(20)  NULL,                 -- SENT | FAILED | SKIPPED
    email_error   TEXT         NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Connection result — ONE ROW PER ENVIRONMENT per run ───────
-- Columns follow exact Excel report requirement:
--   Customer | Environment | DB Server Status | Server Host | Server Error |
--   DB Name | DB Type | Host | Port | Service/SID | Status | Duration | Error | Checked At
CREATE TABLE IF NOT EXISTS process_db_connection_result (
    id                 INT           NOT NULL AUTO_INCREMENT,
    run_id             INT           NOT NULL,
    customer_id        INT           NOT NULL,
    customer_name      VARCHAR(255)  NOT NULL,
    env_type           VARCHAR(50)   NOT NULL,       -- DEV | VAL | PRD

    -- DB Server (Step A — WMI ONLY)
    server_host        VARCHAR(255)  NOT NULL DEFAULT '',
    server_status      VARCHAR(20)   NOT NULL DEFAULT 'NOT CONNECTED',
                       -- CONNECTED | NOT CONNECTED | NOT FOUND | UNKNOWN
                       --   CONNECTED     = WMI check succeeded
                       --   NOT CONNECTED = WMI check failed (see server_error)
                       --   NOT FOUND     = no active env / no active 'DB Server'
                       --                   row found in Servers
                       --   UNKNOWN       = error while looking up env/server record
    server_error       TEXT          NULL,           -- full error if server down/lookup failed

    -- Target DB (Step B — empty if server not connected)
    db_name            VARCHAR(255)  NOT NULL DEFAULT '',
    db_type            VARCHAR(50)   NOT NULL DEFAULT '',  -- DatabaseType (FMW/OAM/etc.)
    db_host            VARCHAR(255)  NOT NULL DEFAULT '',
    db_port            INT           NOT NULL DEFAULT 1521,
    db_service         VARCHAR(255)  NOT NULL DEFAULT '',
    connection_status  VARCHAR(20)   NOT NULL DEFAULT 'FAILED',
                       -- COMPLETED | FAILED | SKIPPED
                       --   COMPLETED = DB connected           -> Excel: "DB CONNECTED"
                       --   FAILED    = DB connect attempt failed -> Excel: "DB NOT CONNECTED"
                       --   SKIPPED   = no active env/server/db_type found -> Excel: "SKIPPED"
    error_message      TEXT          NULL,           -- FULL error/warning text
                                                       -- (not truncated)
    duration_ms        INT           NOT NULL DEFAULT 0,
    checked_at         DATETIME      NOT NULL,

    PRIMARY KEY (id),
    KEY idx_run_id     (run_id),
    KEY idx_customer   (customer_id),
    KEY idx_env        (env_type),
    KEY idx_db_type    (db_type),
    KEY idx_srv_status (server_status),
    KEY idx_db_status  (connection_status),
    KEY idx_checked_at (checked_at),
    CONSTRAINT fk_result_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Step log — detailed audit trail per run ───────────────────
CREATE TABLE IF NOT EXISTS process_run_log (
    id         INT          NOT NULL AUTO_INCREMENT,
    run_id     INT          NOT NULL,
    step_no    INT          NOT NULL DEFAULT 0,      -- 1-12 per requirement
    step_name  VARCHAR(100) NOT NULL,
    status     VARCHAR(20)  NOT NULL,
              -- STARTED | COMPLETED | FAILED | SKIPPED | INFO
    message    TEXT         NULL,
    customer   VARCHAR(255) NULL,
    env_type   VARCHAR(50)  NULL,
    logged_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_run_id  (run_id),
    KEY idx_log_step_no (step_no),
    CONSTRAINT fk_log_run
        FOREIGN KEY (run_id) REFERENCES process_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- Default config rows — edit before first run
-- ============================================================

INSERT INTO app_config (config_key, config_value, description) VALUES
  ('excel_path',        'Excel',        'Folder where Excel reports are saved'),
  ('log_path',          'Logs',         'Folder where log files are written'),
  ('oracle_timeout',    '15',           'Oracle / socket connection timeout (seconds)'),
  ('oracle_dll_path',   '',             'Oracle Instant Client folder (empty = thin mode)'),
  ('config_customers',  '',             'Comma-sep customer names to process; empty = ALL active'),
  ('config_envs',       '',             'Comma-sep envs to process (DEV,VAL,PRD); empty = ALL'),
  ('config_dbtype',     'FMW',          'Comma-sep DatabaseType values to check (e.g. FMW or FMW,OAM). Change this when DB type changes in future.'),
  ('report_label',      'FMW',          'Display name used in Excel title/filename and email subject. Update together with config_dbtype.')
ON DUPLICATE KEY UPDATE description = VALUES(description);


INSERT INTO email_config
  (config_name, smtp_host, smtp_port, smtp_user, smtp_pass,
   use_tls, from_addr, to_addr, cc_addr, bcc_addr, is_active)
VALUES
  ('default',
   'smtp.company.com', 587,
   'alerts@company.com', 'email_password',
   1,
   'alerts@company.com',
   'team@company.com',
   '',
   '',
   1)
ON DUPLICATE KEY UPDATE smtp_host = VALUES(smtp_host);


-- ============================================================
-- CONFIG CHEAT SHEET
--
-- Filter to specific customers only:
--   UPDATE app_config SET config_value='CustomerA,CustomerB'
--   WHERE config_key='config_customers';
--
-- Filter to specific environments only:
--   UPDATE app_config SET config_value='PRD,VAL'
--   WHERE config_key='config_envs';
--
-- Process ALL customers and ALL envs:
--   UPDATE app_config SET config_value='' WHERE config_key IN ('config_customers','config_envs');
--
-- *** FUTURE DB TYPE CHANGE — only these two rows need updating ***
--   UPDATE app_config SET config_value='OAM'     WHERE config_key='config_dbtype';
--   UPDATE app_config SET config_value='OAM'     WHERE config_key='report_label';
--   (Or comma-separate to check multiple types together: 'FMW,OAM')
--
-- Update email TO / CC:
--   UPDATE email_config
--   SET to_addr='a@co.com,b@co.com', cc_addr='mgr@co.com'
--   WHERE is_active=1;
--
-- USEFUL QUERIES
--
-- Latest run summary:
--   SELECT id, status, db_type, total_envs,
--          success_count, fail_count, skipped_count,
--          started_at, completed_at, email_status, log_file
--   FROM process_run ORDER BY id DESC LIMIT 5;
--
-- Results of latest run (all columns):
--   SELECT customer_name, env_type,
--          server_host, server_status, server_error,
--          db_name, db_type, db_host, db_port, db_service,
--          connection_status, duration_ms, error_message, checked_at
--   FROM process_db_connection_result
--   WHERE run_id = (SELECT MAX(id) FROM process_run)
--   ORDER BY customer_name, env_type;
--
-- All failures / skipped (latest run):
--   SELECT cr.customer_name, cr.env_type, cr.db_type,
--          cr.server_status, cr.connection_status, cr.error_message
--   FROM process_db_connection_result cr
--   WHERE cr.run_id = (SELECT MAX(id) FROM process_run)
--     AND cr.connection_status IN ('FAILED','SKIPPED')
--   ORDER BY cr.connection_status, cr.customer_name;
--
-- Step-by-step audit for latest run:
--   SELECT step_no, step_name, status, customer, env_type, message, logged_at
--   FROM process_run_log
--   WHERE run_id = (SELECT MAX(id) FROM process_run)
--   ORDER BY id;
-- ============================================================


-- ============================================================
-- HEALTH_CHECK SCHEMA DEPENDENCY (READ ONLY — unchanged)
-- The following tables are read from health_check schema:
--
-- Customers   -> CustomerID, CustomerName, Status
-- Environments -> EnvID, CustomerID, ServerUser, ServerPwd,
--                ServerType (DEV/VAL/PRD), Status
--               *** ServerUser + ServerPwd used for WMI auth ***
-- Servers     -> ServerID, EnvID, ServerName, Host, Status
--               *** Filtered to ServerName='DB Server' ***
-- OracleDatabase -> dbid, ServerID, User, Password, OrdName,
--                  Port, DatabaseType, Status
--               *** DatabaseType filtered using app_config.config_dbtype ***
--
-- WMI FLOW (server check is WMI-ONLY — no socket fallback):
--   Environments.ServerUser + ServerPwd  -> WMI credentials
--   Servers.Host (where ServerName='DB Server') -> WMI target host
--   If WMI connects -> check target DB(s)
--   If WMI fails / unavailable -> mark NOT CONNECTED, skip DB check
--
-- "NOT FOUND / SKIPPED" ROWS (always written to Excel/results — nothing
-- is silently dropped):
--   1. No active environment matches config_envs for a customer
--      -> server_status='NOT FOUND', connection_status='SKIPPED'
--   2. Error while looking up the env/server record
--      -> server_status='UNKNOWN', connection_status='SKIPPED'
--   3. No active 'DB Server' row found for an environment
--      -> server_status='NOT FOUND', connection_status='SKIPPED'
--   4. WMI server check failed (server unreachable)
--      -> server_status='NOT CONNECTED', connection_status='SKIPPED'
--   5. Server connected, but no active OracleDatabase row matches
--      config_dbtype -> server_status='CONNECTED', db_name empty,
--      connection_status='SKIPPED'
-- In ALL cases, error_message holds the FULL reason (never truncated).
-- ============================================================

