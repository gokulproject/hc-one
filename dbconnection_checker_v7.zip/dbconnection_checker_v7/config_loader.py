"""
config_loader.py
================
Loads all runtime configuration from dbconnection_checker database tables.

Sources:
  app_config    -> excel_path, log_path, oracle_timeout, oracle_dll_path,
                    config_customers, config_envs,
                    config_dbtype, report_label
  email_config  -> smtp settings, to/cc/bcc addresses
"""
import logging
import os
from dataclasses import dataclass, field
from typing import List

logger = logging.getLogger("checker.config")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _abs(path: str) -> str:
    if not path:
        return ""
    return path if os.path.isabs(path) else os.path.join(BASE_DIR, path)


def _parse_list(raw: str) -> List[str]:
    """Comma-separated string → clean list. Empty string → empty list."""
    if not raw or not raw.strip():
        return []
    return [v.strip() for v in raw.split(",") if v.strip()]


@dataclass
class EmailConfig:
    smtp_host:  str       = ""
    smtp_port:  int       = 587
    smtp_user:  str       = ""
    smtp_pass:  str       = ""
    use_tls:    bool      = True
    from_addr:  str       = ""
    to_addrs:   List[str] = field(default_factory=list)
    cc_addrs:   List[str] = field(default_factory=list)
    bcc_addrs:  List[str] = field(default_factory=list)


@dataclass
class AppConfig:
    excel_path:       str       = ""
    log_path:         str       = ""
    oracle_timeout:   int       = 15
    oracle_dll_path:  str       = ""
    config_customers: List[str] = field(default_factory=list)  # empty = ALL
    config_envs:      List[str] = field(default_factory=list)  # empty = ALL
    config_dbtype:    List[str] = field(default_factory=lambda: ["FMW"])
    report_label:     str       = "FMW"
    email:            EmailConfig = field(default_factory=EmailConfig)


def load_config(db) -> AppConfig:
    """
    Load AppConfig from dbconnection_checker DB.
    db: open DBManager connected to dbconnection_checker schema.
    """
    cfg = AppConfig()

    # ── General config ─────────────────────────────────────────────────────
    try:
        rows = db.fetch_all("SELECT config_key, config_value FROM app_config")
        kv   = {r["config_key"]: r["config_value"] for r in rows}

        cfg.excel_path       = _abs(kv.get("excel_path",       "Excel"))
        cfg.log_path         = _abs(kv.get("log_path",         "Logs"))
        cfg.oracle_timeout   = int(kv.get("oracle_timeout",    "15"))
        cfg.oracle_dll_path  = _abs(kv.get("oracle_dll_path",  ""))
        cfg.config_customers = _parse_list(kv.get("config_customers", ""))
        cfg.config_envs      = _parse_list(kv.get("config_envs",      ""))

        # ── Dynamic DB type — change config_dbtype / report_label in
        #    app_config when the target DatabaseType changes in future.
        #    No code change required.
        cfg.config_dbtype    = _parse_list(kv.get("config_dbtype", "FMW")) or ["FMW"]
        cfg.report_label     = kv.get("report_label", cfg.config_dbtype[0])

        logger.info(
            f"[STEP-2] Config loaded | "
            f"excel={cfg.excel_path} log={cfg.log_path} "
            f"timeout={cfg.oracle_timeout}s | "
            f"customers={'ALL' if not cfg.config_customers else cfg.config_customers} | "
            f"envs={'ALL' if not cfg.config_envs else cfg.config_envs} | "
            f"db_type={cfg.config_dbtype} | "
            f"report_label={cfg.report_label}")
    except Exception as exc:
        logger.warning(f"[STEP-2] Could not load app_config — using defaults: {exc}")
        cfg.excel_path      = _abs("Excel")
        cfg.log_path        = _abs("Logs")
        cfg.oracle_timeout  = 15
        cfg.config_dbtype   = ["FMW"]
        cfg.report_label    = "FMW"

    # ── Email config ───────────────────────────────────────────────────────
    try:
        row = db.fetch_one(
            "SELECT * FROM email_config WHERE is_active=1 ORDER BY id LIMIT 1")
        if row:
            cfg.email = EmailConfig(
                smtp_host = row.get("smtp_host",  ""),
                smtp_port = int(row.get("smtp_port", 587)),
                smtp_user = row.get("smtp_user",  ""),
                smtp_pass = row.get("smtp_pass",  ""),
                use_tls   = bool(row.get("use_tls", 1)),
                from_addr = row.get("from_addr",  ""),
                to_addrs  = _parse_list(row.get("to_addr",  "")),
                cc_addrs  = _parse_list(row.get("cc_addr",  "")),
                bcc_addrs = _parse_list(row.get("bcc_addr", "")),
            )
            logger.info(
                f"[STEP-2] Email config loaded | "
                f"smtp={cfg.email.smtp_host}:{cfg.email.smtp_port} | "
                f"to={cfg.email.to_addrs} cc={cfg.email.cc_addrs}")
        else:
            logger.warning("[STEP-2] No active email config in email_config")
    except Exception as exc:
        logger.warning(f"[STEP-2] Could not load email_config: {exc}")

    return cfg
