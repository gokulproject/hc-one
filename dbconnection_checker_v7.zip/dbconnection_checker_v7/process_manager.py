"""
process_manager.py
==================
Orchestrates the complete check run in strict sequence:

  Step 1  — Process Start
  Step 2  — Connect Config Databases (healthcheck + dbconnection_checker)
  Step 3  — Identify Customers
  Step 4  — Identify Environments
  Step 5  — DB Server Connection Check (WMI only)
  Step 6  — Target DB Connection Check (db_type from app_config.config_dbtype)
  Step 7  — Capture Results, Logs, Errors
  Step 8  — Generate Excel Report
  Step 9  — Send Email
  Step 10 — Process Completed

DB type / report label are dynamic — see app_config.config_dbtype and
app_config.report_label. Same logic as before; table names and a few
labels were renamed for a generic, future-usable project.
"""
import logging
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.db_manager           import DBManager
from Common.email_manager        import EmailManager
from Common.logger               import setup_logging, get_log_file_path
from ExcelCreation.excel_manager import generate_excel
from checker                     import Checker
from config                      import FMWCHECKS_DB
from config_loader               import load_config

logger    = logging.getLogger("checker.process")
IST_OFFSET = timedelta(hours=5, minutes=30)


def _now_ist_str() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


class ProcessManager:

    def __init__(self):
        self.run_id    = 0
        self.timestamp = _now_ist_str()
        self.app_cfg   = None

    # ── DB helpers ────────────────────────────────────────────────────────────
    def _create_run(self, db_type_label: str) -> int:
        with DBManager(cfg=FMWCHECKS_DB) as db:
            run_id = db.insert_get_id(
                "INSERT INTO process_run (status, db_type, started_at, created_at) "
                "VALUES ('RUNNING', %s, NOW(), NOW())",
                (db_type_label,))
        logger.info(f"[STEP-2] Run #{run_id} created in dbconnection_checker DB | db_type={db_type_label}")
        return run_id

    def _update_run(self, status, total, success, failed, skipped,
                    excel_path, log_file, email_status, email_error):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """UPDATE process_run SET
                         status        = %s,
                         total_envs    = %s,
                         success_count = %s,
                         fail_count    = %s,
                         skipped_count = %s,
                         excel_path    = %s,
                         log_file      = %s,
                         email_status  = %s,
                         email_error   = %s,
                         completed_at  = NOW()
                       WHERE id = %s""",
                    (status, total, success, failed, skipped,
                     excel_path, log_file, email_status, email_error,
                     self.run_id))
        except Exception as exc:
            logger.error(f"Cannot update run record: {exc}")

    def _log_step(self, step_no: int, step_name: str, status: str,
                  message: str = "", customer: str = "", env_type: str = ""):
        logger.info(
            f"[STEP-{step_no}] {step_name} -> {status}"
            + (f" | {message}" if message else "")
            + (f" | customer={customer}" if customer else "")
            + (f" | env={env_type}" if env_type else ""))
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO process_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     message[:2000] if message else "",
                     customer[:255] if customer else "",
                     env_type[:50]  if env_type  else ""))
        except Exception as exc:
            logger.warning(f"Step log write failed: {exc}")

    # ── Main execute ──────────────────────────────────────────────────────────
    def execute(self):

        # ── STEP 1: Process Start ─────────────────────────────────────────────
        logger.info("=" * 64)
        logger.info(f"[STEP-1] Database Connection Check — Process Start | {self.timestamp}")
        logger.info("=" * 64)

        # ── STEP 2: Connect Config Databases ──────────────────────────────────
        logger.info("[STEP-2] Connecting to config databases...")
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                self.app_cfg = load_config(db)
            logger.info("[STEP-2] dbconnection_checker DB connected")
        except Exception as exc:
            logger.critical(
                f"[STEP-2] Cannot connect to dbconnection_checker DB: {exc}", exc_info=True)
            return

        # Verify healthcheck DB reachable
        try:
            from config import HC_DB
            with DBManager(cfg=HC_DB) as db:
                db.fetch_one("SELECT 1")
            logger.info("[STEP-2] health_check DB connected")
        except Exception as exc:
            logger.critical(
                f"[STEP-2] Cannot connect to health_check DB: {exc}",
                exc_info=True)
            return

        db_type_label = ",".join(self.app_cfg.config_dbtype)

        # ── Create run record ─────────────────────────────────────────────────
        try:
            self.run_id    = self._create_run(db_type_label)
            self.timestamp = _now_ist_str()
        except Exception as exc:
            logger.critical(f"[STEP-2] Cannot create run record: {exc}")
            return

        # ── Switch logging to a dedicated per-run log file ────────────────────
        # File: <log_path>/checker_run_<run_id>_YYYYMMDD.log
        setup_logging(log_dir=self.app_cfg.log_path, run_id=self.run_id)
        log_file = get_log_file_path(self.app_cfg.log_path, run_id=self.run_id)

        self._log_step(2, "CONNECT_DATABASES", "COMPLETED",
                       f"healthcheck + dbconnection_checker both connected | "
                       f"db_type={db_type_label} | report_label={self.app_cfg.report_label}")

        excel_path   = None
        email_status = "SKIPPED"
        email_error  = None
        results      = []
        final_status = "FAILED"

        try:
            # ── STEP 3-7: Run all checks (customer→env→server→db loop) ────────
            self._log_step(3, "PROCESS_START", "STARTED",
                           f"customers={'ALL' if not self.app_cfg.config_customers else self.app_cfg.config_customers} | "
                           f"envs={'ALL' if not self.app_cfg.config_envs else self.app_cfg.config_envs} | "
                           f"db_type={self.app_cfg.config_dbtype}")

            checker = Checker(run_id=self.run_id, app_cfg=self.app_cfg)
            results = checker.run_all()
            db_label = checker.db_label   # dynamic — drives Excel + email labels

            total   = len(results)
            success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
            failed  = sum(1 for r in results if r.get("connection_status") == "FAILED")
            skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")

            self._log_step(
                7, "CAPTURE_RESULTS", "COMPLETED",
                f"total={total} | db_connected={success} | "
                f"db_not_connected={failed} | skipped={skipped}")

            # ── STEP 8: Excel Generation ──────────────────────────────────────
            logger.info("[STEP-8] Generating Excel report...")
            self._log_step(8, "EXCEL_GENERATION", "STARTED",
                           f"path={self.app_cfg.excel_path} | label={db_label}")
            try:
                excel_path = generate_excel(
                    results    = results,
                    run_id     = self.run_id,
                    timestamp  = self.timestamp,
                    excel_path = self.app_cfg.excel_path,
                    db_label   = db_label)
                self._log_step(8, "EXCEL_GENERATION", "COMPLETED",
                               f"file={os.path.basename(excel_path)}")
                logger.info(
                    f"[STEP-8] Excel generation completed | "
                    f"{os.path.basename(excel_path)}")
            except Exception as exc:
                logger.error(
                    f"[STEP-8] Excel generation failed: {exc}", exc_info=True)
                self._log_step(8, "EXCEL_GENERATION", "FAILED", str(exc)[:500])

            # ── STEP 9: Send Email ────────────────────────────────────────────
            logger.info("[STEP-9] Sending email...")
            self._log_step(9, "EMAIL", "STARTED",
                           f"to={self.app_cfg.email.to_addrs} | "
                           f"cc={self.app_cfg.email.cc_addrs}")
            try:
                mailer  = EmailManager(email_cfg=self.app_cfg.email)
                subject = EmailManager.build_subject(results, self.run_id, db_label=db_label)
                body    = EmailManager.build_body(
                    results   = results,
                    run_id    = self.run_id,
                    timestamp = self.timestamp,
                    total     = total,
                    success   = success,
                    failed    = failed,
                    skipped   = skipped,
                    db_label  = db_label)

                sent, err    = mailer.send_report(
                    subject    = subject,
                    body       = body,
                    excel_path = excel_path,
                    run_id     = self.run_id)

                email_status = "SENT" if sent else "FAILED"
                email_error  = err
                self._log_step(9, "EMAIL", email_status,
                               f"subject='{subject}'" + (f" | error={err}" if err else ""))
                if sent:
                    logger.info(f"[STEP-9] Email sent | subject='{subject}'")
                else:
                    logger.error(f"[STEP-9] Email failed | {err}")

            except Exception as exc:
                logger.error(f"[STEP-9] Email error: {exc}", exc_info=True)
                email_status = "FAILED"
                email_error  = str(exc)[:500]
                self._log_step(9, "EMAIL", "FAILED", email_error)

            # ── Determine final run status ────────────────────────────────────
            if total == 0:
                final_status = "NO_DATA"
            elif success == total:
                final_status = "COMPLETED"
            elif success == 0:
                final_status = "FAILED" if failed > 0 else "SKIPPED"
            else:
                final_status = "PARTIAL"

        except Exception as exc:
            logger.critical(
                f"[STEP-?] Unexpected error: {exc}", exc_info=True)
            final_status = "FAILED"
            self._log_step(0, "PROCESS", "FAILED", str(exc)[:500])

        finally:
            suc = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
            fal = sum(1 for r in results if r.get("connection_status") == "FAILED")
            skp = sum(1 for r in results if r.get("connection_status") == "SKIPPED")
            self._update_run(
                status       = final_status,
                total        = len(results),
                success      = suc,
                failed       = fal,
                skipped      = skp,
                excel_path   = excel_path or "",
                log_file     = log_file,
                email_status = email_status,
                email_error  = email_error or "")

            # ── STEP 10: Process Completed ────────────────────────────────────
            logger.info("")
            logger.info("=" * 64)
            logger.info(
                f"[STEP-10] Process Completed | "
                f"run_id={self.run_id} | "
                f"status={final_status} | "
                f"db_type={db_type_label} | "
                f"total={len(results)} | "
                f"db_connected={suc} | db_not_connected={fal} | skipped={skp} | "
                f"log_file={log_file} | "
                f"{_now_ist_str()}")
            logger.info("=" * 64)
            self._log_step(10, "PROCESS_COMPLETED", final_status,
                           f"total={len(results)} db_connected={suc} "
                           f"db_not_connected={fal} skipped={skp} | "
                           f"email={email_status} | log_file={log_file}")
