"""
Common/email_manager.py
=======================
Send DB Connection Check report email — simple plain-text body
with the Excel report attached (no HTML template).

Subject  : {db_label} Database connection for {Customer Name(s)}
Attachment: {DB_LABEL}_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx
"""
import logging
import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta

logger = logging.getLogger("checker.email")

IST_OFFSET = timedelta(hours=5, minutes=30)


def _now_ist_display() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%m-%Y %H:%M")


class EmailManager:

    def __init__(self, email_cfg):
        self.cfg = email_cfg

    def send_report(self,
                    subject:    str,
                    body:       str,
                    excel_path: str = None,
                    run_id:     int = 0) -> tuple:
        """
        Send report email (plain text) with Excel attachment.
        Returns (success: bool, error_message: str|None)
        """
        to_list  = self.cfg.to_addrs
        cc_list  = self.cfg.cc_addrs
        bcc_list = self.cfg.bcc_addrs

        if not to_list:
            logger.warning(
                "[STEP-9] No TO address in email_config — email skipped")
            return False, "No TO address configured"

        try:
            msg            = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = self.cfg.from_addr
            msg["To"]      = ", ".join(to_list)
            if cc_list:
                msg["Cc"]  = ", ".join(cc_list)

            msg.attach(MIMEText(body, "plain", "utf-8"))

            # Attach Excel
            if excel_path and os.path.exists(excel_path):
                with open(excel_path, "rb") as f:
                    part = MIMEBase(
                        "application",
                        "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    f"attachment; filename={os.path.basename(excel_path)}")
                msg.attach(part)
                logger.info(
                    f"[STEP-9] Attached: {os.path.basename(excel_path)}")
            else:
                logger.warning(
                    "[STEP-9] No Excel attachment — file missing or "
                    "Excel generation failed earlier")

            all_recipients = to_list + cc_list + bcc_list

            with smtplib.SMTP(
                    self.cfg.smtp_host,
                    self.cfg.smtp_port, timeout=30) as smtp:
                if self.cfg.use_tls:
                    smtp.starttls()
                if self.cfg.smtp_user:
                    smtp.login(self.cfg.smtp_user, self.cfg.smtp_pass)
                smtp.sendmail(
                    self.cfg.from_addr, all_recipients, msg.as_string())

            logger.info(
                f"[STEP-9] Email sent | run_id={run_id} | "
                f"to={to_list} cc={cc_list} | subject='{subject}'")
            return True, None

        except Exception as exc:
            logger.error(f"[STEP-9] Email failed: {exc}", exc_info=True)
            return False, str(exc)[:500]

    # ── Email subject builder ─────────────────────────────────────────────────
    @staticmethod
    def build_subject(results: list, run_id: int, db_label: str = "FMW") -> str:
        """
        Subject: {db_label} Database connection for {Customer Name(s)}
        Multiple customers → comma-separated list.
        db_label is dynamic — comes from app_config.report_label
        (change there when the target DatabaseType changes in future).
        """
        customers = list(dict.fromkeys(
            r.get("customer_name", "") for r in results
            if r.get("customer_name")))
        cust_str = ", ".join(customers) if customers else "All Customers"
        return f"{db_label} Database connection for {cust_str}"

    # ── Plain-text body builder (no HTML) ─────────────────────────────────────
    @staticmethod
    def build_body(results:   list,
                   run_id:    int,
                   timestamp: str,
                   total:     int,
                   success:   int,
                   failed:    int,
                   skipped:   int = 0,
                   db_label:  str = "FMW") -> str:
        """
        Simple plain-text body:

          Hi Team,

          {db_label} database connection check completed. Please review the
          attached Excel report for details and take action on failed /
          skipped connections.

          Date and Time : DD-MM-YYYY HH:MM
          Run ID        : XXXXX
          Total Rows    : N
          DB Connected  : N
          DB Not Connected : N
          Skipped       : N

          Overall       : <ALL CONNECTED / PARTIAL / ALL FAILED / NO DATA>

          Thanks & Regards,
          RPA Team
        """
        now_display = _now_ist_display()

        if total == 0:
            overall = f"NO DATA — no active {db_label} environments/databases found."
        elif failed == 0 and skipped == 0:
            overall = "ALL CONNECTED — all environments connected successfully."
        elif success == 0:
            overall = "NO SUCCESSFUL CONNECTIONS — please review the attached report urgently."
        else:
            overall = "PARTIAL — some environments failed or were skipped. Please review the attached report."

        return (
            f"Hi Team,\n\n"
            f"{db_label} database connection check completed. "
            f"Please review the attached Excel report for details and "
            f"take action on failed / skipped connections.\n\n"
            f"Date and Time     : {now_display} IST\n"
            f"Run ID            : {run_id}\n"
            f"Total Rows        : {total}\n"
            f"DB Connected      : {success}\n"
            f"DB Not Connected  : {failed}\n"
            f"Skipped           : {skipped}\n\n"
            f"Overall           : {overall}\n\n"
            f"Thanks & Regards,\n"
            f"RPA Team\n"
        )
