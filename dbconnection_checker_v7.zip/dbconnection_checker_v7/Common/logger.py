"""
Common/logger.py
================
File + console logging for the DB Connection Checker project.

Two phases:
  1. Startup logging  -> setup_logging()
       Used before DB config is loaded. Writes to ./Logs/checker_YYYYMMDD.log
  2. Per-run logging   -> setup_logging(log_dir=..., run_id=...)
       Called once a run_id exists. Switches to a dedicated file per
       execution: <log_dir>/checker_run_<run_id>_YYYYMMDD.log
       This keeps every run's full log self-contained and easy to
       attach / share when troubleshooting a specific run.
"""
import logging
import os
from datetime import datetime

LOG_FORMAT     = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _build_filename(run_id: int = None) -> str:
    date_str = datetime.now().strftime("%Y%m%d")
    if run_id:
        return f"checker_run_{run_id}_{date_str}.log"
    return f"checker_{date_str}.log"


def setup_logging(log_dir: str = None, run_id: int = None) -> logging.Logger:
    """
    Configure the root logger.

    log_dir: full path from AppConfig.log_path. If None, defaults to
             ./Logs next to the project root.
    run_id:  if provided, switches to a dedicated per-run log file
             (checker_run_<run_id>_YYYYMMDD.log) and any previous
             file handler is removed (console handler is kept).
    """
    if not log_dir:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Logs")

    os.makedirs(log_dir, exist_ok=True)

    log_file = os.path.join(log_dir, _build_filename(run_id))

    fmt = logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT)

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # Remove any existing file handler(s) — we only ever want ONE active
    # log file at a time (initial -> per-run switch-over).
    for h in list(root.handlers):
        if isinstance(h, logging.FileHandler):
            root.removeHandler(h)
            h.close()

    root.addHandler(fh)

    # Console handler — add once only.
    if not any(isinstance(h, logging.StreamHandler)
               and not isinstance(h, logging.FileHandler) for h in root.handlers):
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(fmt)
        root.addHandler(ch)

    logger = logging.getLogger("checker")
    if run_id:
        logger.info(f"Per-run logging started | run_id={run_id} | file={log_file}")
    else:
        logger.info(f"Logging started | file={log_file}")
    return logger


def get_logger(name: str = "checker") -> logging.Logger:
    return logging.getLogger(name)


def get_log_file_path(log_dir: str, run_id: int = None) -> str:
    """Return the path of the log file for a given run (without creating it)."""
    if not log_dir:
        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "Logs")
    return os.path.join(log_dir, _build_filename(run_id))
