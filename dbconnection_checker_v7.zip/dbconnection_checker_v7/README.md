# DB Connection Checker (formerly "FMWChecks")

Checks DB Server connectivity (via **WMI only**) and target Oracle database
connections (`DatabaseType` driven by `app_config.config_dbtype`, default
`FMW`) for all active customers and environments, generates a colour-coded
Excel report, and emails it (plain-text body + Excel attachment) to
configured recipients.

**Strictly read-only against `health_check`.** All config is read from, and
all results are written to, the **`dbconnection_checker`** MySQL schema.

The DB type checked and all report labels are **fully dynamic** — driven by
`app_config.config_dbtype` / `app_config.report_label`. When the DB type
changes in future, update those two config rows — **no code changes
required**.

---

## What it does

1. For each active **Customer** (or filtered list via `config_customers`):
2. For each active **Environment** (DEV/VAL/PRD, or filtered via `config_envs`):
3. Identify the **DB Server** — the `Servers` row where `ServerName='DB Server'`.
4. **Step A — Server check (WMI ONLY):** connect via WMI using
   `Environments.ServerUser` / `ServerPwd`.
   - WMI connection object is always released, success or failure.
   - If WMI fails → `server_status='NOT CONNECTED'`, row `connection_status='SKIPPED'`,
     full WMI error captured, **Step B is skipped**.
5. **Step B — Target DB check:** for each `OracleDatabase` row whose
   `DatabaseType` is in `config_dbtype`, connect via `oracledb` (no
   `timeout` kwarg passed — see note below) and **always close** the
   connection.
6. **Nothing is silently dropped** — every "not found" case still produces
   one row in Excel:

   | Case | server_status | connection_status |
   |---|---|---|
   | No active environment matches `config_envs` | `NOT FOUND` | `SKIPPED` |
   | Error looking up env/server record | `UNKNOWN` | `SKIPPED` |
   | No active `'DB Server'` row in `Servers` | `NOT FOUND` | `SKIPPED` |
   | WMI server check failed | `NOT CONNECTED` | `SKIPPED` |
   | Server connected, no DB matches `config_dbtype` | `CONNECTED` | `SKIPPED` |
   | DB connect succeeded | `CONNECTED` | `COMPLETED` |
   | DB connect failed | `CONNECTED` | `FAILED` |

   In every case, the **full** error/warning text is written to
   `error_message` (no truncation).

7. Generates a colour-coded Excel report and emails it (TO/CC/BCC) — **plain
   text body, no HTML template**, with the Excel attached.
8. Saves all results + a step-by-step audit log to the
   **`dbconnection_checker`** MySQL schema.
9. Writes a **dedicated log file per execution run** to the configured log
   folder (auto-created if it doesn't exist).

---

## Project structure

```
dbconnection_checker/
├── main.py                  ← entry point: py main.py
├── config.py                ← DB credentials only (HC_DB + FMWCHECKS_DB)
├── config_loader.py         ← reads runtime config from dbconnection_checker DB
├── process_manager.py       ← orchestrates all 10 steps
├── checker.py                ← server (WMI) + target DB connection checks
├── schema.sql               ← creates dbconnection_checker DB + tables + default config
├── requirements.txt
├── Common/
│   ├── db_manager.py        ← MySQL wrapper (HC_DB + FMWCHECKS_DB)
│   ├── email_manager.py     ← SMTP email — plain text body + Excel attachment
│   ├── logger.py            ← file + console logging (per-run log files)
│   └── crypto.py            ← AES-256 password decryption (same key as HC)
├── ExcelCreation/
│   └── excel_manager.py     ← openpyxl Excel report generator
├── Logs/                    ← per-run log files written here (configurable)
├── Excel/                   ← Excel reports saved here (configurable)
└── oracledb_dll/             ← Oracle thick client DLLs (optional, usually not needed)
```

---

## Schema / table renames (vs older "fmwchecks_v5")

| Old | New |
|---|---|
| **database** `fmwchecks` | **database** `dbconnection_checker` |
| `fmw_config` | `app_config` |
| `fmw_run` | `process_run` |
| `fmw_connection_result` | `process_db_connection_result` |
| `fmw_run_log` | `process_run_log` |
| `fmw_email_config` | `email_config` |

`fmw_checker.py` → `checker.py` (class `FMWChecker` → `Checker`).

If migrating from an existing `fmwchecks` database, run the new
`schema.sql` against a fresh `dbconnection_checker` database (or
`mysqldump fmwchecks | mysql dbconnection_checker` then `RENAME TABLE` the
5 tables above and add the new config rows / `skipped_count` column).

---

## Setup

### 1 — Install dependencies
```bash
pip install -r requirements.txt
```
WMI server checks require (on the Windows host running this script):
```bash
pip install WMI pywin32
```

### 2 — Create the schema
```bash
mysql -u root -p < schema.sql
```
Creates `dbconnection_checker` with:
- `email_config` — SMTP + TO/CC/BCC
- `app_config` — paths, timeouts, customer/env/db-type filters, report label
- `process_run` — one row per execution
- `process_db_connection_result` — one row per environment/result per run
- `process_run_log` — step audit trail per run

### 3 — Edit `config.py` (DB credentials only)
```python
HC_DB = {
    "host": "your-mysql-host", "user": "your-user",
    "password": "your-password", "database": "health_check",
}
FMWCHECKS_DB = {
    "host": "your-mysql-host", "user": "your-user",
    "password": "your-password", "database": "dbconnection_checker",
}
ENC_KEY = "your-32-char-key-matching-HC-project"
```

### 4 — Configure email
```sql
UPDATE dbconnection_checker.email_config
SET smtp_host='smtp.yourcompany.com', smtp_port=587,
    smtp_user='alerts@yourcompany.com', smtp_pass='your-smtp-password',
    use_tls=1, from_addr='alerts@yourcompany.com',
    to_addr='person1@co.com,person2@co.com',
    cc_addr='manager@co.com', bcc_addr=''
WHERE is_active=1;
```

### 5 — Run
```bash
py main.py
```

---

## Customer / Environment / DB Type filters (`app_config`)

| config_key | Empty means | Example |
|---|---|---|
| `config_customers` | ALL active customers | `'CustomerA,CustomerB'` |
| `config_envs` | ALL of DEV, VAL, PRD | `'PRD,VAL'` |
| `config_dbtype` | (defaults to `'FMW'`) | `'FMW'` or `'FMW,OAM'` |
| `report_label` | (defaults to `config_dbtype[0]`) | `'OAM'` |

```sql
UPDATE app_config SET config_value='CustomerA,CustomerB' WHERE config_key='config_customers';
UPDATE app_config SET config_value='PRD' WHERE config_key='config_envs';
UPDATE app_config SET config_value='' WHERE config_key IN ('config_customers','config_envs');
```

### *** Future DB type change — only these two rows ***
```sql
UPDATE app_config SET config_value='OAM' WHERE config_key='config_dbtype';
UPDATE app_config SET config_value='OAM' WHERE config_key='report_label';
-- or check multiple types together:
UPDATE app_config SET config_value='FMW,OAM' WHERE config_key='config_dbtype';
```
This automatically updates the `OracleDatabase.DatabaseType IN (...)` filter,
the Excel filename/title/header, and the email subject/body — **no code or
schema change**.

---

## Reads from `health_check` (READ ONLY)

| Table | Columns used |
|---|---|
| `Customers` | CustomerID, CustomerName, Status |
| `Environments` | EnvID, CustomerID, ServerType, ServerUser, ServerPwd, Status |
| `Servers` | ServerID, EnvID, ServerName, Host, Status — **filtered to `ServerName='DB Server'`** |
| `OracleDatabase` | dbid, ServerID, User, Password, OrdName, Port, DatabaseType, Status — filtered by `config_dbtype` |

**No `INSERT`/`UPDATE`/`DELETE` is ever issued against `health_check`** — verified:
every `db.execute(...)` write in `checker.py` / `process_manager.py` runs under
`DBManager(cfg=FMWCHECKS_DB)` (the `dbconnection_checker` schema) only.

---

## Writes to `dbconnection_checker`

| Table | Written |
|---|---|
| `process_run` | One row per execution — status, db_type, success/fail/skipped counts, excel path, log file, email status |
| `process_db_connection_result` | One row per environment/result per run — server status, db status, host/port/service, **full** error/warning, duration |
| `process_run_log` | Step-by-step audit trail per run |

---

## Run outcomes (`process_run.status`)

| Outcome | Meaning |
|---|---|
| `COMPLETED` | All rows — DB connected |
| `PARTIAL` | Mix of connected / not-connected / skipped |
| `FAILED` | All rows failed (DB connect attempted but failed) |
| `SKIPPED` | All rows skipped (no successful connections, no hard failures either — e.g. nothing found) |
| `NO_DATA` | No active customers found at all |

---

## Excel report columns

`# | Customer | Environment | DB Server Status | Server Host | Server Error | DB Name | DB Type | Host | Port | Service/SID | DB Connection Status | Duration (ms) | DB Error / Warning Msg | Checked At (IST)`

- **DB Server Status**: `CONNECTED` / `NOT CONNECTED` / `NOT FOUND` / `UNKNOWN`
- **DB Connection Status** (display mapping — DB stores raw value):
  - `COMPLETED` → **DB CONNECTED**
  - `FAILED` → **DB NOT CONNECTED**
  - `SKIPPED` → **SKIPPED** (shown when no active env/server/db_type was found)
- **DB Error / Warning Msg**: full error or warning text, never truncated.
- Filename: `{REPORT_LABEL}_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx`
- If the configured `excel_path` folder doesn't exist, it is created
  automatically.

---

## Email

Plain-text body (no HTML) + Excel attachment. Subject:
`"{report_label} Database connection for {Customer Name(s)}"`.

Body includes: date/time (IST), run ID, total rows, DB Connected /
DB Not Connected / Skipped counts, and an overall one-line summary.

---

## Logging

- Startup (before run_id exists): `<log_path>/checker_YYYYMMDD.log`
- **Per-run log file**: `<log_path>/checker_run_<RUN_ID>_YYYYMMDD.log`
  (path also stored in `process_run.log_file`)
- `<log_path>` (from `app_config.log_path`) is **created automatically** if
  it doesn't exist.
- Log levels used throughout: `DEBUG` (connection open/close detail),
  `INFO` (step progress), `WARNING` (not-found / skipped cases),
  `ERROR` (connection failures), `CRITICAL` (fatal — DB unreachable, etc.)

---

## Oracle thin vs thick client

- **Thin mode (default):** no DLLs needed, leave `oracle_dll_path` empty.
- **Thick mode:** put Oracle Instant Client DLLs in a folder and set
  `oracle_dll_path` in `app_config`.
- **Note:** `oracledb.connect()` is called **without** a `timeout` kwarg —
  passing `timeout=` caused crashes on some driver/DB combinations. Connection
  attempts rely on the driver's own default behaviour.

---

## WMI server check (WMI only — no socket fallback)

Server connectivity is checked **only via WMI** using
`Environments.ServerUser` / `ServerPwd` against `Servers.Host` where
`ServerName='DB Server'`.

- Missing `wmi` module or any WMI failure → `NOT CONNECTED`, full error
  captured, row marked `SKIPPED`, run continues (never crashes).
- The WMI connection object is always released (success or failure).

---

## Useful queries

```sql
-- Latest run summary
SELECT id, status, db_type, total_envs,
       success_count, fail_count, skipped_count,
       started_at, completed_at, email_status, log_file
FROM dbconnection_checker.process_run
ORDER BY id DESC LIMIT 5;

-- All results from latest run
SELECT customer_name, env_type, server_status, server_error,
       db_name, db_type, db_host, db_port, db_service,
       connection_status, duration_ms, error_message, checked_at
FROM dbconnection_checker.process_db_connection_result
WHERE run_id = (SELECT MAX(id) FROM dbconnection_checker.process_run)
ORDER BY customer_name, env_type;

-- Failures / skipped only (latest run)
SELECT customer_name, env_type, db_type, server_status,
       connection_status, error_message
FROM dbconnection_checker.process_db_connection_result
WHERE run_id = (SELECT MAX(id) FROM dbconnection_checker.process_run)
  AND connection_status IN ('FAILED','SKIPPED')
ORDER BY connection_status, customer_name;

-- Step log for latest run
SELECT step_no, step_name, status, customer, env_type, message, logged_at
FROM dbconnection_checker.process_run_log
WHERE run_id = (SELECT MAX(id) FROM dbconnection_checker.process_run)
ORDER BY id;
```
