"""
ExcelCreation/excel_manager.py
==============================
Generate Excel report per requirement spec.

ONE ROW per environment — including rows where the customer/env/server/
db_type was NOT FOUND, so nothing is silently dropped from the report.

Columns:
  # | Customer | Environment | DB Server Status | Server Host | Server Error |
  DB Name | DB Type | Host | Port | Service/SID | DB Connection Status |
  Duration (ms) | DB Error / Warning Msg | Checked At (IST)

Filename: {DB_LABEL}_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx
DB_LABEL is dynamic — comes from app_config.report_label
(change there when the target DatabaseType changes in future,
no code change needed).

Status values used (set in checker.py):
  server_status     : CONNECTED | NOT CONNECTED | NOT FOUND | UNKNOWN
  connection_status : COMPLETED | FAILED | SKIPPED

Display mapping (Excel only — DB stores the raw values above):
  COMPLETED -> DB CONNECTED
  FAILED    -> DB NOT CONNECTED
  SKIPPED   -> SKIPPED
"""
import logging
import os
from datetime import datetime, timedelta

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger("checker.excel")

IST_OFFSET = timedelta(hours=5, minutes=30)

# ── Colours ───────────────────────────────────────────────────────────────────
BLUE_DARK  = "1565C0"
BLUE_MED   = "0D47A1"
BLUE_LIGHT = "E3F2FD"
GREEN_BG   = "E8F5E9"
GREEN_BG2  = "F0FAF0"
RED_BG     = "FFEBEE"
RED_BG2    = "FFF5F5"
AMBER_BG   = "FFF8E1"
AMBER_BG2  = "FFF3E0"
GREEN_TEXT = "2E7D32"
RED_TEXT   = "C62828"
AMBER_TEXT = "E65100"

# ── DB Connection Status display mapping ───────────────────────────────────────
# Internal value (stored in DB) -> display value (shown in Excel only)
STATUS_DISPLAY = {
    "COMPLETED": "DB CONNECTED",
    "FAILED":    "DB NOT CONNECTED",
    "SKIPPED":   "SKIPPED",
}

STATUS_COLOR = {
    "COMPLETED": GREEN_TEXT,
    "FAILED":    RED_TEXT,
    "SKIPPED":   AMBER_TEXT,
}

SERVER_COLOR = {
    "CONNECTED":     GREEN_TEXT,
    "NOT CONNECTED": RED_TEXT,
    "NOT FOUND":     AMBER_TEXT,
    "UNKNOWN":       AMBER_TEXT,
}


def _side():
    return Side(style="thin", color="BDBDBD")


def _border():
    s = _side()
    return Border(left=s, right=s, top=s, bottom=s)


def _ist_str(dt) -> str:
    if not dt:
        return ""
    return (dt + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


def generate_excel(results:    list,
                   run_id:     int,
                   timestamp:  str,
                   excel_path: str,
                   db_label:   str = "FMW") -> str:
    """
    Build Excel report. Returns full filepath of saved .xlsx.
    Filename format: {DB_LABEL}_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx

    db_label: dynamic display name from app_config.report_label —
    drives the filename, sheet title and report header only.

    If excel_path doesn't exist on disk, it is created automatically
    (os.makedirs(..., exist_ok=True)).
    """
    os.makedirs(excel_path, exist_ok=True)

    label_safe = (db_label or "FMW").upper().replace("/", "_").replace(" ", "_")

    # Filename per requirement: DD-MM-YY-RUNID
    date_part = datetime.now().strftime("%d-%m-%y")
    filename  = f"{label_safe}_CONNECTION_CHECKS_{date_part}-{run_id}.xlsx"
    filepath  = os.path.join(excel_path, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = f"{label_safe[:25]} Connection Results"

    # ── Counts ────────────────────────────────────────────────────────────────
    total   = len(results)
    success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
    failed  = sum(1 for r in results if r.get("connection_status") == "FAILED")
    skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")

    if total == 0:
        summary_text  = "No data processed"
        summary_color = RED_TEXT
    elif failed == 0 and skipped == 0:
        summary_text  = "ALL CONNECTED ✅"
        summary_color = GREEN_TEXT
    elif success == 0:
        summary_text  = f"NO SUCCESSFUL CONNECTIONS ❌  (Failed: {failed}, Skipped: {skipped})"
        summary_color = RED_TEXT
    else:
        summary_text  = (
            f"PARTIAL ⚠  Connected: {success}  "
            f"Not Connected: {failed}  Skipped: {skipped}")
        summary_color = AMBER_TEXT

    # ── Row 1: Title ──────────────────────────────────────────────────────────
    LAST_COL = "O"   # 15 columns
    ws.merge_cells(f"A1:{LAST_COL}1")
    tc           = ws["A1"]
    tc.value     = (
        f"{db_label} Database Connection Check Report  "
        f"|  Run #{run_id}  |  {timestamp}")
    tc.font      = Font(name="Calibri", size=13, bold=True, color="FFFFFF")
    tc.fill      = PatternFill("solid", fgColor=BLUE_DARK)
    tc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # ── Row 2: Summary ────────────────────────────────────────────────────────
    ws.merge_cells(f"A2:{LAST_COL}2")
    sc           = ws["A2"]
    sc.value     = (
        f"Total Rows: {total}   |   "
        f"✅ DB Connected: {success}   |   "
        f"❌ DB Not Connected: {failed}   |   "
        f"⚠ Skipped: {skipped}   |   "
        f"{summary_text}")
    sc.font      = Font(name="Calibri", size=11, bold=True, color=summary_color)
    sc.fill      = PatternFill("solid", fgColor=BLUE_LIGHT)
    sc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # ── Row 3: Headers ────────────────────────────────────────────────────────
    headers = [
        "#",
        "Customer",
        "Environment",
        "DB Server Status",
        "Server Host",
        "Server Error",
        "DB Name",
        "DB Type",
        "Host",
        "Port",
        "Service / SID",
        "DB Connection Status",
        "Duration (ms)",
        "DB Error / Warning Msg",
        "Checked At (IST)",
    ]
    widths = [4, 22, 14, 18, 22, 30, 20, 12, 22, 7, 18, 18, 13, 45, 24]

    for col, (h, w) in enumerate(zip(headers, widths), 1):
        cell           = ws.cell(row=3, column=col, value=h)
        cell.font      = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill      = PatternFill("solid", fgColor=BLUE_MED)
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)
        cell.border    = _border()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[3].height = 22

    # ── Data rows — ONE ROW PER ENVIRONMENT/RESULT ────────────────────────────
    STATUS_COL = 12   # "DB Connection Status" column index

    for idx, r in enumerate(results, 1):
        row_num   = idx + 3
        conn_stat = r.get("connection_status", "SKIPPED")
        srv_stat  = r.get("server_status", "NOT CONNECTED")

        # Background colour driven by connection_status (overall row outcome)
        if conn_stat == "COMPLETED":
            bg = GREEN_BG if idx % 2 == 0 else GREEN_BG2
        elif conn_stat == "FAILED":
            bg = RED_BG   if idx % 2 == 0 else RED_BG2
        else:  # SKIPPED
            bg = AMBER_BG if idx % 2 == 0 else AMBER_BG2

        status_display = STATUS_DISPLAY.get(conn_stat, conn_stat)

        values = [
            idx,
            r.get("customer_name",   "") or "",
            r.get("env_type",        "") or "",
            srv_stat,
            r.get("server_host",     "") or "",
            r.get("server_error",    "") or "",
            r.get("db_name",         "") or "—",
            r.get("db_type",         "") or "",
            r.get("db_host",         "") or "",
            r.get("db_port",         "") or "",
            r.get("db_service",      "") or "—",
            status_display,
            r.get("duration_ms",     0),
            # Full error / warning message — never truncated in Excel.
            r.get("error_message",   "") or "",
            _ist_str(r.get("checked_at")),
        ]

        for col, val in enumerate(values, 1):
            cell           = ws.cell(row=row_num, column=col, value=val)
            cell.font      = Font(name="Calibri", size=10)
            cell.fill      = PatternFill("solid", fgColor=bg)
            cell.border    = _border()
            cell.alignment = Alignment(vertical="center", wrap_text=True)

            # Column 4 — DB Server Status: colour
            if col == 4:
                c = SERVER_COLOR.get(srv_stat, RED_TEXT)
                cell.font      = Font(name="Calibri", size=10, bold=True, color=c)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Column 6 — Server Error: red italic
            if col == 6 and val:
                cell.font = Font(name="Calibri", size=9, italic=True, color=RED_TEXT)

            # Column 12 — DB Connection Status
            if col == STATUS_COL:
                c = STATUS_COLOR.get(conn_stat, RED_TEXT)
                cell.font      = Font(name="Calibri", size=10, bold=True, color=c)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Column 13 — Duration: right-align
            if col == 13:
                cell.alignment = Alignment(horizontal="right", vertical="center")

            # Column 14 — DB Error / Warning Msg: italic, colour matches status
            if col == 14 and val:
                c = STATUS_COLOR.get(conn_stat, RED_TEXT)
                cell.font = Font(name="Calibri", size=9, italic=True, color=c)

        ws.row_dimensions[row_num].height = 20

    # ── Freeze header ─────────────────────────────────────────────────────────
    ws.freeze_panes = "A4"

    # ── Auto-filter ───────────────────────────────────────────────────────────
    if total:
        ws.auto_filter.ref = f"A3:{LAST_COL}{3 + total}"

    wb.save(filepath)
    logger.info(f"[STEP-8] Excel saved: {filepath}")
    return filepath
