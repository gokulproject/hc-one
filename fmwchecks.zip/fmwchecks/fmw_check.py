"""
fmw_check.py
============
FMW (Fusion Middleware / Oracle) Health Check Tool

- Reads customer / environment / DB connection details from: health_check schema
- Reads all tool configuration (email, Excel path, log path, etc.) from: fmwchecks schema
- Supports single/multiple customers and single/multiple environments
- Checks: Oracle DB connectivity, SSL/TLS certificate expiry, server reachability
- Outputs results to Excel and sends email report
"""

import sys
import os
import logging
import traceback
from datetime import datetime

# ── project-local imports ────────────────────────────────────────────────────
from config.db_config   import get_health_check_conn, get_fmwchecks_conn
from config.app_config  import load_app_config
from modules.customer   import fetch_customers
from modules.environment import fetch_environments
from modules.oracle_db  import fetch_oracle_databases
from modules.checks     import run_checks
from modules.excel_report import write_excel_report
from modules.email_sender import send_email_report
from modules.logger     import setup_logger

# ─────────────────────────────────────────────────────────────────────────────

def main():
    # ── 1. Load app config from fmwchecks schema ─────────────────────────────
    fmw_conn = get_fmwchecks_conn()
    cfg      = load_app_config(fmw_conn)

    # ── 2. Set up logger ──────────────────────────────────────────────────────
    log = setup_logger(cfg["log_path"], cfg["log_level"])
    log.info("=" * 70)
    log.info("FMW Health Check started at %s", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    try:
        # ── 3. Connect to health_check schema (read-only source) ──────────────
        hc_conn = get_health_check_conn()

        # ── 4. Fetch customers ─────────────────────────────────────────────────
        #   cfg["customer_filter"] = None → all customers
        #   cfg["customer_filter"] = [1, 3] → only those customer IDs
        customers = fetch_customers(hc_conn, cfg.get("customer_filter"))
        log.info("Customers loaded: %d", len(customers))

        # ── 5. Fetch environments per customer ────────────────────────────────
        #   cfg["env_filter"] = None → all envs
        #   cfg["env_filter"] = ["PRD"] → only PRD environments
        environments = fetch_environments(hc_conn, customers, cfg.get("env_filter"))
        log.info("Environments loaded: %d", sum(len(v) for v in environments.values()))

        # ── 6. Fetch Oracle DB configs per environment ─────────────────────────
        oracle_dbs = fetch_oracle_databases(hc_conn, environments)

        # ── 7. Run all checks ─────────────────────────────────────────────────
        results = run_checks(customers, environments, oracle_dbs, cfg, log)
        log.info("Checks completed. Total checks: %d", len(results))

        # ── 8. Write Excel report ─────────────────────────────────────────────
        report_path = write_excel_report(results, cfg, log)
        log.info("Excel report written: %s", report_path)

        # ── 9. Send email ─────────────────────────────────────────────────────
        send_email_report(cfg, report_path, results, log)
        log.info("Email sent to: %s", cfg["email_recipients"])

    except Exception as exc:
        log.error("FATAL ERROR: %s", exc)
        log.debug(traceback.format_exc())
        sys.exit(1)

    finally:
        try:
            hc_conn.close()
        except Exception:
            pass
        try:
            fmw_conn.close()
        except Exception:
            pass

    log.info("FMW Health Check completed successfully.")

# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    main()
