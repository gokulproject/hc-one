-- =============================================================================
-- fmwchecks_schema_setup.sql
--
-- Creates the fmwchecks schema and all configuration tables.
-- Run this ONCE to set up the tool's own database.
--
-- NOTE: health_check schema is NOT touched here. It is read-only.
-- =============================================================================

CREATE DATABASE IF NOT EXISTS fmwchecks
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE fmwchecks;

-- ---------------------------------------------------------------------------
-- 1. hc_fmt_config
--    General tool configuration (paths, thresholds, filters)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hc_fmt_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value TEXT,
    description  VARCHAR(255),
    status       TINYINT       NOT NULL DEFAULT 1 COMMENT '1=active, 0=disabled',
    updated_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default values
INSERT INTO hc_fmt_config (config_key, config_value, description) VALUES
-- Output paths
('excel_output_path', './output/fmw_health_check_{date}.xlsx',
    'Path for the Excel report. {date} is replaced with YYYYMMDD_HHMMSS'),
('log_path',          './logs/fmw_check.log',
    'Log file path'),
('log_level',         'INFO',
    'Logging level: DEBUG | INFO | WARNING | ERROR'),

-- Certificate check thresholds
('crt_warn_days',     '30',
    'Days before cert expiry to raise WARNING'),
('crt_critical_days', '7',
    'Days before cert expiry to raise CRITICAL'),
('crt_check_port',    '443',
    'Port to use for SSL certificate checks'),

-- Server reachability
('server_check_port', '22',
    'TCP port used to test server reachability (default SSH)'),

-- Which check types to run (true/false JSON)
('check_db',          'true',    'Run Oracle DB connectivity checks'),
('check_crt',         'true',    'Run SSL/TLS certificate expiry checks'),
('check_server',      'true',    'Run server TCP reachability checks'),

-- Scope filters (null = all; JSON arrays for selective runs)
-- Examples:
--   customer_filter: null         → all active customers
--   customer_filter: [1, 3]       → only CustomerID 1 and 3
--   env_filter:      null         → all env types
--   env_filter:      ["PRD"]      → production only
--   env_filter:      ["PRD","VAL"]→ production + validation
('customer_filter',   'null',
    'JSON array of CustomerIDs to check, or null for all'),
('env_filter',        'null',
    'JSON array of ServerType values (PRD/VAL/DEV) to check, or null for all')

ON DUPLICATE KEY UPDATE config_value = VALUES(config_value),
                         description  = VALUES(description);


-- ---------------------------------------------------------------------------
-- 2. hc_email_config
--    SMTP and recipient configuration
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hc_email_config (
    id           INT          NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT,
    description  VARCHAR(255),
    status       TINYINT      NOT NULL DEFAULT 1,
    updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO hc_email_config (config_key, config_value, description) VALUES
('smtp_host',        'smtp.example.com',          'SMTP server hostname'),
('smtp_port',        '587',                        'SMTP port (25 / 587 / 465)'),
('smtp_use_tls',     'true',                       'true = STARTTLS, "ssl" = SMTP_SSL, false = plain'),
('smtp_user',        '',                           'SMTP login user (leave empty for no auth)'),
('smtp_pass',        '',                           'SMTP login password'),
('email_from',       'fmwcheck@example.com',       'From address'),
-- Comma-separated list of recipients stored as JSON array
('email_recipients', '["admin@example.com"]',     'JSON array of recipient email addresses'),
('email_subject',    'FMW Health Check – {date}', 'Email subject ({date} = run timestamp)'),
('email_body',       'Please find the attached FMW Health Check report.', 'Email body text')

ON DUPLICATE KEY UPDATE config_value = VALUES(config_value),
                         description  = VALUES(description);


-- ---------------------------------------------------------------------------
-- Done
-- ---------------------------------------------------------------------------
SELECT 'fmwchecks schema setup complete.' AS result;
