-- =============================================================================
-- health_check_schema_reference.sql
--
-- This is a REFERENCE ONLY.
-- fmw_check.py reads from this schema but NEVER writes to it.
--
-- Run this only if you need to create a fresh health_check schema
-- (e.g. in a test/dev environment).
-- =============================================================================

CREATE DATABASE IF NOT EXISTS health_check
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE health_check;

-- ---------------------------------------------------------------------------
-- Customers
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Customers (
    CustomerID   INT          NOT NULL AUTO_INCREMENT,
    CustomerName VARCHAR(255) NOT NULL,
    CustomerCode VARCHAR(50),
    Tenant       VARCHAR(45),
    Status       TINYINT      NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
    PRIMARY KEY (CustomerID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Environments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Environments (
    EnvID      INT                        NOT NULL AUTO_INCREMENT,
    CustomerID INT                        NOT NULL,
    ServerUser VARCHAR(255),
    ServerPwd  VARCHAR(255),
    ServerType ENUM('VAL', 'PRD', 'DEV')  NOT NULL,
    Status     TINYINT                    NOT NULL DEFAULT 1,
    PRIMARY KEY (EnvID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- OracleDatabase
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS OracleDatabase (
    dbid         INT          NOT NULL AUTO_INCREMENT,
    ServerID     INT          NOT NULL COMMENT 'FK → Environments.EnvID',
    User         VARCHAR(225),
    Password     VARCHAR(225),
    OrdName      VARCHAR(225) COMMENT 'Oracle service name or SID',
    Port         INT          NOT NULL DEFAULT 1521,
    DatabaseType VARCHAR(50),
    Status       TINYINT      NOT NULL DEFAULT 1,
    PRIMARY KEY (dbid),
    FOREIGN KEY (ServerID) REFERENCES Environments(EnvID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Sample data (for testing)
-- ---------------------------------------------------------------------------
INSERT INTO Customers (CustomerName, CustomerCode, Tenant, Status) VALUES
('Acme Corp',    'ACME',  'acme_tenant',  1),
('Beta Ltd',     'BETA',  'beta_tenant',  1);

INSERT INTO Environments (CustomerID, ServerUser, ServerPwd, ServerType, Status) VALUES
(1, 'acme-prd.internal',  'prd_pass',  'PRD', 1),
(1, 'acme-val.internal',  'val_pass',  'VAL', 1),
(2, 'beta-prd.internal',  'prd_pass2', 'PRD', 1);

INSERT INTO OracleDatabase (ServerID, User, Password, OrdName, Port, DatabaseType, Status) VALUES
(1, 'acme_user', 'acme_db_pass', 'ACMEORCL', 1521, 'Oracle 19c', 1),
(3, 'beta_user', 'beta_db_pass', 'BETAORCL', 1521, 'Oracle 19c', 1);

SELECT 'health_check schema reference setup complete.' AS result;
