# FMW Health Check – fmwchecks

Automated health check tool for Oracle Fusion Middleware environments.

---

## What it checks

| Check | Description |
|---|---|
| **ORACLE_DB** | Connects to each Oracle database and runs `SELECT 1 FROM DUAL` |
| **CRT** | Reads the SSL/TLS certificate from the server and checks expiry date |
| **SERVER** | TCP-connects to the server host to confirm reachability |

---

## Architecture – Two Schemas

```
health_check schema  ←  READ ONLY
  Customers
  Environments
  OracleDatabase

fmwchecks schema  ←  CONFIG (read/write)
  hc_fmt_config      general settings
  hc_email_config    SMTP + recipients
```

The tool **never writes** to `health_check`.

---

## Supported scenarios

| Scenario | How |
|---|---|
| Single customer | Set `customer_filter` = `[<CustomerID>]` |
| Multiple customers | Set `customer_filter` = `[1, 3, 5]` |
| All customers | Set `customer_filter` = `null` |
| Single env type | Set `env_filter` = `["PRD"]` |
| Multiple env types | Set `env_filter` = `["PRD","VAL"]` |
| All env types | Set `env_filter` = `null` |

Both filters combine: e.g. customers `[1,2]` + env `["PRD"]` = PRD envs for customers 1 and 2 only.

---

## Setup (fresh install)

### 1. Clone / unzip the project

```bash
unzip fmwchecks.zip -d fmwchecks
cd fmwchecks
```

### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 3. Create fmwchecks schema

```sql
mysql -u root -p < scripts/fmwchecks_schema_setup.sql
```

This creates:
- `fmwchecks` database
- `hc_fmt_config` table (pre-populated with defaults)
- `hc_email_config` table (pre-populated with defaults)

### 4. Configure database connections

```bash
cp .env.template .env
```

Edit `.env` and fill in:
- `HC_DB_*`  – connection to your existing `health_check` schema
- `FMW_DB_*` – connection to the new `fmwchecks` schema

### 5. Configure tool settings in the database

**Paths and thresholds** (`hc_fmt_config`):

```sql
USE fmwchecks;

-- Where to save the Excel report
UPDATE hc_fmt_config SET config_value = '/opt/fmwcheck/output/report_{date}.xlsx'
WHERE config_key = 'excel_output_path';

-- Where to write logs
UPDATE hc_fmt_config SET config_value = '/opt/fmwcheck/logs/fmw_check.log'
WHERE config_key = 'log_path';

-- Only check PRD environments  (remove filter for all)
UPDATE hc_fmt_config SET config_value = '["PRD"]'
WHERE config_key = 'env_filter';

-- Only check specific customers (remove filter for all)
UPDATE hc_fmt_config SET config_value = '[1, 3]'
WHERE config_key = 'customer_filter';
```

**Email config** (`hc_email_config`):

```sql
USE fmwchecks;

UPDATE hc_email_config SET config_value = 'smtp.yourcompany.com'  WHERE config_key = 'smtp_host';
UPDATE hc_email_config SET config_value = '587'                    WHERE config_key = 'smtp_port';
UPDATE hc_email_config SET config_value = 'true'                   WHERE config_key = 'smtp_use_tls';
UPDATE hc_email_config SET config_value = 'fmwsvc@yourcompany.com' WHERE config_key = 'smtp_user';
UPDATE hc_email_config SET config_value = 'yourpassword'           WHERE config_key = 'smtp_pass';
UPDATE hc_email_config SET config_value = 'fmwcheck@yourcompany.com' WHERE config_key = 'email_from';

-- Multiple recipients
UPDATE hc_email_config
SET config_value = '["admin@yourcompany.com","team@yourcompany.com"]'
WHERE config_key = 'email_recipients';
```

### 6. Run

```bash
python fmw_check.py
```

---

## Excel Report Format

The report contains two sheets:

**Summary** tab
- Status count table (OK / WARNING / CRITICAL / ERROR / SKIPPED)
- Per-customer breakdown

**Detail** tab (colour-coded)
- One row per check
- Columns: Customer, CustomerCode, Tenant, EnvID, ServerType, CheckType, Target, Status, Detail, CheckedAt
- Status colours: 🟢 OK | 🟡 WARNING | 🔴 CRITICAL | 🔴 ERROR | ⚫ SKIPPED

---

## File & Directory Structure

```
fmwchecks/
├── fmw_check.py              ← main entry point
├── requirements.txt
├── .env.template             ← copy to .env and fill in values
├── config/
│   ├── db_config.py          ← DB connection factory
│   └── app_config.py         ← loads config from fmwchecks schema
├── modules/
│   ├── customer.py           ← reads health_check.Customers
│   ├── environment.py        ← reads health_check.Environments
│   ├── oracle_db.py          ← reads health_check.OracleDatabase
│   ├── checks.py             ← runs all health checks (DB, CRT, SERVER)
│   ├── excel_report.py       ← writes Excel output
│   ├── email_sender.py       ← sends email with attachment
│   └── logger.py             ← rotating file + console logger
├── scripts/
│   ├── fmwchecks_schema_setup.sql       ← run once to create fmwchecks DB
│   └── health_check_schema_reference.sql ← reference only (READ-ONLY source)
├── output/                   ← Excel reports written here (auto-created)
└── logs/                     ← Log files written here (auto-created)
```

---

## Scheduling (cron example)

```cron
# Run FMW health check every day at 06:00
0 6 * * * /usr/bin/python3 /opt/fmwchecks/fmw_check.py >> /opt/fmwchecks/logs/cron.log 2>&1
```
