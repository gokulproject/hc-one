"""
modules/checks.py
=================
Runs all health checks:
  1. Oracle DB connectivity  (cx_Oracle or oracledb)
  2. SSL/TLS certificate expiry  (CRT check)
  3. Server/host reachability  (TCP ping)

Each check returns a result dict that flows into the Excel report.
"""

import socket
import ssl
import datetime
import logging

# Oracle driver – try modern oracledb first, fall back to cx_Oracle
try:
    import oracledb as cx_Oracle
    _ORACLE_LIB = "oracledb"
except ImportError:
    try:
        import cx_Oracle
        _ORACLE_LIB = "cx_Oracle"
    except ImportError:
        cx_Oracle = None
        _ORACLE_LIB = None


# ── Status constants ──────────────────────────────────────────────────────────
STATUS_OK       = "OK"
STATUS_WARN     = "WARNING"
STATUS_CRITICAL = "CRITICAL"
STATUS_ERROR    = "ERROR"
STATUS_SKIP     = "SKIPPED"

# ─────────────────────────────────────────────────────────────────────────────

def run_checks(customers, environments, oracle_dbs, cfg, log: logging.Logger) -> list[dict]:
    """
    Iterates over all customers → environments → oracle DBs and runs checks.
    Returns flat list of result records.
    """
    results = []

    cust_map = {c["CustomerID"]: c for c in customers}

    for cid, envs in environments.items():
        customer = cust_map[cid]

        for env in envs:
            env_id   = env["EnvID"]
            env_type = env["ServerType"]
            log.info(
                "  Checking customer=%s env=%s (EnvID=%d)",
                customer["CustomerName"], env_type, env_id,
            )

            # ── Server reachability ────────────────────────────────────────
            if cfg.get("check_server", True):
                result = _check_server(customer, env, cfg, log)
                results.append(result)

            # ── Oracle DB checks ───────────────────────────────────────────
            if cfg.get("check_db", True):
                dbs = oracle_dbs.get(env_id, [])
                if not dbs:
                    log.debug("    No Oracle DBs configured for EnvID=%d", env_id)
                for db in dbs:
                    result = _check_oracle_db(customer, env, db, log)
                    results.append(result)

            # ── CRT (SSL certificate) check ────────────────────────────────
            if cfg.get("check_crt", True):
                result = _check_crt(customer, env, cfg, log)
                results.append(result)

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Individual check helpers
# ─────────────────────────────────────────────────────────────────────────────

def _base_record(customer, env, check_type, target=""):
    return {
        "CustomerName": customer["CustomerName"],
        "CustomerCode": customer["CustomerCode"],
        "Tenant":       customer["Tenant"],
        "EnvID":        env["EnvID"],
        "ServerType":   env["ServerType"],
        "CheckType":    check_type,
        "Target":       target,
        "Status":       STATUS_ERROR,
        "Detail":       "",
        "CheckedAt":    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


# ── 1. Server reachability ────────────────────────────────────────────────────

def _check_server(customer, env, cfg, log):
    """
    Tries to resolve and TCP-connect to the server host.
    ServerUser stores the hostname/IP (used as the host target here).
    """
    host = env.get("ServerUser", "")
    port = int(cfg.get("server_check_port", 22))  # default SSH port
    rec  = _base_record(customer, env, "SERVER", f"{host}:{port}")

    if not host:
        rec["Status"] = STATUS_SKIP
        rec["Detail"] = "No ServerUser/host configured"
        return rec

    try:
        sock = socket.create_connection((host, port), timeout=10)
        sock.close()
        rec["Status"] = STATUS_OK
        rec["Detail"] = f"Reachable on port {port}"
        log.debug("    SERVER OK: %s:%s", host, port)
    except OSError as exc:
        rec["Status"] = STATUS_CRITICAL
        rec["Detail"] = str(exc)
        log.warning("    SERVER FAIL: %s:%s – %s", host, port, exc)

    return rec


# ── 2. Oracle DB connectivity ─────────────────────────────────────────────────

def _check_oracle_db(customer, env, db, log):
    host    = env.get("ServerUser", "localhost")
    port    = db.get("Port", 1521)
    service = db.get("OrdName", "")
    user    = db.get("User", "")
    pwd     = db.get("Password", "")
    dsn     = f"{host}:{port}/{service}"
    rec     = _base_record(customer, env, "ORACLE_DB", dsn)

    if not cx_Oracle:
        rec["Status"] = STATUS_SKIP
        rec["Detail"] = "Oracle driver not installed (pip install oracledb)"
        return rec

    try:
        if _ORACLE_LIB == "oracledb":
            cx_Oracle.init_oracle_client()  # thin mode: no client libs needed
        conn = cx_Oracle.connect(user=user, password=pwd, dsn=dsn, timeout=10)
        cur  = conn.cursor()
        cur.execute("SELECT 1 FROM DUAL")
        cur.close()
        conn.close()
        rec["Status"] = STATUS_OK
        rec["Detail"] = f"Connected to {dsn} as {user}"
        log.debug("    DB OK: %s", dsn)
    except Exception as exc:
        rec["Status"] = STATUS_CRITICAL
        rec["Detail"] = str(exc)
        log.warning("    DB FAIL: %s – %s", dsn, exc)

    return rec


# ── 3. SSL/TLS Certificate check ──────────────────────────────────────────────

def _check_crt(customer, env, cfg, log):
    """
    Connects to the server on HTTPS (port 443) and reads the SSL certificate
    expiry date. Flags WARNING / CRITICAL based on cfg thresholds.
    """
    host     = env.get("ServerUser", "")
    port     = int(cfg.get("crt_check_port", 443))
    warn_d   = int(cfg.get("crt_warn_days",     30))
    crit_d   = int(cfg.get("crt_critical_days",  7))
    rec      = _base_record(customer, env, "CRT", f"{host}:{port}")

    if not host:
        rec["Status"] = STATUS_SKIP
        rec["Detail"] = "No hostname configured"
        return rec

    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.create_connection((host, port), timeout=10),
                             server_hostname=host) as ssock:
            cert   = ssock.getpeercert()
            expiry_str = cert["notAfter"]          # e.g. "Dec 31 23:59:59 2025 GMT"
            expiry = datetime.datetime.strptime(expiry_str, "%b %d %H:%M:%S %Y %Z")
            days_left = (expiry - datetime.datetime.utcnow()).days

            if days_left <= crit_d:
                rec["Status"] = STATUS_CRITICAL
            elif days_left <= warn_d:
                rec["Status"] = STATUS_WARN
            else:
                rec["Status"] = STATUS_OK

            rec["Detail"] = (
                f"Expires {expiry.strftime('%Y-%m-%d')} "
                f"({days_left} days remaining)"
            )
            log.debug("    CRT %s: %s days left", rec["Status"], days_left)

    except ssl.SSLCertVerificationError as exc:
        rec["Status"] = STATUS_CRITICAL
        rec["Detail"] = f"CRT verification failed: {exc}"
        log.warning("    CRT FAIL: %s – %s", host, exc)
    except OSError as exc:
        rec["Status"] = STATUS_ERROR
        rec["Detail"] = f"Connection error: {exc}"
        log.warning("    CRT ERROR: %s – %s", host, exc)

    return rec
