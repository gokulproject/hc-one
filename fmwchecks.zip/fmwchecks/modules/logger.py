"""
modules/logger.py
=================
Sets up a rotating file + console logger.
"""

import os
import logging
from logging.handlers import RotatingFileHandler


def setup_logger(log_path: str, level_str: str = "INFO") -> logging.Logger:
    level = getattr(logging, level_str.upper(), logging.INFO)

    os.makedirs(os.path.dirname(os.path.abspath(log_path)), exist_ok=True)

    log = logging.getLogger("fmwcheck")
    log.setLevel(level)

    if log.handlers:
        return log  # already configured (re-entrant safe)

    fmt = logging.Formatter(
        "%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Rotating file handler (10 MB, keep 5 backups) ─────────────────────────
    fh = RotatingFileHandler(log_path, maxBytes=10 * 1024 * 1024, backupCount=5)
    fh.setFormatter(fmt)
    log.addHandler(fh)

    # ── Console handler ───────────────────────────────────────────────────────
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    log.addHandler(ch)

    return log
