"""
modules/excel_report.py
=======================
Writes health check results to a colour-coded Excel file.

Output columns:
  Customer | CustomerCode | Tenant | EnvID | ServerType |
  CheckType | Target | Status | Detail | CheckedAt

Status colour coding:
  OK        → green
  WARNING   → orange/yellow
  CRITICAL  → red
  ERROR     → dark red
  SKIPPED   → grey
"""

import os
import datetime
import logging

try:
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    _HAS_OPENPYXL = True
except ImportError:
    _HAS_OPENPYXL = False


# ── Status colour map (ARGB) ──────────────────────────────────────────────────
_FILL = {
    "OK":       "FF92D050",   # green
    "WARNING":  "FFFFC000",   # amber
    "CRITICAL": "FFFF0000",   # red
    "ERROR":    "FFC00000",   # dark red
    "SKIPPED":  "FFD9D9D9",   # grey
}

_HEADERS = [
    "Customer", "CustomerCode", "Tenant",
    "EnvID", "ServerType", "CheckType",
    "Target", "Status", "Detail", "CheckedAt",
]

_COL_WIDTHS = [25, 15, 15, 8, 12, 12, 35, 10, 55, 20]

_HEADER_FILL  = PatternFill("solid", fgColor="FF2F4F8F") if _HAS_OPENPYXL else None
_HEADER_FONT  = Font(bold=True, color="FFFFFFFF")       if _HAS_OPENPYXL else None
_THIN_BORDER  = Border(
    left   = Side(style="thin"),
    right  = Side(style="thin"),
    top    = Side(style="thin"),
    bottom = Side(style="thin"),
) if _HAS_OPENPYXL else None


def write_excel_report(results: list[dict], cfg: dict, log: logging.Logger) -> str:
    """
    Writes results to an Excel file and returns the final file path.
    """
    raw_path = cfg.get("excel_output_path", "./output/fmw_health_check.xlsx")

    # Substitute {date} placeholder
    today = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path  = raw_path.replace("{date}", today)

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    if not _HAS_OPENPYXL:
        log.error("openpyxl not installed – cannot write Excel. Run: pip install openpyxl")
        return path

    wb = Workbook()

    # ── Summary sheet ─────────────────────────────────────────────────────────
    _write_summary_sheet(wb, results)

    # ── Detail sheet ──────────────────────────────────────────────────────────
    ws = wb.active
    ws.title = "Detail"

    # Header row
    for col_idx, header in enumerate(_HEADERS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill   = _HEADER_FILL
        cell.font   = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = _THIN_BORDER

    ws.row_dimensions[1].height = 20

    # Data rows
    for row_idx, rec in enumerate(results, start=2):
        row_values = [
            rec.get("CustomerName"),
            rec.get("CustomerCode"),
            rec.get("Tenant"),
            rec.get("EnvID"),
            rec.get("ServerType"),
            rec.get("CheckType"),
            rec.get("Target"),
            rec.get("Status"),
            rec.get("Detail"),
            rec.get("CheckedAt"),
        ]
        status = rec.get("Status", "ERROR")
        fill   = PatternFill("solid", fgColor=_FILL.get(status, "FFFFFFFF"))

        for col_idx, value in enumerate(row_values, start=1):
            cell           = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.border    = _THIN_BORDER
            # Colour the Status cell
            if col_idx == 8:
                cell.fill = fill
                cell.font = Font(bold=True)

    # Column widths
    for col_idx, width in enumerate(_COL_WIDTHS, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    # Freeze header row
    ws.freeze_panes = "A2"

    # Auto-filter
    ws.auto_filter.ref = ws.dimensions

    wb.save(path)
    log.info("Excel saved: %s", path)
    return path


def _write_summary_sheet(wb: "Workbook", results: list[dict]):
    """Creates a Summary tab with counts by status and customer."""
    ws = wb.create_sheet("Summary", 0)

    from collections import Counter
    status_counts = Counter(r["Status"] for r in results)

    ws["A1"] = "FMW Health Check – Summary"
    ws["A1"].font = Font(bold=True, size=14)

    ws["A3"] = "Status"
    ws["B3"] = "Count"
    for cell in [ws["A3"], ws["B3"]]:
        cell.fill   = _HEADER_FILL
        cell.font   = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    for row_offset, (status, count) in enumerate(status_counts.items(), start=4):
        ws.cell(row=row_offset, column=1, value=status).fill = PatternFill(
            "solid", fgColor=_FILL.get(status, "FFFFFFFF")
        )
        ws.cell(row=row_offset, column=2, value=count)

    # Per-customer summary
    ws["D3"] = "Customer"
    ws["E3"] = "OK"
    ws["F3"] = "WARNING"
    ws["G3"] = "CRITICAL"
    ws["H3"] = "ERROR"
    for cell in [ws["D3"], ws["E3"], ws["F3"], ws["G3"], ws["H3"]]:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    customers_seen = {}
    for rec in results:
        cn = rec["CustomerName"]
        if cn not in customers_seen:
            customers_seen[cn] = Counter()
        customers_seen[cn][rec["Status"]] += 1

    for row_offset, (cname, counts) in enumerate(customers_seen.items(), start=4):
        ws.cell(row=row_offset, column=4, value=cname)
        ws.cell(row=row_offset, column=5, value=counts.get("OK", 0))
        ws.cell(row=row_offset, column=6, value=counts.get("WARNING", 0))
        ws.cell(row=row_offset, column=7, value=counts.get("CRITICAL", 0))
        ws.cell(row=row_offset, column=8, value=counts.get("ERROR", 0))

    for col, width in zip("ABCDEFGH", [18, 8, 4, 28, 6, 10, 10, 8]):
        ws.column_dimensions[col].width = width
