"""
modules/customer.py
===================
Reads customer records from health_check.Customers.

Schema (READ-ONLY):
  CustomerID   int AI PK
  CustomerName varchar(255)
  CustomerCode varchar(50)
  Tenant       varchar(45)
  Status       tinyint       -- 1 = active

customer_filter : None | list[int]
  None          → fetch all active customers
  [1, 3, 5]     → fetch only those CustomerIDs
"""


def fetch_customers(hc_conn, customer_filter=None) -> list[dict]:
    """
    Returns a list of customer dicts.
    """
    cursor = hc_conn.cursor(dictionary=True)

    if customer_filter:
        placeholders = ", ".join(["%s"] * len(customer_filter))
        sql = (
            f"SELECT CustomerID, CustomerName, CustomerCode, Tenant, Status "
            f"FROM Customers "
            f"WHERE Status = 1 AND CustomerID IN ({placeholders}) "
            f"ORDER BY CustomerName"
        )
        cursor.execute(sql, customer_filter)
    else:
        cursor.execute(
            "SELECT CustomerID, CustomerName, CustomerCode, Tenant, Status "
            "FROM Customers "
            "WHERE Status = 1 "
            "ORDER BY CustomerName"
        )

    customers = cursor.fetchall()
    cursor.close()

    if not customers:
        raise ValueError(
            "No active customers found in health_check.Customers. "
            "Check customer_filter in fmwchecks.hc_fmt_config."
        )

    return customers
