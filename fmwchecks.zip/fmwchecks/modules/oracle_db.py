"""
modules/oracle_db.py
====================
Reads Oracle DB configs from health_check.OracleDatabase.

Schema (READ-ONLY):
  dbid         int AI PK
  ServerID     int              → FK → Environments.EnvID
  User         varchar(225)
  Password     varchar(225)
  OrdName      varchar(225)     -- Oracle service name / SID
  Port         int
  DatabaseType varchar(50)
  Status       tinyint          -- 1 = active

Returns:
  dict[EnvID (int) → list[db_dict]]
"""


def fetch_oracle_databases(hc_conn, environments: dict) -> dict:
    """
    Returns {EnvID: [db_config, ...]} for all environments.
    """
    all_env_ids = [
        env["EnvID"]
        for envs in environments.values()
        for env in envs
    ]

    if not all_env_ids:
        return {}

    cursor = hc_conn.cursor(dictionary=True)
    placeholders = ", ".join(["%s"] * len(all_env_ids))
    sql = (
        f"SELECT dbid, ServerID, User, Password, OrdName, Port, DatabaseType, Status "
        f"FROM OracleDatabase "
        f"WHERE Status = 1 AND ServerID IN ({placeholders}) "
        f"ORDER BY ServerID, OrdName"
    )
    cursor.execute(sql, all_env_ids)
    rows = cursor.fetchall()
    cursor.close()

    result: dict = {eid: [] for eid in all_env_ids}
    for row in rows:
        result[row["ServerID"]].append(row)

    return result
