"""
modules/email_sender.py
=======================
Sends the Excel report as an email attachment.

Config keys (from fmwchecks.hc_email_config):
  smtp_host         – SMTP server hostname
  smtp_port         – SMTP port (default 25 / 587 / 465)
  smtp_use_tls      – True → STARTTLS; "ssl" → SMTP_SSL
  smtp_user         – login user (empty = no auth)
  smtp_pass         – login password
  email_from        – From address
  email_recipients  – list of To addresses
  email_subject     – subject (supports {date} placeholder)
  email_body        – plain text body
"""

import os
import datetime
import logging
import smtplib
from email.message import EmailMessage
from collections import Counter


def send_email_report(cfg: dict, report_path: str, results: list[dict], log: logging.Logger):
    recipients = cfg.get("email_recipients", [])
    if not recipients:
        log.warning("No email recipients configured – skipping email.")
        return

    today   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    subject = cfg.get("email_subject", "FMW Health Check Report – {date}").replace("{date}", today)

    # ── Build summary for email body ──────────────────────────────────────────
    counts = Counter(r["Status"] for r in results)
    summary_lines = [
        cfg.get("email_body", "Please find the FMW Health Check report attached."),
        "",
        f"Run time   : {today}",
        f"Total checks: {len(results)}",
        f"  OK        : {counts.get('OK', 0)}",
        f"  WARNING   : {counts.get('WARNING', 0)}",
        f"  CRITICAL  : {counts.get('CRITICAL', 0)}",
        f"  ERROR     : {counts.get('ERROR', 0)}",
        f"  SKIPPED   : {counts.get('SKIPPED', 0)}",
    ]
    body = "\n".join(summary_lines)

    # ── Compose message ───────────────────────────────────────────────────────
    msg = EmailMessage()
    msg["From"]    = cfg.get("email_from", "fmwcheck@localhost")
    msg["To"]      = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(body)

    # Attach Excel if it exists
    if os.path.isfile(report_path):
        with open(report_path, "rb") as fh:
            msg.add_attachment(
                fh.read(),
                maintype="application",
                subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                filename=os.path.basename(report_path),
            )
    else:
        log.warning("Report file not found, sending email without attachment: %s", report_path)

    # ── Send ──────────────────────────────────────────────────────────────────
    smtp_host = cfg.get("smtp_host", "localhost")
    smtp_port = int(cfg.get("smtp_port", 25))
    use_tls   = cfg.get("smtp_use_tls", False)
    smtp_user = cfg.get("smtp_user", "")
    smtp_pass = cfg.get("smtp_pass", "")

    try:
        if use_tls == "ssl":
            server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=15)
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=15)
            if use_tls:
                server.starttls()

        if smtp_user:
            server.login(smtp_user, smtp_pass)

        server.send_message(msg)
        server.quit()
        log.info("Email sent to: %s", recipients)

    except Exception as exc:
        log.error("Failed to send email: %s", exc)
