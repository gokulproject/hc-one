"""
modules/environment.py
======================
Reads environment records from health_check.Environments.

Schema (READ-ONLY):
  EnvID      int AI PK
  CustomerID int               → FK → Customers
  ServerUser varchar(255)
  ServerPwd  varchar(255)
  ServerType enum('VAL','PRD','DEV')
  Status     tinyint           -- 1 = active

env_filter : None | list[str]
  None          → all active environments
  ['PRD']       → production only
  ['PRD','VAL'] → production + validation

Returns:
  dict[CustomerID (int) → list[env_dict]]
"""


def fetch_environments(hc_conn, customers: list[dict], env_filter=None) -> dict:
    """
    Returns {CustomerID: [env, ...]} for all given customers.
    """
    customer_ids = [c["CustomerID"] for c in customers]
    cursor = hc_conn.cursor(dictionary=True)

    id_placeholders = ", ".join(["%s"] * len(customer_ids))
    params = list(customer_ids)

    if env_filter:
        type_placeholders = ", ".join(["%s"] * len(env_filter))
        sql = (
            f"SELECT EnvID, CustomerID, ServerUser, ServerPwd, ServerType, Status "
            f"FROM Environments "
            f"WHERE Status = 1 "
            f"AND CustomerID IN ({id_placeholders}) "
            f"AND ServerType IN ({type_placeholders}) "
            f"ORDER BY CustomerID, ServerType"
        )
        params += list(env_filter)
    else:
        sql = (
            f"SELECT EnvID, CustomerID, ServerUser, ServerPwd, ServerType, Status "
            f"FROM Environments "
            f"WHERE Status = 1 "
            f"AND CustomerID IN ({id_placeholders}) "
            f"ORDER BY CustomerID, ServerType"
        )

    cursor.execute(sql, params)
    rows = cursor.fetchall()
    cursor.close()

    # Group by CustomerID
    result: dict = {c["CustomerID"]: [] for c in customers}
    for row in rows:
        result[row["CustomerID"]].append(row)

    return result
