"""
config/db_config.py
===================
Database connection factory.

Two separate connections are used:
  - health_check  : source-of-truth for customers / environments / oracle DBs (READ-ONLY)
  - fmwchecks     : tool configuration tables (email, paths, filters, etc.)

Connection parameters are read from environment variables (preferred) or
from a local .env file via python-dotenv.

Environment variables
─────────────────────
  HC_DB_HOST, HC_DB_PORT, HC_DB_USER, HC_DB_PASS, HC_DB_NAME
  FMW_DB_HOST, FMW_DB_PORT, FMW_DB_USER, FMW_DB_PASS, FMW_DB_NAME
"""

import os
import mysql.connector
from mysql.connector import Error

# Optional: load from .env file if present
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
except ImportError:
    pass


def _connect(host, port, user, password, database, schema_label=""):
    """Generic MySQL connector with error handling."""
    try:
        conn = mysql.connector.connect(
            host=host,
            port=int(port),
            user=user,
            password=password,
            database=database,
            connection_timeout=10,
            autocommit=True,
        )
        return conn
    except Error as exc:
        raise ConnectionError(
            f"Cannot connect to {schema_label} schema ({database} @ {host}:{port}): {exc}"
        ) from exc


def get_health_check_conn():
    """Returns a connection to the health_check schema (READ-ONLY usage)."""
    return _connect(
        host     = os.environ.get("HC_DB_HOST",  "localhost"),
        port     = os.environ.get("HC_DB_PORT",  "3306"),
        user     = os.environ.get("HC_DB_USER",  "hc_reader"),
        password = os.environ.get("HC_DB_PASS",  ""),
        database = os.environ.get("HC_DB_NAME",  "health_check"),
        schema_label="health_check",
    )


def get_fmwchecks_conn():
    """Returns a connection to the fmwchecks schema (config read/write)."""
    return _connect(
        host     = os.environ.get("FMW_DB_HOST", "localhost"),
        port     = os.environ.get("FMW_DB_PORT", "3306"),
        user     = os.environ.get("FMW_DB_USER", "fmw_admin"),
        password = os.environ.get("FMW_DB_PASS", ""),
        database = os.environ.get("FMW_DB_NAME", "fmwchecks"),
        schema_label="fmwchecks",
    )
