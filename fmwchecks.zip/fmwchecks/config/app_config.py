"""
config/app_config.py
====================
Loads all tool configuration from the fmwchecks schema tables.

Tables read (all in fmwchecks schema):
  hc_fmt_config   – general settings (excel path, log path, etc.)
  hc_email_config – SMTP and recipient settings
"""

import json


# ── Default fallbacks (used if DB row is missing) ────────────────────────────
_DEFAULTS = {
    "excel_output_path": "./output/fmw_health_check.xlsx",
    "log_path":          "./logs/fmw_check.log",
    "log_level":         "INFO",
    "crt_warn_days":     30,       # warn when cert expires within N days
    "crt_critical_days": 7,        # critical threshold
    "check_db":          True,     # check Oracle DB connectivity
    "check_crt":         True,     # check SSL/TLS certificates
    "check_server":      True,     # check server/host reachability
    "customer_filter":   None,     # None = all customers
    "env_filter":        None,     # None = all env types; or ["PRD","VAL"] etc.
    # email
    "smtp_host":         "localhost",
    "smtp_port":         25,
    "smtp_use_tls":      False,
    "smtp_user":         "",
    "smtp_pass":         "",
    "email_from":        "fmwcheck@example.com",
    "email_recipients":  [],
    "email_subject":     "FMW Health Check Report – {date}",
    "email_body":        "Please find the FMW Health Check report attached.",
}


def _row_to_dict(rows):
    """Convert list of (key, value) rows to a dict."""
    return {r[0]: r[1] for r in rows}


def _parse_value(raw):
    """
    Try to deserialize JSON values (lists, booleans, ints stored as strings).
    Falls back to raw string.
    """
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return raw


def load_app_config(fmw_conn) -> dict:
    """
    Reads configuration from fmwchecks.hc_fmt_config and
    fmwchecks.hc_email_config and returns a merged settings dict.
    """
    cfg = dict(_DEFAULTS)  # start with defaults

    cursor = fmw_conn.cursor()

    # ── hc_fmt_config ─────────────────────────────────────────────────────────
    try:
        cursor.execute(
            "SELECT config_key, config_value FROM hc_fmt_config WHERE status = 1"
        )
        for key, val in cursor.fetchall():
            cfg[key] = _parse_value(val)
    except Exception as exc:
        # table might not exist yet; keep defaults
        print(f"[WARN] Could not read hc_fmt_config: {exc}")

    # ── hc_email_config ───────────────────────────────────────────────────────
    try:
        cursor.execute(
            "SELECT config_key, config_value FROM hc_email_config WHERE status = 1"
        )
        for key, val in cursor.fetchall():
            cfg[key] = _parse_value(val)
    except Exception as exc:
        print(f"[WARN] Could not read hc_email_config: {exc}")

    cursor.close()

    # Ensure recipients is always a list
    if isinstance(cfg.get("email_recipients"), str):
        cfg["email_recipients"] = [
            e.strip() for e in cfg["email_recipients"].split(",") if e.strip()
        ]

    return cfg
