"""
fmw_checker.py
==============
FMW Database Connection Checker.

STRICT FLOW:
  FOR each Customer:
    FOR each Environment:
      Step 5 : Identify DB Server
        IF no server record  → log warning, write SKIPPED row to Excel, continue
      Step 5A: WMI Server connection  (uses Environments.ServerUser + ServerPwd)
        IF NOT connected → log error,  write NOT CONNECTED row to Excel, continue
        IF connected     → disconnect WMI, proceed to Step 6
      Step 6 : Load FMW Oracle DB records
        IF no records    → log warning, write SKIPPED row to Excel, continue
      Step 6B: FMW Oracle DB connection
        IF connected  → COMPLETED row
        IF failed     → FAILED row + full error

Reads from : health_check schema (READ ONLY)
Writes to  : fmwchecks schema
"""
import logging
import os
import sys
import time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.crypto     import decrypt_password, is_encrypted
from Common.db_manager import DBManager
from config            import HC_DB, FMWCHECKS_DB

logger = logging.getLogger("fmw.checker")

FMW_DB_TYPE   = "FMW"
ALL_ENV_TYPES = ["DEV", "VAL", "PRD"]
IST_OFFSET    = timedelta(hours=5, minutes=30)


def _now_ist() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


class FMWChecker:

    def __init__(self, run_id: int, app_cfg=None):
        self.run_id           = run_id
        self.cfg              = app_cfg
        # NOTE: oracle_timeout is intentionally NOT passed to oracledb.connect()
        # because that parameter causes connection crashes on some drivers.
        # We keep it here only for reference / future use.
        self._oracle_timeout  = getattr(app_cfg, "oracle_timeout",   15) if app_cfg else 15
        self._oracle_dll_path = getattr(app_cfg, "oracle_dll_path",  "") if app_cfg else ""
        self._config_customers = getattr(app_cfg, "config_customers", []) if app_cfg else []
        self._config_envs     = getattr(app_cfg, "config_envs",      []) if app_cfg else []
        self._setup_oracle_client()

    # ── Oracle client init ────────────────────────────────────────────────────
    def _setup_oracle_client(self):
        try:
            import oracledb
            dll = self._oracle_dll_path
            if dll and os.path.isdir(dll) and os.listdir(dll):
                oracledb.init_oracle_client(lib_dir=dll)
                logger.info(f"Oracle thick client initialised from: {dll}")
            else:
                logger.info("Oracle thin client mode (no DLL path configured)")
        except Exception as exc:
            logger.warning(f"Oracle client init warning (non-fatal): {exc}")

    # ── STEP 5A: WMI Server connection ────────────────────────────────────────
    def _check_server_wmi(self, host: str,
                          username: str, password: str) -> tuple:
        """
        Connect to Windows server via WMI using ServerUser + ServerPwd.
        Returns (connected: bool, error: str|None, duration_ms: int,
                 wmi_connection_obj or None)
        Caller is responsible for disconnecting (pass obj to _disconnect_wmi).
        """
        logger.info(f"    WMI connecting → {host} | user={username}")
        start = time.time()
        try:
            import wmi
            clean_user = username.replace("\\\\", "\\")
            conn = wmi.WMI(
                computer=host,
                user=clean_user,
                password=r"{}".format(password),
            )
            conn.Win32_OperatingSystem()   # lightweight liveness check
            ms = int((time.time() - start) * 1000)
            logger.info(f"    WMI connected: {host} ({ms}ms)")
            return True, None, ms, conn
        except Exception as exc:
            ms  = int((time.time() - start) * 1000)
            err = str(exc)
            logger.error(f"    WMI failed: {host} | user={username} | {err}")
            return False, err, ms, None

    def _disconnect_wmi(self, conn, host: str):
        """Release WMI connection object."""
        try:
            if conn is not None:
                del conn
            logger.debug(f"    WMI disconnected: {host}")
        except Exception as exc:
            logger.debug(f"    WMI disconnect note: {exc}")

    # ── STEP 6B: FMW Oracle DB connection ─────────────────────────────────────
    def _check_db_connection(self, db_info: dict) -> tuple:
        """
        Attempt Oracle DB connection.
        Returns (connected: bool, error: str|None, duration_ms: int)

        NOTE: 'timeout' is NOT passed to oracledb.connect() — that parameter
        is not supported in thin mode and causes crashes. TCP-level timeout is
        handled by the OS / network stack.
        """
        host    = db_info.get("db_host",    "")
        port    = int(db_info.get("db_port", 1521))
        service = db_info.get("db_service", "")
        user    = db_info.get("db_user",    "")
        pwd_raw = db_info.get("db_password","")
        name    = db_info.get("db_name",    "?")
        cname   = db_info.get("customer_name", "")
        env     = db_info.get("env_type",   "")
        db_type = db_info.get("database_type", "Oracle")

        password = decrypt_password(pwd_raw) if is_encrypted(pwd_raw) else pwd_raw
        dsn      = f"{host}:{port}/{service}"

        logger.info(
            f"    [{db_type}] DB connecting → {cname}/{env} | "
            f"DB={name} | DSN={dsn} | user={user}")

        start = time.time()
        conn  = None
        try:
            import oracledb
            # Do NOT pass timeout= here — it crashes oracledb thin mode
            conn = oracledb.connect(
                user=user,
                password=password,
                dsn=dsn,
            )
            ms = int((time.time() - start) * 1000)
            conn.close()
            conn = None
            logger.info(
                f"    [{db_type}] DB connected: {cname}/{env} | DB={name} | {ms}ms")
            return True, None, ms

        except Exception as exc:
            ms  = int((time.time() - start) * 1000)
            err = str(exc)[:1000]
            logger.error(
                f"    [{db_type}] DB connection failed: "
                f"{cname}/{env} | DB={name} | {err}")
            return False, err, ms

        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass

    # ── HC schema queries ──────────────────────────────────────────────────────
    def _load_customers(self, db) -> list:
        if self._config_customers:
            ph   = ",".join(["%s"] * len(self._config_customers))
            rows = db.fetch_all(
                f"""SELECT CustomerID AS customer_id,
                           CustomerName AS customer_name
                    FROM Customers
                    WHERE CustomerName IN ({ph}) AND Status=1
                    ORDER BY CustomerName""",
                tuple(self._config_customers))
            logger.info(
                f"Customer filter applied: {self._config_customers} → {len(rows)} found")
        else:
            rows = db.fetch_all(
                """SELECT CustomerID AS customer_id,
                          CustomerName AS customer_name
                   FROM Customers
                   WHERE Status=1
                   ORDER BY CustomerName""")
            logger.info(f"All active customers loaded: {len(rows)} found")
        return rows

    def _load_envs(self, db, customer_id: int) -> list:
        scope = self._config_envs if self._config_envs else ALL_ENV_TYPES
        ph    = ",".join(["%s"] * len(scope))
        return db.fetch_all(
            f"""SELECT EnvID      AS env_id,
                       ServerType AS env_type,
                       ServerUser AS server_user,
                       ServerPwd  AS server_pwd
                FROM Environments
                WHERE CustomerID=%s
                  AND ServerType IN ({ph})
                  AND Status=1
                ORDER BY FIELD(ServerType,'DEV','VAL','PRD')""",
            tuple([customer_id] + scope))

    def _load_server(self, db, env_id: int) -> dict:
        return db.fetch_one(
            """SELECT ServerID AS server_id,
                      Host     AS host
               FROM Servers
               WHERE EnvID=%s AND Status=1
               LIMIT 1""",
            (env_id,))

    def _load_fmw_dbs(self, db, server_id: int) -> list:
        return db.fetch_all(
            """SELECT dbid       AS db_id,
                      OrdName    AS db_name,
                      OrdName    AS db_service,
                      Port       AS db_port,
                      User       AS db_user,
                      Password   AS db_password,
                      DatabaseType AS database_type
               FROM OracleDatabase
               WHERE ServerID=%s
                 AND DatabaseType=%s
                 AND Status=1""",
            (server_id, FMW_DB_TYPE))

    # ── Save result ───────────────────────────────────────────────────────────
    def _save_result(self, result: dict):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_connection_result
                       (run_id, customer_id, customer_name, env_type,
                        server_host, server_status, server_error,
                        db_name, db_host, db_port, db_service,
                        connection_status, error_message,
                        duration_ms, checked_at)
                       VALUES
                       (%s,%s,%s,%s, %s,%s,%s, %s,%s,%s,%s, %s,%s, %s,%s)""",
                    (result["run_id"],
                     result["customer_id"],   result["customer_name"],
                     result["env_type"],
                     result["server_host"],   result["server_status"],
                     result["server_error"],
                     result["db_name"],       result["db_host"],
                     result["db_port"],       result["db_service"],
                     result["connection_status"], result["error_message"],
                     result["duration_ms"],   result["checked_at"]))
        except Exception as exc:
            logger.error(f"Failed to save result to DB: {exc}")

    # ── Log step ──────────────────────────────────────────────────────────────
    def _log_step(self, step_no: int, step_name: str, status: str,
                  message: str = "", customer: str = "", env_type: str = ""):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     message[:2000] if message else "",
                     customer[:255] if customer else "",
                     env_type[:50]  if env_type  else ""))
        except Exception as exc:
            logger.warning(f"Step log write failed: {exc}")

    # ── Build a result dict ────────────────────────────────────────────────────
    def _make_result(self, cid, cname, env_type,
                     server_host, server_status, server_error,
                     db_name, db_host, db_port, db_service,
                     connection_status, error_message, duration_ms) -> dict:
        return {
            "run_id":            self.run_id,
            "customer_id":       cid,
            "customer_name":     cname,
            "env_type":          env_type,
            "server_host":       server_host,
            "server_status":     server_status,
            "server_error":      server_error,
            "db_name":           db_name,
            "db_host":           db_host,
            "db_port":           db_port,
            "db_service":        db_service,
            "connection_status": connection_status,
            "error_message":     error_message,
            "duration_ms":       duration_ms,
            "checked_at":        datetime.utcnow(),
        }

    # ── MAIN LOOP ─────────────────────────────────────────────────────────────
    def run_all(self) -> list:
        results   = []
        env_scope = self._config_envs if self._config_envs else ALL_ENV_TYPES

        logger.info("")
        logger.info(
            f"[STEP-3] Loading customers | "
            f"env_scope={env_scope} | {_now_ist()}")
        self._log_step(3, "IDENTIFY_CUSTOMERS", "STARTED",
                       f"customer_filter="
                       f"{'ALL' if not self._config_customers else self._config_customers} | "
                       f"env_filter={'ALL' if not env_scope else env_scope}")

        # ── Load customers ────────────────────────────────────────────────────
        try:
            with DBManager(cfg=HC_DB) as db:
                customers = self._load_customers(db)
        except Exception as exc:
            logger.error(f"[STEP-3] Cannot load customers: {exc}", exc_info=True)
            self._log_step(3, "IDENTIFY_CUSTOMERS", "FAILED", str(exc))
            return []

        if not customers:
            logger.warning("[STEP-3] No active customers found — nothing to process")
            self._log_step(3, "IDENTIFY_CUSTOMERS", "SKIPPED", "No active customers")
            return []

        self._log_step(3, "IDENTIFY_CUSTOMERS", "COMPLETED",
                       f"{len(customers)} customer(s) found")

        # ── Customer loop ─────────────────────────────────────────────────────
        for cust in customers:
            cid   = cust["customer_id"]
            cname = cust["customer_name"]

            logger.info("")
            logger.info(f"{'─'*60}")
            logger.info(f"[STEP-3] Customer: {cname} (ID={cid})")

            # Load environments
            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "STARTED",
                           f"scope={env_scope}", cname)
            try:
                with DBManager(cfg=HC_DB) as db:
                    envs = self._load_envs(db, cid)
            except Exception as exc:
                logger.error(f"[STEP-4] Cannot load environments for {cname}: {exc}")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "FAILED",
                               str(exc), cname)
                continue

            if not envs:
                logger.warning(
                    f"[STEP-4] No active environments ({env_scope}) for '{cname}' — skipping")
                self._log_step(4, "IDENTIFY_ENVIRONMENTS", "SKIPPED",
                               f"No active envs in {env_scope}", cname)
                continue

            self._log_step(4, "IDENTIFY_ENVIRONMENTS", "COMPLETED",
                           f"found: {[e['env_type'] for e in envs]}", cname)

            # ── Environment loop ──────────────────────────────────────────────
            for env in envs:
                env_id       = env["env_id"]
                env_type     = env["env_type"]
                srv_user_raw = env.get("server_user", "")
                srv_pwd_raw  = env.get("server_pwd",  "")
                srv_password = (
                    decrypt_password(srv_pwd_raw)
                    if is_encrypted(srv_pwd_raw)
                    else srv_pwd_raw)

                logger.info("")
                logger.info(f"[STEP-4] ── {cname} / {env_type} ──────────")

                # ── STEP 5: Identify DB Server ────────────────────────────────
                try:
                    with DBManager(cfg=HC_DB) as db:
                        server = self._load_server(db, env_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-5] Cannot load server for {cname}/{env_type}: {exc}")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "FAILED",
                                   str(exc), cname, env_type)
                    # Capture a SKIPPED row in Excel so nothing is missed
                    result = self._make_result(
                        cid, cname, env_type,
                        server_host="",
                        server_status="UNKNOWN",
                        server_error=f"DB lookup error: {exc}",
                        db_name="", db_host="", db_port=1521, db_service="",
                        connection_status="SKIPPED",
                        error_message=f"Server lookup failed: {exc}",
                        duration_ms=0)
                    self._save_result(result)
                    results.append(result)
                    continue

                if not server:
                    msg = "No active server record found in DB"
                    logger.warning(
                        f"[STEP-5] No active server for {cname}/{env_type} — skipping")
                    self._log_step(5, "IDENTIFY_DB_SERVER", "SKIPPED",
                                   msg, cname, env_type)
                    # Capture a SKIPPED row in Excel
                    result = self._make_result(
                        cid, cname, env_type,
                        server_host="",
                        server_status="NOT FOUND",
                        server_error=msg,
                        db_name="", db_host="", db_port=1521, db_service="",
                        connection_status="SKIPPED",
                        error_message=msg,
                        duration_ms=0)
                    self._save_result(result)
                    results.append(result)
                    continue

                server_host = server["host"]
                server_id   = server["server_id"]
                logger.info(
                    f"[STEP-5] DB Server identified: {server_host} "
                    f"(ID={server_id}) | {cname}/{env_type}")
                self._log_step(5, "IDENTIFY_DB_SERVER", "COMPLETED",
                               f"host={server_host}", cname, env_type)

                # ── STEP 5A: WMI Server connection ────────────────────────────
                logger.info(
                    f"[STEP-5A] WMI connecting: "
                    f"{cname}/{env_type} → {server_host} | user={srv_user_raw}")
                self._log_step(5, "WMI_SERVER_CONNECTION", "STARTED",
                               f"host={server_host} user={srv_user_raw}",
                               cname, env_type)

                srv_ok, srv_err, srv_ms, wmi_conn = self._check_server_wmi(
                    server_host, srv_user_raw, srv_password)

                if not srv_ok:
                    logger.error(
                        f"[STEP-5A] WMI NOT CONNECTED: "
                        f"{cname}/{env_type} | {server_host} | {srv_err}")
                    self._log_step(5, "WMI_SERVER_CONNECTION", "FAILED",
                                   f"NOT CONNECTED: {srv_err}", cname, env_type)
                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="NOT CONNECTED",
                        server_error=srv_err,
                        db_name="", db_host=server_host,
                        db_port=1521, db_service="",
                        connection_status="FAILED",
                        error_message=f"WMI server unreachable: {srv_err}",
                        duration_ms=srv_ms)
                    self._save_result(result)
                    results.append(result)
                    self._log_step(7, "CAPTURE_RESULT", "COMPLETED",
                                   "Server=NOT CONNECTED | DB=SKIPPED",
                                   cname, env_type)
                    continue

                logger.info(
                    f"[STEP-5A] WMI connected: "
                    f"{cname}/{env_type} | {server_host} | {srv_ms}ms")
                self._log_step(5, "WMI_SERVER_CONNECTION", "COMPLETED",
                               f"CONNECTED in {srv_ms}ms", cname, env_type)
                self._disconnect_wmi(wmi_conn, server_host)

                # ── STEP 6: Load FMW Oracle DB records ────────────────────────
                logger.info(
                    f"[STEP-6] Loading FMW DBs: "
                    f"{cname}/{env_type} | server_id={server_id}")
                self._log_step(6, "FMW_DB_CONNECTION", "STARTED",
                               f"server_id={server_id}", cname, env_type)

                try:
                    with DBManager(cfg=HC_DB) as db:
                        fmw_dbs = self._load_fmw_dbs(db, server_id)
                except Exception as exc:
                    logger.error(
                        f"[STEP-6] Cannot load FMW DB records for "
                        f"{cname}/{env_type}: {exc}")
                    self._log_step(6, "FMW_DB_CONNECTION", "FAILED",
                                   str(exc), cname, env_type)
                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="CONNECTED",
                        server_error=None,
                        db_name="", db_host=server_host,
                        db_port=1521, db_service="",
                        connection_status="FAILED",
                        error_message=f"FMW DB record lookup failed: {exc}",
                        duration_ms=0)
                    self._save_result(result)
                    results.append(result)
                    continue

                if not fmw_dbs:
                    msg = "No active FMW DB records found for this server"
                    logger.warning(
                        f"[STEP-6] No active FMW DBs for {cname}/{env_type} — skipping")
                    self._log_step(6, "FMW_DB_CONNECTION", "SKIPPED",
                                   msg, cname, env_type)
                    # Capture a SKIPPED row so Excel shows this environment
                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="CONNECTED",
                        server_error=None,
                        db_name="", db_host=server_host,
                        db_port=1521, db_service="",
                        connection_status="SKIPPED",
                        error_message=msg,
                        duration_ms=0)
                    self._save_result(result)
                    results.append(result)
                    continue

                logger.info(
                    f"[STEP-6] {len(fmw_dbs)} FMW DB(s) found "
                    f"for {cname}/{env_type}")

                # ── STEP 6B: Per-DB Oracle connection checks ──────────────────
                for fmw in fmw_dbs:
                    db_info = {
                        "customer_id":   cid,
                        "customer_name": cname,
                        "env_type":      env_type,
                        "db_name":       fmw["db_name"],
                        "db_host":       server_host,
                        "db_port":       fmw.get("db_port", 1521),
                        "db_service":    fmw["db_service"],
                        "db_user":       fmw["db_user"],
                        "db_password":   fmw["db_password"],
                        "database_type": fmw.get("database_type", FMW_DB_TYPE),
                    }

                    db_ok, db_err, db_ms = self._check_db_connection(db_info)

                    result = self._make_result(
                        cid, cname, env_type,
                        server_host=server_host,
                        server_status="CONNECTED",
                        server_error=None,
                        db_name=fmw["db_name"],
                        db_host=server_host,
                        db_port=fmw.get("db_port", 1521),
                        db_service=fmw["db_service"],
                        connection_status="COMPLETED" if db_ok else "FAILED",
                        error_message=db_err,
                        duration_ms=db_ms)

                    self._save_result(result)
                    results.append(result)

                    status_label = "COMPLETED" if db_ok else "FAILED"
                    icon         = "✅" if db_ok else "❌"
                    logger.info(
                        f"[STEP-7] {icon} {status_label}: "
                        f"{cname}/{env_type} | DB={fmw['db_name']} | {db_ms}ms"
                        + (f" | {db_err}" if db_err else ""))
                    self._log_step(
                        7, "CAPTURE_RESULT",
                        status_label,
                        f"DB={fmw['db_name']} | {status_label} | {db_ms}ms"
                        + (f" | Error: {db_err}" if db_err else ""),
                        cname, env_type)

            logger.info(f"[STEP-9] All environments done for {cname}")

        # ── Summary ───────────────────────────────────────────────────────────
        total   = len(results)
        success = sum(1 for r in results if r["connection_status"] == "COMPLETED")
        skipped = sum(1 for r in results if r["connection_status"] == "SKIPPED")
        failed  = total - success - skipped

        logger.info("")
        logger.info(f"{'='*60}")
        logger.info(
            f"[STEP-7] All checks complete | "
            f"total={total} | success={success} | "
            f"failed={failed} | skipped={skipped}")
        logger.info(f"{'='*60}")
        return results
