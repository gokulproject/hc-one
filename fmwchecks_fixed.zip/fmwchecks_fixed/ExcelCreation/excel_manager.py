"""
ExcelCreation/excel_manager.py
==============================
Generate Excel report per requirement spec.

ONE ROW per environment / DB check.
Columns:
  # | Customer | Environment | DB Server Status | Server Host | Server Error |
  DB Name | Host | Port | Service/SID | Status | Duration (ms) | Error Details | Checked At (IST)

Status values:
  COMPLETED  — Oracle DB connected successfully
  FAILED     — Oracle DB connection failed (error in Error Details)
  SKIPPED    — No server record / no FMW DB records found (reason in Error Details)

Filename: FMW_DATABASE_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx
"""
import logging
import os
from datetime import datetime, timedelta

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger("fmw.excel")

IST_OFFSET = timedelta(hours=5, minutes=30)

# ── Colours ───────────────────────────────────────────────────────────────────
BLUE_DARK   = "1565C0"
BLUE_MED    = "0D47A1"
BLUE_LIGHT  = "E3F2FD"
GREEN_BG    = "E8F5E9"
GREEN_BG2   = "F0FAF0"
RED_BG      = "FFEBEE"
RED_BG2     = "FFF5F5"
AMBER_BG    = "FFF8E1"
AMBER_BG2   = "FFFDE7"
GREY_ROW    = "F9F9F9"
GREEN_TEXT  = "2E7D32"
RED_TEXT    = "C62828"
AMBER_TEXT  = "E65100"
GREY_TEXT   = "616161"


def _side():
    return Side(style="thin", color="BDBDBD")


def _border():
    s = _side()
    return Border(left=s, right=s, top=s, bottom=s)


def _ist_str(dt) -> str:
    if not dt:
        return ""
    return (dt + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


def generate_excel(results:    list,
                   run_id:     int,
                   timestamp:  str,
                   excel_path: str) -> str:
    """
    Build Excel report.  Returns full filepath of saved .xlsx.
    Every result row (COMPLETED / FAILED / SKIPPED) is included — no row is lost.
    Filename: FMW_DATABASE_CONNECTION_CHECKS_DD-MM-YY-RUNID.xlsx
    """
    os.makedirs(excel_path, exist_ok=True)

    date_part = datetime.now().strftime("%d-%m-%y")
    filename  = f"FMW_DATABASE_CONNECTION_CHECKS_{date_part}-{run_id}.xlsx"
    filepath  = os.path.join(excel_path, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = "FMW Connection Results"

    # ── Counts (accurate — SKIPPED is neither success nor failed) ─────────────
    total   = len(results)
    success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
    skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")
    failed  = total - success - skipped   # only genuine failures

    if total == 0:
        summary_text  = "No data processed"
        summary_color = RED_TEXT
    elif failed == 0 and skipped == 0:
        summary_text  = "ALL CONNECTED ✅"
        summary_color = GREEN_TEXT
    elif success == 0 and skipped == 0:
        summary_text  = f"ALL FAILED ❌  ({failed} failed)"
        summary_color = RED_TEXT
    else:
        parts = []
        if success > 0:
            parts.append(f"✅ Success: {success}")
        if failed > 0:
            parts.append(f"❌ Failed: {failed}")
        if skipped > 0:
            parts.append(f"⚠ Skipped: {skipped}")
        summary_text  = "  |  ".join(parts)
        summary_color = AMBER_TEXT if failed > 0 else GREY_TEXT

    # ── Row 1: Title ──────────────────────────────────────────────────────────
    LAST_COL = "N"   # 14 columns
    ws.merge_cells(f"A1:{LAST_COL}1")
    tc           = ws["A1"]
    tc.value     = (
        f"FMW Database Connection Check Report  "
        f"|  Run #{run_id}  |  {timestamp}")
    tc.font      = Font(name="Calibri", size=13, bold=True, color="FFFFFF")
    tc.fill      = PatternFill("solid", fgColor=BLUE_DARK)
    tc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # ── Row 2: Summary ────────────────────────────────────────────────────────
    ws.merge_cells(f"A2:{LAST_COL}2")
    sc           = ws["A2"]
    sc.value     = (
        f"Total: {total}   |   "
        f"✅ Success: {success}   |   "
        f"❌ Failed: {failed}   |   "
        f"⚠ Skipped: {skipped}   |   "
        f"{summary_text}")
    sc.font      = Font(name="Calibri", size=11, bold=True, color=summary_color)
    sc.fill      = PatternFill("solid", fgColor=BLUE_LIGHT)
    sc.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 22

    # ── Row 3: Headers ────────────────────────────────────────────────────────
    headers = [
        "#",
        "Customer",
        "Environment",
        "DB Server Status",
        "Server Host",
        "Server Error",
        "DB Name",
        "Host",
        "Port",
        "Service / SID",
        "Status",
        "Duration (ms)",
        "Error Details",
        "Checked At (IST)",
    ]
    widths = [4, 22, 13, 18, 22, 30, 20, 22, 7, 18, 13, 13, 40, 24]

    for col, (h, w) in enumerate(zip(headers, widths), 1):
        cell           = ws.cell(row=3, column=col, value=h)
        cell.font      = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        cell.fill      = PatternFill("solid", fgColor=BLUE_MED)
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)
        cell.border    = _border()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[3].height = 22

    # ── Data rows ─────────────────────────────────────────────────────────────
    for idx, r in enumerate(results, 1):
        row_num    = idx + 3
        status     = r.get("connection_status", "FAILED")
        db_ok      = status == "COMPLETED"
        skipped_r  = status == "SKIPPED"
        srv_status = r.get("server_status", "")
        srv_ok     = srv_status == "CONNECTED"

        # Background colour per row status
        if skipped_r:
            bg = AMBER_BG if idx % 2 == 0 else AMBER_BG2
        elif not srv_ok:
            bg = AMBER_BG if idx % 2 == 0 else AMBER_BG2
        elif db_ok:
            bg = GREEN_BG if idx % 2 == 0 else GREEN_BG2
        else:
            bg = RED_BG if idx % 2 == 0 else RED_BG2

        # Resolve what to display in "Status" column
        if skipped_r:
            display_status = "SKIPPED ⚠"
        elif srv_ok:
            display_status = "COMPLETED ✅" if db_ok else "FAILED ❌"
        else:
            display_status = "—"

        # Error / reason column — always populated when relevant
        error_detail = r.get("error_message", "") or ""

        values = [
            idx,
            r.get("customer_name",  ""),
            r.get("env_type",       ""),
            srv_status or "—",
            r.get("server_host",    ""),
            r.get("server_error",   "") or "",
            r.get("db_name",        ""),
            r.get("db_host",        ""),
            r.get("db_port",        ""),
            r.get("db_service",     ""),
            display_status,
            r.get("duration_ms",    0),
            error_detail,
            _ist_str(r.get("checked_at")),
        ]

        for col, val in enumerate(values, 1):
            cell           = ws.cell(row=row_num, column=col, value=val)
            cell.font      = Font(name="Calibri", size=10)
            cell.fill      = PatternFill("solid", fgColor=bg)
            cell.border    = _border()
            cell.alignment = Alignment(vertical="center", wrap_text=True)

            # Column 4 — DB Server Status
            if col == 4:
                if srv_ok:
                    c = GREEN_TEXT
                elif skipped_r and not r.get("server_host"):
                    c = GREY_TEXT
                else:
                    c = RED_TEXT
                cell.font      = Font(name="Calibri", size=10, bold=True, color=c)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Column 6 — Server Error: red italic
            if col == 6 and val:
                cell.font = Font(name="Calibri", size=9, italic=True, color=RED_TEXT)

            # Column 11 — Status
            if col == 11:
                if skipped_r:
                    c = AMBER_TEXT
                elif srv_ok and db_ok:
                    c = GREEN_TEXT
                elif srv_ok and not db_ok:
                    c = RED_TEXT
                else:
                    c = GREY_TEXT
                cell.font      = Font(name="Calibri", size=10, bold=True, color=c)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Column 12 — Duration: right-align
            if col == 12:
                cell.alignment = Alignment(horizontal="right", vertical="center")

            # Column 13 — Error Details: red italic (amber for skipped)
            if col == 13 and val:
                clr = AMBER_TEXT if skipped_r else RED_TEXT
                cell.font = Font(name="Calibri", size=9, italic=True, color=clr)

        ws.row_dimensions[row_num].height = 20

    # ── Freeze header & auto-filter ───────────────────────────────────────────
    ws.freeze_panes = "A4"
    if total:
        ws.auto_filter.ref = f"A3:{LAST_COL}{3 + total}"

    wb.save(filepath)
    logger.info(f"[STEP-8] Excel report saved: {filepath}")
    return filepath
