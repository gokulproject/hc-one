-- ============================================================
-- FMWChecks Schema  (v2 — full requirement update)
-- Run ONCE before first execution:
--   mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS fmwchecks
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE fmwchecks;

-- ── Email config ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fmw_email_config (
    id          INT           NOT NULL AUTO_INCREMENT,
    config_name VARCHAR(100)  NOT NULL DEFAULT 'default',
    smtp_host   VARCHAR(255)  NOT NULL,
    smtp_port   INT           NOT NULL DEFAULT 587,
    smtp_user   VARCHAR(255)  NOT NULL,
    smtp_pass   VARCHAR(255)  NOT NULL,
    use_tls     TINYINT(1)    NOT NULL DEFAULT 1,
    from_addr   VARCHAR(255)  NOT NULL,
    to_addr     TEXT          NOT NULL,   -- comma-separated
    cc_addr     TEXT          NULL,
    bcc_addr    TEXT          NULL,
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── General / path config ─────────────────────────────────────
-- Keys: excel_path, log_path, oracle_timeout, oracle_dll_path
--       config_customers  (comma-sep customer names; empty = ALL)
--       config_envs       (comma-sep: DEV,VAL,PRD;  empty = ALL)
CREATE TABLE IF NOT EXISTS fmw_config (
    id           INT           NOT NULL AUTO_INCREMENT,
    config_key   VARCHAR(100)  NOT NULL UNIQUE,
    config_value VARCHAR(500)  NOT NULL DEFAULT '',
    description  VARCHAR(500)  NULL,
    updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Run table — one row per execution ─────────────────────────
CREATE TABLE IF NOT EXISTS fmw_run (
    id            INT          NOT NULL AUTO_INCREMENT,
    status        VARCHAR(20)  NOT NULL DEFAULT 'RUNNING',
                  -- RUNNING | COMPLETED | PARTIAL | FAILED | NO_DATA
    started_at    DATETIME     NULL,
    completed_at  DATETIME     NULL,
    total_envs    INT          NOT NULL DEFAULT 0,   -- total environments processed
    success_count INT          NOT NULL DEFAULT 0,   -- DB connected
    fail_count    INT          NOT NULL DEFAULT 0,   -- DB failed or server down
    excel_path    VARCHAR(500) NULL,
    email_status  VARCHAR(20)  NULL,                 -- SENT | FAILED | SKIPPED
    email_error   TEXT         NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Connection result — ONE ROW PER ENVIRONMENT per run ───────
-- Columns follow exact Excel report requirement:
--   Customer | Environment | DB Server Status | Server Host | Server Error |
--   DB Name  | Host | Port | Service/SID | Status | Duration | Error | Checked At
CREATE TABLE IF NOT EXISTS fmw_connection_result (
    id                 INT           NOT NULL AUTO_INCREMENT,
    run_id             INT           NOT NULL,
    customer_id        INT           NOT NULL,
    customer_name      VARCHAR(255)  NOT NULL,
    env_type           VARCHAR(50)   NOT NULL,       -- DEV | VAL | PRD

    -- DB Server (Step A)
    server_host        VARCHAR(255)  NOT NULL DEFAULT '',
    server_status      VARCHAR(20)   NOT NULL DEFAULT 'NOT CONNECTED',
                       -- CONNECTED | NOT CONNECTED
    server_error       TEXT          NULL,           -- full error if server down

    -- FMW Oracle DB (Step B — empty if server not connected)
    db_name            VARCHAR(255)  NOT NULL DEFAULT '',
    db_host            VARCHAR(255)  NOT NULL DEFAULT '',
    db_port            INT           NOT NULL DEFAULT 1521,
    db_service         VARCHAR(255)  NOT NULL DEFAULT '',
    connection_status  VARCHAR(20)   NOT NULL DEFAULT 'FAILED',
                       -- COMPLETED | FAILED
    error_message      TEXT          NULL,           -- full DB error if failed
    duration_ms        INT           NOT NULL DEFAULT 0,
    checked_at         DATETIME      NOT NULL,

    PRIMARY KEY (id),
    KEY idx_run_id     (run_id),
    KEY idx_customer   (customer_id),
    KEY idx_env        (env_type),
    KEY idx_srv_status (server_status),
    KEY idx_db_status  (connection_status),
    KEY idx_checked_at (checked_at),
    CONSTRAINT fk_result_run
        FOREIGN KEY (run_id) REFERENCES fmw_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ── Step log — detailed audit trail per run ───────────────────
CREATE TABLE IF NOT EXISTS fmw_run_log (
    id         INT          NOT NULL AUTO_INCREMENT,
    run_id     INT          NOT NULL,
    step_no    INT          NOT NULL DEFAULT 0,      -- 1-12 per requirement
    step_name  VARCHAR(100) NOT NULL,
    status     VARCHAR(20)  NOT NULL,
              -- STARTED | COMPLETED | FAILED | SKIPPED | INFO
    message    TEXT         NULL,
    customer   VARCHAR(255) NULL,
    env_type   VARCHAR(50)  NULL,
    logged_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_run_id  (run_id),
    KEY idx_log_step_no (step_no),
    CONSTRAINT fk_log_run
        FOREIGN KEY (run_id) REFERENCES fmw_run(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- Default config rows — edit before first run
-- ============================================================

INSERT INTO fmw_config (config_key, config_value, description) VALUES
  ('excel_path',        'Excel',        'Folder where Excel reports are saved'),
  ('log_path',          'Logs',         'Folder where log files are written'),
  ('oracle_timeout',    '15',           'Oracle / socket connection timeout (seconds)'),
  ('oracle_dll_path',   '',             'Oracle Instant Client folder (empty = thin mode)'),
  ('config_customers',  '',             'Comma-sep customer names to process; empty = ALL active'),
  ('config_envs',       '',             'Comma-sep envs to process (DEV,VAL,PRD); empty = ALL')
ON DUPLICATE KEY UPDATE description = VALUES(description);


INSERT INTO fmw_email_config
  (config_name, smtp_host, smtp_port, smtp_user, smtp_pass,
   use_tls, from_addr, to_addr, cc_addr, bcc_addr, is_active)
VALUES
  ('default',
   'smtp.company.com', 587,
   'alerts@company.com', 'email_password',
   1,
   'alerts@company.com',
   'team@company.com',
   '',
   '',
   1)
ON DUPLICATE KEY UPDATE smtp_host = VALUES(smtp_host);


-- ============================================================
-- CONFIG CHEAT SHEET
--
-- Filter to specific customers only:
--   UPDATE fmw_config SET config_value='CustomerA,CustomerB'
--   WHERE config_key='config_customers';
--
-- Filter to specific environments only:
--   UPDATE fmw_config SET config_value='PRD,VAL'
--   WHERE config_key='config_envs';
--
-- Process ALL customers and ALL envs:
--   UPDATE fmw_config SET config_value='' WHERE config_key IN ('config_customers','config_envs');
--
-- Update email TO / CC:
--   UPDATE fmw_email_config
--   SET to_addr='a@co.com,b@co.com', cc_addr='mgr@co.com'
--   WHERE is_active=1;
--
-- USEFUL QUERIES
--
-- Latest run summary:
--   SELECT id, status, total_envs, success_count, fail_count,
--          started_at, completed_at, email_status
--   FROM fmw_run ORDER BY id DESC LIMIT 5;
--
-- Results of latest run (all columns):
--   SELECT customer_name, env_type,
--          server_host, server_status, server_error,
--          db_name, db_host, db_port, db_service,
--          connection_status, duration_ms, error_message, checked_at
--   FROM fmw_connection_result
--   WHERE run_id = (SELECT MAX(id) FROM fmw_run)
--   ORDER BY customer_name, env_type;
--
-- All failures:
--   SELECT r.id run_id, r.started_at,
--          cr.customer_name, cr.env_type,
--          cr.server_status, cr.connection_status, cr.error_message
--   FROM fmw_connection_result cr
--   JOIN fmw_run r ON r.id = cr.run_id
--   WHERE cr.connection_status = 'FAILED'
--   ORDER BY r.started_at DESC;
--
-- Step-by-step audit for latest run:
--   SELECT step_no, step_name, status, customer, env_type, message, logged_at
--   FROM fmw_run_log
--   WHERE run_id = (SELECT MAX(id) FROM fmw_run)
--   ORDER BY id;
-- ============================================================
