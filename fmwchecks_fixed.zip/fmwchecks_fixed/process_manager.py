"""
process_manager.py
==================
Orchestrates the complete FMW Check run in strict sequence:

  Step 1  — Process Start
  Step 2  — Connect Config Databases (healthcheck + fmwchecks)
  Step 3  — Identify Customers
  Step 4  — Identify Environments
  Step 5  — DB Server Connection Check (WMI)
  Step 6  — FMW Database Connection Check
  Step 7  — Capture Results, Logs, Errors
  Step 8  — Generate Excel Report
  Step 9  — Send Email
  Step 10 — Process Completed
"""
import logging
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Common.db_manager           import DBManager
from Common.email_manager        import EmailManager
from Common.logger               import setup_logging
from ExcelCreation.excel_manager import generate_excel
from fmw_checker                 import FMWChecker
from config                      import FMWCHECKS_DB
from config_loader               import load_config

logger     = logging.getLogger("fmw.process")
IST_OFFSET = timedelta(hours=5, minutes=30)


def _now_ist_str() -> str:
    return (datetime.utcnow() + IST_OFFSET).strftime("%d-%b-%Y %I:%M:%S %p IST")


def _count_results(results: list) -> tuple:
    """Return (total, success, failed, skipped) — accurate counts."""
    total   = len(results)
    success = sum(1 for r in results if r.get("connection_status") == "COMPLETED")
    skipped = sum(1 for r in results if r.get("connection_status") == "SKIPPED")
    failed  = total - success - skipped
    return total, success, failed, skipped


class ProcessManager:

    def __init__(self):
        self.run_id    = 0
        self.timestamp = _now_ist_str()
        self.app_cfg   = None

    # ── DB helpers ────────────────────────────────────────────────────────────
    def _create_run(self) -> int:
        with DBManager(cfg=FMWCHECKS_DB) as db:
            run_id = db.insert_get_id(
                "INSERT INTO fmw_run (status, started_at, created_at) "
                "VALUES ('RUNNING', NOW(), NOW())")
        logger.info(f"[STEP-2] Run #{run_id} created in fmwchecks DB")
        return run_id

    def _update_run(self, status, total, success, failed,
                    excel_path, email_status, email_error):
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """UPDATE fmw_run SET
                         status        = %s,
                         total_envs    = %s,
                         success_count = %s,
                         fail_count    = %s,
                         excel_path    = %s,
                         email_status  = %s,
                         email_error   = %s,
                         completed_at  = NOW()
                       WHERE id = %s""",
                    (status, total, success, failed,
                     excel_path, email_status, email_error,
                     self.run_id))
        except Exception as exc:
            logger.error(f"Cannot update run record: {exc}")

    def _log_step(self, step_no: int, step_name: str, status: str,
                  message: str = "", customer: str = "", env_type: str = ""):
        logger.info(
            f"[STEP-{step_no}] {step_name} → {status}"
            + (f" | {message}" if message else "")
            + (f" | customer={customer}" if customer else "")
            + (f" | env={env_type}" if env_type else ""))
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                db.execute(
                    """INSERT INTO fmw_run_log
                       (run_id, step_no, step_name, status,
                        message, customer, env_type, logged_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())""",
                    (self.run_id, step_no, step_name, status,
                     message[:2000] if message else "",
                     customer[:255] if customer else "",
                     env_type[:50]  if env_type  else ""))
        except Exception as exc:
            logger.warning(f"Step log write failed: {exc}")

    # ── Main execute ──────────────────────────────────────────────────────────
    def execute(self):

        # ── STEP 1: Process Start ─────────────────────────────────────────────
        logger.info("=" * 64)
        logger.info(f"[STEP-1] FMW Database Check — Process Start | {self.timestamp}")
        logger.info("=" * 64)

        # ── STEP 2: Connect Config Databases ──────────────────────────────────
        logger.info("[STEP-2] Connecting to config databases...")
        try:
            with DBManager(cfg=FMWCHECKS_DB) as db:
                self.app_cfg = load_config(db)
            logger.info("[STEP-2] fmwchecks DB connected ✅")
        except Exception as exc:
            logger.critical(
                f"[STEP-2] Cannot connect to fmwchecks DB: {exc}", exc_info=True)
            return

        setup_logging(log_dir=self.app_cfg.log_path)

        try:
            from config import HC_DB
            with DBManager(cfg=HC_DB) as db:
                db.fetch_one("SELECT 1")
            logger.info("[STEP-2] health_check DB connected ✅")
        except Exception as exc:
            logger.critical(
                f"[STEP-2] Cannot connect to health_check DB: {exc}",
                exc_info=True)
            return

        try:
            self.run_id    = self._create_run()
            self.timestamp = _now_ist_str()
        except Exception as exc:
            logger.critical(f"[STEP-2] Cannot create run record: {exc}")
            return

        self._log_step(2, "CONNECT_DATABASES", "COMPLETED",
                       "healthcheck + fmwchecks both connected")

        excel_path   = None
        email_status = "SKIPPED"
        email_error  = None
        results      = []
        final_status = "FAILED"

        try:
            # ── STEP 3-7: Run all checks ──────────────────────────────────────
            self._log_step(3, "PROCESS_START", "STARTED",
                           f"customers={'ALL' if not self.app_cfg.config_customers else self.app_cfg.config_customers} | "
                           f"envs={'ALL' if not self.app_cfg.config_envs else self.app_cfg.config_envs}")

            checker = FMWChecker(run_id=self.run_id, app_cfg=self.app_cfg)
            results = checker.run_all()

            total, success, failed, skipped = _count_results(results)

            self._log_step(
                7, "CAPTURE_RESULTS", "COMPLETED",
                f"total={total} | success={success} | failed={failed} | skipped={skipped}")

            # ── STEP 8: Excel Generation ──────────────────────────────────────
            logger.info("[STEP-8] Generating Excel report...")
            self._log_step(8, "EXCEL_GENERATION", "STARTED",
                           f"path={self.app_cfg.excel_path}")
            try:
                excel_path = generate_excel(
                    results    = results,
                    run_id     = self.run_id,
                    timestamp  = self.timestamp,
                    excel_path = self.app_cfg.excel_path)
                self._log_step(8, "EXCEL_GENERATION", "COMPLETED",
                               f"file={os.path.basename(excel_path)}")
                logger.info(
                    f"[STEP-8] Excel report generated ✅ | "
                    f"{os.path.basename(excel_path)}")
            except Exception as exc:
                logger.error(
                    f"[STEP-8] Excel generation failed: {exc}", exc_info=True)
                self._log_step(8, "EXCEL_GENERATION", "FAILED", str(exc)[:500])

            # ── STEP 9: Send Email ────────────────────────────────────────────
            logger.info("[STEP-9] Sending email...")
            self._log_step(9, "EMAIL", "STARTED",
                           f"to={self.app_cfg.email.to_addrs} | "
                           f"cc={self.app_cfg.email.cc_addrs}")
            try:
                mailer  = EmailManager(email_cfg=self.app_cfg.email)
                subject = EmailManager.build_subject(results, self.run_id)
                html    = EmailManager.build_html(
                    results   = results,
                    run_id    = self.run_id,
                    timestamp = self.timestamp,
                    total     = total,
                    success   = success,
                    failed    = failed)

                sent, err    = mailer.send_report(
                    subject    = subject,
                    html_body  = html,
                    excel_path = excel_path,
                    run_id     = self.run_id)

                email_status = "SENT" if sent else "FAILED"
                email_error  = err
                self._log_step(9, "EMAIL", email_status,
                               f"subject='{subject}'" + (f" | error={err}" if err else ""))
                if sent:
                    logger.info(f"[STEP-9] Email sent ✅ | subject='{subject}'")
                else:
                    logger.error(f"[STEP-9] Email failed ❌ | {err}")

            except Exception as exc:
                logger.error(f"[STEP-9] Email error: {exc}", exc_info=True)
                email_status = "FAILED"
                email_error  = str(exc)[:500]
                self._log_step(9, "EMAIL", "FAILED", email_error)

            # ── Determine final run status ────────────────────────────────────
            if total == 0:
                final_status = "NO_DATA"
            elif failed == 0 and skipped == 0:
                final_status = "COMPLETED"
            elif success > 0:
                final_status = "PARTIAL"
            else:
                final_status = "FAILED"

        except Exception as exc:
            logger.critical(
                f"[STEP-?] Unexpected error: {exc}", exc_info=True)
            final_status = "FAILED"
            self._log_step(0, "PROCESS", "FAILED", str(exc)[:500])

        finally:
            total, suc, fal, skp = _count_results(results)
            self._update_run(
                status       = final_status,
                total        = total,
                success      = suc,
                failed       = fal,
                excel_path   = excel_path or "",
                email_status = email_status,
                email_error  = email_error or "")

            # ── STEP 10: Process Completed ────────────────────────────────────
            logger.info("")
            logger.info("=" * 64)
            logger.info(
                f"[STEP-10] Process Completed | "
                f"run_id={self.run_id} | "
                f"status={final_status} | "
                f"total={total} | success={suc} | failed={fal} | skipped={skp} | "
                f"{_now_ist_str()}")
            logger.info("=" * 64)
            self._log_step(10, "PROCESS_COMPLETED", final_status,
                           f"total={total} success={suc} failed={fal} skipped={skp} | "
                           f"email={email_status}")
