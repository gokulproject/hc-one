"""
healthcheck/scheduler_service.py  (v12 – Self-contained Thread Scheduler)
==========================================================================
Runs entirely inside the Django process using a background thread.
No qcluster, no Celery, no external worker needed.

ARCHITECTURE:
  - One long-running daemon thread (_SchedulerThread) starts at Django startup
  - Every 60 s it polls the `schedules` table and fires due jobs
  - Each job runs in its own daemon thread so the poll loop never blocks
  - Rerun queue is polled every 60 s in the same loop
  - Stuck-run recovery runs every 10 ticks (~10 min)
  - Django Q is silently ignored even if it is installed in the project

DEPLOYMENT:
  python manage.py runserver      # scheduler starts automatically
  gunicorn / uvicorn / waitress   # scheduler starts automatically
  No extra process needed.

TIMEZONE: All inputs IST -> stored UTC -> displayed IST 12-hour.
"""

import logging
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone as _dtz
from typing import Optional

logger = logging.getLogger("hc.scheduler")

# ──────────────────────────────────────────────
# Module-level state
# ──────────────────────────────────────────────
_active_runs: dict = {}          # run_id -> label, for in-process tracking
_active_runs_lock = threading.Lock()

_scheduler_thread: Optional["_SchedulerThread"] = None
_scheduler_lock   = threading.Lock()

IST_OFFSET = timedelta(hours=5, minutes=30)

POLL_SECONDS      = 60    # main loop cadence
STUCK_CHECK_EVERY = 10   # ticks between stuck-run scans
REFRESH_EVERY     = 5    # ticks between schedule-list refreshes (5 min)


# ──────────────────────────────────────────────
# IST / UTC helpers
# ──────────────────────────────────────────────

def _now_utc() -> datetime:
    return datetime.utcnow()


def _now_ist() -> datetime:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
    except Exception:
        return datetime.utcnow() + IST_OFFSET


def _utc_to_ist(dt: datetime) -> datetime:
    if dt is None:
        return None
    try:
        from zoneinfo import ZoneInfo
        if hasattr(dt, "tzinfo") and dt.tzinfo:
            return dt.astimezone(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None)
        return dt + IST_OFFSET
    except Exception:
        if hasattr(dt, "tzinfo") and dt.tzinfo:
            return dt.replace(tzinfo=None) + IST_OFFSET
        return dt + IST_OFFSET


def _ist_to_utc(dt: datetime) -> datetime:
    if dt is None:
        return None
    if hasattr(dt, "tzinfo") and dt.tzinfo:
        return dt.astimezone(_dtz.utc).replace(tzinfo=None)
    return dt - IST_OFFSET


def _strip_tz(dt: datetime) -> Optional[datetime]:
    if dt is None:
        return None
    return dt.replace(tzinfo=None) if (hasattr(dt, "tzinfo") and dt.tzinfo) else dt


def _fmt(dt: datetime) -> str:
    if dt is None:
        return "Never"
    return _utc_to_ist(_strip_tz(dt)).strftime("%d-%b-%Y %I:%M %p IST")


def _cron_to_timedelta(cron_expr: str) -> timedelta:
    try:
        from croniter import croniter
        base = datetime(2026, 1, 1, 0, 0, 0)
        ci   = croniter(cron_expr, base)
        t1   = ci.get_next(datetime)
        t2   = ci.get_next(datetime)
        delta = t2 - t1
        if delta.total_seconds() < 60:
            logger.warning(f"Cron '{cron_expr}' interval < 60 s – using 60 s minimum")
            return timedelta(minutes=1)
        return delta
    except Exception as exc:
        logger.error(f"Cannot parse cron '{cron_expr}': {exc}. Defaulting to 1 hour.")
        return timedelta(hours=1)


def _cron_next_after(cron_expr: str, after: datetime) -> datetime:
    """Return the next cron tick strictly after *after* (naive UTC)."""
    try:
        from croniter import croniter
        ci = croniter(cron_expr, after)
        return ci.get_next(datetime)
    except Exception:
        return after + _cron_to_timedelta(cron_expr)


def _db_err():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError:
        pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError:
        pass
    return types


def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


# ──────────────────────────────────────────────
# Tracker helpers
# ──────────────────────────────────────────────

def _update_tracker(db, tid: int, **kw):
    if not kw or not tid:
        return
    try:
        db.execute(
            "UPDATE scheduler_tracker SET " +
            ", ".join(f"{k}=%s" for k in kw) +
            ", updated_at=NOW() WHERE id=%s",
            list(kw.values()) + [tid])
    except Exception as e:
        logger.warning(f"tracker update: {e}")


def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, fire_utc,
                    triggered_by="thread_scheduler") -> int:
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id,customer_id,env_types,schedule_name,cron_expression,
                status,scheduled_fire_at,triggered_by,is_active,created_at,updated_at)
               VALUES(%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, fire_utc, triggered_by))
    except Exception as e:
        logger.warning(f"tracker insert: {e}")
        return 0


# ──────────────────────────────────────────────
# Core execution
# ──────────────────────────────────────────────

def _execute_run(run_id: int, label: str, tracker_id: int = 0):
    """
    Execute one HC run.  COM-safe on Windows.
    Always called inside a daemon thread.
    """
    _ci = False
    try:
        try:
            import pythoncom
            pythoncom.CoInitialize()
            _ci = True
        except Exception:
            pass

        eng = _get_engine()
        with _active_runs_lock:
            _active_runs[run_id] = label
        try:
            with eng["DBManager"]() as db:
                eng["ConfigLoader"].load(db)
                if tracker_id:
                    _update_tracker(db, tracker_id, run_id=run_id,
                                    status="RUNNING", actual_start_at=_now_utc())
                eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

            final = _get_status(run_id)
            logger.info(f"[Sched] Run #{run_id} ({label}) -> {final}")

            if tracker_id:
                with eng["DBManager"]() as db:
                    st = "COMPLETED" if final in ("COMPLETED", "PARTIAL") else "FAILED"
                    _update_tracker(db, tracker_id, status=st,
                                    completed_at=_now_utc(),
                                    error_message=None if st == "COMPLETED" else final)
        except Exception as exc:
            logger.error(f"[Sched] Run #{run_id} error: {exc}", exc_info=True)
            if tracker_id:
                try:
                    with eng["DBManager"]() as db:
                        _update_tracker(db, tracker_id, status="FAILED",
                                        completed_at=_now_utc(),
                                        error_message=str(exc)[:1000])
                except Exception:
                    pass
        finally:
            with _active_runs_lock:
                _active_runs.pop(run_id, None)
    finally:
        if _ci:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _get_status(run_id: int) -> str:
    try:
        with _get_engine()["DBManager"]() as db:
            r = db.fetch_one("SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return r["status"] if r else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def _spawn_run_thread(run_id: int, label: str, tracker_id: int = 0):
    """Launch _execute_run in a new daemon thread."""
    t = threading.Thread(
        target=_execute_run, args=(run_id, label, tracker_id),
        daemon=True, name=f"hc_run_{run_id}")
    t.start()


# ──────────────────────────────────────────────
# Schedule loading
# ──────────────────────────────────────────────

def _load_schedules() -> list:
    try:
        with _get_engine()["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types, s.cron_expression,
                          s.schedule_name, s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s
                   JOIN customers c ON c.id=s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


# ──────────────────────────────────────────────
# Per-schedule fire logic
# ──────────────────────────────────────────────

def _fire_schedule(s: dict, now_utc: datetime):
    """
    Check if schedule s is due and fire it.
    Runs on the scheduler thread; actual HC work is in a child thread.
    """
    sid          = s["id"]
    cron_expr    = s["cron_expression"]
    last_run_raw = _strip_tz(s.get("last_run_at"))
    next_run_raw = _strip_tz(s.get("next_run_at"))
    start_at_raw = _strip_tz(s.get("start_at"))

    # Determine fire time
    if next_run_raw is not None:
        fire_utc = next_run_raw
    elif last_run_raw is None and start_at_raw is not None:
        fire_utc = start_at_raw
    else:
        fire_utc = _cron_next_after(cron_expr, now_utc - timedelta(seconds=1))

    if now_utc < fire_utc:
        return  # Not yet due

    label    = f"{s['customer_name']}/{s['env_types']}"
    now_ist  = _utc_to_ist(now_utc)
    interval = _cron_to_timedelta(cron_expr)
    next_utc = _cron_next_after(cron_expr, now_utc)

    logger.info(
        f"[Sched] Firing '{s['schedule_name']}' | {label} | "
        f"IST={now_ist.strftime('%d-%b-%Y %I:%M:%S %p')}")

    eng = _get_engine()
    tracker_id = 0
    run_id     = 0

    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            fresh = db.fetch_one("SELECT is_active FROM schedules WHERE id=%s", (sid,))
            if not fresh or not fresh["is_active"]:
                logger.info(f"[Sched] '{s['schedule_name']}' deactivated – skipping.")
                return

            tracker_id = _create_tracker(
                db, sid, s["customer_id"], s["env_types"],
                s["schedule_name"], cron_expr, now_utc)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'SCHEDULED','PENDING','thread_scheduler')""",
                (sid, s["customer_id"], s["env_types"]))

        with eng["DBManager"]() as db:
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, sid))

        if tracker_id:
            with eng["DBManager"]() as db:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                last_run_at=now_utc,
                                next_run_at=next_utc)

        next_ist = _utc_to_ist(next_utc)
        logger.info(
            f"[Sched] Run #{run_id} created | "
            f"next={next_ist.strftime('%I:%M %p IST')} "
            f"(+{int(interval.total_seconds() // 60)} min)")

        _spawn_run_thread(run_id, label, tracker_id)

    except Exception as exc:
        if isinstance(exc, _db_err()):
            logger.error(f"[Sched] DB down for '{s['schedule_name']}'. Will retry next tick.")
            return
        logger.error(f"[Sched] fire error for '{s['schedule_name']}': {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id, status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception:
                pass


# ──────────────────────────────────────────────
# Rerun queue processor
# ──────────────────────────────────────────────

def _process_rerun_queue():
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            pending = db.fetch_all(
                """SELECT rq.*, c.name AS cname
                   FROM rerun_queue rq
                   JOIN customers c ON c.id=rq.customer_id
                   WHERE rq.status='PENDING' AND rq.scheduled_at<=NOW()
                   ORDER BY rq.scheduled_at""")
    except Exception as exc:
        logger.error(f"[Rerun] Cannot fetch rerun_queue: {exc}")
        return

    if not pending:
        return

    logger.info(f"[Rerun] Processing {len(pending)} pending rerun(s)")
    for entry in pending:
        _fire_rerun_entry(entry)


def _fire_rerun_entry(entry: dict):
    entry_id  = entry["id"]
    cname     = entry.get("cname", str(entry["customer_id"]))
    env_types = entry["env_types"]
    label     = f"{cname}/{env_types}"

    def _do_rerun():
        _ci = False
        try:
            try:
                import pythoncom
                pythoncom.CoInitialize()
                _ci = True
            except Exception:
                pass

            eng    = _get_engine()
            run_id = 0
            try:
                with eng["DBManager"]() as db:
                    eng["ConfigLoader"].load(db)
                    affected = db.execute(
                        "UPDATE rerun_queue SET status='IN_PROGRESS', started_at=NOW() "
                        "WHERE id=%s AND status='PENDING'",
                        (entry_id,))
                    if not affected:
                        return

                    run_id = db.insert_get_id(
                        """INSERT INTO execution_runs
                           (customer_id, env_types, run_type, status,
                            triggered_by, rerun_of_run_id, rerun_attempt)
                           VALUES (%s,%s,'RERUN','PENDING','thread_rerun',%s,%s)""",
                        (entry["customer_id"], env_types,
                         entry["original_run_id"], entry["attempt_number"]))

                logger.info(
                    f"[Rerun] {label} | attempt {entry['attempt_number']}/{entry['max_attempts']}"
                    f" -> Run #{run_id}")

                _execute_run(run_id, label)

                final_status = _get_status(run_id)
                if final_status == "COMPLETED":
                    with eng["DBManager"]() as db:
                        db.execute(
                            "UPDATE rerun_queue SET status='COMPLETED', completed_at=NOW() "
                            "WHERE id=%s", (entry_id,))
                    logger.info(f"[Rerun] {label} | Run #{run_id} COMPLETED")
                else:
                    logger.info(
                        f"[Rerun] {label} | Run #{run_id} status={final_status} "
                        f"(attempt {entry['attempt_number']}/{entry['max_attempts']})")

            except Exception as exc:
                logger.error(f"[Rerun] entry {entry_id} error: {exc}", exc_info=True)
                try:
                    with eng["DBManager"]() as db:
                        db.execute(
                            "UPDATE rerun_queue SET status='FAILED', last_error=%s WHERE id=%s",
                            (str(exc)[:1000], entry_id))
                except Exception:
                    pass
        finally:
            if _ci:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass

    t = threading.Thread(target=_do_rerun, daemon=True, name=f"hc_rerun_{entry_id}")
    t.start()


# ──────────────────────────────────────────────
# Stuck-run recovery
# ──────────────────────────────────────────────

def _recover_stuck_runs():
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            cfg           = eng["ConfigLoader"].get()
            stuck_minutes = getattr(cfg, "stuck_run_timeout_minutes", 90)
            stuck = db.fetch_all(
                """SELECT er.*, c.name AS cname
                   FROM execution_runs er
                   JOIN customers c ON c.id=er.customer_id
                   WHERE er.status IN ('IN_PROGRESS','PENDING')
                     AND er.started_at IS NOT NULL
                     AND er.started_at < NOW() - INTERVAL %s MINUTE
                   ORDER BY er.started_at""",
                (stuck_minutes,))
    except Exception as exc:
        logger.error(f"[Stuck] Cannot query stuck runs: {exc}")
        return

    if not stuck:
        return

    logger.info(f"[Stuck] Found {len(stuck)} stuck run(s) to recover")

    for run in stuck:
        run_id = run["id"]
        cname  = run["cname"]
        env    = run["env_types"]
        reason = (
            f"Run #{run_id} stuck in {run['status']} for >{stuck_minutes} min. "
            f"Likely cause: process killed or DB lost connection mid-run.")

        try:
            with eng["DBManager"]() as db:
                db.execute(
                    """UPDATE execution_runs
                       SET status='FAILED', completed_at=NOW(), error_summary=%s
                       WHERE id=%s AND status IN ('IN_PROGRESS','PENDING')""",
                    (reason[:2000], run_id))

            logger.info(f"[Stuck] Run #{run_id} {cname}/{env} marked FAILED")

            try:
                from healthcheck.engine.notifications.email_service import EmailService
                from healthcheck.engine.core.logger import SilentLogger
                with eng["DBManager"]() as db:
                    svc = EmailService(db, SilentLogger())
                    for et in [e.strip() for e in env.split(",")]:
                        svc.send_failure(
                            run_id=run_id, customer_id=run["customer_id"],
                            customer_name=cname, env_type=et,
                            error_message=reason,
                            triggered_by=run.get("triggered_by", "system"),
                            step_failures=[{"step": "Run Recovery", "reason": reason}])
            except Exception as mail_exc:
                logger.warning(f"[Stuck] Email failed for #{run_id}: {mail_exc}")

            try:
                cfg     = eng["ConfigLoader"].get()
                cur_att = run.get("rerun_attempt") or 0
                mx      = cfg.rerun_max_attempts
                nxt_att = cur_att + 1
                if nxt_att <= mx:
                    try:
                        with eng["DBManager"]() as db:
                            iv_row = db.fetch_one(
                                "SELECT config_value FROM system_config "
                                "WHERE config_key='rerun_interval_hours'")
                        interval_hours = (
                            float(iv_row["config_value"]) if iv_row else cfg.rerun_interval_hours)
                    except Exception:
                        interval_hours = cfg.rerun_interval_hours
                    sched = datetime.utcnow() + timedelta(hours=interval_hours)
                    with eng["DBManager"]() as db:
                        existing = db.fetch_one(
                            "SELECT id FROM rerun_queue "
                            "WHERE original_run_id=%s AND status IN ('PENDING','IN_PROGRESS')",
                            (run_id,))
                        if not existing:
                            db.insert_get_id(
                                """INSERT INTO rerun_queue
                                   (original_run_id, customer_id, env_types,
                                    attempt_number, max_attempts,
                                    status, scheduled_at, last_error)
                                   VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s)""",
                                (run_id, run["customer_id"], env,
                                 nxt_att, mx, sched, reason[:2000]))
                            logger.info(
                                f"[Stuck] Queued recovery rerun "
                                f"attempt {nxt_att}/{mx} for #{run_id}")
            except Exception as exc:
                logger.warning(f"[Stuck] Rerun queue failed for #{run_id}: {exc}")

        except Exception as exc:
            logger.error(f"[Stuck] Recovery error for #{run_id}: {exc}")


# ──────────────────────────────────────────────
# Background scheduler thread
# ──────────────────────────────────────────────

class _SchedulerThread(threading.Thread):
    """
    Daemon thread that drives the entire HC scheduler.
    One instance per process lifetime.
    """

    def __init__(self):
        super().__init__(name="hc_scheduler", daemon=True)
        self._stop_event = threading.Event()
        self._tick       = 0
        self._schedules  = []

    def stop(self):
        self._stop_event.set()

    def run(self):
        logger.info(
            f"[Sched] Thread started | tz=Asia/Kolkata | "
            f"IST={_now_ist().strftime('%d-%b-%Y %I:%M:%S %p')}")
        while not self._stop_event.is_set():
            try:
                self._tick += 1
                self._do_tick()
            except Exception as exc:
                logger.error(
                    f"[Sched] Unhandled tick error: {exc}\n{traceback.format_exc()}")
            self._stop_event.wait(POLL_SECONDS)

    def _do_tick(self):
        now_utc = _now_utc()
        logger.debug(f"[Sched] Tick #{self._tick} at {now_utc}")

        # Refresh schedule list from DB
        if self._tick == 1 or self._tick % REFRESH_EVERY == 0:
            self._schedules = _load_schedules()
            logger.info(f"[Sched] Loaded {len(self._schedules)} active schedule(s)")

        # Fire any due schedules
        for s in self._schedules:
            try:
                _fire_schedule(s, now_utc)
            except Exception as exc:
                logger.error(
                    f"[Sched] Error checking schedule id={s['id']}: {exc}",
                    exc_info=True)

        # Process rerun queue
        try:
            _process_rerun_queue()
        except Exception as exc:
            logger.error(f"[Sched] Rerun queue error: {exc}")

        # Stuck-run recovery every STUCK_CHECK_EVERY ticks
        if self._tick % STUCK_CHECK_EVERY == 0:
            try:
                _recover_stuck_runs()
            except Exception as exc:
                logger.error(f"[Sched] Stuck recovery error: {exc}")


# ──────────────────────────────────────────────
# Public lifecycle API
# ──────────────────────────────────────────────

def get_scheduler():
    """Return True if the scheduler thread is alive."""
    return _scheduler_thread is not None and _scheduler_thread.is_alive()


def _is_qcluster_process() -> bool:
    """Return True if this process is a Django Q qcluster worker."""
    import sys as _sys
    return "qcluster" in " ".join(_sys.argv)


def start_scheduler():
    """
    Start the background scheduler thread.
    Idempotent – safe to call multiple times.
    Works with runserver / gunicorn / uvicorn / waitress.

    STRICT RULE: The healthcheck scheduler runs in the web service process
    ONLY. It will refuse to start inside a qcluster worker process.
    qcluster must not trigger or schedule any healthcheck logic.
    """
    global _scheduler_thread

    # Hard block: never start inside a qcluster worker process
    if _is_qcluster_process():
        logger.warning(
            "[Sched] start_scheduler() called from a qcluster process — "
            "REFUSING. Healthcheck scheduler runs in the web service only.")
        return None

    with _scheduler_lock:
        if _scheduler_thread is not None and _scheduler_thread.is_alive():
            logger.info("[Sched] Already running")
            return True

        try:
            _scheduler_thread = _SchedulerThread()
            _scheduler_thread.start()
            logger.info(
                f"[Sched] Started | tz=Asia/Kolkata | "
                f"IST={_now_ist().strftime('%d-%b-%Y %I:%M:%S %p')}")
            return True
        except Exception as exc:
            logger.error(f"[Sched] Start failed: {exc}", exc_info=True)
            return None


def stop_scheduler():
    """Stop the scheduler thread gracefully."""
    global _scheduler_thread
    with _scheduler_lock:
        if _scheduler_thread is None:
            return
        _scheduler_thread.stop()
        _scheduler_thread.join(timeout=10)
        _scheduler_thread = None
        logger.info("[Sched] Stopped")


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """
    Return scheduler status dict compatible with all views/templates.

    Fields:
        running          bool  - True if scheduler thread is alive
        cluster_running  bool  - always False (no qcluster)
        job_count        int   - number of active schedules in DB
        jobs             list  - [{id, name, next_run, last_run}] in IST
        active_runs      list  - [{run_id, label}] currently IN_PROGRESS
        active_run_count int
        timezone         str
        server_time_ist  str
    """
    now_ist_str = _now_ist().strftime("%d-%b-%Y %I:%M:%S %p")
    is_running  = get_scheduler()

    jobs = []
    try:
        schedules = _load_schedules()
        for s in schedules:
            nxt  = _strip_tz(s.get("next_run_at"))
            last = _strip_tz(s.get("last_run_at"))
            jobs.append({
                "id":       s["id"],
                "name":     s["schedule_name"],
                "next_run": _fmt(nxt),
                "last_run": _fmt(last),
            })
    except Exception as exc:
        logger.debug(f"scheduler_status: schedule query failed: {exc}")

    active = []
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            active_db = db.fetch_all(
                """SELECT er.id, er.env_types, c.name AS cname
                   FROM execution_runs er
                   JOIN customers c ON c.id=er.customer_id
                   WHERE er.status='IN_PROGRESS'""")
        active = [
            {"run_id": r["id"], "label": f"{r['cname']}/{r['env_types']}"}
            for r in active_db
        ]
    except Exception:
        with _active_runs_lock:
            active = [{"run_id": r, "label": l} for r, l in _active_runs.items()]

    return {
        "running":          is_running,
        "cluster_running":  False,
        "job_count":        len(jobs),
        "jobs":             jobs,
        "active_runs":      active,
        "active_run_count": len(active),
        "timezone":         "Asia/Kolkata (IST)",
        "server_time_ist":  now_ist_str,
    }


# ──────────────────────────────────────────────
# Manual run helpers
# ──────────────────────────────────────────────

def run_now_sync(schedule_id: int) -> Optional[int]:
    """
    Admin 'Run Now' – create run row, execute in background thread.
    Returns run_id immediately.
    """
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
        if not s:
            return None

        now_utc  = _now_utc()
        next_utc = _cron_next_after(s["cron_expression"], now_utc)

        with eng["DBManager"]() as db:
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id,customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))
            tid = _create_tracker(db, schedule_id, s["customer_id"], s["env_types"],
                                   s["schedule_name"], s["cron_expression"],
                                   now_utc, "admin:run_now")

        with eng["DBManager"]() as db:
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_utc, next_utc, schedule_id))

        label = f"{s['cname']}/{s['env_types']}"
        _spawn_run_thread(run_id, label, tid)

        logger.info(
            f"[Sched] admin:run_now -> Run #{run_id} dispatched | "
            f"next={_fmt(next_utc)}")
        return run_id

    except Exception as exc:
        logger.error(f"run_now_sync: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str) -> Optional[int]:
    """Manual run for a customer/env pair. Executes in background thread."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id,env_types,run_type,status,triggered_by)
                   VALUES(%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust  = db.fetch_one("SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        label = f"{cname}/{env_types}"
        _spawn_run_thread(run_id, label)
        return run_id

    except Exception as exc:
        logger.error(f"run_customer_now: {exc}", exc_info=True)
        return None


def reschedule_after_start_at_update(schedule_id: int) -> bool:
    """
    Called when admin changes start_at.
    Resets next_run_at so the scheduler picks up the new time on the next tick.
    """
    import time as _time
    eng = _get_engine()

    try:
        with eng["DBManager"]() as db:
            s = db.fetch_one(
                "SELECT s.*,c.name AS cname FROM schedules s "
                "JOIN customers c ON c.id=s.customer_id WHERE s.id=%s",
                (schedule_id,))
        if not s:
            logger.error(f"[Sched] reschedule: schedule {schedule_id} not found")
            return False
    except Exception as exc:
        logger.error(f"[Sched] reschedule read error: {exc}", exc_info=True)
        return False

    start_at_raw = _strip_tz(s.get("start_at"))
    now_utc_val  = _now_utc()

    if start_at_raw is None:
        fire_utc = now_utc_val + timedelta(seconds=5)
    elif start_at_raw > now_utc_val:
        fire_utc = start_at_raw
    else:
        fire_utc = _cron_next_after(s["cron_expression"], now_utc_val)

    MAX_RETRIES = 3
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with eng["DBManager"]() as db:
                db.execute(
                    "UPDATE schedules SET last_run_at=NULL, next_run_at=%s WHERE id=%s",
                    (fire_utc, schedule_id))
            break
        except Exception as exc:
            err_str = str(exc)
            is_lock = any(kw in err_str for kw in ("1205", "1213", "Lock wait", "Deadlock"))
            if is_lock and attempt < MAX_RETRIES:
                wait = attempt * 2
                logger.warning(
                    f"[Sched] reschedule lock conflict (attempt {attempt}/{MAX_RETRIES}), "
                    f"retrying in {wait}s – {exc}")
                _time.sleep(wait)
                continue
            logger.error(f"[Sched] reschedule_after_start_at_update error: {exc}", exc_info=True)
            return False

    fire_ist = _utc_to_ist(fire_utc)
    logger.info(
        f"[Sched] reschedule [{schedule_id}] '{s['schedule_name']}' -> "
        f"fire @ {fire_ist.strftime('%d-%b-%Y %I:%M %p IST')}")

    # Force immediate reload on the scheduler thread
    global _scheduler_thread
    if _scheduler_thread is not None and _scheduler_thread.is_alive():
        _scheduler_thread._tick = 0
        _scheduler_thread._schedules = []

    return True
