import os
import logging
import sys
from django.apps import AppConfig

logger = logging.getLogger("hc.scheduler")


def _is_qcluster_process() -> bool:
    """
    Return True if this Django process is a qcluster worker.

    qcluster always appears as 'manage.py qcluster' in argv.
    The healthcheck scheduler must NEVER start inside qcluster —
    it runs only inside the web service process (runserver / gunicorn /
    uvicorn / waitress).
    """
    argv_str = " ".join(sys.argv)
    return "qcluster" in argv_str


class HealthcheckConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "healthcheck"
    verbose_name = "Health Check v6"

    def ready(self):
        """
        Called once when Django starts.
        Starts the built-in background scheduler thread ONLY inside the
        web service process.

        Guards:
        1. qcluster worker process  → SKIP. The healthcheck scheduler must
           never run inside qcluster. qcluster is for other Django Q tasks
           only; it has no role in healthcheck scheduling.
        2. Management commands (migrate, shell, collectstatic, etc.) → SKIP
           (DJANGO_MANAGEMENT_COMMAND=1 env var).
        3. Dev runserver reloader parent process → SKIP (child sets RUN_MAIN=true).

        The scheduler runs as a daemon thread inside the web service process.
        One place only — not in qcluster, not in management commands.
        """
        # Guard 1: Never start inside a qcluster worker process
        if _is_qcluster_process():
            logger.info(
                "[HealthcheckConfig.ready] qcluster process detected — "
                "healthcheck scheduler will NOT start here. "
                "Scheduler runs in the web service process only.")
            return

        # Guard 2: Skip management commands
        if os.environ.get("DJANGO_MANAGEMENT_COMMAND") == "1":
            return

        # Guard 3: Dev reloader parent process – skip (child will start it)
        is_runserver = "runserver" in " ".join(sys.argv)
        run_main     = os.environ.get("RUN_MAIN")
        if is_runserver and run_main != "true":
            return

        try:
            from healthcheck.scheduler_service import start_scheduler
            start_scheduler()
            logger.info(
                "[HealthcheckConfig.ready] Scheduler thread started successfully.")
        except Exception as e:
            logger.warning(f"Could not start scheduler thread on startup: {e}")
