# Healthcheck Scheduler – Setup Guide

> **IMPORTANT:** The healthcheck scheduler runs **entirely inside the Django
> service process** as a background daemon thread.  
> Django Q / qcluster does **NOT** schedule or trigger healthcheck jobs.  
> Do **not** use `async_task`, Django Q `Schedule` objects, or `qcluster`
> for anything related to the healthcheck scheduler.

---

## Architecture

```
Django service process (runserver / gunicorn / uvicorn / waitress)
  └── AppConfig.ready()
        └── start_scheduler()          ← thread-based, no Q cluster
              └── _SchedulerThread (daemon thread)
                    ├── every 60 s  → polls `schedules` table, fires due jobs
                    ├── every 60 s  → processes rerun_queue
                    └── every 10 min → recovers stuck runs

Each fired job runs in its own daemon thread (_execute_run).
No external worker process is needed.
```

**The healthcheck scheduler runs in ONE place only: inside the Django service
process. Never in qcluster.**

---

## 1. Install dependencies

```bash
pip install croniter
# django-q2 is NOT required for the healthcheck scheduler.
# Only install it if your project uses Django Q for unrelated tasks.
```

---

## 2. INSTALLED_APPS (settings.py)

```python
INSTALLED_APPS = [
    ...
    'healthcheck',   # scheduler auto-starts via HealthcheckConfig.ready()
    ...
    # 'django_q',    # OPTIONAL – only if used for other non-healthcheck tasks
]
```

> ⚠ If `django_q` is in `INSTALLED_APPS` for other purposes, that is fine.
> The healthcheck scheduler is completely independent of it and will never
> submit jobs to the Q cluster.

---

## 3. Django Q configuration (if used for OTHER tasks)

If your project uses Django Q for tasks **unrelated** to healthcheck, add the
`Q_CLUSTER` block as normal. The healthcheck engine will not interact with it.

```python
# Q_CLUSTER settings are for your OTHER tasks only.
# The healthcheck scheduler does NOT use this.
Q_CLUSTER = {
    'name': 'my_other_tasks',
    ...
}
```

---

## 4. Run migrations

```bash
python manage.py migrate
```

---

## 5. Start the Django service (only process needed)

```bash
# Development
python manage.py runserver

# Production
gunicorn project.wsgi
# or: uvicorn project.asgi
# or: waitress-serve project.wsgi:application
```

The scheduler thread starts automatically inside the service process.  
**No separate `python manage.py qcluster` process is needed or wanted for
healthcheck scheduling.**

---

## How the scheduler starts

```
Django startup
  └── HealthcheckConfig.ready()          (apps.py)
        └── start_scheduler()            (scheduler_service.py)
              └── _SchedulerThread.start()
```

Guards in place:
- Dev `runserver` reloader parent is skipped (`RUN_MAIN` guard).
- Management commands (`migrate`, `shell`, etc.) are skipped
  (`DJANGO_MANAGEMENT_COMMAND=1` guard).
- `start_scheduler()` is idempotent – safe to call multiple times.

---

## Scheduler UI badges

| Badge | Meaning |
|---|---|
| **Scheduler Running** (green) | `_SchedulerThread` is alive inside this service process |
| **Scheduler Stopped** (red) | Thread not running – restart the service |

There is no "Worker Online / qcluster" badge. The scheduler is entirely
contained within the service process.

---

## Admin: Run Now

Clicking **Run Now** in the Django admin calls `run_now_sync(schedule_id)`,
which creates an `execution_run` row and dispatches a daemon thread directly.
It does **not** use `async_task` or the Q cluster.

---

## Cron expression → exact interval

User input `start_at=04:08`, cron `*/10 * * * *`:

- Fires at 04:08, 04:18, 04:28 … (exact +10 min from `start_at`)
- NOT clock-anchored (04:10, 04:20 …) — interval is preserved from `start_at`

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Schedules not firing | Scheduler thread died | Restart the Django service |
| Double runs | Two service processes running | Ensure only one service process per host, or use a shared-DB lock |
| Runs stuck in PENDING | Service crashed mid-run | Stuck-run recovery runs automatically every 10 min on next startup |
| `qcluster` running alongside | Leftover from old setup | Stop the qcluster process – it plays no role in healthcheck scheduling |
