"""
healthcheck/scheduler_service.py  (v9 - FULLY CORRECTED)
==========================================================

TIMEZONE ARCHITECTURE
---------------------
MySQL DB          : stores NAIVE datetimes = IST wall-clock (e.g. 16:44:00)
                    Django USE_TZ=True means Django ORM returns UTC-aware datetimes
                    for DateTimeField — we always convert to IST before use.
Admin UI          : always shows / accepts IST times
APScheduler       : configured with IST timezone → fires at IST wall-clock times
CMD logs          : always print IST
DB writes         : always write IST-naive (strip tzinfo after converting to IST)

CRON + START_AT LOGIC  (THE REAL FIX)
--------------------------------------
Problem: cron="*/10 * * * *"  start_at=4:44 PM
  Wrong approach: replace minute → "44 16 * * *"  (fires ONLY at 4:44 PM daily)
  Correct approach:
    1. Keep original cron "*/10 * * * *" as-is.
    2. Use APScheduler's `start_date` parameter on the CronTrigger.
       This tells APScheduler: "don't fire until this IST datetime".
    3. APScheduler will then fire at the NEXT cron tick AT OR AFTER start_date.
       → 4:44 PM (start_date) → next */10 tick at/after 4:44 = 4:44 itself if :44 % 10 != 0
         Actually */10 fires at :00,:10,:20,:30,:40,:50
         4:44 start → first fire = 4:50 PM, then 5:00, 5:10, 5:20 ...
       → If admin wants EXACTLY 4:44 and then 4:54, 5:04 ...
         they should use cron="44,54 * * * *" or we use start_date approach
         with a small offset cron.

  REAL SOLUTION for "every 10 min starting at 4:44":
    Use APScheduler IntervalTrigger with start_date=4:44 IST.
    This fires EXACTLY at 4:44, 4:54, 5:04, 5:14 ... preserving the :44 minute.

  CRON DETECTION:
    */N  or  N  in minute field  → treat as "interval every N minutes"
    Use IntervalTrigger(minutes=N, start_date=start_at_ist)

    All other crons (daily/weekly/monthly) → use CronTrigger with start_date=start_at_ist
"""
import logging
import re
import threading
from datetime import datetime, timedelta

import pytz

logger = logging.getLogger("hc.scheduler")

IST = pytz.timezone("Asia/Kolkata")


# ── Timezone helpers ──────────────────────────────────────────────────────────

def _now_ist() -> datetime:
    """Current time as IST-aware datetime."""
    return datetime.now(IST)


def _to_ist(dt) -> datetime:
    """
    Convert any datetime to IST-aware datetime.
    Handles:
      - None → None
      - naive datetime → assume IST (DB stored as IST-naive)
      - UTC-aware (Django ORM with USE_TZ=True) → convert to IST
      - already IST-aware → return as-is
    """
    if dt is None:
        return None
    if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
        return dt.astimezone(IST)
    # naive → treat as IST (our DB convention)
    return IST.localize(dt)


def _ist_naive(dt) -> datetime:
    """
    Return naive datetime representing IST wall-clock time.
    This is what we store in MySQL (no timezone column).
    e.g. 4:44 PM IST → datetime(2025,4,30,16,44,0)  (no tzinfo)
    """
    if dt is None:
        return None
    return _to_ist(dt).replace(tzinfo=None)


def _fmt(dt) -> str:
    """Format for logs — always IST."""
    if dt is None:
        return "None"
    return _to_ist(dt).strftime("%Y-%m-%d %H:%M:%S IST")


# ── Cron analysis ─────────────────────────────────────────────────────────────

def _parse_interval_minutes(cron_expression: str):
    """
    If the cron expresses a simple minute interval, return interval in minutes.
    Otherwise return None (use CronTrigger).

    Examples:
      "*/10 * * * *"  → 10
      "*/5 * * * *"   → 5
      "*/30 * * * *"  → 30
      "0 8 * * *"     → None  (daily at 8am, not interval)
      "0 */2 * * *"   → None  (every 2 hours, use CronTrigger)
    """
    parts = cron_expression.strip().split()
    if len(parts) < 5:
        return None
    minute_field = parts[0]
    hour_field   = parts[1]
    # Only treat as simple minute interval if hour/day/month/dow are all *
    if hour_field != "*" or parts[2] != "*" or parts[3] != "*" or parts[4] != "*":
        return None
    m = re.fullmatch(r"\*/(\d+)", minute_field)
    if m:
        val = int(m.group(1))
        if 1 <= val <= 59:
            return val
    return None


def _next_run_after(cron_expression: str, after_ist: datetime) -> datetime:
    """
    Calculate next run time (IST-naive) after given IST-aware datetime.
    Handles both interval crons and standard crons.
    """
    from croniter import croniter
    interval_mins = _parse_interval_minutes(cron_expression)
    after_naive = after_ist.replace(tzinfo=None)
    if interval_mins:
        # For "*/N" crons: next fire = after + interval
        nxt = after_naive + timedelta(minutes=interval_mins)
    else:
        nxt = croniter(cron_expression, after_naive).get_next(datetime)
    return nxt  # IST-naive


# ── Error types ───────────────────────────────────────────────────────────────

def _db_error_types():
    types = (ConnectionError,)
    try:
        from healthcheck.engine.core.db_manager import DBConnectionError
        types += (DBConnectionError,)
    except ImportError:
        pass
    try:
        import pymysql.err as pe
        types += (pe.OperationalError, pe.InterfaceError)
    except ImportError:
        pass
    return types


# ── Global state ──────────────────────────────────────────────────────────────

_scheduler       = None
_scheduler_lock  = threading.Lock()
_active_runs     = {}            # run_id → label
_active_runs_lock = threading.Lock()


def _get_engine():
    from healthcheck.engine_bridge import get_engine
    return get_engine()


# ── DB helpers ────────────────────────────────────────────────────────────────

def _update_tracker(db, tracker_id: int, **kwargs):
    try:
        if not kwargs or not tracker_id:
            return
        sets = ", ".join(f"{k}=%s" for k in kwargs)
        vals = list(kwargs.values()) + [tracker_id]
        db.execute(
            f"UPDATE scheduler_tracker SET {sets}, updated_at=NOW() WHERE id=%s",
            vals)
    except Exception as exc:
        logger.warning(f"tracker update failed: {exc}")


def _create_tracker(db, schedule_id, customer_id, env_types,
                    schedule_name, cron_expr, fire_at_ist,
                    triggered_by="apscheduler") -> int:
    try:
        return db.insert_get_id(
            """INSERT INTO scheduler_tracker
               (schedule_id, customer_id, env_types, schedule_name,
                cron_expression, status, scheduled_fire_at,
                triggered_by, is_active, created_at, updated_at)
               VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s,1,NOW(),NOW())""",
            (schedule_id, customer_id, env_types, schedule_name,
             cron_expr, _ist_naive(fire_at_ist), triggered_by))
    except Exception as exc:
        logger.warning(f"tracker insert failed: {exc}")
        return 0


# ── Run execution (background thread) ────────────────────────────────────────

def _execute_run(run_id: int, label: str, tracker_id: int = 0,
                 cron_expression: str = ""):
    """Execute one HC run. COM init/uninit always paired."""
    _coinit_done = False
    try:
        import pythoncom
        pythoncom.CoInitialize()
        _coinit_done = True
    except ImportError:
        pass
    except Exception as exc:
        logger.debug(f"CoInitialize skipped: {exc}")

    eng = _get_engine()
    with _active_runs_lock:
        _active_runs[run_id] = label

    now_ist = _now_ist()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                status="RUNNING",
                                actual_start_at=_ist_naive(now_ist))
            eng["RunLauncher"](db, run_id, eng["ConfigLoader"].get()).launch()

        final = _get_run_status(run_id)
        logger.info(f"[Scheduler] Run #{run_id} ({label}) → {final}")

        if tracker_id:
            with eng["DBManager"]() as db:
                ok = final in ("COMPLETED", "PARTIAL")
                _update_tracker(db, tracker_id,
                                status="COMPLETED" if ok else "FAILED",
                                completed_at=_ist_naive(_now_ist()),
                                error_message=None if ok else final)
    except Exception as exc:
        logger.error(f"[Scheduler] Run #{run_id} error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    completed_at=_ist_naive(_now_ist()),
                                    error_message=str(exc)[:1000])
            except Exception:
                pass
    finally:
        with _active_runs_lock:
            _active_runs.pop(run_id, None)
        if _coinit_done:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _get_run_status(run_id: int) -> str:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            row = db.fetch_one(
                "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
            return row["status"] if row else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


# ── Schedule firing ───────────────────────────────────────────────────────────

def _fire_schedule(schedule_id: int, customer_id: int, env_types: str,
                   schedule_name: str, customer_name: str,
                   cron_expression: str):
    """
    Called by APScheduler at the correct IST time.
    APScheduler handles start_date/timing — we just execute.
    All DB times written as IST-naive.
    """
    now_ist  = _now_ist()
    now_naive = _ist_naive(now_ist)
    nxt_naive = _next_run_after(cron_expression, now_ist)
    label    = f"{customer_name}/{env_types}"

    logger.info(
        f"[Scheduler] FIRE '{schedule_name}' | {label}"
        f" | now={_fmt(now_ist)}"
        f" | next={nxt_naive.strftime('%H:%M IST')}")

    eng = _get_engine()
    tracker_id = 0
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)

            tracker_id = _create_tracker(
                db, schedule_id, customer_id, env_types,
                schedule_name, cron_expression, now_ist)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id, customer_id, env_types,
                    run_type, status, triggered_by)
                   VALUES (%s,%s,%s,'SCHEDULED','PENDING','apscheduler')""",
                (schedule_id, customer_id, env_types))

            # Write IST-naive times to DB
            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_naive, nxt_naive, schedule_id))

            if tracker_id:
                _update_tracker(db, tracker_id,
                                run_id=run_id,
                                last_run_at=now_naive,
                                next_run_at=nxt_naive)

        logger.info(
            f"[Scheduler] Run #{run_id} created"
            f" | last_run={now_naive.strftime('%H:%M')}"
            f" | next_run={nxt_naive.strftime('%H:%M')} IST")

        _execute_run(run_id, label, tracker_id, cron_expression)

    except Exception as exc:
        if isinstance(exc, _db_error_types()):
            logger.error(f"[Scheduler] DB unavailable: {exc}")
            return
        logger.error(f"[Scheduler] Fire error: {exc}", exc_info=True)
        if tracker_id:
            try:
                with eng["DBManager"]() as db:
                    _update_tracker(db, tracker_id,
                                    status="FAILED",
                                    error_message=str(exc)[:1000])
            except Exception:
                pass


# ── Job registration ──────────────────────────────────────────────────────────

def _load_schedules() -> list:
    try:
        eng = _get_engine()
        with eng["DBManager"]() as db:
            return db.fetch_all(
                """SELECT s.id, s.customer_id, s.env_types,
                          s.cron_expression, s.schedule_name,
                          s.start_at, s.last_run_at, s.next_run_at,
                          c.name AS customer_name
                   FROM schedules s
                   JOIN customers c ON c.id = s.customer_id
                   WHERE s.is_active=1 AND c.is_active=1""")
    except Exception as exc:
        logger.error(f"Cannot load schedules: {exc}")
        return []


def _make_trigger(cron_expression: str, start_at_ist):
    """
    Build the correct APScheduler trigger.

    RULE:
    - "*/N * * * *"  (every N minutes)
        → IntervalTrigger(minutes=N, start_date=start_at_ist)
        → Fires EXACTLY at start_at, then start_at+N, start_at+2N ...
        → Preserves the exact minute from start_at (e.g. :44, :54, :04)

    - Any other cron (daily, weekly, hourly etc.)
        → CronTrigger(... , start_date=start_at_ist, timezone=IST)
        → Fires at first matching cron tick AT OR AFTER start_at
        → start_at acts as "don't fire before this time"

    WHY IntervalTrigger for */N:
        CronTrigger "*/10" fires at :00,:10,:20,:30,:40,:50 always.
        If start_at=4:44, CronTrigger would fire at 4:50 (not 4:44).
        IntervalTrigger(minutes=10, start_date=4:44) fires at
        4:44 → 4:54 → 5:04 → 5:14 ... EXACTLY preserving :44 offset.
    """
    from apscheduler.triggers.cron     import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger

    interval_mins = _parse_interval_minutes(cron_expression)

    if interval_mins and start_at_ist is not None:
        # Every-N-minutes cron with a specific start_at
        # Use IntervalTrigger so the exact minute offset is preserved
        logger.debug(
            f"  → IntervalTrigger every {interval_mins}min "
            f"start={_fmt(start_at_ist)}")
        return IntervalTrigger(
            minutes    = interval_mins,
            start_date = start_at_ist,   # IST-aware → APScheduler fires at IST wall-clock
            timezone   = IST,
        )

    if interval_mins and start_at_ist is None:
        # */N with no start_at → fire at next matching standard tick
        return IntervalTrigger(minutes=interval_mins, timezone=IST)

    # Standard cron (daily, weekly, hourly, etc.)
    parts = cron_expression.strip().split()
    trigger_kwargs = dict(
        minute      = parts[0] if len(parts) > 0 else "*",
        hour        = parts[1] if len(parts) > 1 else "*",
        day         = parts[2] if len(parts) > 2 else "*",
        month       = parts[3] if len(parts) > 3 else "*",
        day_of_week = parts[4] if len(parts) > 4 else "*",
        timezone    = IST,
    )
    if start_at_ist is not None:
        trigger_kwargs["start_date"] = start_at_ist
    return CronTrigger(**trigger_kwargs)


def _register_jobs(scheduler):
    """Remove and re-register all schedule jobs from DB."""
    # Remove existing schedule jobs
    for job in scheduler.get_jobs():
        if job.id.startswith("sched_"):
            try:
                job.remove()
            except Exception:
                pass

    schedules = _load_schedules()
    logger.info(f"[Scheduler] Registering {len(schedules)} schedule(s) — timezone=IST")

    for s in schedules:
        job_id = f"sched_{s['id']}"
        try:
            raw_start_at = s.get("start_at")

            # Convert start_at to IST-aware (handles UTC-aware from Django ORM
            # and naive IST from raw DB)
            start_at_ist = _to_ist(raw_start_at) if raw_start_at else None

            trigger = _make_trigger(s["cron_expression"], start_at_ist)

            scheduler.add_job(
                _fire_schedule,
                trigger         = trigger,
                id              = job_id,
                name            = s["schedule_name"],
                args            = [s["id"], s["customer_id"], s["env_types"],
                                   s["schedule_name"], s["customer_name"],
                                   s["cron_expression"]],
                max_instances   = 1,
                coalesce        = True,
                replace_existing= True,
                misfire_grace_time = 300,
            )

            # Log what will happen
            interval_mins = _parse_interval_minutes(s["cron_expression"])
            if interval_mins and start_at_ist:
                logger.info(
                    f"  OK [{s['id']}] {s['schedule_name']}"
                    f" | every {interval_mins}min"
                    f" | first fire={_fmt(start_at_ist)}"
                    f" | then :+{interval_mins}min each time")
            elif start_at_ist:
                logger.info(
                    f"  OK [{s['id']}] {s['schedule_name']}"
                    f" | cron={s['cron_expression']}"
                    f" | first fire at/after {_fmt(start_at_ist)}")
            else:
                logger.info(
                    f"  OK [{s['id']}] {s['schedule_name']}"
                    f" | cron={s['cron_expression']}"
                    f" | fires at next tick (no start_at)")

        except Exception as exc:
            logger.error(f"  FAIL [{s['id']}] {s.get('schedule_name','?')}: {exc}",
                         exc_info=True)


# ── Lifecycle ─────────────────────────────────────────────────────────────────

def get_scheduler():
    return _scheduler


def start_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            logger.info("Scheduler already running — skip duplicate start")
            return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool       import ThreadPoolExecutor

            _scheduler = BackgroundScheduler(
                executors    = {"default": ThreadPoolExecutor(max_workers=20)},
                job_defaults = {"coalesce": True, "max_instances": 1},
                timezone     = IST,   # scheduler's internal clock = IST
            )
            _register_jobs(_scheduler)

            # Reload jobs from DB every 5 minutes (picks up new/edited schedules)
            _scheduler.add_job(
                lambda: _register_jobs(_scheduler),
                "interval", minutes=5,
                id="refresh_schedules",
                name="Refresh schedules from DB",
                replace_existing=True,
            )
            _scheduler.start()
            logger.info(
                f"[Scheduler] Started | timezone=Asia/Kolkata | "
                f"now={_fmt(_now_ist())}")
            return _scheduler

        except ImportError:
            logger.error("APScheduler not installed: pip install apscheduler")
            return None
        except Exception as exc:
            logger.error(f"Scheduler start failed: {exc}", exc_info=True)
            return None


def stop_scheduler():
    global _scheduler
    with _scheduler_lock:
        if _scheduler and _scheduler.running:
            try:
                _scheduler.shutdown(wait=False)
            except Exception as exc:
                logger.warning(f"Shutdown warning (safe): {exc}")
            logger.info("[Scheduler] Stopped")
        _scheduler = None


def restart_scheduler():
    stop_scheduler()
    return start_scheduler()


def scheduler_status() -> dict:
    """Live status — all times in IST."""
    import pytz as _pytz
    _IST = _pytz.timezone("Asia/Kolkata")
    now_ist_str = datetime.now(_IST).strftime("%d-%b-%Y %H:%M:%S IST")

    if _scheduler is None or not _scheduler.running:
        return {
            "running": False, "job_count": 0, "jobs": [],
            "active_runs": [], "active_run_count": 0,
            "server_time_ist": now_ist_str,
        }

    jobs = []
    for job in _scheduler.get_jobs():
        if not job.id.startswith("sched_"):
            continue
        nxt = job.next_run_time
        nxt_str = nxt.astimezone(_IST).strftime("%d-%b-%Y %H:%M IST") if nxt else "—"
        jobs.append({"id": job.id, "name": job.name, "next_run": nxt_str})

    with _active_runs_lock:
        active = [{"run_id": rid, "label": lbl}
                  for rid, lbl in _active_runs.items()]

    return {
        "running":          True,
        "job_count":        len(jobs),
        "jobs":             jobs,
        "active_runs":      active,
        "active_run_count": len(active),
        "server_time_ist":  now_ist_str,
    }


# ── Manual run helpers ────────────────────────────────────────────────────────

def run_now_sync(schedule_id: int):
    """Trigger a schedule immediately (manual). Returns run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            s = db.fetch_one(
                """SELECT s.*, c.name AS cname
                   FROM schedules s JOIN customers c ON c.id=s.customer_id
                   WHERE s.id=%s""", (schedule_id,))
            if not s:
                return None

            now_ist   = _now_ist()
            now_naive = _ist_naive(now_ist)
            nxt_naive = _next_run_after(s["cron_expression"], now_ist)

            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id, customer_id, env_types,
                    run_type, status, triggered_by)
                   VALUES (%s,%s,%s,'MANUAL','PENDING','admin:run_now')""",
                (s["id"], s["customer_id"], s["env_types"]))

            db.execute(
                "UPDATE schedules SET last_run_at=%s, next_run_at=%s WHERE id=%s",
                (now_naive, nxt_naive, schedule_id))

            tracker_id = _create_tracker(
                db, schedule_id, s["customer_id"], s["env_types"],
                s["schedule_name"], s["cron_expression"],
                now_ist, triggered_by="admin:run_now")

        t = threading.Thread(
            target=_execute_run,
            args=(run_id, f"{s['cname']}/{s['env_types']}", tracker_id,
                  s["cron_expression"]),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_now_sync error: {exc}", exc_info=True)
        return None


def run_customer_now(customer_id: int, env_types: str):
    """Trigger a manual run for customer+env. Returns run_id."""
    eng = _get_engine()
    try:
        with eng["DBManager"]() as db:
            eng["ConfigLoader"].load(db)
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (customer_id, env_types, run_type, status, triggered_by)
                   VALUES (%s,%s,'MANUAL','PENDING','admin:manual')""",
                (customer_id, env_types))
            cust  = db.fetch_one(
                "SELECT name FROM customers WHERE id=%s", (customer_id,))
            cname = cust["name"] if cust else str(customer_id)

        t = threading.Thread(
            target=_execute_run, args=(run_id, f"{cname}/{env_types}", 0, ""),
            daemon=True, name=f"hc_run_{run_id}")
        t.start()
        return run_id
    except Exception as exc:
        logger.error(f"run_customer_now error: {exc}", exc_info=True)
        return None
