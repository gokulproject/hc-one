from django import forms
from healthcheck.models import Customer, Environment, Schedule, EscalationConfig


class CustomerForm(forms.ModelForm):
    class Meta:
        model  = Customer
        fields = ["name", "code", "tenant_type", "is_active", "notes"]
        widgets = {
            "name":        forms.TextInput(attrs={"class": "form-control"}),
            "code":        forms.TextInput(attrs={"class": "form-control"}),
            "tenant_type": forms.Select(
                choices=[("Single","Single"),("Multi","Multi")],
                attrs={"class": "form-select"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }


class EnvironmentForm(forms.ModelForm):
    # Extra field for plain password input (not stored directly)
    plain_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={"class": "form-control",
                                          "placeholder": "Leave blank to keep existing"}),
        help_text="Enter new password (will be AES-256 encrypted). Leave blank to keep existing.",
    )

    class Meta:
        model  = Environment
        fields = ["customer", "env_type", "server_user", "is_active", "notes"]
        widgets = {
            "customer":   forms.Select(attrs={"class": "form-select"}),
            "env_type":   forms.Select(
                choices=[("PRD","Production"),("VAL","Validation"),("DEV","Development")],
                attrs={"class": "form-select"}),
            "server_user": forms.TextInput(attrs={"class": "form-control",
                                                   "placeholder": "DOMAIN\\\\username"}),
            "is_active":   forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":       forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Load customer choices from healthcheck_db
        try:
            from healthcheck.models import Customer
            self.fields["customer"].queryset = Customer.objects.using("healthcheck_db").filter(is_active=True)
        except Exception:
            pass


class ScheduleForm(forms.ModelForm):
    class Meta:
        model  = Schedule
        fields = ["customer", "env_types", "schedule_name",
                  "cron_expression", "start_at", "is_active", "notes"]
        widgets = {
            "customer":        forms.Select(attrs={"class": "form-select"}),
            "env_types":       forms.TextInput(attrs={
                                   "class": "form-control",
                                   "placeholder": "DEV or PRD,VAL"}),
            "schedule_name":   forms.TextInput(attrs={"class": "form-control"}),
            "cron_expression": forms.TextInput(attrs={
                                   "class": "form-control",
                                   "placeholder": "*/10 * * * *  or  0 8 * * *"}),
            # start_at: admin picks IST datetime — stored as IST-naive in DB
            "start_at":        forms.DateTimeInput(
                                   attrs={"class": "form-control",
                                          "type":  "datetime-local",
                                          "placeholder": "YYYY-MM-DDTHH:MM"},
                                   format="%Y-%m-%dT%H:%M"),
            "is_active":       forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "notes":           forms.TextInput(attrs={"class": "form-control"}),
        }

    def clean_start_at(self):
        """
        start_at from the form is a naive datetime entered by admin in IST.
        We store it as IST-naive in DB (no conversion needed).
        Just validate it's not in the past by more than 1 day.
        """
        start_at = self.cleaned_data.get("start_at")
        return start_at  # keep naive IST as-is

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try:
            from healthcheck.models import Customer
            self.fields["customer"].queryset = Customer.objects.using("healthcheck_db").filter(is_active=True)
        except Exception:
            pass


class EscalationConfigForm(forms.ModelForm):
    class Meta:
        model  = EscalationConfig
        fields = ["threshold", "interval_hours", "max_escalations", "notify_rerun_fail"]
        widgets = {
            "threshold":       forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "interval_hours":  forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "max_escalations": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "notify_rerun_fail": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
