"""
scheduling/scheduler.py  (v8)
==============================
Fixes:
  1. Dual-run prevention: DB lock check before firing.
  2. start_at = FIRST fire point itself (not next cron slot after it).
     After first run → next calculated from last_run_at using cron.
  3. last_run_at / next_run_at: always updated after every run.
  4. Memory release: handled in RunLauncher (oracle close).
  5. next_run_at stored correctly from last_run_at base (not now).
"""
import threading
import time
import traceback
from datetime import datetime, timedelta

from croniter import croniter

from core.config import ConfigLoader
from core.db_manager import DBManager
from core.logger import SilentLogger
from scheduling.run_launcher import RunLauncher

POLL_SECONDS = 60
_FIRE_LOCK   = threading.Lock()


class HealthCheckScheduler:

    def __init__(self):
        self._running = True
        self._tick    = 0

    # ────────────────────────────────────────────────────────
    # Logging
    # ────────────────────────────────────────────────────────

    def _log(self, msg: str):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[SCHEDULER] {ts} | {msg}", flush=True)

    def _db_log(self, db, run_id: int, level: str, msg: str):
        try:
            db.execute(
                """INSERT INTO execution_logs
                   (run_id, log_level, py_file, py_module, py_function,
                    py_line, message, logged_at)
                   VALUES (%s,%s,'scheduler.py','scheduler','_db_log',0,%s,NOW(3))""",
                (run_id, level.upper(), msg))
        except Exception:
            pass

    # ────────────────────────────────────────────────────────
    # Main loop
    # ────────────────────────────────────────────────────────

    def start(self):
        self._log("Started. Press Ctrl+C to stop.")
        while self._running:
            try:
                self._tick += 1
                self._log(f"Tick #{self._tick}")
                self._do_tick()
            except Exception as exc:
                self._log(f"ERROR in tick: {exc}\n{traceback.format_exc()}")
            time.sleep(POLL_SECONDS)

    def stop(self):
        self._running = False

    def _do_tick(self):
        with DBManager() as db:
            cfg = ConfigLoader.load(db)
            self._fire_schedules(db, cfg)
            self._process_reruns(db, cfg)
            self._purge_logs(db, cfg)

    # ────────────────────────────────────────────────────────
    # Fire scheduled runs
    # ────────────────────────────────────────────────────────

    def _fire_schedules(self, db, cfg):
        schedules = db.fetch_all(
            """SELECT s.*, c.name AS cname, c.code AS ccode
               FROM schedules s
               JOIN customers c ON c.id = s.customer_id
               WHERE s.is_active = 1 AND c.is_active = 1""")
        now = datetime.now()

        for sched in schedules:
            try:
                self._maybe_fire(db, cfg, sched, now)
            except Exception as exc:
                self._log(
                    f"Error processing schedule id={sched['id']}: "
                    f"{exc}\n{traceback.format_exc()}")

    def _maybe_fire(self, db, cfg, sched, now):
        start_at = sched.get("start_at")
        last     = sched.get("last_run_at")

        # ── Step 1: start_at gate ────────────────────────────
        # If start_at is set and we haven't reached it yet → skip
        if start_at and now < start_at:
            self._log(
                f"{sched['cname']}/{sched['env_types']} | "
                f"{sched['schedule_name']} | "
                f"Waiting for start_at = {start_at.strftime('%Y-%m-%d %H:%M')}")
            return

        # ── Step 2: calculate DUE time ───────────────────────
        #
        # FIX: start_at is the FIRST fire point itself.
        #
        # CASE A — Never run before AND start_at is set:
        #   due = start_at exactly
        #   (user said "start at 2:55" → first fire IS 2:55)
        #
        # CASE B — Never run before, NO start_at:
        #   due = most recent cron slot before now
        #   (normal cron behaviour)
        #
        # CASE C — Already ran before:
        #   due = next cron slot after last_run_at
        #   (fire based on when last run finished)

        if start_at and last is None:
            # CASE A: first fire = start_at itself
            due = start_at
            self._log(
                f"{sched['cname']}/{sched['env_types']} | "
                f"{sched['schedule_name']} | "
                f"First run — due = start_at = {due.strftime('%Y-%m-%d %H:%M')}")

        elif last is not None:
            # CASE C: calculate from last_run_at
            ci  = croniter(sched["cron_expression"], last)
            due = ci.get_next(datetime)
            self._log(
                f"{sched['cname']}/{sched['env_types']} | "
                f"{sched['schedule_name']} | "
                f"Due = {due.strftime('%Y-%m-%d %H:%M')} "
                f"(from last_run {last.strftime('%Y-%m-%d %H:%M')})")

        else:
            # CASE B: no start_at, never ran → most recent slot before now
            ci  = croniter(sched["cron_expression"], now)
            due = ci.get_prev(datetime)
            self._log(
                f"{sched['cname']}/{sched['env_types']} | "
                f"{sched['schedule_name']} | "
                f"Due = {due.strftime('%Y-%m-%d %H:%M')} "
                f"(prev cron slot from now)")

        # ── Step 3: should we fire? ──────────────────────────
        # Fire only if:
        #   - now has reached the due time
        #   - AND we haven't already run for this slot
        should_fire = (now >= due) and (last is None or last < due)

        if not should_fire:
            self._log(
                f"{sched['cname']}/{sched['env_types']} | "
                f"{sched['schedule_name']} | "
                f"Not due yet (due={due.strftime('%H:%M')}, "
                f"last={last.strftime('%H:%M') if last else 'never'})")
            return

        # ── Step 4: dual-run guard ───────────────────────────
        # Prevent same schedule firing twice if run takes > 60s
        with _FIRE_LOCK:
            in_prog = db.fetch_one(
                """SELECT id FROM execution_runs
                   WHERE schedule_id = %s
                   AND status IN ('IN_PROGRESS', 'PENDING')
                   LIMIT 1""",
                (sched["id"],))

            if in_prog:
                self._log(
                    f"{sched['cname']}/{sched['env_types']} | "
                    f"{sched['schedule_name']} | "
                    f"Already running as Run #{in_prog['id']} — skipping")
                return

            # Create run row INSIDE the lock to prevent
            # another tick from also firing
            run_id = db.insert_get_id(
                """INSERT INTO execution_runs
                   (schedule_id, customer_id, env_types,
                    run_type, status, triggered_by, started_at)
                   VALUES (%s,%s,%s,'SCHEDULED','IN_PROGRESS','scheduler',NOW())""",
                (sched["id"], sched["customer_id"], sched["env_types"]))

        # ── Step 5: fire ─────────────────────────────────────
        self._log(
            f"{sched['cname']}/{sched['env_types']} | "
            f"{sched['schedule_name']} | "
            f"FIRING → Run #{run_id}")

        self._db_log(db, run_id, "INFO",
            f"Scheduled run fired | "
            f"schedule='{sched['schedule_name']}' "
            f"cron='{sched['cron_expression']}' "
            f"due='{due.strftime('%Y-%m-%d %H:%M')}' "
            f"customer='{sched['cname']}' "
            f"env='{sched['env_types']}'")

        t0 = time.time()
        try:
            RunLauncher(db, run_id, cfg).launch()
        except Exception as exc:
            self._log(f"RunLauncher error run #{run_id}: {exc}")
            db.execute(
                """UPDATE execution_runs
                   SET status='FAILED', error_summary=%s
                   WHERE id=%s""",
                (str(exc)[:2000], run_id))
        elapsed = int(time.time() - t0)

        # ── Step 6: update last_run_at and next_run_at ───────
        # FIX: next_run_at calculated from last_run_at (now),
        #      NOT from due time — so offset is preserved.
        #
        # Example:
        #   start_at   = 2:55 PM  first fire
        #   run ends   = 2:57 PM  → last_run_at = 2:57
        #   next = croniter("*/15", 2:57).get_next() = 3:10 PM ✅
        #   (not 3:00 which would be from clock-zero)

        finished_at = datetime.now()
        nxt = croniter(sched["cron_expression"], finished_at).get_next(datetime)

        db.execute(
            """UPDATE schedules
               SET last_run_at = %s,
                   next_run_at = %s
               WHERE id = %s""",
            (finished_at, nxt, sched["id"]))

        final  = db.fetch_one(
            "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
        status = final["status"] if final else "UNKNOWN"

        self._log(
            f"{sched['cname']}/{sched['env_types']} | "
            f"Run #{run_id} {status} in {elapsed}s | "
            f"Next run: {nxt.strftime('%Y-%m-%d %H:%M')}")

        self._db_log(db, run_id, "INFO",
            f"Run {status} in {elapsed}s | "
            f"next_run_at='{nxt.strftime('%Y-%m-%d %H:%M')}' | "
            f"schedule='{sched['schedule_name']}'")

    # ────────────────────────────────────────────────────────
    # Process rerun queue
    # ────────────────────────────────────────────────────────

    def _process_reruns(self, db, cfg):
        pending = db.fetch_all(
            """SELECT rq.*, c.name AS cname
               FROM rerun_queue rq
               JOIN customers c ON c.id = rq.customer_id
               WHERE rq.status = 'PENDING'
               AND rq.scheduled_at <= NOW()
               ORDER BY rq.scheduled_at""")

        if not pending:
            return

        self._log(f"Processing {len(pending)} pending rerun(s)")

        for entry in pending:
            try:
                self._run_rerun(db, cfg, entry)
            except Exception as exc:
                self._log(f"Rerun entry id={entry['id']} error: {exc}")
                try:
                    db.execute(
                        "UPDATE rerun_queue SET last_error=%s WHERE id=%s",
                        (str(exc)[:1000], entry["id"]))
                except Exception:
                    pass

    def _run_rerun(self, db, cfg, entry):
        # Mark as in-progress
        db.execute(
            """UPDATE rerun_queue
               SET status = 'IN_PROGRESS',
                   started_at = NOW()
               WHERE id = %s""",
            (entry["id"],))

        # Create new execution run for this attempt
        run_id = db.insert_get_id(
            """INSERT INTO execution_runs
               (customer_id, env_types, run_type, status,
                triggered_by, rerun_of_run_id, rerun_attempt)
               VALUES (%s,%s,'RERUN','PENDING','scheduler_rerun',%s,%s)""",
            (entry["customer_id"], entry["env_types"],
             entry["original_run_id"], entry["attempt_number"]))

        self._log(
            f"{entry['cname']}/{entry['env_types']} | "
            f"Rerun attempt {entry['attempt_number']}/{entry['max_attempts']} "
            f"→ Run #{run_id}")

        self._db_log(db, run_id, "INFO",
            f"Rerun attempt {entry['attempt_number']}/{entry['max_attempts']} | "
            f"original_run_id={entry['original_run_id']} | "
            f"customer='{entry['cname']}' env='{entry['env_types']}'")

        # Execute the run
        t0 = time.time()
        try:
            RunLauncher(db, run_id, cfg).launch()
        except Exception as exc:
            self._log(f"Rerun RunLauncher error #{run_id}: {exc}")
            db.execute(
                """UPDATE execution_runs
                   SET status='FAILED', error_summary=%s
                   WHERE id=%s""",
                (str(exc)[:2000], run_id))
        elapsed = int(time.time() - t0)

        # Check result
        final  = db.fetch_one(
            "SELECT status FROM execution_runs WHERE id=%s", (run_id,))
        status = final["status"] if final else "UNKNOWN"
        run_ok = status in ("COMPLETED", "PARTIAL")

        self._log(
            f"{entry['cname']}/{entry['env_types']} | "
            f"Rerun #{run_id} attempt {entry['attempt_number']} "
            f"→ {status} in {elapsed}s")

        self._db_log(
            db, run_id,
            "INFO" if run_ok else "WARNING",
            f"Rerun {status} in {elapsed}s | "
            f"attempt={entry['attempt_number']}/{entry['max_attempts']}")

        # Mark rerun_queue row complete
        db.execute(
            """UPDATE rerun_queue
               SET status     = %s,
                   completed_at = NOW()
               WHERE id = %s""",
            ("COMPLETED" if run_ok else "FAILED", entry["id"]))

        if run_ok:
            # Run passed → no more retries needed
            self._log(
                f"{entry['cname']}/{entry['env_types']} | "
                f"Rerun PASSED — no more retries needed")
            return

        # Run failed → queue next attempt or mark EXHAUSTED
        next_attempt = entry["attempt_number"] + 1

        if next_attempt <= entry["max_attempts"]:
            # Queue next attempt
            nxt_sched = datetime.now() + timedelta(
                hours=cfg.rerun_interval_hours)

            db.execute(
                """INSERT INTO rerun_queue
                   (original_run_id, customer_id, env_types,
                    attempt_number, max_attempts,
                    status, scheduled_at, last_error)
                   VALUES (%s,%s,%s,%s,%s,'PENDING',%s,%s)""",
                (entry["original_run_id"],
                 entry["customer_id"],
                 entry["env_types"],
                 next_attempt,
                 entry["max_attempts"],
                 nxt_sched,
                 f"Attempt {entry['attempt_number']} failed with status={status}"))

            self._log(
                f"{entry['cname']}/{entry['env_types']} | "
                f"Queued attempt {next_attempt}/{entry['max_attempts']} "
                f"at {nxt_sched.strftime('%Y-%m-%d %H:%M')}")

        else:
            # All attempts exhausted
            db.execute(
                """UPDATE rerun_queue
                   SET status = 'EXHAUSTED'
                   WHERE id   = %s""",
                (entry["id"],))

            self._log(
                f"{entry['cname']}/{entry['env_types']} | "
                f"ALL {entry['max_attempts']} attempts EXHAUSTED "
                f"for original run #{entry['original_run_id']}")

            self._db_log(db, run_id, "ERROR",
                f"All {entry['max_attempts']} rerun attempts exhausted | "
                f"original_run_id={entry['original_run_id']}")

            # Send exhausted email
            try:
                from notifications.email_service import EmailService
                cust = db.fetch_one(
                    "SELECT name FROM customers WHERE id=%s",
                    (entry["customer_id"],))
                EmailService(db, SilentLogger()).send_rerun_exhausted(
                    run_id        = entry["original_run_id"],
                    customer_id   = entry["customer_id"],
                    customer_name = cust["name"] if cust else str(entry["customer_id"]),
                    env_types     = entry["env_types"],
                    max_attempts  = entry["max_attempts"])
            except Exception as e:
                self._log(f"Failed to send exhausted email: {e}")

    # ────────────────────────────────────────────────────────
    # Log purge
    # ────────────────────────────────────────────────────────

    def _purge_logs(self, db, cfg):
        try:
            n = db.execute(
                """DELETE FROM execution_logs
                   WHERE logged_at < DATE_SUB(NOW(), INTERVAL %s DAY)""",
                (cfg.log_retention_days,))
            if n:
                self._log(
                    f"Purged {n} old log rows "
                    f"(older than {cfg.log_retention_days} days)")
        except Exception as exc:
            self._log(f"Log purge failed: {exc}")
