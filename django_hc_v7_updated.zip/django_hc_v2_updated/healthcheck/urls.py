from django.urls import path
from healthcheck import views

app_name = "healthcheck"

urlpatterns = [
    # Auth
    path("login/",   views.login_view,  name="login"),
    path("logout/",  views.logout_view, name="logout"),

    # Dashboard
    path("", views.dashboard, name="dashboard"),

    # Reports
    path("reports/",                         views.reports_list,   name="reports_list"),
    path("reports/<int:run_id>/",            views.report_detail,  name="report_detail"),
    path("reports/<int:run_id>/logs/",       views.run_logs,       name="run_logs"),
    path("reports/<int:run_id>/logs/dl/",    views.download_logs,  name="download_logs"),
    path("reports/<int:run_id>/excel/",      views.download_excel, name="download_excel"),

    # Escalation
    path("escalation/",                   views.escalation_view,   name="escalation"),
    path("escalation/<int:pk>/pause/",    views.pause_escalation,  name="pause_escalation"),
    path("escalation/<int:pk>/resume/",   views.resume_escalation, name="resume_escalation"),

    # Rerun
    path("rerun/",                        views.rerun_view,    name="rerun"),
    path("rerun/<int:run_id>/trigger/",   views.trigger_rerun, name="trigger_rerun"),

    # Alert history
    path("alerts/", views.alert_history, name="alert_history"),

    # Admin: Manual run
    path("manual-run/", views.manual_run, name="manual_run"),

    # Admin: Scheduler
    path("scheduler/",              views.scheduler_view,    name="scheduler"),
    path("scheduler/action/",       views.scheduler_action,  name="scheduler_action"),
    path("scheduler/tracker/",      views.scheduler_tracker, name="scheduler_tracker"),

    # API
    path("api/run/<int:run_id>/status/", views.api_run_status,       name="api_run_status"),
    path("api/scheduler/status/",        views.api_scheduler_status,  name="api_scheduler_status"),
    path("api/recent-runs/",             views.api_recent_runs,        name="api_recent_runs"),
]
